package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

/**
 * PFダウンロード中止Responseクラス.
 * 
 */
public class PFDownloadStopResponse extends BaseDownloadStopResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = PFDownloadStopResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC3;

    /** Constructor */
    public PFDownloadStopResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}

