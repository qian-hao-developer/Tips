
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetPenMode extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x2d;

    private static final int LENGTH = 5;

    private static final String COLOR = "color";

    private String mColor;

    private static final String THICKNESS = "thickness";

    private int mThickness;

    public ResponseGetPenMode(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mColor = String.format("%02x%02x%02x", result[3], result[2], result[1]);
        mThickness = (int) (result[4] & 0xff);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(COLOR, mColor);
            json.put(THICKNESS, mThickness);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
}
