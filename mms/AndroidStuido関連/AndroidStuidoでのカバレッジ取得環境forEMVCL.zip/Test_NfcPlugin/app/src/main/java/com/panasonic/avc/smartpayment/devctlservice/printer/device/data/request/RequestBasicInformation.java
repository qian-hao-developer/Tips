
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * 基本情報取得要求
 */
public class RequestBasicInformation extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x000C;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x0000;

    /**
     * @brief コンストラクタ
     * @param cutType カットの種類
     */
    public RequestBasicInformation() {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        return toCommand(null);
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        return true;
    }

}
