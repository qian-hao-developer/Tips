package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * PFダウンロード開始Requestクラス.
 * 
 */
public class PFDownloadStartRequest extends BaseDownloadStartRequest {

    /** @brief ログ用タグ */
    private static final String TAG = PFDownloadStartRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC0;

    /** Constructor */
    public PFDownloadStartRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    @Override
    public byte[] toCommand() {

        return toCommand(mDataSize);
    }
}
