
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetPenMode extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetPenMode(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetPenMode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetPenMode> CREATOR = new Parcelable.Creator<ResultGetPenMode>() {

        @Override
        public ResultGetPenMode createFromParcel(Parcel in) {
            return new ResultGetPenMode(in);
        }

        @Override
        public ResultGetPenMode[] newArray(int size) {
            return new ResultGetPenMode[size];
        }
    };
}
