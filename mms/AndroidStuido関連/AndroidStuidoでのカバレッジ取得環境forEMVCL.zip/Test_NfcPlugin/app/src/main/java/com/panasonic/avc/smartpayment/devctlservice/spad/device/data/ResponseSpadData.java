
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data;

import java.nio.ByteBuffer;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetArea;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetBackgroundColor;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetBootScreenMode;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetBrightness;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetCapability;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetContrast;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetInformation;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetInking;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetInkingThreshold;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetPenMode;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetStatus;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetUID;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response.ResponseGetUID2;

public class ResponseSpadData {

    private static final String ID = "id";

    private String mId;

    private byte[] mResult;

    public ResponseSpadData(byte id) {
        mId = String.format("%02x", id);
    }

    public String getId() {
        return mId;
    }

    public byte[] getResult() {
        return mResult;
    }

    public boolean parse(byte[] result) {
        return false;
    }

    public JSONObject toJSONObject() {
        JSONObject json = new JSONObject();
        try {
            if (mId != null) {
                json.put(ID, mId);
            } else {
                json.put(ID, JSONObject.NULL);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

    protected boolean isCorrect(byte[] result) {
        byte id = ResponseSpadData.parseId(result);
        if (id == 0x00 || mId == null) {
            return false;
        }

        String inputId = String.format("%02x", id);
        if (inputId.equals(mId)) {
            return true;
        }
        return false;
    }

    public static ResponseSpadData createResponseData(byte[] result) {
        if (result == null || result.length < 1) {
            return null;
        }

        byte id = parseId(result);

        ResponseSpadData data = null;

        switch (id) {
            case ResponseGetArea.COMMAND_ID:
                data = new ResponseGetArea(id);
                break;
            case ResponseGetBackgroundColor.COMMAND_ID:
                data = new ResponseGetBackgroundColor(id);
                break;
            case ResponseGetBootScreenMode.COMMAND_ID:
                data = new ResponseGetBootScreenMode(id);
                break;
            case ResponseGetBrightness.COMMAND_ID:
                data = new ResponseGetBrightness(id);
                break;
            case ResponseGetCapability.COMMAND_ID:
                data = new ResponseGetCapability(id);
                break;
            case ResponseGetContrast.COMMAND_ID:
                data = new ResponseGetContrast(id);
                break;
            case ResponseGetInformation.COMMAND_ID:
                data = new ResponseGetInformation(id);
                break;
            case ResponseGetInking.COMMAND_ID:
                data = new ResponseGetInking(id);
                break;
            case ResponseGetInkingThreshold.COMMAND_ID:
                data = new ResponseGetInkingThreshold(id);
                break;
            case ResponseGetPenMode.COMMAND_ID:
                data = new ResponseGetPenMode(id);
                break;
            case ResponseGetStatus.COMMAND_ID:
                data = new ResponseGetStatus(id);
                break;
            case ResponseGetUID.COMMAND_ID:
                data = new ResponseGetUID(id);
                break;
            case ResponseGetUID2.COMMAND_ID:
                data = new ResponseGetUID2(id);
                break;
        }

        if (data == null || !(data.parse(result))) {
            return null;
        }

        return data;
    }

    private static byte parseId(byte[] result) {
        if (result == null || result.length < 1) {
            return 0;
        }

        // 先頭1バイトはコマンドタイプなのでカットする
        ByteBuffer res = ByteBuffer.wrap(result);
        res.position(0);
        return res.get();
    }
}
