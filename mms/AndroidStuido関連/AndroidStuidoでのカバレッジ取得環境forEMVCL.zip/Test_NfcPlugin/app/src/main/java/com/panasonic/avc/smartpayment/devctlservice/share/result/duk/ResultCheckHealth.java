
package com.panasonic.avc.smartpayment.devctlservice.share.result.duk;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * CheckHealth処理結果データ
 */
public class ResultCheckHealth extends AnalyzeResultData {

    /** @brief DUKの状態情報 */
    private boolean mSts;

    /** @brief DUKの状態情報タグ */
    private static final String DEVSTS = "devsts";

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x21;

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth(Parcel in) {
        super(in);
    }

    /**
     * コンストラクタ
     */
    public ResultCheckHealth() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCheckHealth> CREATOR = new Parcelable.Creator<ResultCheckHealth>() {
        public ResultCheckHealth createFromParcel(Parcel in) {
            return new ResultCheckHealth(in);
        }

        public ResultCheckHealth[] newArray(int size) {
            return new ResultCheckHealth[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mSts ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mSts = (in.readInt() == 1);
    }

    /**
     * @brief 状態情報を取得する
     * @return sts 状態情報
     */
    public boolean isDevSts() {
        return mSts;
    }

    /**
     * @brief 状態情報を設定する
     * @param sts 状態情報
     */
    public void setDevSts(boolean sts) {
        mSts = sts;
    }

    /**
     * @see AnalyzeResultData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int result = buffer[PinpadDefine.INDEX_PARAMETER];

        if (result != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.DUK, result, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        // 応答が返ってきたためタンパが発生してないためtrueを設定する
        mSts = true;

        return true;
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(DEVSTS, JSONObject.NULL);
            } else {
                json.put(DEVSTS, isDevSts());
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
