
package com.panasonic.avc.smartpayment.devctlservice.pos.device;

/**
 * Nativeコール用クラス
 */
public class PosConnectionNative {

    /** @brief インスタンス */
    private static PosConnectionNative sInstance = new PosConnectionNative();

    static {
        System.loadLibrary("posx");
    }

    /**
     * @brief シングルトンインスタンスを取得する
     * @return インスタンス
     */
    public static PosConnectionNative getInstance() {
        return sInstance;
    }

    /**
     * @brief コンストラクタ
     */
    protected PosConnectionNative() {

    }

    /**
     * @brief POSのポートをオープンします
     * @param interfaceType 通信インタフェース
     * @param mode ブロックモード
     * @return POSのファイルディスクリプタ (-1:オープン失敗)
     */
    public native int nativePosPortOpen(int interfaceType, int mode);

    /**
     * @brief POSのポートをクローズします
     * @param fd POSのファイルディスクリプタ
     * @return 結果 (-1:クローズ失敗、0:クローズ成功)
     */
    public native int nativePosPortClose(int fd);

    /**
     * @brief シリアル通信設定を変更します
     * @param fd POSのファイルディスクリプタ
     * @param speed 通信速度 - 50, 75, 110, 134, 150, 200, 300, 600, 1200, 1800,
     *            2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400 bps
     *            のいずれか（上記以外はパラメータエラー）
     * @param dataBit データ長 - 5 ～ 8 bit のいずれか（上記以外はパラメータエラー）
     * @param stopBit ストップビット長
     * @param parity パリティ種別 - 0:パリティチェックなし 1:奇数パリティ 2:偶数パリティ 3:マークパリティ
     *            4:スペースパリティ（上記以外はパラメータエラー）
     * @return 結果 (-1:変更失敗、0:変更成功)
     */
    public native int nativePosPortConfig(int fd, int speed, int dataBit, int stopBit, int parity);

    /**
     * @brief POSにデータを送信します
     * @param fd POSのファイルディスクリプタ
     * @param blocksz ブロックサイズ (0:ブロック分割しない)
     * @param buffer 送信データ
     * @param length 送信データサイズ
     * @return 送信に成功したデータサイズ (-1:送信失敗)
     */
    public native int nativePosSend(int fd, int blocksz, byte[] buffer, int length);

    /**
     * @brief POSからデータを受信します
     * @param fd POSのファイルディスクリプタ
     * @return 受信に成功したデータ (NULL:受信失敗、size==0:受信データ無し)
     */
    public native byte[] nativePosReceive(int fd);
}
