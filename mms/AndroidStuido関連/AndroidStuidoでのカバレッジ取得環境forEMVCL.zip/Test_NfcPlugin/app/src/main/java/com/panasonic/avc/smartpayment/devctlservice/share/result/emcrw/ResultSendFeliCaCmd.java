
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultSendFeliCaCmd extends ResultFeliCaApl {

    /** @brief カードレスポンスパケット長 **/
    private int mCardResponsePacketLength;

    /** @brief カードレスポンスパケット **/
    private String mCardResponsePacket;

    /**
     * @brief コンストラクタ
     */
    public ResultSendFeliCaCmd(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendFeliCaCmd() {

    }

    /**
     * @brief カードレスポンスパケット長を返します
     **/
    public int getCardResponsePacketLength() {
        return mCardResponsePacketLength;
    }

    /**
     * @brief カードレスポンスパケット長を設定します
     **/
    public void setCardResponsePacketLength(int mCardResponsePacketLength) {
        this.mCardResponsePacketLength = mCardResponsePacketLength;
    }

    /**
     * @brief カードレスポンスパケットを返します
     **/
    public String getCardResponsePacket() {
        return mCardResponsePacket;
    }

    /**
     * @brief カードレスポンスパケットを設定します
     **/
    public void setCardResponsePacket(String mCardResponsePacket) {
        this.mCardResponsePacket = mCardResponsePacket;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendFeliCaCmd> CREATOR = new Parcelable.Creator<ResultSendFeliCaCmd>() {

        @Override
        public ResultSendFeliCaCmd createFromParcel(Parcel in) {
            return new ResultSendFeliCaCmd(in);
        }

        @Override
        public ResultSendFeliCaCmd[] newArray(int size) {
            return new ResultSendFeliCaCmd[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mCardResponsePacketLength);
        dest.writeString(mCardResponsePacket);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mCardResponsePacketLength = in.readInt();
        mCardResponsePacket = in.readString();
    }
}
