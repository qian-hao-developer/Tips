
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ActivationIcc処理結果データ
 */
public class ResultActivationIcc extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultActivationIcc(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultActivationIcc() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultActivationIcc> CREATOR = new Parcelable.Creator<ResultActivationIcc>() {
        public ResultActivationIcc createFromParcel(Parcel in) {
            return new ResultActivationIcc(in);
        }

        public ResultActivationIcc[] newArray(int size) {
            return new ResultActivationIcc[size];
        }
    };

}
