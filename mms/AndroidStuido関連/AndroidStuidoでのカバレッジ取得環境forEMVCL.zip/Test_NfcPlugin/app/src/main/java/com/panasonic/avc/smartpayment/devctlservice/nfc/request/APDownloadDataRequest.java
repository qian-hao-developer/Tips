package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * APダウンロードデータRequestクラス.
 * 
 */
public class APDownloadDataRequest extends BaseDownloadDataRequest {

    /** @brief ログ用タグ */
    private static final String TAG = APDownloadDataRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x81;

    /** Constructor */
    public APDownloadDataRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
