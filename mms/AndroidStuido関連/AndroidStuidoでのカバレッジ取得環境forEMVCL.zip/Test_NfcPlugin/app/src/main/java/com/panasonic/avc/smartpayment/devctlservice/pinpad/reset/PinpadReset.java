
package com.panasonic.avc.smartpayment.devctlservice.pinpad.reset;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.os.Handler;
import android.os.Message;

import com.panasonic.avc.smartpayment.devctlservice.R;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.NotifyUsbDeviceConnectionListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestRebootPinpad;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseRebootPinpad;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.icrw.ContactIcCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt.Management;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.ped.PinEnterDevice;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadResetCountDownTimer.PinpadResetCountDownTimerListener;
import com.panasonic.avc.smartpayment.devctlservice.share.UpdateDeviceType;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.system.util.CreateAlartViewNoButton;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * PinpadReset処理部
 */
public class PinpadReset implements PinpadResetCountDownTimerListener {

    /** @brief PINPAD リセット時刻通知のブロードキャストインテント名 */
    public static final String RESET_PINPAD_EXECUTE = "android.intent.action.RESET_PINPAD_EXECUTE";

    /** @brief デバッグ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = PinpadReset.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static PinpadReset sInstance = new PinpadReset();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 5000;

    /** @brief 接触ICカードリーダライタ処理部 */
    private ContactIcCard mContactIcCard = ContactIcCard.getInstance();

    /** @brief PinEnterDevice処理部 */
    private PinEnterDevice mPinEnterDevice = PinEnterDevice.getInstance();

    /** @brief ICRW が Term 済み */
    private boolean mTerminatedICRW = false;

    /** @brief PED が Term 済み */
    private boolean mTerminatedPED = false;

    /** @brief リブート中 */
    private boolean mRebooting;

    /** @brief PINPAD デバイス認識待ちタイマー */
    private PinpadResetCountDownTimer mPinpadResetCountDownTimer;

    /** @brief ポップアップビュー */
    private CreateAlartViewNoButton mPinpadResetView;

    private Context mContext;

    /** @brief IME非表示用アクション */
    private final static String ACTION_LAUNCHER_HIDE_IME = "android.intent.action.HIDE_IME";

    /** @brief PINPAD リブート状態通知リスナー */
    private NotifyRebootingListener mNotifyRebootingListener;

    /** @brief 端末管理コントロールクラス */
    private Management mManagement = Management.getInstance();

    /** @brief プラグイン種別 */
    public enum PluginType {
        ICRW,
        PED,
    }

    /** @brief プラグイン状態種別 */
    public enum StatusType {
        INIT,
        TERM,
    }

    /** @brief プラグイン状態通知リスナー */
    public interface NotifyStatusListener {

        /**
         * @brief プラグイン状態通知
         * @param device 許諾デバイス
         */
        public void notifyStatus(PluginType plugin, StatusType status);
    }

    /** @brief PINPAD リブート状態通知リスナー */
    public interface NotifyRebootingListener {

        /**
         * @brief リブート開始通知
         */
        public void onStartRebooting();

        /**
         * @brief リブート終了通知
         */
        public void onFinishRebooting();
    }

    /**
     * @brief コンストラクタ
     */
    private PinpadReset() {
    }

    /**
     * @brief シングルトンインスタンスを取得する
     * @return インスタンス
     */
    public static PinpadReset getInstance() {
        return sInstance;
    }

    /**
     * @brief PINPADをリセットします
     */
    public void resetPinpad() {

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            return;
        }

        mControlDeviceManager
                .registerNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListenerInWaitTerm);

        if (!mContactIcCard.registerNotifyStatusListener(mNotifyStatusListener)
                || !mPinEnterDevice.registerNotifyStatusListener(mNotifyStatusListener)) {
            // 既に Term 待ち中
            return;
        }

        mTerminatedICRW = false;
        mTerminatedPED = false;

        mContactIcCard.requestNotifyStatus();
        mPinEnterDevice.requestNotifyStatus();

    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @@brief リブート開始処理
     */
    private void startReboot() {

        if (!mControlDeviceManager.isActive()) {
            notifyRebooting(false);
            return;
        }

        if (mManagement.isDefferentVersion(UpdateDeviceType.PINPAD)) {
            notifyRebooting(false);
            return;
        }

        showPinpadResetDialog();

        mControlDeviceManager
                .registerNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListenerInReboot);

        if (rebootPinpad()) {
            // リブート要求成功
            mPinpadResetCountDownTimer = new PinpadResetCountDownTimer();
            mPinpadResetCountDownTimer.setListener(this);
            mPinpadResetCountDownTimer.start();
        } else {
            // リブート要求失敗
            finishReboot();
        }

    }

    /**
     * @@brief リブート終了処理
     */
    private void finishReboot() {
        mControlDeviceManager
                .unregisterNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListenerInReboot);
        dismissPinpadResetDialog();
        notifyRebooting(false);
    }

    /**
     * @@brief PINPAD リブート状態を通知する
     * @param rebooting リブート中
     */
    private void notifyRebooting(boolean rebooting) {
        mRebooting = rebooting;
        if (mNotifyRebootingListener == null) {
            return;
        }
        if (mRebooting) {
            mNotifyRebootingListener.onStartRebooting();
        } else {
            mNotifyRebootingListener.onFinishRebooting();
        }
    }

    /**
     * @brief PINPADリブートを要求します
     * @return 実行結果
     */
    private boolean rebootPinpad() {
        final RequestRebootPinpad request = new RequestRebootPinpad();
        ResponseRebootPinpad response = new ResponseRebootPinpad();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            return false;
        }

        if (!request.isValidValue()) {
            return false;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            return false;
        } else if (!response.inputPinpadResult(buffer)) {
            return false;
        }

        return true;
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * @brief PINPAD 再認識待ちでタイムアウトでリブート終了処理
     */
    @Override
    public void notifyTimeUp() {
        finishReboot();
    }

    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * @brief ポップアップを表示する
     */
    private void showPinpadResetDialog() {

        Intent intent = new Intent(ACTION_LAUNCHER_HIDE_IME);
        mContext.sendBroadcast(intent);

        mPinpadResetView = new CreateAlartViewNoButton();
        if (mContext != null) {
            mPinpadResetView.showView(mContext, R.string.pinpad_rebooting_title,
                    R.string.pinpad_rebooting_message);
        }
    }

    /**
     * @brief ポップアップを消去する
     */
    private void dismissPinpadResetDialog() {
        if (mPinpadResetView != null) {
            mPinpadResetView.dismissView();
            mPinpadResetView = null;
        }
    }

    /**
     * @brief PINPAD リブート状態通知リスナーを設定する
     * @param listener
     */
    public void setNotifyOnRebootingListener(NotifyRebootingListener listener) {
        mNotifyRebootingListener = listener;
    }

    /** @brief プラグイン状態通知リスナー */
    private NotifyStatusListener mNotifyStatusListener = new NotifyStatusListener() {

        /**
         * @brief ICRW, PED の Term を待つ
         */
        @Override
        public void notifyStatus(PluginType plugin, StatusType status) {
            switch (plugin) {
                case ICRW:
                    mTerminatedICRW = (status == StatusType.TERM);
                    break;

                case PED:
                    mTerminatedPED = (status == StatusType.TERM);
                    break;
            }
            if (mTerminatedICRW && mTerminatedPED) {
                mControlDeviceManager
                        .unregisterNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListenerInWaitTerm);
                mContactIcCard.unregisterNotifyStatusListener(mNotifyStatusListener);
                mPinEnterDevice.unregisterNotifyStatusListener(mNotifyStatusListener);
                synchronized (this) {
                    if (mRebooting) {
                        return;
                    }
                    notifyRebooting(true);
                    mRebootHandler.sendMessage(mRebootHandler.obtainMessage());
                }

            }
        }

    };

    /** @brief デバイス認識待ちリスナー（ICRW, PED の Term 待ち中） */
    private NotifyUsbDeviceConnectionListener mNotifyUsbDeviceConnectionListenerInWaitTerm = new NotifyUsbDeviceConnectionListener() {

        /**
         * @brief Term 待ち中の PINPAD 認識でリブート処理をスキップ
         */
        @Override
        public void onOpened(UsbDevice device) {
            mControlDeviceManager
                    .unregisterNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListenerInWaitTerm);
            mContactIcCard.unregisterNotifyStatusListener(mNotifyStatusListener);
            mPinEnterDevice.unregisterNotifyStatusListener(mNotifyStatusListener);
        }

        @Override
        public void onClosed(UsbDevice device) {
            // NOP
        }

    };

    /** @brief デバイス認識待ちリスナー（リブート中） */
    private NotifyUsbDeviceConnectionListener mNotifyUsbDeviceConnectionListenerInReboot = new NotifyUsbDeviceConnectionListener() {

        /**
         * @brief Term リブート中の PINPAD 認識でリブート終了処理
         */
        @Override
        public void onOpened(UsbDevice device) {
            if (mPinpadResetCountDownTimer != null) {
                mPinpadResetCountDownTimer.cancel();
            }

            ResultCheckHealth result = mPinEnterDevice.checkHealth();
            if (result.getDevice() == 0 && result.getUpos() == 0) {
                if (result.isSts() && result.isTamper()) {
                    SystemNotification.notifyDismissIcon(mContext, IconType.OTHER_DEVICE);
                }
            }
            finishReboot();
        }

        @Override
        public void onClosed(UsbDevice device) {
            // NOP
        }

    };

    /** @brief リブートハンドラー */
    @SuppressLint("HandlerLeak")
    private Handler mRebootHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            startReboot();
        }
    };

}
