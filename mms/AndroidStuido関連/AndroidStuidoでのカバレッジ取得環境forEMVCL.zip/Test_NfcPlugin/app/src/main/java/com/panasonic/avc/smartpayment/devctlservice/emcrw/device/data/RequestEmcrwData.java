
package com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

import com.panasonic.avc.smartpayment.devctlservice.cfg.Configuration;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * 非接触ICカードリーダ要求データ
 */
public class RequestEmcrwData {

    /** @brief ログ出力用タグ */
    private static final String TAG = Configuration.class.getSimpleName();

    /** @brief プロトコルリンク */
    private int mLinkLevel = EmcrwDefine.LINK_LEVEL_CCT;

    protected byte mSTX = (byte) 0x02;
    private byte mIDmp = (byte) 0x32;
    private byte[] mCMD = new byte[] {
            (byte) 0x30, (byte) 0x30
    };
    protected byte mETX = (byte) 0x03;

    /** @brief ID */
    private byte mID = (byte) 0x02;

    /** @brief MC */
    private byte mMC;

    /** @brief SC */
    private byte mSC;

    /** @brief 暗号化の有無 */
    private boolean mIsEncrypt;

    /** @brief パケットヘッダ */
    private byte[] mHead = null;

    /** @brief パケットデータ */
    private byte[] mData = null;

    /** @brief デフォルトタイムアウト時間 */
    private static final int READ_TIMEOUT = 6000;

    /** @brief タイムアウト時間 */
    protected int mReadTimeout;

    /** @brief デフォルトタイムアウトカウント */
    private static final int READ_COUNT = 1;

    /** @brief タイムアウトのカウント時間 */
    protected int mReadCount;

    /** @brief レスポンスパケットの長さ */
    protected int mReturnLength;

    /**
     * @brief コンストラクタ
     */
    public RequestEmcrwData() {
        mIsEncrypt = true;
        mReadTimeout = READ_TIMEOUT;
        mReadCount = READ_COUNT;
    }

    /**
     * @brief コンストラクタ
     */
    public RequestEmcrwData(int level) {
        mLinkLevel = level;
        mIsEncrypt = true;
        mReadTimeout = READ_TIMEOUT;
        mReadCount = READ_COUNT;
    }

    public void setCommand(byte mc, byte sc) {
        mMC = mc;
        mSC = sc;
    }

    public void setData(byte[] data) {
        ByteBuffer buf = ByteBuffer.allocate(data.length);
        buf.clear();
        buf.put(data);
        buf.rewind();
        mData = new byte[data.length];
        buf.get(mData);
    }

    public byte[] toPacket() {
        byte[] packet = null;
        byte[] payload = null;

        if (mLinkLevel == EmcrwDefine.LINK_LEVEL_CCT) {
            int head_length = 5;
            ByteBuffer head = ByteBuffer.allocate(head_length);
            head.clear();
            head.put(mID);
            head.put(mMC);
            if (mIsEncrypt) {
                head.put(mSC);
            } else {
                // 非暗号化のときはbit7を立てる
                byte b = (byte) (mSC | (byte) 0x80);
                head.put(b);
            }
            if (mData != null) {
                head.put(CalcUtil.toByteLength(mData.length, true));
            } else {
                head.put((byte) 0x00);
                head.put((byte) 0x00);
            }
            mHead = new byte[head_length];
            head.rewind();
            head.get(mHead);

        } else if (mLinkLevel == EmcrwDefine.LINK_LEVEL_PINPAD) {

            // add Data
            int data_len = 0;
            if (mData != null) {
                data_len = 5 + mData.length;
            } else {
                data_len = 5;
            }
            ByteBuffer buf = ByteBuffer.allocate(data_len);
            buf.clear();
            buf.put(mID);
            buf.put(mMC);
            buf.put(mSC);
            if (mData != null) {
                buf.put(CalcUtil.toByteLength(mData.length, false));
                // buf.put(CalcUtil.toByteLength(mData.length, true));
                buf.put(mData);
            } else {
                buf.put((byte) 0x00);
                buf.put((byte) 0x00);
            }
            buf.rewind();
            mData = new byte[data_len];
            buf.get(mData);

            // create Head
            int head_length = 6;
            ByteBuffer head = ByteBuffer.allocate(head_length);
            head.clear();
            head.put(mIDmp);
            head.put(mCMD);
            if (mData != null) {
                head.put(int2bcd(mData.length));
            } else {
                head.put((byte) 0x00);
                head.put((byte) 0x00);
            }
            mHead = new byte[head_length];
            head.rewind();
            head.get(mHead);

        }

        // paylod作成
        int payload_length = 0;
        if (mData != null) {
            payload_length = mHead.length + mData.length + 1;
        } else {
            payload_length = mHead.length + 1;
        }
        ByteBuffer payload_buf = ByteBuffer.allocate(payload_length);
        payload_buf.clear();
        payload_buf.put(mHead);
        if (mData != null) {
            payload_buf.put(mData);
        }
        payload_buf.put(mETX);
        payload = new byte[payload_length];
        payload_buf.rewind();
        payload_buf.get(payload);

        // パケット作成
        int length = 1 + payload.length + 2;
        ByteBuffer buf = ByteBuffer.allocate(length);
        buf.clear();
        buf.put(mSTX);
        buf.put(payload);
        buf.put(generateCRC(payload));

        packet = new byte[length];
        buf.rewind();
        buf.get(packet);

        return packet;
    }

    /**
     * @brief パラメータ部を合成しコマンドに変換する
     * @param parameter パラメータ部
     * @return コマンド
     */
    protected byte[] toCommand(byte[] parameter) {

        byte[] data = new byte[parameter.length];
        for (int i = 0; i < data.length; i++) {
            data[i] = parameter[i];
        }
        return packetGeneratorPF(data);
    }

    /**
     * @brief コマンドを作成する
     * @return コマンド
     */
    public byte[] toCommand() {
        return toCommand(null);
    }

    public static final byte[] INT2BCD = new byte[] {
            (byte) 0x0, (byte) 0x1, (byte) 0x2, (byte) 0x3, (byte) 0x4,
            (byte) 0x5, (byte) 0x6, (byte) 0x7, (byte) 0x8, (byte) 0x9,
            (byte) 0x10, (byte) 0x11, (byte) 0x12, (byte) 0x13, (byte) 0x14,
            (byte) 0x15, (byte) 0x16, (byte) 0x17, (byte) 0x18, (byte) 0x19,
            (byte) 0x20, (byte) 0x21, (byte) 0x22, (byte) 0x23, (byte) 0x24,
            (byte) 0x25, (byte) 0x26, (byte) 0x27, (byte) 0x28, (byte) 0x29,
            (byte) 0x30, (byte) 0x31, (byte) 0x32, (byte) 0x33, (byte) 0x34,
            (byte) 0x35, (byte) 0x36, (byte) 0x37, (byte) 0x38, (byte) 0x39,
            (byte) 0x40, (byte) 0x41, (byte) 0x42, (byte) 0x43, (byte) 0x44,
            (byte) 0x45, (byte) 0x46, (byte) 0x47, (byte) 0x48, (byte) 0x49,
            (byte) 0x50, (byte) 0x51, (byte) 0x52, (byte) 0x53, (byte) 0x54,
            (byte) 0x55, (byte) 0x56, (byte) 0x57, (byte) 0x58, (byte) 0x59,
            (byte) 0x60, (byte) 0x61, (byte) 0x62, (byte) 0x63, (byte) 0x64,
            (byte) 0x65, (byte) 0x66, (byte) 0x67, (byte) 0x68, (byte) 0x69,
            (byte) 0x70, (byte) 0x71, (byte) 0x72, (byte) 0x73, (byte) 0x74,
            (byte) 0x75, (byte) 0x76, (byte) 0x77, (byte) 0x78, (byte) 0x79,
            (byte) 0x80, (byte) 0x81, (byte) 0x82, (byte) 0x83, (byte) 0x84,
            (byte) 0x85, (byte) 0x86, (byte) 0x87, (byte) 0x88, (byte) 0x89,
            (byte) 0x90, (byte) 0x91, (byte) 0x92, (byte) 0x93, (byte) 0x94,
            (byte) 0x95, (byte) 0x96, (byte) 0x97, (byte) 0x98, (byte) 0x99
    };

    public byte[] long2bcd(long longNum) {
        long p = longNum;
        ByteArrayOutputStream bout = new ByteArrayOutputStream(6);

        while (p > 0) {
            bout.write(INT2BCD[(int) (p % 100)]);
            p = p / 100;
        }

        return reverse(bout.toByteArray());
    }

    public byte[] int2bcd(int intNum) {
        int p = intNum;
        int loop = 0;
        ByteArrayOutputStream bout = new ByteArrayOutputStream(3);

        while (p > 0) {
            bout.write(INT2BCD[p % 100]);
            p = p / 100;
            loop++;
        }

        // 0x00が足りないので桁数に合わせて変える
        for (int i = 0; i < 3 - loop; i++) {
            bout.write((byte) 0x00);
        }

        return reverse(bout.toByteArray());
    }

    public byte[] reverse(byte[] src) {

        int left = 0;
        int right = src.length - 1;
        byte tmp;

        while (left < right) {
            tmp = src[right];
            src[right] = src[left];
            src[left] = tmp;

            left += 1;
            right -= 1;
        }

        return src;
    }

    private static int createCRC3(byte[] bytes) {
        long shiftCRC;
        int crc = 0x0000;
        byte tmp;
        for (int i = 0; i < bytes.length; i++) {
            shiftCRC = crc;
            tmp = bytes[i];
            for (int j = 0; j < 8; j++) {
                if (((tmp ^ shiftCRC) & 1) > 0) {
                    shiftCRC ^= (0x8408 << 1);
                }
                shiftCRC >>= 1;
                tmp >>= 1;
            }
            crc = (int) shiftCRC;
            // Log.d(TAG, "cal: " + crc);
        }

        return crc;
    }

    // パケット終端のCRC生成
    public byte[] generateCRC(byte[] target) {
        int crc = createCRC3(target);

        // 0から始まった場合に３桁しかなくて困るのでformatする
        String crcStr = String.format("%04x", crc);

        // リトルエンディアンでRWに渡すので最初からひっくり返しておいてそのままByteBufferに入れる（手抜き）
        String firstByteStr = (crcStr.substring(2, 4));
        String secondByteStr = (crcStr.substring(0, 2));

        byte[] crcbytes = new byte[] {
                (byte) (Integer.parseInt(firstByteStr, 16)),
                (byte) (Integer.parseInt(secondByteStr, 16))
        };

        // Log.d(TAG, "CRC");
        // Log.d(TAG, crcStr);
        // Log.d(TAG, dumpBytes(crcbytes));

        return crcbytes;
    }

    // パケット終端のCRC生成
    public byte[] generateCRC2(byte[] target) {
        int crc = createCRC3(target);

        // 0から始まった場合に３桁しかなくて困るのでformatする
        String crcStr = String.format("%04x", crc);

        // リトルエンディアンでRWに渡すので最初からひっくり返しておいてそのままByteBufferに入れる（手抜き）
        String firstByteStr = (crcStr.substring(0, 2));
        String secondByteStr = (crcStr.substring(2, 4));

        byte[] crcbytes = new byte[] {
                (byte) (Integer.parseInt(firstByteStr, 16)),
                (byte) (Integer.parseInt(secondByteStr, 16))
        };

        // Log.d(TAG, "CRC");
        // Log.d(TAG, crcStr);
        // Log.d(TAG, dumpBytes(crcbytes));

        return crcbytes;
    }

    // 送信するパケットを生成する
    // PFコマンド用(ヘッダあり)
    protected byte[] packetGeneratorPF(byte[] payload) {

        int payloadLen = payload.length;
        ByteBuffer crcPayloadBuf;

        crcPayloadBuf = ByteBuffer.allocate(1 + payloadLen);
        crcPayloadBuf.clear();

        // データ部
        crcPayloadBuf.put(payload);

        byte[] ret;

        // ETX
        crcPayloadBuf.put(mETX);
        // CRC算出範囲のバイト列格納用
        byte[] crcPayload = new byte[payloadLen + 1];

        crcPayloadBuf.rewind();
        // CRC取得対象のバイト列取得
        crcPayloadBuf.get(crcPayload);

        int packetLen;
        packetLen = 1 + crcPayload.length + 2;

        ByteBuffer packetBuf = ByteBuffer.allocate(packetLen);
        packetBuf.put(mSTX);
        packetBuf.put(crcPayload);
        packetBuf.put(generateCRC(crcPayload));

        ret = new byte[packetLen];

        packetBuf.rewind();
        packetBuf.get(ret);

        return ret;
    }

    protected byte[] packetGeneratorPF2(byte[] payload) {

        int payloadLen = payload.length;
        ByteBuffer crcPayloadBuf;

        crcPayloadBuf = ByteBuffer.allocate(1 + 2 + 3 + payloadLen + 1);
        crcPayloadBuf.clear();
        // ヘッダ部 IDmp
        crcPayloadBuf.put(mIDmp);
        // ヘッダ部 CMD (pinpad用コマンド)
        crcPayloadBuf.put(mCMD);

        // データ長のBCD変換
        byte[] payloadLenBytes = int2bcd(payloadLen);

        // ヘッダ部データ部データ長 LENm
        crcPayloadBuf.put(payloadLenBytes);

        // データ部
        crcPayloadBuf.put(payload);

        byte[] ret;
        // ETX
        crcPayloadBuf.put(mETX);
        // CRC算出範囲のバイト列格納用
        byte[] crcPayload = new byte[1 + 2 + 3 + payloadLen + 1];

        crcPayloadBuf.rewind();
        // CRC取得対象のバイト列取得
        crcPayloadBuf.get(crcPayload);

        int packetLen;
        packetLen = 1 + crcPayload.length + 2;

        ByteBuffer packetBuf = ByteBuffer.allocate(packetLen);
        packetBuf.put(mSTX);
        packetBuf.put(crcPayload);
        packetBuf.put(generateCRC(crcPayload));

        ret = new byte[packetLen];
        packetBuf.rewind();
        packetBuf.get(ret);

        return ret;

    }

    // 送信するパケットを生成する
    // 透過コマンド用(ヘッダなし)
    protected byte[] packetGeneratorAPL(byte[] payload) {

        int payloadLen = payload.length;
        ByteBuffer crcPayloadBuf;

        crcPayloadBuf = ByteBuffer.allocate(1 + payloadLen);
        crcPayloadBuf.clear();

        // データ部
        crcPayloadBuf.put(payload);

        byte[] ret;

        // ETX
        crcPayloadBuf.put(mETX);
        // CRC算出範囲のバイト列格納用
        byte[] crcPayload = new byte[payloadLen + 1];

        crcPayloadBuf.rewind();
        // CRC取得対象のバイト列取得
        crcPayloadBuf.get(crcPayload);

        int packetLen;
        packetLen = 1 + crcPayload.length + 2;

        ByteBuffer packetBuf = ByteBuffer.allocate(packetLen);
        packetBuf.put(mSTX);
        packetBuf.put(crcPayload);

        if (payload[10] == 0x06) {
            packetBuf.put((byte) 0xee);
            packetBuf.put((byte) 0x59);
        } else {
            packetBuf.put((byte) 0x09);
            packetBuf.put((byte) 0xa0);
        }

        ret = new byte[packetLen];

        packetBuf.rewind();
        packetBuf.get(ret);

        return ret;

    }

    // 送信するパケットを生成する
    protected byte[] packetGenerator(byte[] payload) {

        int payloadLen = payload.length;
        ByteBuffer crcPayloadBuf;

        // 透過コマンド以外はヘッダを付与する
        if (payload[5] != 0x70) {

            crcPayloadBuf = ByteBuffer.allocate(1 + 2 + 3 + payloadLen + 1);
            crcPayloadBuf.clear();
            // ヘッダ部 IDmp
            crcPayloadBuf.put(mIDmp);
            // ヘッダ部 CMD (pinpad用コマンド)
            crcPayloadBuf.put(mCMD);

            // データ長のBCD変換
            byte[] payloadLenBytes = int2bcd(payloadLen);

            // Log.d(TAG, "PayloadLength");
            // Log.d(TAG, dumpBytes(payloadLenBytes));

            // ヘッダ部データ部データ長 LENm
            crcPayloadBuf.put(payloadLenBytes);

        } else {
            crcPayloadBuf = ByteBuffer.allocate(1 + payloadLen);
            crcPayloadBuf.clear();
        }

        // データ部
        crcPayloadBuf.put(payload);

        byte[] ret;
        if (payload[5] != 0x70) {
            // ETX
            crcPayloadBuf.put(mETX);
            // CRC算出範囲のバイト列格納用
            byte[] crcPayload = new byte[1 + 2 + 3 + payloadLen + 1];

            crcPayloadBuf.rewind();
            // CRC取得対象のバイト列取得
            crcPayloadBuf.get(crcPayload);

            int packetLen;
            packetLen = 1 + crcPayload.length + 2;

            // Log.d(TAG, "CRC算出範囲の長さ： " + crcPayload.length);
            // Log.d(TAG, "送信パケット長： " + packetLen);

            ByteBuffer packetBuf = ByteBuffer.allocate(packetLen);
            packetBuf.put(mSTX);
            packetBuf.put(crcPayload);
            packetBuf.put(generateCRC(crcPayload));

            ret = new byte[packetLen];
            packetBuf.rewind();
            packetBuf.get(ret);

        } else {
            // ETX
            crcPayloadBuf.put(mETX);
            // CRC算出範囲のバイト列格納用
            byte[] crcPayload = new byte[payloadLen + 1];

            crcPayloadBuf.rewind();
            // CRC取得対象のバイト列取得
            crcPayloadBuf.get(crcPayload);

            int packetLen;
            packetLen = 1 + crcPayload.length + 2;

            // Log.d(TAG, "CRC算出範囲の長さ： " + crcPayload.length);
            // Log.d(TAG, "送信パケット長： " + packetLen);

            ByteBuffer packetBuf = ByteBuffer.allocate(packetLen);
            packetBuf.put(mSTX);
            packetBuf.put(crcPayload);
            // packetBuf.put(generateCRC(crcPayload));

            if (payload[10] == 0x06) {
                packetBuf.put((byte) 0xee);
                packetBuf.put((byte) 0x59);
            } else {
                packetBuf.put((byte) 0x09);
                packetBuf.put((byte) 0xa0);
            }

            ret = new byte[packetLen];

            packetBuf.rewind();
            packetBuf.get(ret);
        }

        // Log.d(TAG, "GeneratedPacket");
        // Log.d(TAG, dumpBytes(ret));

        return ret;

    }

    public byte[] calcLength2(int length) {
        byte[] buf = new byte[2];
        buf[1] = (byte) (0x000000ff & (length));
        buf[0] = (byte) (0x000000ff & (length >>> 8));
        return buf;
    }

    public byte[] calcLength2Little(int length) {
        byte[] buf = new byte[2];
        buf[0] = (byte) (0x000000ff & (length));
        buf[1] = (byte) (0x000000ff & (length >>> 8));
        return buf;
    }

    public int getPaddingLength(int length) {
        int size = 0;
        for (int i = 1; (i * 16) < 65536; i++) {
            if ((i * 16) == 24) {
                continue;
            }
            if ((length + 16) < (i * 16)) {
                size = (i * 16) - length;
                break;
            }
        }
        return size;
    }

    public int getReturnLength() {
        return mReturnLength;
    }

    public void setReturnLength(int returnLength) {
        mReturnLength = returnLength;
        if (mLinkLevel == EmcrwDefine.LINK_LEVEL_PINPAD) {
            mReturnLength += 6;
        }
    }

    public int getTimeout() {
        return mReadTimeout;
    }

    public void setTimeout(int timeout) {
        mReadTimeout = timeout;
    }

    public int getCount() {
        return mReadCount;
    }

    public void setCount(int count) {
        mReadCount = count;
    }

    public byte getMC() {
        return mMC;
    }

    public void setMC(byte mMC) {
        this.mMC = mMC;
    }

    public byte getSC() {
        return mSC;
    }

    public void setSC(byte mSC) {
        this.mSC = mSC;
    }

    public void setEncrpt(boolean encrypt) {
        mIsEncrypt = encrypt;
    }
}
