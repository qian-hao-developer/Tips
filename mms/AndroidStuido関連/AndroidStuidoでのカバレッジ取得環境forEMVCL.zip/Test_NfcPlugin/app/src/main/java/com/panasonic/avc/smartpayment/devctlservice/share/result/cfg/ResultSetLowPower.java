
package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultSetLowPower処理結果データ
 */
public class ResultSetLowPower extends ResultData {

    /** @brief 省電力関連タグ */
    private static final String LOWPOWER = "lowpower";

    private static final String TIME = "time";

    private int mTime;

    /**
     * @brief コンストラクタ
     */
    public ResultSetLowPower(Parcel in) {
        super(in);
        mTime = in.readInt();
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetLowPower() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetLowPower> CREATOR = new Parcelable.Creator<ResultSetLowPower>() {
        public ResultSetLowPower createFromParcel(Parcel in) {
            return new ResultSetLowPower(in);
        }

        public ResultSetLowPower[] newArray(int size) {
            return new ResultSetLowPower[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mTime);
    }

    public int getTime() {
        return mTime;
    }

    public void setTime(int time) {
        mTime = time;
    }

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonLowPower = new JSONObject();
        try {
            json.put(DEVICE, getDevice());

            if (getTime() <= 0 || getTime() > 5) {
                jsonLowPower.put(TIME, JSONObject.NULL);
            } else {
                jsonLowPower.put(TIME, getTime());
            }

            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(LOWPOWER, JSONObject.NULL);
            } else {
                json.put(LOWPOWER, jsonLowPower);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
