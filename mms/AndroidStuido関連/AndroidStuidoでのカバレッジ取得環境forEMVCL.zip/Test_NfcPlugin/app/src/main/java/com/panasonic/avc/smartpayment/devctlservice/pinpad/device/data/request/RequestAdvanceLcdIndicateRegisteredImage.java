
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 拡張LCD表示コマンド(文字列表示)
 */
public class RequestAdvanceLcdIndicateRegisteredImage extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x03;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 0x7;

    /** @brief 表示種別 */
    private static final byte LCD_INDICATE_MODE = 0x00;

    /** @brief 画像表示で指定を行わない */
    public static final int IMAGE_NO_NUMBER = 0;

    /** @brief 表示位置X座標 */
    private int mX;

    /** @brief 表示位置Y座標 */
    private int mY;

    /** @brief 表示画像番号 */
    private int mImage;

    /**
     * @brief コンストラクタ
     * @param x 表示位置X座標
     * @param y 表示位置Y座標
     * @param image 表示画像番号
     */
    public RequestAdvanceLcdIndicateRegisteredImage(int x, int y, int image) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mX = x;
        mY = y;
        mImage = image;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = LCD_INDICATE_MODE;

        parameter[3] = (byte) mX;
        parameter[4] = (byte) mY;
        parameter[5] = 1;
        parameter[6] = (byte) mImage;

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mX < 0 || mX > 127) {
            return false;
        }

        if (mY < 0 || mY > 7) {
            return false;
        }

        if (mImage != IMAGE_NO_NUMBER) {
            return false;
        }

        return true;
    }

}
