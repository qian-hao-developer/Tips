
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * 機器情報応答
 */
public class ResponseDeviceInformation extends ResponseData {

    /** @brief マスターコマンド */
    protected static final byte MASTER_COMMAND = (byte) 0x00;

    /** @brief サブコマンド */
    protected static final byte SUB_COMMAND = (byte) 0x00;

    /** @brief コマンドの長さ **/
    protected static final int LENGTH = 0x21;

    /** @brief 結果 **/
    protected int mResult;

    /** @brief UID **/
    protected String mUid;

    /** @brief ファームウェアバージョン **/
    protected String mFirmwareVersion;

    /** @brief IFD **/
    protected String mIfd;

    /** @brief 拡張コード **/
    protected String mAdvance;

    /** @brief 不正開封検知情報 */
    protected boolean mTamper;

    /**
     * @brief コンストラクタ
     */
    public ResponseDeviceInformation() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @return 結果を取得する
     */
    public int getResult() {
        return mResult;
    }

    /**
     * 結果を設定する
     * 
     * @param 結果
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * UIDを取得する
     * 
     * @return uid
     */
    public String getUid() {
        return mUid;
    }

    /**
     * UIDを設定する
     * 
     * @param uid UID
     */
    public void setUid(String uid) {
        mUid = uid;
    }

    /**
     * ファームウェアバージョンを取得する
     * 
     * @return ファームウェアバージョン
     */
    public String getFirmwareVersion() {
        return mFirmwareVersion;
    }

    /**
     * ファームウェアバージョンを設定する
     * 
     * @param ファームウェアバージョン
     */
    public void setFirmwareVersion(String firmwareVersion) {
        mFirmwareVersion = firmwareVersion;
    }

    /**
     * IFDを取得する
     * 
     * @return IFD
     */
    public String getIfd() {
        return mIfd;
    }

    /**
     * IFDを設定する
     * 
     * @param IFD
     */
    public void setIfd(String ifd) {
        mIfd = ifd;
    }

    /**
     * 拡張コードを取得する
     * 
     * @return 拡張
     */
    public String getAdvance() {
        return mAdvance;
    }

    /**
     * 拡張コードを設定する
     * 
     * @param 拡張
     */
    public void setAdvance(String advance) {
        mAdvance = advance;
    }

    /**
     * @brief 不正開封検知情報を取得します ※trueで検知なし、falseで検知あり
     * @param[in] 不正開封検知情報
     */
    public boolean isTamper() {
        return mTamper;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        mResult = buffer[PinpadDefine.INDEX_PARAMETER];
        if (mResult != PluginDefine.RESULT_DEVICE_SCCESS) {
            setDevice(mResult);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        byte[] status = new byte[12];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 1, status, 0, status.length);
        status = CalcUtil.reverseByte(status);

        byte[] uid = new byte[8];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 13, uid, 0, uid.length);
        uid = CalcUtil.reverseByte(uid);
        mUid = String.valueOf((long) (uid[0] << 24) | (long) (uid[1] << 16) | (long) (uid[2] << 8)
                | (long) (uid[3]));

        byte[] fv = new byte[4];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 21, fv, 0, fv.length);
        mFirmwareVersion = new String(fv);

        byte[] ifd = new byte[4];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 25, ifd, 0, ifd.length);
        mIfd = new String(ifd);

        byte[] advance = new byte[2];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 29, advance, 0, advance.length);
        advance = CalcUtil.reverseByte(advance);
        mAdvance = new String(advance);

        byte tamper_status = buffer[PinpadDefine.INDEX_PARAMETER + 1];

        if ((tamper_status & 0x0f) == 0x0f) {
            mTamper = false; // 検知あり
        } else {
            mTamper = true; // 検知なし
        }

        return true;
    }

}
