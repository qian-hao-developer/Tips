
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultEraseArea extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultEraseArea(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultEraseArea() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultEraseArea> CREATOR = new Parcelable.Creator<ResultEraseArea>() {

        @Override
        public ResultEraseArea createFromParcel(Parcel in) {
            return new ResultEraseArea(in);
        }

        @Override
        public ResultEraseArea[] newArray(int size) {
            return new ResultEraseArea[size];
        }
    };
}
