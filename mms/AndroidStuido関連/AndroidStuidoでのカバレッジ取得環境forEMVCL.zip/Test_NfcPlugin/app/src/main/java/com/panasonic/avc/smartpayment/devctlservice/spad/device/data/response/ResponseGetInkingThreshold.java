
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetInkingThreshold extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x22;

    private static final int LENGTH = 5;

    private static final String ON = "on";

    private int mOn;

    private static final String OFF = "off";

    private int mOff;

    public ResponseGetInkingThreshold(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mOn = CalcUtil.toInt(result[1], result[2]);
        mOff = CalcUtil.toInt(result[3], result[4]);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(ON, mOn);
            json.put(OFF, mOff);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
}
