package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultSetBuzzer処理結果データ
 */
public class ResultSetBuzzer extends ResultData {

    /** @brief Configuration Buzzerタグ */
    private static final String BUZZER = "buzzer";

    /** @brief 音量の設定状態情報タグ */
    private static final String VOLUME = "vol";

    private int mVolume;

    /**
     * @brief コンストラクタ
     */
    public ResultSetBuzzer(Parcel in) {
        super(in);
        mVolume = in.readInt();
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetBuzzer() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetBuzzer> CREATOR = new Parcelable.Creator<ResultSetBuzzer>() {
        public ResultSetBuzzer createFromParcel(Parcel in) {
            return new ResultSetBuzzer(in);
        }

        public ResultSetBuzzer[] newArray(int size) {
            return new ResultSetBuzzer[size];
        }
    };
    
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mVolume);
    }

    /**
     * @brief 音量の設定状態情報を取得します
     * @return 音量の設定状態情報
     */
    public int getVolume() {
        return mVolume;
    }

    /**
     * @brief 音量の設定状態情報を設定します
     * @param[in] volume 音量の設定状態情報
     */
    public void setVolume(int volume) {
        mVolume = volume;
    }

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonBuzzer = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonBuzzer.put(VOLUME, getVolume());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(BUZZER, JSONObject.NULL);
            } else {
                json.put(BUZZER, jsonBuzzer);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
