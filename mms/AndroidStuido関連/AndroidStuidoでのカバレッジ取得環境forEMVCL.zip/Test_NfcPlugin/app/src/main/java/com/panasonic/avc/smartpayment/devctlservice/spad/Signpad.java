
package com.panasonic.avc.smartpayment.devctlservice.spad;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

import android.hardware.usb.UsbDevice;
import android.os.RemoteException;
import android.util.Log;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.NotifyUsbDeviceConnectionListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.SignpadDataListener;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.ISpadServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.spad.ResponseControlSignpad;
import com.panasonic.avc.smartpayment.devctlservice.share.response.spad.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.spad.ResponseSignpad;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultClearSPAD;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultDispImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultEraseArea;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetArea;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetBackgroundColor;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetBootScreenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetBrightness;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetCapability;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetInformation;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetInking;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetInkingThreshold;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetPenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetStatus;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetUID;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetUID2;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultInitSPAD;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultIntervalON;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultPenData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSendSPAD;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetArea;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBackgroundColor;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBootScreenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBrightness;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetInking;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetInkingThreshold;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetPenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetUID;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultTermSPAD;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.RequestSpadData;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class Signpad {

    /** @brief ログ出力用タグ */
    private static final String TAG = Signpad.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static Signpad sInstance = new Signpad();

    /** @brief バインド相手のリスナー(STU-530用) */
    private ConcurrentHashMap<String, ISpadServiceListener> mISpadServiceListenerList = new ConcurrentHashMap<String, ISpadServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    public ControlDeviceManager mControlDeviceManager;

    /** @brief タイムアウトまでの時間 */
    private static final int TIMEOUT = 2000;

    /** @brief サインパッドデータリード用スレッド */
    private SignpadDataReadThread mSignpadDataReadThread = null;

    private boolean mIsAdvanced;

    /** @brief STU-430 のProductID */
    public static final int PRODUCT_ID_430 = SignpadDefine.PID_STU_430;

    /** @brief STU-530 のProductID */
    public static final int PRODUCT_ID_530 = SignpadDefine.PID_STU_530;

    /**
     * @brief コンストラクタ
     */
    private Signpad() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static Signpad getInstance() {
        return sInstance;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
        mControlDeviceManager.registerNotifyUsbDeviceConnectionListener(mConnectionListener);
    }

    /**
     * @brief サインパッドプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerSpadServiceListener(String tag, ISpadServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mISpadServiceListenerList) {
            mISpadServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief サインパッドプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterSpadServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mISpadServiceListenerList) {
            mISpadServiceListenerList.remove(tag);
        }
    }

    public boolean isAdvanced() {
        return mIsAdvanced;
    }

    /**
     * @brief SPADを初期化します
     * @return 実行結果
     */
    public ResultInitSPAD initSPAD(boolean isAdvanced) {

        ResultInitSPAD result = new ResultInitSPAD();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        } else {
            mControlDeviceManager.setSpadDataListener(mISpadDataListener);
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            mIsAdvanced = isAdvanced;
        }

        // initSPAD 時は手書き入力を無効化
        ResultSetInking ret = setInking(false);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドをターミネートします
     * @return 実行結果
     */
    public ResultTermSPAD termSPAD() {
        ResultTermSPAD result = new ResultTermSPAD();

        // termSPAD 時は手書き入力を無効化
        setInking(false);

        mControlDeviceManager.removeSpadDataListener(mISpadDataListener);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief サインパッドにデータを送信します
     * @param[in] datasz 送信データサイズ
     * @param[in] data 送信データの16進文字列
     */
    public ResultSendSPAD sendSPAD(int datasz, String data) {

        boolean ret = false;

        ResultSendSPAD result = new ResultSendSPAD();
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        } else {

            RequestSpadData request = new RequestSpadData();
            request.setCommand(data);

            // data のチェック
            if (!request.isValidValue()) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }

            // 長さが正しいかチェック
            if (datasz != (data.length() / 2)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }

            ret = mControlDeviceManager.write(request, TIMEOUT);

            // Log.d(TAG, "ret: " + ret);

            if (ret) {
                // 書き込み成功
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            } else {
                // 書き込み失敗
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            }
        }

        return result;
    }

    /**
     * @brief インターバル 100ms 有効無効を切り替えます
     * @param[in] interval インターバルの有効/無効[論理型]
     * @return 実行結果
     */
    public ResultIntervalON intervalON(boolean interval) {
        ResultIntervalON result = new ResultIntervalON();
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        } else {
            if (interval) {
                // スレッド開始
                if (mSignpadDataReadThread == null || !mSignpadDataReadThread.isAlive()) {
                    mSignpadDataReadThread = new SignpadDataReadThread();
                    mSignpadDataReadThread.clearPenDataBuffer();
                    mSignpadDataReadThread.start();
                    result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                    result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
                }
            } else {
                // スレッド終了
                if (mSignpadDataReadThread != null) {
                    mSignpadDataReadThread.mTerminated = true;
                    result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                    result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
                }
            }
        }
        return result;
    }

    // byte列をダンプする（あとで消す）
    public String dumpBytes(byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        StringBuilder buf = new StringBuilder(bytes.length * 3);
        for (int i = 0; i < bytes.length; i++) {
            int d = bytes[i];
            if (d < 0) {
                // byte型では128～255が負値になっているので補正
                d += 256;
            }
            if (d < 16) {
                // 0～15は16進数で1けたになるので、2けたになるよう頭に0を追加
                buf.append("0");
            }
            // 1バイトを16進数2けたで表示
            buf.append(Integer.toString(d, 16));
            buf.append(" ");
        }
        return buf.toString();
    }

    /**
     * @brief signpad thread
     */
    class SignpadDataReadThread extends Thread {

        private boolean mTerminated = false;

        private static final int READ_PEN_TIMEOUT = 300; // 300msでタイムアウト

        /** @brief 100ms周期で座標情報を送信するためのタイマー */
        private Timer mTimer = null;

        /** @brief タイマーで実行するタスク */
        private TimerTask mTask = null;

        /** @brief Signpadから読み取った座標データを格納するバッファ */
        private ResponseSignpad mListA = new ResponseSignpad();

        /** @brief Signpadから読み取った座標データを格納するバッファ */
        private ResponseSignpad mListB = new ResponseSignpad();

        /** @brief 今どのバッファを使用しているか */
        private int mCurrentList = 0; // 0=A, 1=B

        /** @brief mCurrentList 用ロックオブジェクト */
        private Object mCurrentLock = new Object();

        @Override
        public void run() {

            if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                sendError(PluginDefine.RESULT_DEVICE_SCCESS, 0,
                        PluginDefine.RESULT_UPOS_PORT_ERROR, null);
                return;
            } else {

                Log.d(TAG, "SignpadDataReadThread starting...");

                // サインパッドのデータを周期的に返すようにタイマーを設定
                mTask = new SignpadDataSender();
                mTimer = new Timer();
                mTimer.schedule(mTask, 50, 100);

                ResultPenData tmp = new ResultPenData();

                byte[] buffer = new byte[7];

                // データ読み取りループ
                while (!mTerminated && mControlDeviceManager.isActive()) {
                    buffer = readPenData(READ_PEN_TIMEOUT);
                    tmp = parsePenData(buffer);
                    if (tmp != null) {
                        switch (getCurrentList()) {
                            case 0:
                                synchronized (mListA) {
                                    mListA.add(tmp);
                                }
                                break;
                            case 1:
                                synchronized (mListB) {
                                    mListB.add(tmp);
                                }
                                break;
                        }
                    }
                }

                // タイマーを停止
                if (mTimer != null) {
                    mTimer.cancel();
                    mTimer = null;
                }

                // 変な座標が残らないようにバッファをクリア
                synchronized (mListA) {
                    mListA.clear();
                }
                synchronized (mListB) {
                    mListB.clear();
                }

                // バッファの使用状況をリセット
                mCurrentList = 0;

                // terminateフラグをリセット
                mTerminated = false;

                // terminate end
                Log.d(TAG, "SignpadDataReadThread terminated.");
            }
        }

        /**
         * @return タイムアウトしたら {@code null}
         */
        private byte[] readPenData(int timeout) {
            return mControlDeviceManager.read(timeout);
        }

        /**
         * バッファクリア
         */
        private void clearPenDataBuffer() {
            while (readPenData(50) != null) {
                // NOP: タイムアウトするまで読み込む (50ms)
            }
        }

        /**
         * @brief Signpadから座標・筆圧データを取り出す
         */
        private ResultPenData parsePenData(byte[] penData) {

            if (penData == null) {
                return null;
            }

            ByteBuffer tmp = ByteBuffer.wrap(penData);
            tmp.position(1);

            // RDYのチェック
            int by = tmp.get() & 0xFF;
            int rdy = (by >> 7);
            if (rdy == 0) {
                // Pen left form SignPad readable range.
                // In this case, X, Y, Pressure & Switch data are Valid.

                // NOP: 無効のデータであっても上位に通知する
                // 上位アプリが、ペンがデジタイザから離れたことを検知できるようにするため
            }

            // Switch
            int sw = ((by & 0x70) >> 4);
            // Switchのレポート状態は以下の通り
            // |ペンの位置|ペンボタン状態|Switch|
            // |接触　　　|no push　　　 |1　　 |
            // |非接触　　|no push　　　 |0　　 |
            // |接触　　　|push　　　　　|3　　 |
            // |非接触　　|push　　　　　|2　　 |
            // STU-530/430付属のペンはボタンが存在しないので、接触時には必ず1、非接触時には0がレポートされる。
            // もし、ボタンが存在するペンを使用する場合には注意が必要。

            // 筆圧
            int pressure = tmp.get() & 0xFF;
            pressure += (by & 0x0F) << 8;

            if (pressure == 0) {
                // NOP: 筆圧 0 のデータであっても上位に通知する
                // (筆圧 0 は、デジタイザはペンを検出したが接触はしていないことを意味する)
                // 上位アプリが、ペンがデジタイザから離れたことを検知できるようにするため
            }

            // 座標データ
            int x = tmp.getShort();
            int y = tmp.getShort();

            return new ResultPenData(x, y, sw, pressure);
        }

        /**
         * @brief 読み取ったデータを周期的に送信するタスク
         */
        class SignpadDataSender extends TimerTask {
            @Override
            public void run() {
                switch (changeCurrentList()) {
                    case 0:
                        synchronized (mListA) {
                            if (checkList(mListA)) {
                                sendSpadEvent(mListA);
                                mListA.clear();
                            }
                        }
                        break;
                    case 1:
                        synchronized (mListB) {
                            if (checkList(mListB)) {
                                sendSpadEvent(mListB);
                                mListB.clear();
                            }
                        }
                        break;
                }
            }

            /**
             * listが空かどうかチェックする
             * 
             * @param list
             * @return listの中身が存在するかどうか
             */
            private boolean checkList(ResponseSignpad list) {
                boolean ret = false;

                if (!list.isEmpty()) {
                    ret = true;
                }

                return ret;
            }

        }

        private int getCurrentList() {
            synchronized (mCurrentLock) {
                return mCurrentList;
            }
        }

        private int changeCurrentList() {
            synchronized (mCurrentLock) {
                switch (mCurrentList) {
                    case 0:
                        mCurrentList = 1;
                        return 0;
                    default:
                        mCurrentList = 0;
                        return 1;
                }
            }
        }

    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name, ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, Signpad.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief サインパッドの手書き入力が可能な範囲を設定します
     * @param[in] ulx 左上 X 座標を指定[整数型]します
     * @param[in] uly 左上 Y 座標を指定[整数型]します
     * @param[in] lrx 右下 X 座標を指定[整数型]します
     * @param[in] lry 右下 Y 座標を指定[整数型]します
     * @return 実行結果
     */
    public ResultSetArea setArea(int ulx, int uly, int lrx, int lry) {
        ResultSetArea result = new ResultSetArea();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!isValidPosition(ulx, uly, lrx, lry)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "012a";
        data += CalcUtil.toString(true, ulx);
        data += CalcUtil.toString(true, uly);
        data += CalcUtil.toString(true, lrx);
        data += CalcUtil.toString(true, lry);
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの手書き入力が可能な範囲を取得します
     * @return 実行結果
     */
    public ResultGetArea getArea() {
        ResultGetArea result = new ResultGetArea();

        String data = "022a0000000000000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの手書き入力が可能な範囲を取得します
     * @param[in] status 手書き入力の有効/無効を指定[論理型]します
     * @return 実行結果
     */
    public ResultSetInking setInking(boolean status) {
        ResultSetInking result = new ResultSetInking();

        String data = "0121";
        data += status ? "01" : "00";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの画面への手書き入力の有効無効を取得します
     * @return JSON形式 [device, upos]
     * @throws RemoteException
     */
    public ResultGetInking getInking() {
        ResultGetInking result = new ResultGetInking();

        String data = "022100";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの画面への手書き入力が有効となる筆圧の範囲を設定します
     * @param[in] on 指定した値より高くなると入力が有効になります
     * @param[in] off 指定した値より低くなると入力が無効になります
     * @return 実行結果
     */
    public ResultSetInkingThreshold setInkingThreshold(int on, int off) {
        ResultSetInkingThreshold result = new ResultSetInkingThreshold();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        } else if (on < 0 || on > 1023 || off < 0 || off > 1023) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "0122";
        data += CalcUtil.toString(true, on);
        data += CalcUtil.toString(true, off);
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの画面への手書き入力が有効となる筆圧の範囲を取得します
     * @return 実行結果
     */
    public ResultGetInkingThreshold getInkingThreshold() {
        ResultGetInkingThreshold result = new ResultGetInkingThreshold();

        String data = "022200000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの画面を消去します
     * @return 実行結果
     */
    public ResultClearSPAD clearSPAD() {
        ResultClearSPAD result = new ResultClearSPAD();

        String data = "012000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの画面を領域指定で部分消去します
     * @param[in] ulx 左上 X 座標を指定[整数型]します
     * @param[in] uly 左上 Y 座標を指定[整数型]します
     * @param[in] lrx 右下 X 座標を指定[整数型]します
     * @param[in] lry 右下 Y 座標を指定[整数型]します
     * @return 実行結果
     */
    public ResultEraseArea eraseArea(int ulx, int uly, int lrx, int lry) {
        ResultEraseArea result = new ResultEraseArea();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!isValidPosition(ulx, uly, lrx, lry)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "01230001";
        data += CalcUtil.toString(true, ulx);
        data += CalcUtil.toString(true, uly);
        data += CalcUtil.toString(true, lrx);
        data += CalcUtil.toString(true, lry);
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief イメージをサインパッドに転送し、指定した領域に表示するよう設定します
     * @param[in] encode 画像のエンコードモードを指定[整数型]します
     * @param[in] ulx 左上 X 座標を指定[整数型]します
     * @param[in] uly 左上 Y 座標を指定[整数型]します
     * @param[in] lrx 右下 X 座標を指定[整数型]します
     * @param[in] lry 右下 Y 座標を指定[整数型]します
     * @param[in] datasz 送信データサイズを指定[整数型]します
     * @param[in] data 送信データを 16 進文字列で指定します
     * @return 実行結果
     */
    public ResultDispImage dispImage(int encode, int ulx, int uly, int lrx, int lry, int datasz,
            String data) {
        ResultDispImage result = new ResultDispImage();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }
        if (!isValidEncode(encode) || !isValidPosition(ulx, uly, lrx, lry)
                || (datasz != data.length() / 2)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        // 画像表示位置指定
        String senddata = "0124";
        senddata += String.format("%02x", (encode & 0xff));
        senddata += "01";
        senddata += CalcUtil.toString(true, ulx);
        senddata += CalcUtil.toString(true, uly);
        senddata += CalcUtil.toString(true, lrx);
        senddata += CalcUtil.toString(true, lry);

        int senddatasz = senddata.length() / 2;
        ResultSendSPAD ret = sendSPAD(senddatasz, senddata);
        result.setResult(ret);

        if (result.getDevice() != 0 || result.getUpos() != 0) {
            return result;
        }

        // 画像転送開始
        senddata = "0125";
        senddata += String.format("%02x", (encode & 0xff));
        senddatasz = senddata.length() / 2;
        ret = sendSPAD(senddatasz, senddata);
        result.setResult(ret);

        if (result.getDevice() != 0 || result.getUpos() != 0) {
            return result;
        }

        // 画像描画
        // 画像データを 253 バイトにブロッキング
        final int DATA_BLOCK_SIZE_MAX = 256 - 3;
        for (int i = 0; i * DATA_BLOCK_SIZE_MAX < datasz; i++) {
            senddata = "0126";
            if ((i + 1) * DATA_BLOCK_SIZE_MAX < datasz) {
                senddata += CalcUtil.toString(true, DATA_BLOCK_SIZE_MAX);
                senddata += data.substring(i * DATA_BLOCK_SIZE_MAX * 2, (i + 1)
                        * DATA_BLOCK_SIZE_MAX * 2);
            } else {
                senddata += CalcUtil.toString(true, datasz - (i * DATA_BLOCK_SIZE_MAX));
                senddata += data.substring(i * DATA_BLOCK_SIZE_MAX * 2);
                // ゼロパディング
                while (senddata.length() / 2 != 257) {
                    senddata += "00";
                }
            }
            senddatasz = senddata.length() / 2;
            ret = sendSPAD(senddatasz, senddata);
            result.setResult(ret);

            if (result.getDevice() != 0 || result.getUpos() != 0) {
                return result;
            }
        }

        // 画像転送終了
        senddata = "012700";
        senddatasz = senddata.length() / 2;
        ret = sendSPAD(senddatasz, senddata);
        result.setResult(ret);

        return result;
    }

    /**
     * @brief サインパッドの背景色を変更します
     * @param[in] color 24bit のカラーコードを 16 進文字列で指定します
     * @return 実行結果
     */
    public ResultSetBackgroundColor setBackgroundColor(String color) {
        ResultSetBackgroundColor result = new ResultSetBackgroundColor();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        } else if (color.length() != 6) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "012e";
        data += color.substring(4, 6);
        data += color.substring(2, 4);
        data += color.substring(0, 2);
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの背景色を取得します
     * @return 実行結果
     */
    public ResultGetBackgroundColor getBackgroundColor() {
        ResultGetBackgroundColor result = new ResultGetBackgroundColor();

        String data = "022e000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief ペンで引く線の色と線の太さを変更します
     * @param[in] color ペンの線の色を 24bit のカラーコードを 16 進文字列で指定します
     * @param[in] thickness ペンの線の太さを指定[整数型]します
     * @return 実行結果
     */
    public ResultSetPenMode setPenMode(String color, int thickness) {
        ResultSetPenMode result = new ResultSetPenMode();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        } else if (color.length() != 6 || !isValidThickness(thickness)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "012d";
        data += color.substring(4, 6);
        data += color.substring(2, 4);
        data += color.substring(0, 2);
        data += String.format("%02x", thickness);
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief ペンで引く線の色と線の太さの設定情報を取得します
     * @return 実行結果
     */
    public ResultGetPenMode getPenMode() {
        ResultGetPenMode result = new ResultGetPenMode();

        String data = "022d00000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの輝度を変更します
     * @param[in] brightness 画面の輝度を指定[整数型]します
     * @return 実行結果
     */
    public ResultSetBrightness setBrightness(int brightness) {
        ResultSetBrightness result = new ResultSetBrightness();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        } else if (brightness < 0 || brightness > 4) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "012b";
        data += CalcUtil.toString(true, brightness);
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの輝度を取得します
     * @return 実行結果
     */
    public ResultGetBrightness getBrightness() {
        ResultGetBrightness result = new ResultGetBrightness();

        String data = "022b0000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドのモデル情報、ファームウェアバージョン情報を取得します
     * @return 実行結果
     */
    public ResultGetInformation getInformation() {
        ResultGetInformation result = new ResultGetInformation();

        String data = "020800000000000000000000000000000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの画面周りの基礎情報を設定します
     * @return 実行結果
     */
    public ResultGetCapability getCapability() {
        ResultGetCapability result = new ResultGetCapability();

        String data = "020900000000000000000000000000000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの状態を取得します
     * @return 実行結果
     */
    public ResultGetStatus getStatus() {
        ResultGetStatus result = new ResultGetStatus();

        String data = "020300000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドのUID情報を設定します
     * @param[in] uid 4byte 分の送信データを 16 進文字列で指定します
     * @return 実行結果
     */
    public ResultSetUID setUID(String uid) {
        ResultSetUID result = new ResultSetUID();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        } else if (uid.length() != 8) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        String data = "010a" + uid;
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドのUID情報を取得します
     * @return 実行結果
     */
    public ResultGetUID getUID() {
        ResultGetUID result = new ResultGetUID();

        String data = "020a00000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドのUID2情報を取得します
     * @return 実行結果
     */
    public ResultGetUID2 getUID2() {
        ResultGetUID2 result = new ResultGetUID2();

        String data = "020B00000000000000000000";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの電源ON時にロゴ表示を行うかどうかのステータスを設定します
     * @param[in] bootscreen ロゴ表示の有効/無効を指定[論理型]します
     * @return 実行結果
     */
    public ResultSetBootScreenMode setBootScreenMode(boolean bootscreen) {
        ResultSetBootScreenMode result = new ResultSetBootScreenMode();

        String data = "012f";
        data += bootscreen ? "01" : "00";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief サインパッドの電源ON時にロゴ表示を行うかどうかのステータスを取得します
     * @return 実行結果
     */
    public ResultGetBootScreenMode getBootScreenMode() {
        ResultGetBootScreenMode result = new ResultGetBootScreenMode();

        String data = "022f00";
        int datasz = data.length() / 2;

        ResultSendSPAD ret = sendSPAD(datasz, data);
        result.setResult(ret);
        return result;
    }

    /**
     * @brief エラーを送信する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private void sendError(int ecode, int vcode, int extcode, String extinfo) {
        ResponseError error = new ResponseError();
        error.setEcode(ecode);
        error.setVcode(vcode);
        error.setExtcode(extcode);
        error.setExtinfo(extinfo);

        synchronized (mISpadServiceListenerList) {
            for (Map.Entry<String, ISpadServiceListener> listener : mISpadServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(error);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief 座標データを送信する
     * @param list ResponseSignpad
     */
    private void sendSpadEvent(ResponseSignpad list) {
        synchronized (mISpadServiceListenerList) {
            for (Map.Entry<String, ISpadServiceListener> listener : mISpadServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onSpadEvent(list);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief ControlTransferの結果を送信する
     * @param data ResponseControlSignpad
     */
    private void sendSpadControlEvent(ResponseControlSignpad data) {
        synchronized (mISpadServiceListenerList) {
            for (Map.Entry<String, ISpadServiceListener> listener : mISpadServiceListenerList
                    .entrySet()) {
                try {
                    Log.d(TAG, "sendSpadControlEvent()");
                    listener.getValue().onSpadControlEvent(data);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief 有効な座標か判定する
     */
    private boolean isValidPosition(int ulx, int uly, int lrx, int lry) {
        if (mControlDeviceManager.getProductId() == PRODUCT_ID_430) {
            if (ulx < 0 || ulx > 319 || uly < 0 || uly > 199 || lrx < 0 || lrx > 319
                    || lry < 0 || lry > 199) {
                return false;
            }
        } else if (mControlDeviceManager.getProductId() == PRODUCT_ID_530) {
            if (ulx < 0 || ulx > 799 || uly < 0 || uly > 479 || lrx < 0 || lrx > 799
                    || lry < 0 || lry > 479) {
                return false;
            }
        }
        return true;
    }

    /**
     * @brief 有効なペンの太さか判定する
     */
    private boolean isValidThickness(int thickness) {
        if (mControlDeviceManager.getProductId() == PRODUCT_ID_430) {
            if (thickness < 0 || thickness > 2) {
                return false;
            }
        } else if (mControlDeviceManager.getProductId() == PRODUCT_ID_530) {
            if (thickness < 0 || thickness > 3) {
                return false;
            }
        }
        return true;
    }

    /**
     * @brief 有効な画像エンコードモードか判定する
     */
    private boolean isValidEncode(int encode) {
        final int RAW = 0;
        final int ZLIB = 1;
        final int COLOR_16BIT = 2;
        final int COLOR_24BIT = 4;
        if (mControlDeviceManager.getProductId() == PRODUCT_ID_430) {
            switch (encode) {
                case RAW:
                case ZLIB:
                    // NOP
                    break;
                default:
                    return false;
            }
        } else if (mControlDeviceManager.getProductId() == PRODUCT_ID_530) {
            switch (encode) {
                case RAW:
                case ZLIB:
                case COLOR_16BIT:
                case COLOR_24BIT:
                    // NOP
                    break;
                default:
                    return false;
            }
        }
        return true;
    }

    private SignpadDataListener mISpadDataListener = new SignpadDataListener() {

        @Override
        public void sendSpadData(ResponseSignpad spadData) {
            sendSpadEvent(spadData);
        }

        @Override
        public void sendSpadControlData(byte[] command) {
            Log.d(TAG, "sendSpadControlData()");

            ResponseSpadData data = ResponseSpadData.createResponseData(command);

            if (data == null) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0, PluginDefine.ERROR_EXT_CODE_NETWORK, null);
            } else {
                ResponseControlSignpad result = new ResponseControlSignpad(mIsAdvanced);

                if (mIsAdvanced) {
                    result.setResultData(data.toJSONObject().toString());
                } else {
                    result.setResultData(CalcUtil.toHexString(command));
                }

                Log.d(TAG, "sendSpadControlData result: " + result.toJSON());

                sendSpadControlEvent(result);
            }

        }

    };

    private NotifyUsbDeviceConnectionListener mConnectionListener = new NotifyUsbDeviceConnectionListener() {

        @Override
        public void onOpened(UsbDevice device) {
            // USB 接続時は手書き入力を無効化
            setInking(false);
        }

        @Override
        public void onClosed(UsbDevice device) {
            // NOP
        }

    };

}
