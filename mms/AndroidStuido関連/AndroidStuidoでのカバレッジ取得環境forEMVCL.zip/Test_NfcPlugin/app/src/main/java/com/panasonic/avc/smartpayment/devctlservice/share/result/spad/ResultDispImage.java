
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultDispImage extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultDispImage(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultDispImage() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultDispImage> CREATOR = new Parcelable.Creator<ResultDispImage>() {

        @Override
        public ResultDispImage createFromParcel(Parcel in) {
            return new ResultDispImage(in);
        }

        @Override
        public ResultDispImage[] newArray(int size) {
            return new ResultDispImage[size];
        }
    };
}
