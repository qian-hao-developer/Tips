
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * USB接続通知用BroadcastReceiver
 */
public class UsbDeviceReceiver extends BroadcastReceiver {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = UsbDeviceReceiver.class.getSimpleName();

    /** @brief ログ表示 */
    @SuppressWarnings("unused")
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief USBホスト許諾時アクション */
    public static final String ACTION_USB_PERMISSION = "com.panasonic.avc.smartpayment.devctlservice.USB_PERMISSION";

    /**
     * @see BroadcastReceiver#onReceive(Context, Intent)
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        // mLoggingManager.d(TAG, intent.getAction());

        String action = intent.getAction();
        UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
            // mLoggingManager.d(TAG, "ACTION_USB_DEVICE_ATTACHED");
            DeviceTracker.getInstance().notifyConnectedUsbDevice(device);
        } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
            // mLoggingManager.d(TAG, "ACTION_USB_DEVICE_DETACHED");
            DeviceTracker.getInstance().notifyDisconnectedUsbDevice(device);
        } else if (ACTION_USB_PERMISSION.equals(action)) {
            // mLoggingManager.d(TAG, "ACTION_USB_PERMISSION");
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                DeviceTracker.getInstance().notifyPermittedUsbDevice(device);
            }
        }
    }

}
