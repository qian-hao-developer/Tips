
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_LineFeedの実行結果データ
 */
public class ResultPrintLineFeed extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintLineFeed(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintLineFeed() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintLineFeed> CREATOR = new Parcelable.Creator<ResultPrintLineFeed>() {
        public ResultPrintLineFeed createFromParcel(Parcel in) {
            return new ResultPrintLineFeed(in);
        }

        public ResultPrintLineFeed[] newArray(int size) {
            return new ResultPrintLineFeed[size];
        }
    };
}
