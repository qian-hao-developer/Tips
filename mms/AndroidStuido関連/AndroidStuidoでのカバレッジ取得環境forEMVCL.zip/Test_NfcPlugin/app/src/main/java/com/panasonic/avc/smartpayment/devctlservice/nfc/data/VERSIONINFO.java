package com.panasonic.avc.smartpayment.devctlservice.nfc.data;

/**
 * 非接触EMVアプリバージョンとチェックサム情報格納クラス<br>
 */
public class VERSIONINFO {
    /** 非接触EMVアプリバージョン. */
    public byte[] ReaderVersion;
    /** . */
    public byte[] EntryPointVersion;
    /** . */
    public byte[] KernelC1Version;
    /** . */
    public byte[] KernelC2Version;
    /** . */
    public byte[] KernelC3Version;
    /** . */
    public byte[] KernelC4Version;
    /** . */
    public byte[] KernelC5Version;
    /** . */
    public byte[] KernelC6Version;
    /** . */
    public byte[] KernelC7Version;
    /** . */
    public byte[] KernelC8Version;
    /** . */
    public byte[] KernelC9Version;
    /** . */
    public byte[] KernelC10Version;
    /** . */
    public byte[] KernelC11Version;
    /** . */
    public byte[] KernelC12Version;
    /** . */
    public byte[] KernelC13Version;
    /** . */
    public byte[] KernelC14Version;
    /** . */
    public byte[] KernelC15Version;
    /** 非接触EMVアプリのチェックサム. */
    public long EntryPointChecksum;
    /** . */
    public long KernelC1Checksum;
    /** . */
    public long KernelC2Checksum;
    /** . */
    public long KernelC3Checksum;
    /** . */
    public long KernelC4Checksum;
    /** . */
    public long KernelC5Checksum;
    /** . */
    public long KernelC6Checksum;
    /** . */
    public long KernelC7Checksum;
    /** . */
    public long KernelC8Checksum;
    /** . */
    public long KernelC9Checksum;
    /** . */
    public long KernelC10Checksum;
    /** . */
    public long KernelC11Checksum;
    /** . */
    public long KernelC12Checksum;
    /** . */
    public long KernelC13Checksum;
    /** . */
    public long KernelC14Checksum;
    /** . */
    public long KernelC15Checksum;
}
