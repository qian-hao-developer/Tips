
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * UpdateLCDModeの実行結果データ
 */
public class ResultUpdateLCDMode extends AnalyzeResultData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x00;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x00;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x21;

    private int mResult;

    /** @brief ディスプレイ関連の設定状態タグ */
    private static final String LCD = "lcd";

    /** @brief 表示モードの設定状態情報 */
    private boolean mMode;

    /** @brief 表示モードの設定状態情報タグ */
    private static final String MODE = "mode";

    /** @brief バックライトの設定状態情報 */
    private boolean mLump;

    /** @brief バックライトの設定状態情報タグ */
    private static final String LUMP = "lump";

    /** @brief ディスプレイコントラストの設定状態情報 */
    private int mContrast;

    /** @brief ディスプレイコントラストの設定状態情報タグ */
    private static final String CONTRAST = "contrast";

    /**
     * @brief コンストラクタ
     */
    public ResultUpdateLCDMode(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultUpdateLCDMode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultUpdateLCDMode> CREATOR = new Parcelable.Creator<ResultUpdateLCDMode>() {
        public ResultUpdateLCDMode createFromParcel(Parcel in) {
            return new ResultUpdateLCDMode(in);
        }

        public ResultUpdateLCDMode[] newArray(int size) {
            return new ResultUpdateLCDMode[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mMode ? 1 : 0);
        dest.writeInt(mLump ? 1 : 0);
        dest.writeInt(mContrast);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mMode = in.readInt() == 1 ? true : false;
        mLump = in.readInt() == 1 ? true : false;
        mContrast = in.readInt();
    }

    /**
     * @brief 表示モードの設定状態情報を取得します
     * @return 表示モードの設定状態情報
     */
    public boolean isMode() {
        return mMode;
    }

    /**
     * @brief 表示モードの設定状態情報を設定します
     * @param[in] mode 表示モードの設定状態情報
     */
    public void setMode(boolean mode) {
        mMode = mode;
    }

    /**
     * @brief バックライトの設定状態情報を取得します
     * @return バックライトの設定状態情報
     */
    public boolean isLump() {
        return mLump;
    }

    /**
     * @brief バックライトの設定状態情報を設定します
     * @param[in] lump バックライトの設定状態情報
     */
    public void setLump(boolean lump) {
        mLump = lump;
    }

    /**
     * @brief ディスプレイコントラストの設定状態情報を取得します
     * @return ディスプレイコントラストの設定状態情報
     */
    public int getContrast() {
        return mContrast;
    }

    /**
     * @brief ディスプレイコントラストの設定状態情報を設定します
     * @param[in] contrast ディスプレイコントラストの設定状態情報
     */
    public void setContrast(int contrast) {
        mContrast = contrast;
    }

    /**
     * @return the result
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @param result the result to set
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * @see AnalyzeResultData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        mResult = buffer[PinpadDefine.INDEX_PARAMETER];
        if (mResult != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.HMI, mResult, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(mResult);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        mContrast = (int) buffer[PinpadDefine.INDEX_PARAMETER + 4];
        mLump = (buffer[PinpadDefine.INDEX_PARAMETER + 8] & 0x01) > 0;
        mMode = (buffer[PinpadDefine.INDEX_PARAMETER + 8] & (0x01 << 1)) == 0;

        return true;
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonLCD = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonLCD.put(MODE, isMode());
            jsonLCD.put(LUMP, isLump());
            jsonLCD.put(CONTRAST, getContrast());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(LCD, JSONObject.NULL);
            } else {
                json.put(LCD, jsonLCD);
            }

            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
