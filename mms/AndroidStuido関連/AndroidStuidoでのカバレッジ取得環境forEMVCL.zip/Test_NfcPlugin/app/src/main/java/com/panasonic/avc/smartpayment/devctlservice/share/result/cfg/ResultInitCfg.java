
package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultInitCfg処理結果データ
 */
public class ResultInitCfg extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultInitCfg(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitCfg() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitCfg> CREATOR = new Parcelable.Creator<ResultInitCfg>() {
        public ResultInitCfg createFromParcel(Parcel in) {
            return new ResultInitCfg(in);
        }

        public ResultInitCfg[] newArray(int size) {
            return new ResultInitCfg[size];
        }
    };

}
