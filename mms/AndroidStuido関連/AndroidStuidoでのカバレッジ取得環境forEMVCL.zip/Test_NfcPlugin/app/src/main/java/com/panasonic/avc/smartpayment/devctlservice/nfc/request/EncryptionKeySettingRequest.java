package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.ENCRYPTION_KEY_SETTING_REQUEST.EXPONENTDATA;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.ENCRYPTION_KEY_SETTING_REQUEST.MODULUSDATA;

import java.util.Arrays;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * 暗号鍵設定Requestクラス.
 * 
 */
public class EncryptionKeySettingRequest extends BaseRequest {

    /** @brief ログ用タグ */
    private static final String TAG = EncryptionKeySettingRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x80;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x41;

    /** @brief モジュラス . */
    private byte[] mModulusData;
    /** @brief エクスポーネント . */
    private byte[] mExponentData;

    /**
     * モジュラスを設定する.
     * 
     * @param modulusData モジュラス
     */
    public void setModulusData(byte[] modulusData) {
        mModulusData = modulusData;
    }

    /**
     * エクスポーネントを設定する.
     * 
     * @param exponentData エクスポーネント
     */
    public void setExponentData(byte[] exponentData) {
        mExponentData = exponentData;
    }

    /** Constructor */
    public EncryptionKeySettingRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // モジュラス:必須チェック
        if (mModulusData == null) {
            Logger.e(TAG, "isValidValue mModulusData is null ");
            return false;
        }

        // サイズチェック
        if (mModulusData.length != MODULUSDATA.getDataLength()) {
            Logger.e(TAG, "isValidValue mModulusData length unmatch = "
                    + mModulusData.length);
            return false;
        }

        // 値チェック（オール0x00の場合エラー）
        boolean checkFlg = false;
        for (int i = 0; i < mModulusData.length; i++) {
            if (mModulusData[i] != (byte) 0x00) {
                checkFlg = true;
            }
        }

        if (!checkFlg) {
            // 1件も0x00以外が無かった場合
            Logger.e(TAG,
                    "isValidValue mModulusData unmatch ="
                            + Arrays.toString(mModulusData));
            return false;
        }

        // エクスポーネント:必須チェック
        if (mExponentData == null) {
            Logger.e(TAG, "isValidValue mExponentData is null ");
            return false;
        }

        // サイズチェック
        if (mExponentData.length != EXPONENTDATA.getDataLength()) {
            Logger.e(TAG, "isValidValue mExponentData length unmatch = "
                    + mExponentData.length);
            return false;
        }

        // 値チェック（オール0x00の場合エラー）
        checkFlg = false;
        for (int i = 0; i < mExponentData.length; i++) {
            if (mExponentData[i] != (byte) 0x00) {
                checkFlg = true;
            }
        }

        if (!checkFlg) {
            // 1件も0x00以外が無かった場合
            Logger.e(TAG,
                    "isValidValue mExponentData unmatch ="
                            + Arrays.toString(mExponentData));
            return false;
        }

        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return toCommand(ByteUtil.mergeByteArray(mModulusData, mExponentData));
    }
}
