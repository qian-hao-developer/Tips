
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultCheckHealth extends ResultData {

    /** @brief 非接触ICカードリーダライタの利用可否情報 **/
    boolean mSts;

    /** @brief 非接触ICカードリーダライタの利用可否情報タグ **/
    boolean mTamper;

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth() {

    }

    /**
     * @brief 非接触ICカードリーダライタの利用可否情報を取得します
     * @return 非接触ICカードリーダライタの利用可否情報
     */
    public boolean getSts() {
        return mSts;
    }

    /**
     * @brief 非接触ICカードリーダライタの利用可否情報を設定します
     * @param[in] 接触ICカードリーダライタの利用可否情報
     */
    public void setSts(boolean sts) {
        mSts = sts;
    }

    /**
     * @brief 不正開封検知情報を取得します
     * @param[in] 不正開封検知情報
     */
    public boolean isTamper() {
        return mTamper;
    }

    /**
     * @brief 不正開封検知情報を設定します
     * @return 不正開封検知情報
     */
    public void setTamper(boolean tamper) {
        mTamper = tamper;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCheckHealth> CREATOR = new Parcelable.Creator<ResultCheckHealth>() {

        @Override
        public ResultCheckHealth createFromParcel(Parcel in) {
            return new ResultCheckHealth(in);
        }

        @Override
        public ResultCheckHealth[] newArray(int size) {
            return new ResultCheckHealth[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mSts ? 1 : 0);
        dest.writeInt(mTamper ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mSts = in.readInt() == 1 ? true : false;
        mTamper = in.readInt() == 1 ? true : false;
    }

}
