
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultSetImage extends ResultFeliCaApl {

    /**
     * @brief コンストラクタ
     */
    public ResultSetImage(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetImage() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetImage> CREATOR = new Parcelable.Creator<ResultSetImage>() {

        @Override
        public ResultSetImage createFromParcel(Parcel in) {
            return new ResultSetImage(in);
        }

        @Override
        public ResultSetImage[] newArray(int size) {
            return new ResultSetImage[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

}
