
package com.panasonic.avc.smartpayment.devctlservice.share.result.bcr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * TermBCRの実行結果データ
 */
public class ResultTermBCR extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermBCR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermBCR() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermBCR> CREATOR = new Parcelable.Creator<ResultTermBCR>() {
        public ResultTermBCR createFromParcel(Parcel in) {
            return new ResultTermBCR(in);
        }

        public ResultTermBCR[] newArray(int size) {
            return new ResultTermBCR[size];
        }
    };
}
