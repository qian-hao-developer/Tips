
package com.panasonic.avc.smartpayment.devctlservice.share.response.msr;

import java.util.Arrays;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * event_MSDataのコールバックデータ
 */
public class ResponseMsData implements Parcelable {
    /** @brief 読み取りオプション */
    private int mMode;

    /** @brief トラックデータ数 */
    private static final int TRACK_NUM = 3;

    /** @brief 磁気カード読み取り操作情報 */
    private int mResult;

    /** @brief 磁気カード読み取り操作情報タグ */
    private static final String RESULT = "result";

    /** @brief 磁気カードデータ情報タグ */
    private static final String MSDATA = "msdata";

    /** @brief トラックデータ状態 */
    private int[] mSts = new int[TRACK_NUM];

    /** @brief トラックデータ状態タグ */
    private static final String STS = "sts";

    /** @brief 暗号化されたトラックデータ */
    private String mTrackData;

    /** @brief 暗号化されたトラックデータタグ */
    private static final String TRACKDATA = "trackdata";

    /** @brief トランザクションキー情報 */
    private String mKsn;

    /** @brief トランザクションキー情報タグ */
    private static final String KSN = "ksn";

    /** @brief 磁気カードデータ検査情報タグ */
    private static final String CHKDATA = "chkdata";

    /** @brief トラックデータのデータ長 */
    private int[] mLen = new int[TRACK_NUM];

    /** @brief トラックデータのデータ長タグ */
    private static final String LEN = "len";

    /** @brief トラックデータの検査結果 */
    private int[] mChk = new int[TRACK_NUM];

    /** @brief トラックデータの検査結果タグ */
    private static final String CHK = "chk";

    /**
     * @brief コンストラクタ
     * @param mode 読み取りオプション
     * @param result 磁気カード読み取り操作情報
     * @param sts_jis2 トラックデータ(JIS-Ⅱ)の状態
     * @param sts_jis1track1 トラックデータ(JIS-ⅠTrack1)の状態
     * @param sts_jis1track2 トラックデータ(JIS-ⅠTrack2)の状態
     * @param trackdata 暗号化されたトラックデータ
     * @param ksn トランザクションキー情報
     * @param len_jis2 トラックデータ(JIS-Ⅱ)のデータ長
     * @param len_jis1track1 トラックデータ(JIS-ⅠTrack1)のデータ長
     * @param len_jis1track2 トラックデータ(JIS-ⅠTrack2)のデータ長
     * @param chk_jis2 トラックデータ(JIS-Ⅱ)の検査結果
     * @param chk_jis1track1 トラックデータ(JIS-ⅠTrack1)の検査結果
     * @param chk_jis1track2 トラックデータ(JIS-ⅠTrack2)の検査結果
     */
    public ResponseMsData(int mode, int result, int sts_jis2, int sts_jis1track1,
            int sts_jis1track2,
            String trackdata, String ksn, int len_jis2, int len_jis1track1, int len_jis1track2,
            int chk_jis2, int chk_jis1track1, int chk_jis1track2) {
        mMode = mode;
        mResult = result;
        mSts[0] = sts_jis2;
        mSts[1] = sts_jis1track1;
        mSts[2] = sts_jis1track2;
        mTrackData = trackdata;
        mKsn = ksn;
        mLen[0] = len_jis2;
        mLen[1] = len_jis1track1;
        mLen[2] = len_jis1track2;
        mChk[0] = chk_jis2;
        mChk[1] = chk_jis1track1;
        mChk[2] = chk_jis1track2;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseMsData() {

    }

    /**
     * @brief コンストラクタ
     */
    public ResponseMsData(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResponseMsData> CREATOR = new Parcelable.Creator<ResponseMsData>() {
        public ResponseMsData createFromParcel(Parcel in) {
            return new ResponseMsData(in);
        }

        public ResponseMsData[] newArray(int size) {
            return new ResponseMsData[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mMode);
        dest.writeInt(mResult);
        dest.writeIntArray(mSts);
        dest.writeString(mTrackData);
        dest.writeString(mKsn);
        dest.writeIntArray(mLen);
        dest.writeIntArray(mChk);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mMode = in.readInt();
        mResult = in.readInt();
        in.readIntArray(mSts);
        mTrackData = in.readString();
        mKsn = in.readString();
        in.readIntArray(mLen);
        in.readIntArray(mChk);
    }

    /**
     * @brief 読み取りオプションを取得します
     * @return 読み取りオプション
     */
    public int getMode() {
        return mMode;
    }

    /**
     * @brief 読み取りオプションを設定します
     * @param result 読み取りオプション
     */
    public void setMode(int mode) {
        mMode = mode;
    }

    /**
     * @brief 磁気カード読み取り操作情報を取得します
     * @return 磁気カード読み取り操作情報
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @brief 磁気カード読み取り操作情報を設定します
     * @param result 磁気カード読み取り操作情報
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * @brief トラックデータ状態を取得します
     * @return トラックデータ状態
     */
    public int[] getSts() {
        return mSts;
    }

    /**
     * @brief トラックデータ状態を設定します
     * @param sts トラックデータ状態
     */
    public void setSts(int[] sts) {
        for (int i = 0; i < mSts.length; i++) {
            mSts[i] = sts[i];
        }
    }

    /**
     * @brief 暗号化されたトラックデータを取得します
     * @return 暗号化されたトラックデータ
     */
    public String getTrackData() {
        return mTrackData;
    }

    /**
     * @brief 暗号化されたトラックデータを設定します
     * @param trackData 暗号化されたトラックデータ
     */
    public void setTrackData(String trackData) {
        mTrackData = trackData;
    }

    /**
     * @brief トランザクションキー情報を取得します
     * @return トランザクションキー情報
     */
    public String getKsn() {
        return mKsn;
    }

    /**
     * @brief トランザクションキー情報を設定します
     * @param ksn トランザクションキー情報
     */
    public void setKsn(String ksn) {
        mKsn = ksn;
    }

    /**
     * @brief トラックデータのデータ長を取得します
     * @return トラックデータのデータ長
     */
    public int[] getLen() {
        return mLen;
    }

    /**
     * @brief トラックデータのデータ長を設定します
     * @param sts トラックデータのデータ長
     */
    public void setLen(int[] len) {
        for (int i = 0; i < mLen.length; i++) {
            mLen[i] = len[i];
        }
    }

    /**
     * @brief トラックデータの検査結果を取得します
     * @return トラックデータの検査結果
     */
    public int[] getChk() {
        return mChk;
    }

    /**
     * @brief トラックデータの検査結果を設定します
     * @param sts トラックデータの検査結果
     */
    public void setChk(int[] chk) {
        for (int i = 0; i < mChk.length; i++) {
            mChk[i] = chk[i];
        }
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(RESULT, getResult());
            if (getResult() != PluginDefine.MSDATA_RESULT_READING) {
                json.put(MSDATA, JSONObject.NULL);
                json.put(CHKDATA, JSONObject.NULL);
            } else {
                if (getMode() != PluginDefine.MSREAD_MODE_CHECK) {
                    JSONObject jsonMsData = new JSONObject();
                    JSONArray jsonArraySts = new JSONArray(Arrays.asList());
                    for (int sts : getSts()) {
                        jsonArraySts.put(sts);
                    }
                    jsonMsData.put(STS, jsonArraySts);
                    if (getTrackData() != null && getTrackData().length() != 0) {
                        jsonMsData.put(TRACKDATA, getTrackData());
                    } else {
                        jsonMsData.put(TRACKDATA, JSONObject.NULL);
                    }
                    if (getKsn() != null && getKsn().length() != 0) {
                        jsonMsData.put(KSN, getKsn());
                    } else {
                        jsonMsData.put(KSN, JSONObject.NULL);
                    }
                    json.put(MSDATA, jsonMsData);
                    json.put(CHKDATA, JSONObject.NULL);
                } else {
                    JSONObject jsonChkData = new JSONObject();
                    JSONArray jsonArrayLen = new JSONArray(Arrays.asList());
                    for (int len : getLen()) {
                        jsonArrayLen.put(len);
                    }
                    JSONArray jsonArrayChk = new JSONArray(Arrays.asList());
                    for (int chk : getChk()) {
                        jsonArrayChk.put(chk);
                    }
                    json.put(MSDATA, JSONObject.NULL);
                    jsonChkData.put(LEN, jsonArrayLen);
                    jsonChkData.put(CHK, jsonArrayChk);
                    json.put(CHKDATA, jsonChkData);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
