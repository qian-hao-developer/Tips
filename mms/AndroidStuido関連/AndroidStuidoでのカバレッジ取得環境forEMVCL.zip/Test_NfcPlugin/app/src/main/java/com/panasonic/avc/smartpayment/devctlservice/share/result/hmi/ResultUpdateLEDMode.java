
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * UpdateLEDModeの実行結果データ
 */
public class ResultUpdateLEDMode extends ResultData {

    /** @brief LED の設定状態タグ */
    private static final String LED = "led";

    /** @brief LED#1、LED#2 の設定状態情報 */
    private int[] mMode = new int[2];

    /** @brief LED#1、LED#2 の設定状態情報タグ */
    private static final String MODE = "mode";

    /**
     * @brief コンストラクタ
     */
    public ResultUpdateLEDMode(Parcel in) {
        // super(in);
        // super(Parcel) を実行すると mMode が初期化されないまま readFromParcel(Parcel) が実行時され、
        // NullPointerException となるので super(Parcel) は実行しない
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultUpdateLEDMode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultUpdateLEDMode> CREATOR = new Parcelable.Creator<ResultUpdateLEDMode>() {
        public ResultUpdateLEDMode createFromParcel(Parcel in) {
            return new ResultUpdateLEDMode(in);
        }

        public ResultUpdateLEDMode[] newArray(int size) {
            return new ResultUpdateLEDMode[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeIntArray(mMode);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        in.readIntArray(mMode);
    }

    /**
     * @brief LED#1、LED#2 の設定状態情報を取得します
     * @return LED#1、LED#2 の設定状態情報
     */
    public int[] getMode() {
        return mMode;
    }

    /**
     * @brief LED#1、LED#2 の設定状態情報を設定します
     * @param[in] mode LED#1、LED#2 の設定状態情報
     */
    public void setMode(int[] mode) {
        if (mode.length < mMode.length) {
            return;
        }
        for (int i = 0; i < mMode.length; i++) {
            mMode[i] = mode[i];
        }
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonLED = new JSONObject();
        JSONArray jsonMode = new JSONArray();

        try {
            json.put(DEVICE, getDevice());
            int[] mode = getMode();
            for (int tmp : mode) {
                jsonMode.put(tmp);
            }
            jsonLED.put(MODE, jsonMode);
            json.put(LED, jsonLED);
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
