
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultClearSPAD extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultClearSPAD(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultClearSPAD() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultClearSPAD> CREATOR = new Parcelable.Creator<ResultClearSPAD>() {

        @Override
        public ResultClearSPAD createFromParcel(Parcel in) {
            return new ResultClearSPAD(in);
        }

        @Override
        public ResultClearSPAD[] newArray(int size) {
            return new ResultClearSPAD[size];
        }
    };
}
