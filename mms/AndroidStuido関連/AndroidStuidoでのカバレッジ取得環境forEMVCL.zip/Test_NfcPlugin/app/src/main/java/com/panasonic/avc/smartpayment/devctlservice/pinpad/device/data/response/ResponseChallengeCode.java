
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * 暗証番号入力用チャレンジ取得応答
 */
public class ResponseChallengeCode extends ResponseData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x04;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x03;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x12;

    /** @brief 処理結果 **/
    private int mResult;

    /** @brief チャレンジコード **/
    private byte[] mChallenge;

    /** @brief 処理結果 パラメータエラー **/
    private static final byte PINPAD_CHALLENGE_RESULT_PARAM_ERROR = 0x06;

    /** @brief 処理結果 自己リブートタイマS **/
    private static final byte PINPAD_CHALLENGE_RESULT_SELF_REBOOT_S = (byte) 0xb0;

    /** @brief 処理結果 自己リブートタイマF **/
    private static final byte PINPAD_CHALLENGE_RESULT_SELF_REBOOT_F = (byte) 0xb1;

    /**
     * @brief コンストラクタ
     */
    public ResponseChallengeCode() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @return the result
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @param result the result to set
     */
    public void setResult(int result) {
        mResult = result;
    }

    public byte[] getChallenge() {
        return mChallenge;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        byte result = buffer[PinpadDefine.INDEX_PARAMETER];

        if (result == PluginDefine.RESULT_DEVICE_SCCESS
                || result == PINPAD_CHALLENGE_RESULT_SELF_REBOOT_S
                || result == PINPAD_CHALLENGE_RESULT_SELF_REBOOT_F) {
            mResult = PluginDefine.RESULT_DEVICE_SCCESS;
        } else {
            if (result == PINPAD_CHALLENGE_RESULT_PARAM_ERROR) {
                setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            } else {
                mResult = result;
                setDevice(mResult);
                setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            }
            mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.PED, mResult, -1,
                    buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            return false;
        }

        mChallenge = new byte[16];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 2, mChallenge, 0, mChallenge.length);

        return true;
    }

}
