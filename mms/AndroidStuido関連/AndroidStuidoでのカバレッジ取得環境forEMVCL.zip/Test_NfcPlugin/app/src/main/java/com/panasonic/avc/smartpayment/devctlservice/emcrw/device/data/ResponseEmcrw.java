
package com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data;

import android.util.Log;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

public class ResponseEmcrw {

    private final String TAG = "ResponseEmcrw";

    /** @brief プロトコルリンク */
    private int mLinkLevel = EmcrwDefine.LINK_LEVEL_CCT;

    private int mHeaLength = 0;

    private final int STX_SIZE = 1;

    protected int HEAD_LENGTH_CCT = 5;
    protected int HEAD_LENGTH_PINPAD = 6;

    protected byte[] mBuffer = null;
    protected byte mID;
    protected byte mMC;
    protected byte mSC;
    protected int mLength;
    protected byte[] mDataLength = null;
    protected byte[] mData = null;

    protected int mCommandCode;
    protected int mEndCode;
    protected int mEndSubCode;

    /**
     * @brief コンストラクタ
     */
    public ResponseEmcrw() {
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseEmcrw(int level) {
        mLinkLevel = level;

        if (mLinkLevel == EmcrwDefine.LINK_LEVEL_CCT) {
            mHeaLength = HEAD_LENGTH_CCT;
        } else if (mLinkLevel == EmcrwDefine.LINK_LEVEL_PINPAD) {
            mHeaLength = HEAD_LENGTH_PINPAD;
        }
    }

    public boolean inputResponse(byte[] bytes) {

        if (bytes == null || bytes.length == 0 || bytes[0] == 0x00
                || bytes.length < (STX_SIZE + mHeaLength)) {
            mBuffer = null;
            return false;
        }

        if (checkResponseData(bytes)) {
            mBuffer = new byte[bytes.length];
            System.arraycopy(bytes, 0, mBuffer, 0, bytes.length);

            // レスポンスをセットする
            setResponse();
        } else {
            return false;
        }
        return true;
    }

    private void setResponseCCT() {
        mID = mBuffer[1];
        mMC = mBuffer[2];
        mSC = mBuffer[3];
        mDataLength = new byte[2];
        mDataLength[0] = mBuffer[4];
        mDataLength[1] = mBuffer[5];
        mLength = CalcUtil.toInt(mBuffer[4], mBuffer[5]);
        if (mLength != 0) {
            mData = new byte[mLength];
            System.arraycopy(mBuffer, 6, mData, 0, mLength);
        }
        if (mLength >= 3) {
            mCommandCode = CalcUtil.toInt(mData[0], (byte) 0x00);
            mEndCode = CalcUtil.toInt(mData[1], (byte) 0x00);
            mEndSubCode = CalcUtil.toInt(mData[2], (byte) 0x00);
        }
    }

    private void setResponsePINPAD() {
        mID = mBuffer[1];
        mMC = mBuffer[8];
        mSC = mBuffer[9];
        mDataLength = new byte[2];
        mDataLength[0] = mBuffer[10];
        mDataLength[1] = mBuffer[11];
        mLength = CalcUtil.toInt(mBuffer[10], mBuffer[11]);
        if (mLength != 0) {
            mData = new byte[mLength];
            System.arraycopy(mBuffer, 12, mData, 0, mLength);
        }
    }

    private void setResponse() {
        if (mLinkLevel == EmcrwDefine.LINK_LEVEL_CCT) {
            setResponseCCT();
        } else if (mLinkLevel == EmcrwDefine.LINK_LEVEL_PINPAD) {
            setResponsePINPAD();
        }
    }

    public void dumpBuffer() {
        String log = "";
        // log += "ID=[" + mID + "],";
        log += "MC=[" + CalcUtil.byte2hex(mMC) + "],";
        log += "SC=[" + CalcUtil.byte2hex(mSC) + "],";
        log += "LENGTH=[" + mLength + "],";
        if (mLength != 0) {
            log += "DATA=[" + CalcUtil.byte2hex(mData) + "]";
        } else {
            log += "DATA=[]";
        }
        if (mLength >= 3) {
            log += ",EndCode=[" + mEndCode + "]";
            log += ",EndSubCode=[" + mEndSubCode + "]";
        } else {
            log += ",EndCode=[]";
            log += ".EndSubCode=[]";
        }

        Log.d(TAG, log);
    }

    public boolean isSuccess() {
        if (mEndCode == (byte) 0x00 && mEndSubCode == (byte) 0x00) {
            return true;
        }
        return false;
    }

    public byte getID() {
        return mID;
    }

    public byte getMC() {
        return mMC;
    }

    public byte getSC() {
        return mSC;
    }

    public byte[] getDataLength() {
        return mDataLength;
    }

    public byte[] getData() {
        return mData;
    }

    public byte[] getBuffer() {
        return mBuffer;
    }

    public int getCommandCode() {
        return mCommandCode;
    }

    public int getEndCode() {
        return mEndCode;
    }

    public int getEndSubCode() {
        return mEndSubCode;
    }

    public int getLength() {
        return mLength;
    }

    /**
     * @brief レスポンスデータを解析する(データ長、CRC)
     * @param bytes チェックしたいバイト列
     * @return 成否
     */
    protected boolean checkResponseData(byte[] bytes) {

        if (bytes == null || bytes.length < EmcrwDefine.DATA_SIZE_WITHOUT_PARAMETER) {
            return false;
        }

        if (bytes[0] != EmcrwDefine.STX_CODE) {
            return false;
        }

        if (bytes[bytes.length - EmcrwDefine.CRC_SIZE - 1] != EmcrwDefine.ETX_CODE) {
            return false;
        }

        byte[] calcCRC = new byte[bytes.length - EmcrwDefine.CRC_NOT_CALC_SIZE];

        System.arraycopy(bytes, EmcrwDefine.STX_SIZE, calcCRC, 0, bytes.length
                - EmcrwDefine.CRC_NOT_CALC_SIZE);

        int crc = CalcUtil.createCRC(calcCRC);

        int inputCrc = (int) ((bytes[bytes.length - EmcrwDefine.CRC_SIZE] & 0xff) << 8)
                | (int) (bytes[bytes.length - EmcrwDefine.CRC_SIZE + 1] & 0xff);

        if (crc != inputCrc) {
            return false;
        }

        return true;
    }
}
