package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

/**
 * APダウンロードデータResponseクラス.
 * 
 */
public class APDownloadDataResponse extends BaseDownloadDataResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = APDownloadDataResponse.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x81;

    /** Constructor */
    public APDownloadDataResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
