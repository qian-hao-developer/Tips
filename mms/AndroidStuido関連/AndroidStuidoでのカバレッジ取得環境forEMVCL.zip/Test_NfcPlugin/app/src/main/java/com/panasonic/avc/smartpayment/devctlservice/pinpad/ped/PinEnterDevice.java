
package com.panasonic.avc.smartpayment.devctlservice.pinpad.ped;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.msr.MagneticStripeCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAck;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestChallengeCode;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestInitPed;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestInterruption;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestPin;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAck;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAdvanceDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseChallengeCode;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.NotifyStatusListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.PluginType;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.StatusType;
import com.panasonic.avc.smartpayment.devctlservice.share.IPedServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ped.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ped.ResponsePinData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultCancelGetPin;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultGetSignatureKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultInitPed;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultStartGetEMPinData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultStartGetPinData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultTermPed;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;
import com.panasonic.avc.smartpayment.devctlservice.tamper.TamperDetectionInfoController;

/**
 * PinEnterDevice処理部
 */
public class PinEnterDevice {

    /** @brief デバッグ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = PinEnterDevice.class.getName();

    /** @brief シングルトンインスタンス */
    private static PinEnterDevice sInstance = new PinEnterDevice();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IPedServiceListener> mIPedServiceListenerList = new ConcurrentHashMap<String, IPedServiceListener>();

    /** @brief 非同期用スレッド(InitICRW) */
    private Thread mStartGetPedDataThread;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 5000;

    /** @brief PIN入力のタイムアウト */
    private static final int PIN_TIME_OUT = 500;

    /** @brief PIN入力のタイムアウト */
    private static final int PIN_TIME_OUT_COUNT = 500;

    /** @brief データ読み込み終了フラグ */
    private boolean mIsActive;

    /** @brief コンテキスト */
    private Context mContext;

    /** @brief プラグイン状態通知リスナーリスト */
    private ArrayList<NotifyStatusListener> mNotifyStatusListenerList = new ArrayList<NotifyStatusListener>();

    /** @brief 現在のプラグイン状態 */
    private StatusType mStatus = StatusType.TERM;

    /**
     * @brief コンストラクタ
     */
    private PinEnterDevice() {

    }

    /**
     * @brief シングルトンインスタンスを取得する
     * @return インスタンス
     */
    public static PinEnterDevice getInstance() {
        return sInstance;
    }

    /**
     * @brief Pedを初期化します
     * @param[in] time PIN入力デバイスを整時するための時刻情報
     * @return 実行結果
     */
    public ResultInitPed initPed(String time) {
        ResultInitPed result = new ResultInitPed();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestInitPed request = new RequestInitPed(time);
        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        notifyStatus(StatusType.INIT);
        return result;
    }

    /**
     * @brief Ped入力を開始します(共通)
     * @param[in] request 暗証番号入力要求
     * @return 実行結果
     * @see #startGetPinData(boolean, int, int, String, String, int, int, int,
     *      int, String, String, int)
     * @see #startGetEMPinData(boolean, int, int, int, boolean, String, int,
     *      int, int)
     */
    private ResultData startGetPinDataCommon(final RequestPin request) {

        ResultData result = new ResultData();

        // 暗証番号入力用チャレンジ取得
        RequestChallengeCode requestChallenge = new RequestChallengeCode();
        ResponseChallengeCode responseChallenge = new ResponseChallengeCode();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!requestChallenge.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mStartGetPedDataThread != null && mStartGetPedDataThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        byte[] bufferChallenge;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestChallenge, TIME_OUT);
            bufferChallenge = mControlDeviceManager.read(TIME_OUT);
        }

        if (isTimeout(bufferChallenge)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            mControlDeviceManager.unlock();
            return result;
        } else if (!responseChallenge.inputPinpadResult(bufferChallenge)) {
            mControlDeviceManager.unlock();
            result.setDevice(responseChallenge.getDevice());
            result.setUpos(responseChallenge.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        MagneticStripeCard magneticStripeCard = MagneticStripeCard.getInstance();
        ResultGetSignatureKey key = magneticStripeCard.getSignatureKey();
        if (key.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                || key.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            mControlDeviceManager.unlock();
            return result;
        }

        request.setChallenge(responseChallenge.getChallenge());
        request.setKey(key.getKey());

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            mControlDeviceManager.unlock();
            return result;
        }

        byte[] buffer;
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        ResponseAck ack = new ResponseAck();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            mControlDeviceManager.unlock();
            return result;
        } else if (!ack.inputPinpadResult(buffer)) {
            result.setDevice(ack.getDevice());
            result.setUpos(ack.getUpos());
            mControlDeviceManager.unlock();
            return result;
        }

        mIsActive = true;
        mStartGetPedDataThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    mControlDeviceManager.unlock();
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }
                int count = 0;
                while (mIsActive) {
                    byte[] buffer = mControlDeviceManager.read(PIN_TIME_OUT);
                    ResponsePinData response = new ResponsePinData();

                    if (isTimeout(buffer)) {
                        if (!mIsActive) {
                            // Term 時に抜ける
                            break;
                        } else if (count < PIN_TIME_OUT_COUNT) {
                            count++;
                            continue;
                        } else {
                            response.setResult(ResponsePinData.PLUGIN_TIMEOUT);
                        }
                    } else if (!response.inputPinpadResult(buffer)) {
                        mControlDeviceManager.unlock();
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                PluginDefine.ERROR_EXT_CODE_REJECT, null);
                        if (isShowError(response.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        return;
                    }

                    response.setTraining(request.getTraining());
                    response.setPintype(request.getPintype());

                    synchronized (mIPedServiceListenerList) {
                        for (Map.Entry<String, IPedServiceListener> listener : mIPedServiceListenerList
                                .entrySet()) {
                            try {
                                listener.getValue().onPinEvent(response);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    RequestAck requestAck = new RequestAck();
                    synchronized (mControlDeviceManager.getLockObject()) {
                        mControlDeviceManager.write(requestAck, TIME_OUT);
                    }
                    mIsActive = false;
                    break;
                }
                mControlDeviceManager.unlock();
            }
        };

        mStartGetPedDataThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief Ped入力を開始します
     * @param[in] training トレーニングモードかどうか
     * @param[in] pintype カードの保有者認証方式
     * @param[in] country 表示する国モード
     * @param[in] currency 通貨コード
     * @param[in] amount 金額
     * @param[in] screenType 表示する画面パターンを指定する
     * @param[in] min 入力PINの最小桁数
     * @param[in] max 入力PINの最大桁数
     * @param[in] indicate バイパス表示パターン
     * @param[in] exp エクスポーネント
     * @param[in] pubkey PINデータ暗号用公開鍵
     * @param[in] isSound 音声案内
     * @return 実行結果
     */
    public ResultStartGetPinData startGetPinData(boolean isTraining, int pintype, int country,
            String currency, String amount, int screenType, int min, int max, int indicate,
            String exp, String pubkey, int isSound) {

        ResultStartGetPinData result = new ResultStartGetPinData();

        final RequestPin request = new RequestPin(isTraining, pintype, country,
                currency, amount, screenType, min, max, indicate, exp, pubkey, isSound);
        ResultData ret = startGetPinDataCommon(request);

        result.setDevice(ret.getDevice());
        result.setUpos(ret.getUpos());
        return result;
    }

    /**
     * @brief 電子マネー用Ped入力を開始します
     * @param[in] training トレーニングモードかどうか
     * @param[in] pintype カードの保有者認証方式
     * @param[in] title1 左端に表示する文字列番号指定
     * @param[in] title2 右端に表示する文字列番号指定
     * @param[in] isShowCountry 通貨表示有無指定
     * @param[in] amount 金額
     * @param[in] min 入力PINの最小桁数
     * @param[in] max 入力PINの最大桁数
     * @param[in] isSound 音声案内
     * @return 実行結果
     */
    public ResultStartGetEMPinData startGetEMPinData(boolean isTraining, int pintype, int title1,
            int title2, boolean isShowCountry, String amount, int min, int max, int isSound) {

        ResultStartGetEMPinData result = new ResultStartGetEMPinData();

        final RequestPin request = new RequestPin(isTraining, pintype, title1, title2,
                isShowCountry, amount, min, max, isSound);
        ResultData ret = startGetPinDataCommon(request);

        result.setDevice(ret.getDevice());
        result.setUpos(ret.getUpos());
        return result;
    }

    /**
     * @brief 署名作成用の中間鍵を取得します
     * @return 実行結果
     */
    protected ResultGetSignatureKey getSignatureKey() {
        MagneticStripeCard magneticStripeCard = MagneticStripeCard.getInstance();
        magneticStripeCard.initMSR();
        ResultGetSignatureKey key = magneticStripeCard.getSignatureKey();
        return key;
    }

    /**
     * @brief PIN入力状態を解除します
     * @return 実行結果
     */
    public ResultCancelGetPin cancelGetPin() {
        final RequestInterruption request = new RequestInterruption();
        ResultCancelGetPin result = new ResultCancelGetPin();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!mIsActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mIsActive = false;
        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief Ped入力デバイスをターミネートします
     * @return 実行結果
     */
    public ResultTermPed termPed() {
        mIsActive = false;
        ResultTermPed result = new ResultTermPed();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        notifyStatus(StatusType.TERM);
        return result;
    }

    /**
     * @brief コールバック用のリスナーを登録します
     * @param[in] listener コールバック先のリスナー
     */
    public void registerPedServiceListener(String tag, IPedServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIPedServiceListenerList) {
            mIPedServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief コールバック用のリスナーを破棄します
     * @param[in] listener 破棄対象リスナー
     */
    public void unregisterPedServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIPedServiceListenerList) {
            mIPedServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, PinEnterDevice.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief Ped入力デバイスの製品品番、シリアル番号、ハード構成情報、APL Version、PF Versionを取得します
     * @return 実行結果
     */
    public ResultGetVersionInfo getVersionInfo() {
        // 機器情報要求
        RequestDeviceInformation requestDeviceInfo = new RequestDeviceInformation();
        ResponseDeviceInformation responseDeviceInfo = new ResponseDeviceInformation();

        // 拡張製品情報取得
        RequestAdvanceDeviceInformation requestAdvanceDevInfo = new RequestAdvanceDeviceInformation();
        ResponseAdvanceDeviceInformation responseAdvanceDevInfo = new ResponseAdvanceDeviceInformation();

        ResultGetVersionInfo result = new ResultGetVersionInfo();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        // 機器情報要求コマンド
        if (!requestDeviceInfo.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mStartGetPedDataThread != null && mStartGetPedDataThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return result;
        }

        byte[] bufferDevInfo;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestDeviceInfo, TIME_OUT);
            bufferDevInfo = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(bufferDevInfo)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseDeviceInfo.inputPinpadResult(bufferDevInfo)) {
            result.setDevice(responseDeviceInfo.getDevice());
            result.setUpos(responseDeviceInfo.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        // タンパ検出時に ICRW/PED の GetVersionInfoを 実行した場合、正常終了(SUCCESS)とする
        // [背景]
        // 顧客アプリがタンパ検出処理を実行する際に、
        // Init→GetVersionInfo→ChkHealth→Term の順にAPI呼出を行う挙動となっている。
        // ChkHealthでタンパ検知有無を判別する前のGetVersionInfoではエラーを返すと
        // 処理が終了してしまうため。
        if (!responseDeviceInfo.isTamper()) {
            // タンパ検知あり
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            result.setModel(null);
            result.setSno(null);
            result.setHdInfo(null);
            result.setAplVer(null);
            result.setPfVer(null);
            return result;
        }

        // 拡張製品情報取得コマンド
        if (!requestAdvanceDevInfo.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] bufferAdvance;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestAdvanceDevInfo, TIME_OUT);
            bufferAdvance = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(bufferAdvance)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseAdvanceDevInfo.inputPinpadResult(bufferAdvance)) {
            result.setDevice(responseAdvanceDevInfo.getDevice());
            result.setUpos(responseAdvanceDevInfo.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setModel(responseAdvanceDevInfo.getProduct());
        result.setSno(responseAdvanceDevInfo.getSerial());
        result.setHdInfo(null);
        result.setAplVer(responseDeviceInfo.getIfd());
        result.setPfVer(responseDeviceInfo.getFirmwareVersion());

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief PIN入力デバイス利用可否情報を取得します
     * @return 実行結果
     */
    public ResultCheckHealth checkHealth() {
        final RequestDeviceInformation request = new RequestDeviceInformation();
        ResultCheckHealth result = new ResultCheckHealth();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mStartGetPedDataThread != null && mStartGetPedDataThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        TamperDetectionInfoController.DEVICE device = TamperDetectionInfoController.DEVICE.PINPAD;
        if (TamperDetectionInfoController.hasTamper(device)) {
            result.setTamper(false);
        } else {
            if (!result.isTamper()) {
                TamperDetectionInfoController.saveTamper(device);
            }
        }
        if (!result.isTamper()) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @brief エラーを送信する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private void sendError(int ecode, int vcode, int extcode, String extinfo) {
        ResponseError error = new ResponseError();
        error.setEcode(ecode);
        error.setVcode(vcode);
        error.setExtcode(extcode);
        error.setExtinfo(extinfo);

        synchronized (mIPedServiceListenerList) {
            for (Map.Entry<String, IPedServiceListener> listener : mIPedServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(error);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param device deviceの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int device) {
        if (device != PluginDefine.RESULT_DEVICE_SCCESS) {
            return true;
        }

        return false;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * @brief プラグイン状態通知リスナーを登録します
     * @param[in] listener リスナー
     */
    public boolean registerNotifyStatusListener(NotifyStatusListener listener) {
        synchronized (mNotifyStatusListenerList) {
            if (!mNotifyStatusListenerList.contains(listener)) {
                return mNotifyStatusListenerList.add(listener);
            }
            return false;
        }
    }

    /**
     * @brief プラグイン状態通知リスナーを解除します
     * @param[in] listener リスナー
     */
    public boolean unregisterNotifyStatusListener(NotifyStatusListener listener) {
        synchronized (mNotifyStatusListenerList) {
            return mNotifyStatusListenerList.remove(listener);
        }
    }

    /**
     * @brief プラグイン状態の通知を要求します
     * @param[in] listener リスナー
     */
    public void requestNotifyStatus() {
        notifyStatus(mStatus);
    }

    /**
     * @brief プラグイン状態を通知します
     * @param[in] status プラグイン状態
     */
    private void notifyStatus(StatusType status) {
        mStatus = status;
        synchronized (mNotifyStatusListenerList) {
            for (NotifyStatusListener listener : mNotifyStatusListenerList) {
                listener.notifyStatus(PluginType.PED, status);
            }
        }
    }

}
