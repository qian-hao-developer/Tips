
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_CutPaperの実行結果データ
 */
public class ResultPrintFlush extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintFlush(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintFlush() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintFlush> CREATOR = new Parcelable.Creator<ResultPrintFlush>() {
        public ResultPrintFlush createFromParcel(Parcel in) {
            return new ResultPrintFlush(in);
        }

        public ResultPrintFlush[] newArray(int size) {
            return new ResultPrintFlush[size];
        }
    };
}
