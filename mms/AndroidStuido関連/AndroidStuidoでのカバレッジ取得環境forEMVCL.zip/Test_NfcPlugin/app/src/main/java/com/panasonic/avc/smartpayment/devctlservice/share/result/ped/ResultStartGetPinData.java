
package com.panasonic.avc.smartpayment.devctlservice.share.result.ped;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * StartGetPINDataの実行結果データ
 */
public class ResultStartGetPinData extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultStartGetPinData(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultStartGetPinData() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultStartGetPinData> CREATOR = new Parcelable.Creator<ResultStartGetPinData>() {
        public ResultStartGetPinData createFromParcel(Parcel in) {
            return new ResultStartGetPinData(in);
        }

        public ResultStartGetPinData[] newArray(int size) {
            return new ResultStartGetPinData[size];
        }
    };
}
