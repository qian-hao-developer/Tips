
package com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.RequestBarcodeReaderData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * バーコードリーダにデータを送信します
 */
public class RequestSendBCR extends RequestBarcodeReaderData  {

    /** @brief 送信データ */
    private String mData;

    /** @brief 送信データサイズ */
    private int mDataSize;

    /**
     * @brief コンストラクタ
     * @param datasz 送信データサイズ
     * @param data 送信データ
     */
    public RequestSendBCR(int datasz, String data) {
        mDataSize = datasz;
        mData = data;
    }

    /**
     * @see RequestBarcodeReaderData#toCommand()
     */
    public byte[] toCommand() {
        return CalcUtil.toByte(mData);
    }

    /**
     * @see RequestBarcodeReaderData#isValidValue()
     */
    public boolean isValidValue() {
        if (mData == null || mData.equals("")) {
            return false;
        }
        try {
            byte[] byteArray = CalcUtil.toByte(mData);
            if (byteArray == null) {
                return false;
            }
            if (byteArray.length != mDataSize) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

}
