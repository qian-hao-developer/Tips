
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_SetImageの実行結果データ
 */
public class ResultPrintSetImage extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintSetImage(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintSetImage() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintSetImage> CREATOR = new Parcelable.Creator<ResultPrintSetImage>() {
        public ResultPrintSetImage createFromParcel(Parcel in) {
            return new ResultPrintSetImage(in);
        }

        public ResultPrintSetImage[] newArray(int size) {
            return new ResultPrintSetImage[size];
        }
    };
}
