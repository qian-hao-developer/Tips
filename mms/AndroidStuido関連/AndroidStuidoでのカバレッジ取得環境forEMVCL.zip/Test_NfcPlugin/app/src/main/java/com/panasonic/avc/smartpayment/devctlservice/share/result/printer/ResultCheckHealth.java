
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * CheckHealth処理結果データ
 */
public class ResultCheckHealth extends ResultPrnData {

    /** @brief プリンタデバイス状態タグ */
    private static final String CONDITION = "condition";

    /** @brief プリンタデバイスの状態情報 */
    private int mSts;

    /** @brief プリンタデバイスの状態情報タグ */
    private static final String STS = "sts";

    /** @brief ペーパーカッターがホーム位置か否か */
    private boolean mCut;

    /** @brief ペーパーカッタータグ */
    private static final String CUT = "cut";

    /** @brief 正常 */
    private static int STS_NORMAL = 0;

    /** @brief 紙切れ検出 */
    public static int STS_PAPER_EMPTY = 1;

    /** @brief ヘッド状態異常 */
    private static int STS_ABNORMAL_HEAD_STATUS = 2;

    /** @brief ヘッド状態異常H */
    private static int STS_ABNORMAL_HEAD_HARD = 3;

    /** @brief ヘッド状態異常S */
    private static int STS_ABNORMAL_HEAD_SOFT = 4;

    /** @brief モータ温度異常 */
    private static int STS_ABNORMAL_MOTER = 5;

    /** @brief 電源電圧異常 */
    private static int STS_ABNORMAL_VOLTAGE = 6;

    /** @brief プリンタカバーオープン */
    private static int STS_ABNORMAL_COVER_OPEN = 7;

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth(Parcel in) {
        super(in);
    }

    /**
     * コンストラクタ
     */
    public ResultCheckHealth() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCheckHealth> CREATOR = new Parcelable.Creator<ResultCheckHealth>() {
        public ResultCheckHealth createFromParcel(Parcel in) {
            return new ResultCheckHealth(in);
        }

        public ResultCheckHealth[] newArray(int size) {
            return new ResultCheckHealth[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mSts);
        dest.writeInt(mCut ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mSts = in.readInt();
        mCut = in.readInt() == 1 ? true : false;
    }

    /**
     * @brief 状態情報を取得する
     * @return sts 状態情報
     */
    public int getSts() {
        return mSts;
    }

    /**
     * @brief 状態情報を設定する
     * @param sts 状態情報
     */
    public void setSts(int sts) {
        mSts = sts;
    }

    /**
     * @brief ペーパーカット状態を取得する
     * @return ペーパーカット状態
     */
    public boolean isCut() {
        return mCut;
    }

    /**
     * @brief ペーパーカット状態を設定する
     * @param cut ペーパーカット状態
     */
    public void setCut(boolean cut) {
        mCut = cut;
    }

    /**
     * @brief ステータス情報をパースし反映する
     * @param status ステータス
     */
    public void parseStatus(long status) {
        mCut = true;

        boolean paper = (status & 1 << 18) > 0 ? true : false;
        boolean headS = (status & 1 << 14) > 0 ? true : false;
        boolean headH = (status & 1 << 8) > 0 ? true : false;
        boolean moter = (status & 1 << 7) > 0 ? true : false;
        boolean vol = (status & 1 << 15) > 0 ? true : false;
        boolean open = (status & 1 << 10) > 0 ? true : false;

        if (status == 0) {
            mSts = STS_NORMAL;
        } else if (paper) {
            mSts = STS_PAPER_EMPTY;
        } else if (headS) {
            mSts = STS_ABNORMAL_HEAD_SOFT;
        } else if (headH) {
            mSts = STS_ABNORMAL_HEAD_HARD;
        } else if (moter) {
            mSts = STS_ABNORMAL_MOTER;
        } else if (vol) {
            mSts = STS_ABNORMAL_VOLTAGE;
        } else if (open) {
            mSts = STS_ABNORMAL_COVER_OPEN;
        }
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonCondtion = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonCondtion.put(STS, getSts());
            jsonCondtion.put(CUT, isCut());

            if (getDevice() == PluginDefine.RESULT_DEVICE_SCCESS
                    && getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                json.put(CONDITION, jsonCondtion);
            } else if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(CONDITION, JSONObject.NULL);
            } else {
                json.put(CONDITION, jsonCondtion);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
