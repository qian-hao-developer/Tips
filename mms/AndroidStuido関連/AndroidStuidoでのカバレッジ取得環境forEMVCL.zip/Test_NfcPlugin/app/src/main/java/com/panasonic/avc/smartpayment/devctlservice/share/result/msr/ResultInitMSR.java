
package com.panasonic.avc.smartpayment.devctlservice.share.result.msr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitMSRの実行結果データ
 */
public class ResultInitMSR extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultInitMSR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitMSR() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitMSR> CREATOR = new Parcelable.Creator<ResultInitMSR>() {
        public ResultInitMSR createFromParcel(Parcel in) {
            return new ResultInitMSR(in);
        }

        public ResultInitMSR[] newArray(int size) {
            return new ResultInitMSR[size];
        }
    };
}
