
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetInkingThreshold extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetInkingThreshold(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetInkingThreshold() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetInkingThreshold> CREATOR = new Parcelable.Creator<ResultSetInkingThreshold>() {

        @Override
        public ResultSetInkingThreshold createFromParcel(Parcel in) {
            return new ResultSetInkingThreshold(in);
        }

        @Override
        public ResultSetInkingThreshold[] newArray(int size) {
            return new ResultSetInkingThreshold[size];
        }
    };
}
