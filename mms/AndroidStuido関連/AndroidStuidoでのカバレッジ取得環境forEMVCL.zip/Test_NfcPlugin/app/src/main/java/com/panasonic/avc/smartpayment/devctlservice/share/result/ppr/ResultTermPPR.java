
package com.panasonic.avc.smartpayment.devctlservice.share.result.ppr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * TermPPRの実行結果データ
 */
public class ResultTermPPR extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultTermPPR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermPPR() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermPPR> CREATOR = new Parcelable.Creator<ResultTermPPR>() {
        public ResultTermPPR createFromParcel(Parcel in) {
            return new ResultTermPPR(in);
        }

        public ResultTermPPR[] newArray(int size) {
            return new ResultTermPPR[size];
        }
    };
}
