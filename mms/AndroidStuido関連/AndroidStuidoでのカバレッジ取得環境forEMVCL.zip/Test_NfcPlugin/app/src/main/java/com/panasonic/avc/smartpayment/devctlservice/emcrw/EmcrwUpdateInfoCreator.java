
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * IC カードリーダライタ FW 更新情報を取得
 */
public class EmcrwUpdateInfoCreator {

    /**
     * IC カードリーダライタ FW 更新情報を取得する
     * 
     * @param dir_path IC カードリーダライタ FW 更新情報ディレクトリパス
     * @return IC カードリーダライタ FW 更新情報
     */
    public static EmcrwUpdateInfo create(String dir_path) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(dir_path, "firmware")));
            String rwUnityVer = br.readLine();
            String tmp = br.readLine();
            EmcrwPlatformData pfData = new EmcrwPlatformData();
            pfData.setVersion(tmp.substring(0, 16));
            if (tmp.charAt(16) != ' ') { // 区切り文字
                br.close();
                return null;
            }
            pfData.setFileName(tmp.substring(17));
            int app_num = Integer.parseInt(br.readLine());
            EmcrwApplicationDataMap apDataMap = new EmcrwApplicationDataMap(app_num);
            for (int i = 0; i < app_num; i++) {
                tmp = br.readLine();
                EmcrwApplicationData apDate = new EmcrwApplicationData();
                apDate.setID(tmp.substring(0, 2));
                if (tmp.charAt(2) != ':') { // 区切り文字
                    br.close();
                    return null;
                }
                apDate.setVersion(tmp.substring(3, 19));
                if (tmp.charAt(19) != ' ') { // 区切り文字
                    br.close();
                    return null;
                }
                apDate.setFileName(tmp.substring(20));
                apDataMap.add(apDate);
            }
            br.close();
            return new EmcrwUpdateInfo(dir_path, rwUnityVer, pfData, apDataMap);
        } catch (IOException e) {
            return null;
        } catch (NumberFormatException e) {
            return null;
        } catch (IndexOutOfBoundsException e) {
            return null;
        }

    }
}
