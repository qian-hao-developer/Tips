
package com.panasonic.avc.smartpayment.devctlservice.share.result.mgt;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPEDの実行結果データ
 */
public class ResultExecUpdate extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultExecUpdate(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultExecUpdate() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultExecUpdate> CREATOR = new Parcelable.Creator<ResultExecUpdate>() {
        public ResultExecUpdate createFromParcel(Parcel in) {
            return new ResultExecUpdate(in);
        }

        public ResultExecUpdate[] newArray(int size) {
            return new ResultExecUpdate[size];
        }
    };
}
