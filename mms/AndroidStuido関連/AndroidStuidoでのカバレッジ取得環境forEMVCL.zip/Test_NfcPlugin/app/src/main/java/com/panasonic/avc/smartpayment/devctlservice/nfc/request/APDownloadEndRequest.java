package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * APダウンロード終了Requestクラス.
 * 
 */
public class APDownloadEndRequest extends BaseDownloadEndRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = APDownloadEndRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x82;

    /** Constructor */
    public APDownloadEndRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
