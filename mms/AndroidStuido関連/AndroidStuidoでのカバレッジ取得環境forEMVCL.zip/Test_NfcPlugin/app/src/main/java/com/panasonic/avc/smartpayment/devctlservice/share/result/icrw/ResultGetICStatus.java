
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * GetICStatus処理結果データ
 */
public class ResultGetICStatus extends AnalyzeResultData {

    /** @brief ICカード装着情報取得結果 */
    private int mIcCard;

    /** @brief 周辺装置処理結果タグ */
    private static final String ICCARD = "iccard";

    /** @brief マスターコマンド **/
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド **/
    private static final byte SUB_COMMAND = 0x02;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 8;

    /** @brief ICカード挿入済み **/
    private static final int IC_CARD_INSERT = 1;

    /** @brief ICカード未挿入 **/
    private static final int IC_CARD_REMOVE = 2;

    /**
     * @brief コンストラクタ
     */
    public ResultGetICStatus(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetICStatus() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetICStatus> CREATOR = new Parcelable.Creator<ResultGetICStatus>() {
        public ResultGetICStatus createFromParcel(Parcel in) {
            return new ResultGetICStatus(in);
        }

        public ResultGetICStatus[] newArray(int size) {
            return new ResultGetICStatus[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mIcCard);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    @Override
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mIcCard = in.readInt();
    }

    /**
     * @brief ICカードの状態を取得します
     * @retun ICカードの状態
     */
    public int getIcCard() {
        return mIcCard;
    }

    /**
     * @brief ICカードの状態を設定します
     * @param[in] icCard ICカードの状態
     */
    public void setIcCard(int icCard) {
        mIcCard = icCard;
    }

    /**
     * @see AnalyzeResultData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int result = buffer[PinpadDefine.INDEX_PARAMETER];

        if (result != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.RW, result, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        int sensor = buffer[PinpadDefine.INDEX_PARAMETER + 6];
        int activation = buffer[PinpadDefine.INDEX_PARAMETER + 7];

        if (sensor != 0) {
            mIcCard = IC_CARD_INSERT;
        } else {
            mIcCard = IC_CARD_REMOVE;
        }

        return true;
    }

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(ICCARD, JSONObject.NULL);
            } else {
                json.put(ICCARD, getIcCard());
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
