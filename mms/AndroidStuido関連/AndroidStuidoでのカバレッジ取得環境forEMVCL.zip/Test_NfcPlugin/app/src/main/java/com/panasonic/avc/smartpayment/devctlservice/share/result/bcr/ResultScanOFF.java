
package com.panasonic.avc.smartpayment.devctlservice.share.result.bcr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ScanOFFの実行結果データ
 */
public class ResultScanOFF extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultScanOFF(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultScanOFF() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultScanOFF> CREATOR = new Parcelable.Creator<ResultScanOFF>() {
        public ResultScanOFF createFromParcel(Parcel in) {
            return new ResultScanOFF(in);
        }

        public ResultScanOFF[] newArray(int size) {
            return new ResultScanOFF[size];
        }
    };
}
