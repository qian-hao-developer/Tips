
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_Imageの実行結果データ
 */
public class ResultPrintImage extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintImage(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintImage() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintImage> CREATOR = new Parcelable.Creator<ResultPrintImage>() {
        public ResultPrintImage createFromParcel(Parcel in) {
            return new ResultPrintImage(in);
        }

        public ResultPrintImage[] newArray(int size) {
            return new ResultPrintImage[size];
        }
    };
}
