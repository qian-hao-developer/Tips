
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitICRW処理結果データ
 */
public class ResultInitICRW extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultInitICRW(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitICRW() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitICRW> CREATOR = new Parcelable.Creator<ResultInitICRW>() {
        public ResultInitICRW createFromParcel(Parcel in) {
            return new ResultInitICRW(in);
        }

        public ResultInitICRW[] newArray(int size) {
            return new ResultInitICRW[size];
        }
    };
}
