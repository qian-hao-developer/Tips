
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.PrinterDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;

/**
 * プリンタ実行結果解析クラス
 */
public class ResponsePrinterData {

    /** @brief STX */
    private byte mStx = PinpadDefine.STX_CODE;

    /** @brief コマンド種別 */
    protected int mCommandId;

    /** @brief コマンド詳細 */
    protected int mCommandDetail;

    /** @brief SEQ */
    protected int mSequence;

    /** @brief CRC */
    private int mCrc;

    /** @brief upos */
    private int mUpos;

    /** @brief device */
    private int mDevice;

    /** @brief ステータス */
    protected long mStatus;

    /** @brief デバイスエラーの有無 */
    protected boolean mDeviceError;

    /** @brief エラー詳細 */
    protected int mExtCode;

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    protected boolean mLackDataSize;

    public int getExtCode() {
        return mExtCode;
    }

    public void setExtCode(int extCode) {
        mExtCode = extCode;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponsePrinterData() {

    }

    /**
     * @brief STXを取得する
     * @return STX
     */
    public byte getStx() {
        return mStx;
    }

    /**
     * @brief STXを設定する
     * @param stx STX
     */
    public void setStx(byte stx) {
        mStx = stx;
    }

    /**
     * @brief コマンド種別を取得する
     * @return コマンド種別
     */
    public int getCommandId() {
        return mCommandId;
    }

    /**
     * @brief コマンド種別を設定する
     * @param commandId コマンド種別
     */
    public void setCommandId(int commandId) {
        mCommandId = commandId;
    }

    /**
     * @brief コマンド詳細を取得する
     * @return コマンド詳細
     */
    public int getCommandDetail() {
        return mCommandDetail;
    }

    /**
     * @brief コマンド詳細を設定する
     * @param commandDetail コマンド詳細
     */
    public void setCommandDetail(int commandDetail) {
        mCommandDetail = commandDetail;
    }

    /**
     * @brief シーケンス番号を取得する
     * @return シーケンス番号
     */
    public int getSequence() {
        return mSequence;
    }

    /**
     * @brief シーケンス番号を設定する
     * @param sequence シーケンス番号
     */
    public void setSequence(int sequence) {
        mSequence = sequence;
    }

    /**
     * @brief CRCを取得する
     * @return CRC
     */
    public int getCrc() {
        return mCrc;
    }

    /**
     * @brief CRCを設定する
     * @param crc CRC
     */
    public void setCrc(int crc) {
        mCrc = crc;
    }

    public int getUpos() {
        return mUpos;
    }

    public void setUpos(int upos) {
        mUpos = upos;
    }

    public int getDevice() {
        return mDevice;
    }

    public void setDevice(int device) {
        mDevice = device;
    }

    /**
     * @brief ステータスを取得する
     * @return ステータス
     */
    public long getStatus() {
        return mStatus;
    }

    /**
     * @brief ステータスを設定する
     * @param status ステータスs
     */
    public void setStatus(long status) {
        mStatus = status;
    }

    /**
     * @brief 応答解析を行う
     * @param bytes 応答バイト列
     * @return 解析できたかどうか
     */
    public boolean inputPrinterResult(byte[] bytes) {
        return false;
    }

    /**
     * @brief データの上限下限チェック
     * @return 問題があるかどうか
     */
    public boolean isValidValue() {
        return false;
    }

    public boolean lackDataSize() {
        return mLackDataSize;
    }

    /**
     * @brief PINPADからのレスポンスをデータサイズにカットする
     * @param bytes レスポンスデータ
     * @return カット後のデータ
     */
    protected byte[] cutPinpadResult(byte[] bytes) {
        if (bytes == null || bytes.length < PrinterDefine.DATA_SIZE_WITHOUT_PARAMETER) {
            return null;
        }

        byte low = bytes[PrinterDefine.INDEX_LEN_1];
        byte high = bytes[PrinterDefine.INDEX_LEN_2];

        int len = CalcUtil.toInt(low, high) + PrinterDefine.DATA_SIZE_WITHOUT_PARAMETER;

        if (bytes.length < len) {
            return null;
        }

        byte[] buffer = new byte[len];

        System.arraycopy(bytes, 0, buffer, 0, len);

        return buffer;
    }

    /**
     * ステータス確認
     * 
     * @return 正常/異常
     */
    protected boolean checkStatus() {
        boolean font = (mStatus & 0x02) > 0;
        boolean offline = (mStatus & 0x08) > 0;
        boolean autoPaper = (mStatus & 0x10) > 0;
        boolean paperFeed = (mStatus & 0x40) > 0;
        boolean moter = (mStatus & 0x80) > 0;
        boolean headHW = (mStatus & 0x100) > 0;
        boolean reveive = (mStatus & 0x200) > 0;
        boolean headup = (mStatus & 0x400) > 0;
        boolean cutter = (mStatus & 0x800) > 0;
        boolean mark = (mStatus & 0x1000) > 0;
        boolean fatal = (mStatus & 0x2000) > 0;
        boolean headSW = (mStatus & 0x4000) > 0;
        boolean vol = (mStatus & 0x8000) > 0;
        boolean nearEnd = (mStatus & 0x10000) > 0;
        boolean paperLess = (mStatus & 0x40000) > 0;
        boolean terminal = (mStatus & 0x1000000) > 0;
        boolean param = (mStatus & 0x2000000) > 0;
        boolean error = (mStatus & 0x4000000) > 0;
        boolean image = (mStatus & 0x8000000) > 0;

        if (mStatus == 0) {
            mDeviceError = false;
            return true;
        }

        mDeviceError = true;

        if (paperLess) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_PAPER_LESS;
        } else if (headHW) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_HEAD_HW;
        } else if (headSW) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_HEAD_SW;
        } else if (moter) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_MORTER;
        } else if (vol) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_VOLTAGE;
        } else if (headup) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_COVER_OPEN;
        } else if (font) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_FONT;
        } else if (image) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_IMAGE;
        } else if (param) {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_PARAM;
        } else {
            mExtCode = PluginDefine.ERROR_EXT_PRINTER_OTHER;
        }

        return false;
    }

    /**
     * デバイスエラーの有無
     * 
     * @return 有/無
     */

    public boolean isDeviceError() {
        return mDeviceError;
    }
}
