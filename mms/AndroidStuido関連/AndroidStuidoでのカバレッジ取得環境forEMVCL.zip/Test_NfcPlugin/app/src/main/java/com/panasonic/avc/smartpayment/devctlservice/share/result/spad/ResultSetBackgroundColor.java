
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetBackgroundColor extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetBackgroundColor(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetBackgroundColor() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetBackgroundColor> CREATOR = new Parcelable.Creator<ResultSetBackgroundColor>() {

        @Override
        public ResultSetBackgroundColor createFromParcel(Parcel in) {
            return new ResultSetBackgroundColor(in);
        }

        @Override
        public ResultSetBackgroundColor[] newArray(int size) {
            return new ResultSetBackgroundColor[size];
        }
    };
}
