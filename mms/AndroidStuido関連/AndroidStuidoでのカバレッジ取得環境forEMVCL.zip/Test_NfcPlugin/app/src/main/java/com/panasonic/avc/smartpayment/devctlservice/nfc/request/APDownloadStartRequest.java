package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DOWNLOAD_START_REQUEST.RESERVE;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * APダウンロード開始Requestクラス.
 * 
 */
public class APDownloadStartRequest extends BaseDownloadStartRequest {

    /** @brief ログ用タグ */
    private static final String TAG = APDownloadStartRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x80;

    /** Constructor */
    public APDownloadStartRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    @Override
    public byte[] toCommand() {

        // 先頭予備は処理内で設定する：値初期化は0x00なので不要
        byte[] reserveArray = new byte[RESERVE.getDataLength()];

        return super
                .toCommand(ByteUtil.mergeByteArray(reserveArray, mDataSize));
    }
}
