
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetBootScreenMode extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetBootScreenMode(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetBootScreenMode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetBootScreenMode> CREATOR = new Parcelable.Creator<ResultSetBootScreenMode>() {

        @Override
        public ResultSetBootScreenMode createFromParcel(Parcel in) {
            return new ResultSetBootScreenMode(in);
        }

        @Override
        public ResultSetBootScreenMode[] newArray(int size) {
            return new ResultSetBootScreenMode[size];
        }
    };
}
