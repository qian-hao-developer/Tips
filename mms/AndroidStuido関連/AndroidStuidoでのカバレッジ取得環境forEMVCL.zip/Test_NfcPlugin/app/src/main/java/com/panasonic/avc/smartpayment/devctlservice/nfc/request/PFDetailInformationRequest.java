package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * PFの詳細状態取得コマンド
 */
public class PFDetailInformationRequest extends BaseRequest {

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x04;

    /**
     * @brief コンストラクタ
     */
    public PFDetailInformationRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     *
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        return super.toCommand(null);
    }
}
