
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_EscTextの実行結果データ
 */
public class ResultPrintEscText extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintEscText(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintEscText() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintEscText> CREATOR = new Parcelable.Creator<ResultPrintEscText>() {
        public ResultPrintEscText createFromParcel(Parcel in) {
            return new ResultPrintEscText(in);
        }

        public ResultPrintEscText[] newArray(int size) {
            return new ResultPrintEscText[size];
        }
    };
}
