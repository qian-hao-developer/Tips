package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants;
import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DEVICE_INFORMATION_RESPONSE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * 機器情報要求Responseクラス.
 * 
 */
public class DeviceInformationResponse extends BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = DeviceInformationResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x30;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x10;
    /** @brief SC */
    private static byte SUBCOMMAND_NO_KERNEL = (byte) 0x11;

    /** @brief データ長データ2桁目(LittleEndian) */
    private static byte DATALENGTH_HIGH = (byte) 0x00;
    /** @brief データ長データ1桁目(LittleEndian) */
    private static byte DATALENGTH_LOW = (byte) 0x01;

    /** @brief R/W状態フラグ . */
    private byte mStatusFlg;
    /** @brief R/W状態番号 . */
    private byte mStatusNo;
    /** @brief 音量設定値 . */
    private byte mVolume;
    /** @brief タイマ1設定値 . */
    private byte[] mTimerSetting1;
    /** @brief タイマ2設定値 . */
    private byte[] mTimerSetting2;
    /** @brief タイマ3設定値 . */
    private byte[] mTimerSetting3;
    /** @brief タイマ4設定値 . */
    private byte[] mTimerSetting4;
    /** @brief タイマ5設定値 . */
    private byte[] mTimerSetting5;
    /** @brief LCD表示データ . */
    private byte mLcdMessageData;
    /** @brief 表示言語 . */
    private byte mMessageLanguage;
    /** @brief Readerアプリバージョン . */
    private byte[] mReadApVer;
    /** @brief カーネル C1アプリバージョン . */
    private byte[] mKernelC1ApVer;
    /** @brief カーネル C2アプリバージョン . */
    private byte[] mKernelC2ApVer;
    /** @brief カーネル C3アプリバージョン . */
    private byte[] mKernelC3ApVer;
    /** @brief カーネル C4アプリバージョン . */
    private byte[] mKernelC4ApVer;
    /** @brief カーネル C5アプリバージョン . */
    private byte[] mKernelC5ApVer;
    /** @brief カーネル C6アプリバージョン . */
    private byte[] mKernelC6ApVer;
    /** @brief カーネル C7アプリバージョン . */
    private byte[] mKernelC7ApVer;
    /** @brief カーネル C8アプリバージョン . */
    private byte[] mKernelC8ApVer;
    /** @brief カーネル C9アプリバージョン . */
    private byte[] mKernelC9ApVer;
    /** @brief カーネル C10アプリバージョン . */
    private byte[] mKernelC10ApVer;
    /** @brief カーネル C11アプリバージョン . */
    private byte[] mKernelC11ApVer;
    /** @brief カーネル C12アプリバージョン . */
    private byte[] mKernelC12ApVer;
    /** @brief カーネル C13アプリバージョン . */
    private byte[] mKernelC13ApVer;
    /** @brief カーネル C14アプリバージョン . */
    private byte[] mKernelC14ApVer;
    /** @brief カーネル C15アプリバージョン . */
    private byte[] mKernelC15ApVer;
    /** @brief パラメータ設定日付 . */
    private Calendar mParamSetDate;
    /** @brief EMV設定日付(カーネル共通) . */
    private Calendar mEmvSettingDateKernelCommon;
    /** @brief EMV設定日付(カーネル C1) . */
    private Calendar mEmvSettingDateKernelC1;
    /** @brief EMV設定日付(カーネル C2) . */
    private Calendar mEmvSettingDateKernelC2;
    /** @brief EMV設定日付(カーネル C3) . */
    private Calendar mEmvSettingDateKernelC3;
    /** @brief EMV設定日付(カーネル C4) . */
    private Calendar mEmvSettingDateKernelC4;
    /** @brief EMV設定日付(カーネル C5) . */
    private Calendar mEmvSettingDateKernelC5;
    /** @brief EMV設定日付(カーネル C6) . */
    private Calendar mEmvSettingDateKernelC6;
    /** @brief EMV設定日付(カーネル C7) . */
    private Calendar mEmvSettingDateKernelC7;
    /** @brief EMV設定日付(カーネル C8) . */
    private Calendar mEmvSettingDateKernelC8;
    /** @brief EMV設定日付(カーネル C9) . */
    private Calendar mEmvSettingDateKernelC9;
    /** @brief EMV設定日付(カーネル C10) . */
    private Calendar mEmvSettingDateKernelC10;
    /** @brief EMV設定日付(カーネル C11) . */
    private Calendar mEmvSettingDateKernelC11;
    /** @brief EMV設定日付(カーネル C12) . */
    private Calendar mEmvSettingDateKernelC12;
    /** @brief EMV設定日付(カーネル C13) . */
    private Calendar mEmvSettingDateKernelC13;
    /** @brief EMV設定日付(カーネル C14) . */
    private Calendar mEmvSettingDateKernelC14;
    /** @brief EMV設定日付(カーネル C15) . */
    private Calendar mEmvSettingDateKernelC15;
    /** @brief EMV設定日付(デフォルトカーネル ID追加変更) . */
    private Calendar mEmvSettingDateKernelDefault;
    /** @brief EMV設定日付(Revocation List) . */
    private Calendar mEmvSettingDateRevocationList;
    /** @brief Entry Pointチェックサム . */
    private byte[] mCheckSumEntryPoint;
    /** @brief カーネル C1チェックサム . */
    private byte[] mCheckSumKernelC1;
    /** @brief カーネル C2チェックサム . */
    private byte[] mCheckSumKernelC2;
    /** @brief カーネル C3チェックサム . */
    private byte[] mCheckSumKernelC3;
    /** @brief カーネル C4チェックサム . */
    private byte[] mCheckSumKernelC4;
    /** @brief カーネル C5チェックサム . */
    private byte[] mCheckSumKernelC5;
    /** @brief カーネル C6チェックサム . */
    private byte[] mCheckSumKernelC6;
    /** @brief カーネル C7チェックサム . */
    private byte[] mCheckSumKernelC7;
    /** @brief カーネル C8チェックサム . */
    private byte[] mCheckSumKernelC8;
    /** @brief カーネル C9チェックサム . */
    private byte[] mCheckSumKernelC9;
    /** @brief カーネル C10チェックサム . */
    private byte[] mCheckSumKernelC10;
    /** @brief カーネル C11チェックサム . */
    private byte[] mCheckSumKernelC11;
    /** @brief カーネル C12チェックサム . */
    private byte[] mCheckSumKernelC12;
    /** @brief カーネル C13チェックサム . */
    private byte[] mCheckSumKernelC13;
    /** @brief カーネル C14チェックサム . */
    private byte[] mCheckSumKernelC14;
    /** @brief カーネル C15チェックサム . */
    private byte[] mCheckSumKernelC15;
    /** @brief Entry Pointアプリバージョン . */
    private byte[] mEntryPointAPVer;
    /** @brief ファイルDLL日付１ . */
    private Calendar mFileDLLDate1;
    /** @brief ファイルDLL日付２ . */
    private Calendar mFileDLLDate2;
    /** @brief ファイルDLL日付３ . */
    private Calendar mFileDLLDate3;
    /** @brief ファイルDLL日付４ . */
    private Calendar mFileDLLDate4;
    /** @brief ファイルDLL日付５ . */
    private Calendar mFileDLLDate5;
    /** @brief ファイルDLL日付６ . */
    private Calendar mFileDLLDate6;
    /** @brief ファイルDLL日付７ . */
    private Calendar mFileDLLDate7;
    /** @brief ファイルDLL日付８ . */
    private Calendar mFileDLLDate8;
    /** @brief ファイルDLL日付９ . */
    private Calendar mFileDLLDate9;
    /** @brief ファイルDLL日付１０ . */
    private Calendar mFileDLLDate10;
    /** @brief ファイルDLL日付１１ . */
    private Calendar mFileDLLDate11;
    /** @brief ファイルDLL日付１２ . */
    private Calendar mFileDLLDate12;
    /** @brief ファイルDLL日付１３ . */
    private Calendar mFileDLLDate13;
    /** @brief ファイルDLL日付１４ . */
    private Calendar mFileDLLDate14;
    /** @brief ファイルDLL日付１５ . */
    private Calendar mFileDLLDate15;

    /** Kernelデータ不要か否か. */
    private boolean isNoKernelData = false;

    /**
     * R/W状態フラグを返却する.
     * 
     * @return R/W状態フラグ
     */
    public byte getStatusFlg() {
        return mStatusFlg;
    }

    /**
     * R/W状態番号を返却する.
     * 
     * @return R/W状態番号
     */
    public byte getStatusNo() {
        return mStatusNo;
    }

    /**
     * 音量設定値を返却する.
     * 
     * @return 音量設定値
     */
    public byte getVolume() {
        return mVolume;
    }

    /**
     * タイマ1設定値を返却する.
     * 
     * @return タイマ1設定値
     */
    public byte[] getTimerSetting1() {
        return mTimerSetting1;
    }

    /**
     * タイマ2設定値を返却する.
     * 
     * @return タイマ2設定値
     */
    public byte[] getTimerSetting2() {
        return mTimerSetting2;
    }

    /**
     * タイマ3設定値を返却する.
     * 
     * @return タイマ3設定値
     */
    public byte[] getTimerSetting3() {
        return mTimerSetting3;
    }

    /**
     * タイマ4設定値を返却する.
     * 
     * @return タイマ4設定値
     */
    public byte[] getTimerSetting4() {
        return mTimerSetting4;
    }

    /**
     * タイマ5設定値を返却する.
     * 
     * @return タイマ5設定値
     */
    public byte[] getTimerSetting5() {
        return mTimerSetting5;
    }

    /**
     * LCD表示データを返却する.
     * 
     * @return LCD表示データ
     */
    public byte getLcdMessageData() {
        return mLcdMessageData;
    }

    /**
     * 表示言語を返却する.
     * 
     * @return 表示言語
     */
    public byte getMessageLanguage() {
        return mMessageLanguage;
    }

    /**
     * Readerアプリバージョンを返却する.
     * 
     * @return Readerアプリバージョン
     */
    public byte[] getReadApVer() {
        return mReadApVer;
    }

    /**
     * カーネル C1アプリバージョンを返却する.
     * 
     * @return カーネル C1アプリバージョン
     */
    public byte[] getKernelC1ApVer() {
        return mKernelC1ApVer;
    }

    /**
     * カーネル C2アプリバージョンを返却する.
     * 
     * @return カーネル C2アプリバージョン
     */
    public byte[] getKernelC2ApVer() {
        return mKernelC2ApVer;
    }

    /**
     * カーネル C3アプリバージョンを返却する.
     * 
     * @return カーネル C3アプリバージョン
     */
    public byte[] getKernelC3ApVer() {
        return mKernelC3ApVer;
    }

    /**
     * カーネル C4アプリバージョンを返却する.
     * 
     * @return カーネル C4アプリバージョン
     */
    public byte[] getKernelC4ApVer() {
        return mKernelC4ApVer;
    }

    /**
     * カーネル C5アプリバージョンを返却する.
     * 
     * @return カーネル C5アプリバージョン
     */
    public byte[] getKernelC5ApVer() {
        return mKernelC5ApVer;
    }

    /**
     * カーネル C6アプリバージョンを返却する.
     * 
     * @return カーネル C6アプリバージョン
     */
    public byte[] getKernelC6ApVer() {
        return mKernelC6ApVer;
    }

    /**
     * カーネル C7アプリバージョンを返却する.
     * 
     * @return カーネル C7アプリバージョン
     */
    public byte[] getKernelC7ApVer() {
        return mKernelC7ApVer;
    }

    /**
     * カーネル C8アプリバージョンを返却する.
     * 
     * @return カーネル C8アプリバージョン
     */
    public byte[] getKernelC8ApVer() {
        return mKernelC8ApVer;
    }

    /**
     * カーネル C9アプリバージョンを返却する.
     * 
     * @return カーネル C9アプリバージョン
     */
    public byte[] getKernelC9ApVer() {
        return mKernelC9ApVer;
    }

    /**
     * カーネル C10アプリバージョンを返却する.
     * 
     * @return カーネル C10アプリバージョン
     */
    public byte[] getKernelC10ApVer() {
        return mKernelC10ApVer;
    }

    /**
     * カーネル C11アプリバージョンを返却する.
     * 
     * @return カーネル C11アプリバージョン
     */
    public byte[] getKernelC11ApVer() {
        return mKernelC11ApVer;
    }

    /**
     * カーネル C12アプリバージョンを返却する.
     * 
     * @return カーネル C12アプリバージョン
     */
    public byte[] getKernelC12ApVer() {
        return mKernelC12ApVer;
    }

    /**
     * カーネル C13アプリバージョンを返却する.
     * 
     * @return カーネル C13アプリバージョン
     */
    public byte[] getKernelC13ApVer() {
        return mKernelC13ApVer;
    }

    /**
     * カーネル C14アプリバージョンを返却する.
     * 
     * @return カーネル C14アプリバージョン
     */
    public byte[] getKernelC14ApVer() {
        return mKernelC14ApVer;
    }

    /**
     * カーネル C15アプリバージョンを返却する.
     * 
     * @return カーネル C15アプリバージョン
     */
    public byte[] getKernelC15ApVer() {
        return mKernelC15ApVer;
    }

    /**
     * パラメータ設定日付を返却する.
     * 
     * @return パラメータ設定日付
     */
    public Calendar getParamSetDate() {
        return mParamSetDate;
    }

    /**
     * EMV設定日付(カーネル共通)を返却する.
     * 
     * @return EMV設定日付(カーネル共通)
     */
    public Calendar getEmvSettingDateKernelCommon() {
        return mEmvSettingDateKernelCommon;
    }

    /**
     * EMV設定日付(カーネル C1)を返却する.
     * 
     * @return EMV設定日付(カーネル C1)
     */
    public Calendar getEmvSettingDateKernelC1() {
        return mEmvSettingDateKernelC1;
    }

    /**
     * EMV設定日付(カーネル C2)を返却する.
     * 
     * @return EMV設定日付(カーネル C2)
     */
    public Calendar getEmvSettingDateKernelC2() {
        return mEmvSettingDateKernelC2;
    }

    /**
     * EMV設定日付(カーネル C3)を返却する.
     * 
     * @return EMV設定日付(カーネル C3)
     */
    public Calendar getEmvSettingDateKernelC3() {
        return mEmvSettingDateKernelC3;
    }

    /**
     * EMV設定日付(カーネル C4)を返却する.
     * 
     * @return EMV設定日付(カーネル C4)
     */
    public Calendar getEmvSettingDateKernelC4() {
        return mEmvSettingDateKernelC4;
    }

    /**
     * EMV設定日付(カーネル C5)を返却する.
     * 
     * @return EMV設定日付(カーネル C5)
     */
    public Calendar getEmvSettingDateKernelC5() {
        return mEmvSettingDateKernelC5;
    }

    /**
     * EMV設定日付(カーネル C6)を返却する.
     * 
     * @return EMV設定日付(カーネル C6)
     */
    public Calendar getEmvSettingDateKernelC6() {
        return mEmvSettingDateKernelC6;
    }

    /**
     * EMV設定日付(カーネル C7)を返却する.
     * 
     * @return EMV設定日付(カーネル C7)
     */
    public Calendar getEmvSettingDateKernelC7() {
        return mEmvSettingDateKernelC7;
    }

    /**
     * EMV設定日付(カーネル C8)を返却する.
     * 
     * @return EMV設定日付(カーネル C8)
     */
    public Calendar getEmvSettingDateKernelC8() {
        return mEmvSettingDateKernelC8;
    }

    /**
     * EMV設定日付(カーネル C9)を返却する.
     * 
     * @return EMV設定日付(カーネル C9)
     */
    public Calendar getEmvSettingDateKernelC9() {
        return mEmvSettingDateKernelC9;
    }

    /**
     * EMV設定日付(カーネル C10)を返却する.
     * 
     * @return EMV設定日付(カーネル C10)
     */
    public Calendar getEmvSettingDateKernelC10() {
        return mEmvSettingDateKernelC10;
    }

    /**
     * EMV設定日付(カーネル C11)を返却する.
     * 
     * @return EMV設定日付(カーネル C11)
     */
    public Calendar getEmvSettingDateKernelC11() {
        return mEmvSettingDateKernelC11;
    }

    /**
     * EMV設定日付(カーネル C12)を返却する.
     * 
     * @return EMV設定日付(カーネル C12)
     */
    public Calendar getEmvSettingDateKernelC12() {
        return mEmvSettingDateKernelC12;
    }

    /**
     * EMV設定日付(カーネル C13)を返却する.
     * 
     * @return EMV設定日付(カーネル C13)
     */
    public Calendar getEmvSettingDateKernelC13() {
        return mEmvSettingDateKernelC13;
    }

    /**
     * EMV設定日付(カーネル C14)を返却する.
     * 
     * @return EMV設定日付(カーネル C14)
     */
    public Calendar getEmvSettingDateKernelC14() {
        return mEmvSettingDateKernelC14;
    }

    /**
     * EMV設定日付(カーネル C15)を返却する.
     * 
     * @return EMV設定日付(カーネル C15)
     */
    public Calendar getEmvSettingDateKernelC15() {
        return mEmvSettingDateKernelC15;
    }

    /**
     * EMV設定日付(デフォルトカーネル ID追加変更)を返却する.
     * 
     * @return EMV設定日付(デフォルトカーネル ID追加変更)
     */
    public Calendar getEmvSettingDateKernelDefault() {
        return mEmvSettingDateKernelDefault;
    }

    /**
     * EMV設定日付(Revocation List)を返却する.
     * 
     * @return EMV設定日付(Revocation List)
     */
    public Calendar getEmvSettingDateRevocationList() {
        return mEmvSettingDateRevocationList;
    }

    /**
     * Entry Pointチェックサムを返却する.
     * 
     * @return Entry Pointチェックサム
     */
    public byte[] getCheckSumEntryPoint() {
        return mCheckSumEntryPoint;
    }

    /**
     * カーネル C1チェックサムを返却する.
     * 
     * @return カーネル C1チェックサム
     */
    public byte[] getCheckSumKernelC1() {
        return mCheckSumKernelC1;
    }

    /**
     * カーネル C2チェックサムを返却する.
     * 
     * @return カーネル C2チェックサム
     */
    public byte[] getCheckSumKernelC2() {
        return mCheckSumKernelC2;
    }

    /**
     * カーネル C3チェックサムを返却する.
     * 
     * @return カーネル C3チェックサム
     */
    public byte[] getCheckSumKernelC3() {
        return mCheckSumKernelC3;
    }

    /**
     * カーネル C4チェックサムを返却する.
     * 
     * @return カーネル C4チェックサム
     */
    public byte[] getCheckSumKernelC4() {
        return mCheckSumKernelC4;
    }

    /**
     * カーネル C5チェックサムを返却する.
     * 
     * @return カーネル C5チェックサム
     */
    public byte[] getCheckSumKernelC5() {
        return mCheckSumKernelC5;
    }

    /**
     * カーネル C6チェックサムを返却する.
     * 
     * @return カーネル C6チェックサム
     */
    public byte[] getCheckSumKernelC6() {
        return mCheckSumKernelC6;
    }

    /**
     * カーネル C7チェックサムを返却する.
     * 
     * @return カーネル C7チェックサム
     */
    public byte[] getCheckSumKernelC7() {
        return mCheckSumKernelC7;
    }

    /**
     * カーネル C8チェックサムを返却する.
     * 
     * @return カーネル C8チェックサム
     */
    public byte[] getCheckSumKernelC8() {
        return mCheckSumKernelC8;
    }

    /**
     * カーネル C9チェックサムを返却する.
     * 
     * @return カーネル C9チェックサム
     */
    public byte[] getCheckSumKernelC9() {
        return mCheckSumKernelC9;
    }

    /**
     * カーネル C10チェックサムを返却する.
     * 
     * @return カーネル C10チェックサム
     */
    public byte[] getCheckSumKernelC10() {
        return mCheckSumKernelC10;
    }

    /**
     * カーネル C11チェックサムを返却する.
     * 
     * @return カーネル C11チェックサム
     */
    public byte[] getCheckSumKernelC11() {
        return mCheckSumKernelC11;
    }

    /**
     * カーネル C12チェックサムを返却する.
     * 
     * @return カーネル C12チェックサム
     */
    public byte[] getCheckSumKernelC12() {
        return mCheckSumKernelC12;
    }

    /**
     * カーネル C13チェックサムを返却する.
     * 
     * @return カーネル C13チェックサム
     */
    public byte[] getCheckSumKernelC13() {
        return mCheckSumKernelC13;
    }

    /**
     * カーネル C14チェックサムを返却する.
     * 
     * @return カーネル C14チェックサム
     */
    public byte[] getCheckSumKernelC14() {
        return mCheckSumKernelC14;
    }

    /**
     * カーネル C15チェックサムを返却する.
     * 
     * @return カーネル C15チェックサム
     */
    public byte[] getCheckSumKernelC15() {
        return mCheckSumKernelC15;
    }

    /**
     * Entry Pointアプリバージョンを返却する.
     * 
     * @return Entry Pointアプリバージョン
     */
    public byte[] getEntryPointAPVer() {
        return mEntryPointAPVer;
    }

    /**
     * ファイルDLL日付１を返却する.
     * 
     * @return ファイルDLL日付１
     */
    public Calendar getFileDLLDate1() {
        return mFileDLLDate1;
    }

    /**
     * ファイルDLL日付２を返却する.
     * 
     * @return ファイルDLL日付２
     */
    public Calendar getFileDLLDate2() {
        return mFileDLLDate2;
    }

    /**
     * ファイルDLL日付３を返却する.
     * 
     * @return ファイルDLL日付３
     */
    public Calendar getFileDLLDate3() {
        return mFileDLLDate3;
    }

    /**
     * ファイルDLL日付４を返却する.
     * 
     * @return ファイルDLL日付４
     */
    public Calendar getFileDLLDate4() {
        return mFileDLLDate4;
    }

    /**
     * ファイルDLL日付５を返却する.
     * 
     * @return ファイルDLL日付５
     */
    public Calendar getFileDLLDate5() {
        return mFileDLLDate5;
    }

    /**
     * ファイルDLL日付６を返却する.
     * 
     * @return ファイルDLL日付６
     */
    public Calendar getFileDLLDate6() {
        return mFileDLLDate6;
    }

    /**
     * ファイルDLL日付７を返却する.
     * 
     * @return ファイルDLL日付７
     */
    public Calendar getFileDLLDate7() {
        return mFileDLLDate7;
    }

    /**
     * ファイルDLL日付８を返却する.
     * 
     * @return ファイルDLL日付８
     */
    public Calendar getFileDLLDate8() {
        return mFileDLLDate8;
    }

    /**
     * ファイルDLL日付９を返却する.
     * 
     * @return ファイルDLL日付９
     */
    public Calendar getFileDLLDate9() {
        return mFileDLLDate9;
    }

    /**
     * ファイルDLL日付１０を返却する.
     * 
     * @return ファイルDLL日付１０
     */
    public Calendar getFileDLLDate10() {
        return mFileDLLDate10;
    }

    /**
     * ファイルDLL日付１１を返却する.
     * 
     * @return ファイルDLL日付１１
     */
    public Calendar getFileDLLDate11() {
        return mFileDLLDate11;
    }

    /**
     * ファイルDLL日付１２を返却する.
     * 
     * @return ファイルDLL日付１２
     */
    public Calendar getFileDLLDate12() {
        return mFileDLLDate12;
    }

    /**
     * ファイルDLL日付１３を返却する.
     * 
     * @return ファイルDLL日付１３
     */
    public Calendar getFileDLLDate13() {
        return mFileDLLDate13;
    }

    /**
     * ファイルDLL日付１４を返却する.
     * 
     * @return ファイルDLL日付１４
     */
    public Calendar getFileDLLDate14() {
        return mFileDLLDate14;
    }

    /**
     * ファイルDLL日付１５を返却する.
     * 
     * @return ファイルDLL日付１５
     */
    public Calendar getFileDLLDate15() {
        return mFileDLLDate15;
    }

    /**
     * カーネル取得するResponseかを設定する
     * @param noKernelData Kernel不要の場合true
     */
    public void setNoKernelData(boolean noKernelData) {isNoKernelData = noKernelData; }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {  // PT_IMPOSSIBLE_BRANCH
            return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return (cutDeviceResult(bytes) != null);  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MAINCOMMAND) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND mismatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (!isNoKernelData) {
            if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND) {
                Logger.e(TAG, "checkResponseData SUBCOMMAND mismatch = "
                        + bytes[SUBCOMMAND_INDEX]);
                return false;
            }
        } else {
            if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND_NO_KERNEL) {
                Logger.e(TAG, "checkResponseData SUBCOMMAND_NO_KERNEL mismatch = "
                        + bytes[SUBCOMMAND_INDEX]);
                return false;
            }
        }

        if (bytes[DATALENGTHHIGH_INDEX] != DATALENGTH_HIGH) {
            Logger.e(TAG, "checkResponseData DATALENGTH_HIGH mismatch = "
                    + bytes[DATALENGTHHIGH_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHLOW_INDEX] != DATALENGTH_LOW) {
            Logger.e(TAG, "checkResponseData DATALENGTH_LOW mismatch = "
                    + bytes[DATALENGTHLOW_INDEX]);
            return false;
        }

        DEVICE_INFORMATION_RESPONSE[] dataConstArray = DEVICE_INFORMATION_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;
        DateFormat dateFormat = new SimpleDateFormat(
                CommandDataConstants.DATE_FORMAT_YYYYMMDD);

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (DEVICE_INFORMATION_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {
            /* R/W状態フラグ */
            case STATUSFLG:
                // 格納前チェック不要
                break;
            /* R/W状態番号 */
            case STATUSNO:
                // 格納前チェック不要
                break;
            /* 音量設定値 */
            case VOLUME:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                // 0～2
                if (!ByteUtil.checkTargetValueByte(checkByteArray[0],
                        (byte) 0x00, (byte) 0x01, (byte) 0x02)) {
                    Logger.e(TAG, "checkResponseData " + dataConst.name()
                            + " mismatch =" + checkByteArray[0]);
                    return false;
                }
                break;
            /* タイマ1設定値 */
            case TIMERSETTING1:
                // 格納前チェック不要(1byte0~255,2~3byte 0~65535の為)
                break;
            /* タイマ2設定値 */
            case TIMERSETTING2:
                // 格納前チェック不要(1byte0~255,2~3byte 0~65535の為)
                break;
            /* タイマ3設定値 */
            case TIMERSETTING3:
                // 格納前チェック不要(1byte0~255,2~3byte 0~65535の為)
                break;
            /* タイマ4設定値 */
            case TIMERSETTING4:
                // 格納前チェック不要(1byte0~255,2~3byte 0~65535の為)
                break;
            /* タイマ5設定値 */
            case TIMERSETTING5:
                // 格納前チェック不要(1byte0~255,2~3byte 0~65535の為)
                break;
            /* LCD表示データ */
            case LCDMESSAGEDATA:
                // 格納前チェック不要(フラグ使用の為)
                break;
            /* 表示言語 */
            case MESSAGELANGUAGE:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                // 0～1（日本語、英語）
                if (!ByteUtil.checkTargetValueByte(checkByteArray[0],
                        (byte) 0x00, (byte) 0x01)) {
                    Logger.e(TAG, "checkResponseData " + dataConst.name()
                            + " mismatch =" + checkByteArray[0]);
                    return false;
                }
                break;
            /* Readerアプリバージョン */
            case READAPVER:
                // アプリバージョン格納前チェック不要(1byte0x00~0xff,2byte0x00~0xffの為)
                break;
            /* カーネル C1アプリバージョン */
            case KERNELC1APVER:
                break;
            /* カーネル C2アプリバージョン */
            case KERNELC2APVER:
                break;
            /* カーネル C3アプリバージョン */
            case KERNELC3APVER:
                break;
            /* カーネル C4アプリバージョン */
            case KERNELC4APVER:
                break;
            /* カーネル C5アプリバージョン */
            case KERNELC5APVER:
                break;
            /* カーネル C6アプリバージョン */
            case KERNELC6APVER:
                break;
            /* カーネル C7アプリバージョン */
            case KERNELC7APVER:
                break;
            /* カーネル C8アプリバージョン */
            case KERNELC8APVER:
                break;
            /* カーネル C9アプリバージョン */
            case KERNELC9APVER:
                break;
            /* カーネル C10アプリバージョン */
            case KERNELC10APVER:
                break;
            /* カーネル C11アプリバージョン */
            case KERNELC11APVER:
                break;
            /* カーネル C12アプリバージョン */
            case KERNELC12APVER:
                break;
            /* カーネル C13アプリバージョン */
            case KERNELC13APVER:
                break;
            /* カーネル C14アプリバージョン */
            case KERNELC14APVER:
                break;
            /* カーネル C15アプリバージョン */
            case KERNELC15APVER:
                break;
            /* パラメータ設定日付 */
            case PARAMSETDATE:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル共通) */
            case EMVSETTINGDATEKERNELCOMMON:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C1) */
            case EMVSETTINGDATEKERNELC1:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C2) */
            case EMVSETTINGDATEKERNELC2:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C3) */
            case EMVSETTINGDATEKERNELC3:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C4) */
            case EMVSETTINGDATEKERNELC4:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C5) */
            case EMVSETTINGDATEKERNELC5:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C6) */
            case EMVSETTINGDATEKERNELC6:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C7) */
            case EMVSETTINGDATEKERNELC7:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C8) */
            case EMVSETTINGDATEKERNELC8:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C9) */
            case EMVSETTINGDATEKERNELC9:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C10) */
            case EMVSETTINGDATEKERNELC10:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C11) */
            case EMVSETTINGDATEKERNELC11:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C12) */
            case EMVSETTINGDATEKERNELC12:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C13) */
            case EMVSETTINGDATEKERNELC13:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C14) */
            case EMVSETTINGDATEKERNELC14:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(カーネル C15) */
            case EMVSETTINGDATEKERNELC15:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(デフォルトカーネル ID追加変更) */
            case EMVSETTINGDATEKERNELDEFAULT:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* EMV設定日付(Revocation List) */
            case EMVSETTINGDATEREVOCATIONLIST:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* Entry Pointチェックサム */
            case CHECKSUMENTRYPOINT:
                // チェックサム項目はチェック不要
                break;
            /* カーネル C1チェックサム */
            case CHECKSUMKERNELC1:
                break;
            /* カーネル C2チェックサム */
            case CHECKSUMKERNELC2:
                break;
            /* カーネル C3チェックサム */
            case CHECKSUMKERNELC3:
                break;
            /* カーネル C4チェックサム */
            case CHECKSUMKERNELC4:
                break;
            /* カーネル C5チェックサム */
            case CHECKSUMKERNELC5:
                break;
            /* カーネル C6チェックサム */
            case CHECKSUMKERNELC6:
                break;
            /* カーネル C7チェックサム */
            case CHECKSUMKERNELC7:
                break;
            /* カーネル C8チェックサム */
            case CHECKSUMKERNELC8:
                break;
            /* カーネル C9チェックサム */
            case CHECKSUMKERNELC9:
                break;
            /* カーネル C10チェックサム */
            case CHECKSUMKERNELC10:
                break;
            /* カーネル C11チェックサム */
            case CHECKSUMKERNELC11:
                break;
            /* カーネル C12チェックサム */
            case CHECKSUMKERNELC12:
                break;
            /* カーネル C13チェックサム */
            case CHECKSUMKERNELC13:
                break;
            /* カーネル C14チェックサム */
            case CHECKSUMKERNELC14:
                break;
            /* カーネル C15チェックサム */
            case CHECKSUMKERNELC15:
                break;
            /* Entry Pointアプリバージョン */
            case ENTRYPOINTAPVER:
                break;
            /* ファイルDLL日付１ */
            case FILEDLLDATE1:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付２ */
            case FILEDLLDATE2:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付３ */
            case FILEDLLDATE3:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付４ */
            case FILEDLLDATE4:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付５ */
            case FILEDLLDATE5:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付６ */
            case FILEDLLDATE6:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付７ */
            case FILEDLLDATE7:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付８ */
            case FILEDLLDATE8:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付９ */
            case FILEDLLDATE9:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付１０ */
            case FILEDLLDATE10:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付１１ */
            case FILEDLLDATE11:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付１２ */
            case FILEDLLDATE12:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付１３ */
            case FILEDLLDATE13:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付１４ */
            case FILEDLLDATE14:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;
            /* ファイルDLL日付１５ */
            case FILEDLLDATE15:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                if (!checkDateCalendar(checkByteArray, dateFormat, dataConst)) {
                    return false;
                }
                break;

            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ格納を行う
        DEVICE_INFORMATION_RESPONSE[] dataConstArray = DEVICE_INFORMATION_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;
        DateFormat dateFormat = new SimpleDateFormat(
                CommandDataConstants.DATE_FORMAT_YYYYMMDD);

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (DEVICE_INFORMATION_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {
            /* R/W状態フラグ */
            case STATUSFLG:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mStatusFlg = checkByteArray[0];
                break;
            /* R/W状態番号 */
            case STATUSNO:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mStatusNo = checkByteArray[0];
                break;
            /* 音量設定値 */
            case VOLUME:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mVolume = checkByteArray[0];
                break;
            /* タイマ1設定値 */
            case TIMERSETTING1:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mTimerSetting1 = checkByteArray;
                break;
            /* タイマ2設定値 */
            case TIMERSETTING2:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mTimerSetting2 = checkByteArray;
                break;
            /* タイマ3設定値 */
            case TIMERSETTING3:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mTimerSetting3 = checkByteArray;
                break;
            /* タイマ4設定値 */
            case TIMERSETTING4:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mTimerSetting4 = checkByteArray;
                break;
            /* タイマ5設定値 */
            case TIMERSETTING5:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mTimerSetting5 = checkByteArray;
                break;
            /* LCD表示データ */
            case LCDMESSAGEDATA:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mLcdMessageData = checkByteArray[0];
                break;
            /* 表示言語 */
            case MESSAGELANGUAGE:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mMessageLanguage = checkByteArray[0];
                break;
            /* Readerアプリバージョン */
            case READAPVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mReadApVer = checkByteArray;
                break;
            /* カーネル C1アプリバージョン */
            case KERNELC1APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC1ApVer = checkByteArray;
                break;
            /* カーネル C2アプリバージョン */
            case KERNELC2APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC2ApVer = checkByteArray;
                break;
            /* カーネル C3アプリバージョン */
            case KERNELC3APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC3ApVer = checkByteArray;
                break;
            /* カーネル C4アプリバージョン */
            case KERNELC4APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC4ApVer = checkByteArray;
                break;
            /* カーネル C5アプリバージョン */
            case KERNELC5APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC5ApVer = checkByteArray;
                break;
            /* カーネル C6アプリバージョン */
            case KERNELC6APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC6ApVer = checkByteArray;
                break;
            /* カーネル C7アプリバージョン */
            case KERNELC7APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC7ApVer = checkByteArray;
                break;
            /* カーネル C8アプリバージョン */
            case KERNELC8APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC8ApVer = checkByteArray;
                break;
            /* カーネル C9アプリバージョン */
            case KERNELC9APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC9ApVer = checkByteArray;
                break;
            /* カーネル C10アプリバージョン */
            case KERNELC10APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC10ApVer = checkByteArray;
                break;
            /* カーネル C11アプリバージョン */
            case KERNELC11APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC11ApVer = checkByteArray;
                break;
            /* カーネル C12アプリバージョン */
            case KERNELC12APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC12ApVer = checkByteArray;
                break;
            /* カーネル C13アプリバージョン */
            case KERNELC13APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC13ApVer = checkByteArray;
                break;
            /* カーネル C14アプリバージョン */
            case KERNELC14APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC14ApVer = checkByteArray;
                break;
            /* カーネル C15アプリバージョン */
            case KERNELC15APVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mKernelC15ApVer = checkByteArray;
                break;
            /* パラメータ設定日付 */
            case PARAMSETDATE:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mParamSetDate = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* EMV設定日付(カーネル共通) */
            case EMVSETTINGDATEKERNELCOMMON:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelCommon = convertDateCalendar(
                        checkByteArray, dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C1) */
            case EMVSETTINGDATEKERNELC1:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC1 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C2) */
            case EMVSETTINGDATEKERNELC2:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC2 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C3) */
            case EMVSETTINGDATEKERNELC3:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC3 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C4) */
            case EMVSETTINGDATEKERNELC4:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC4 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C5) */
            case EMVSETTINGDATEKERNELC5:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC5 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C6) */
            case EMVSETTINGDATEKERNELC6:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC6 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C7) */
            case EMVSETTINGDATEKERNELC7:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC7 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C8) */
            case EMVSETTINGDATEKERNELC8:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC8 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C9) */
            case EMVSETTINGDATEKERNELC9:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC9 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C10) */
            case EMVSETTINGDATEKERNELC10:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC10 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C11) */
            case EMVSETTINGDATEKERNELC11:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC11 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C12) */
            case EMVSETTINGDATEKERNELC12:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC12 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C13) */
            case EMVSETTINGDATEKERNELC13:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC13 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C14) */
            case EMVSETTINGDATEKERNELC14:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC14 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(カーネル C15) */
            case EMVSETTINGDATEKERNELC15:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelC15 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* EMV設定日付(デフォルトカーネル ID追加変更) */
            case EMVSETTINGDATEKERNELDEFAULT:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateKernelDefault = convertDateCalendar(
                        checkByteArray, dateFormat, dataConst);
                break;
            /* EMV設定日付(Revocation List) */
            case EMVSETTINGDATEREVOCATIONLIST:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEmvSettingDateRevocationList = convertDateCalendar(
                        checkByteArray, dateFormat, dataConst);
                break;
            /* Entry Pointチェックサム */
            case CHECKSUMENTRYPOINT:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumEntryPoint = checkByteArray;
                break;
            /* カーネル C1チェックサム */
            case CHECKSUMKERNELC1:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC1 = checkByteArray;
                break;
            /* カーネル C2チェックサム */
            case CHECKSUMKERNELC2:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC2 = checkByteArray;
                break;
            /* カーネル C3チェックサム */
            case CHECKSUMKERNELC3:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC3 = checkByteArray;
                break;
            /* カーネル C4チェックサム */
            case CHECKSUMKERNELC4:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC4 = checkByteArray;
                break;
            /* カーネル C5チェックサム */
            case CHECKSUMKERNELC5:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC5 = checkByteArray;
                break;
            /* カーネル C6チェックサム */
            case CHECKSUMKERNELC6:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC6 = checkByteArray;
                break;
            /* カーネル C7チェックサム */
            case CHECKSUMKERNELC7:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC7 = checkByteArray;
                break;
            /* カーネル C8チェックサム */
            case CHECKSUMKERNELC8:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC8 = checkByteArray;
                break;
            /* カーネル C9チェックサム */
            case CHECKSUMKERNELC9:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC9 = checkByteArray;
                break;
            /* カーネル C10チェックサム */
            case CHECKSUMKERNELC10:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC10 = checkByteArray;
                break;
            /* カーネル C11チェックサム */
            case CHECKSUMKERNELC11:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC11 = checkByteArray;
                break;
            /* カーネル C12チェックサム */
            case CHECKSUMKERNELC12:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC12 = checkByteArray;
                break;
            /* カーネル C13チェックサム */
            case CHECKSUMKERNELC13:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC13 = checkByteArray;
                break;
            /* カーネル C14チェックサム */
            case CHECKSUMKERNELC14:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC14 = checkByteArray;
                break;
            /* カーネル C15チェックサム */
            case CHECKSUMKERNELC15:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mCheckSumKernelC15 = checkByteArray;
                break;
            /* Entry Pointアプリバージョン */
            case ENTRYPOINTAPVER:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mEntryPointAPVer = checkByteArray;
                break;
            /* ファイルDLL日付１ */
            case FILEDLLDATE1:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate1 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付２ */
            case FILEDLLDATE2:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate2 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付３ */
            case FILEDLLDATE3:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate3 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付４ */
            case FILEDLLDATE4:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate4 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付５ */
            case FILEDLLDATE5:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate5 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付６ */
            case FILEDLLDATE6:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate6 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付７ */
            case FILEDLLDATE7:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate7 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付８ */
            case FILEDLLDATE8:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate8 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付９ */
            case FILEDLLDATE9:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate9 = convertDateCalendar(checkByteArray, dateFormat,
                        dataConst);
                break;
            /* ファイルDLL日付１０ */
            case FILEDLLDATE10:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate10 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* ファイルDLL日付１１ */
            case FILEDLLDATE11:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate11 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* ファイルDLL日付１２ */
            case FILEDLLDATE12:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate12 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* ファイルDLL日付１３ */
            case FILEDLLDATE13:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate13 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* ファイルDLL日付１４ */
            case FILEDLLDATE14:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate14 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            /* ファイルDLL日付１５ */
            case FILEDLLDATE15:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mFileDLLDate15 = convertDateCalendar(checkByteArray,
                        dateFormat, dataConst);
                break;
            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return bytes;
    }

    private Calendar convertDateCalendar(byte[] convartArray,
            DateFormat dateFormatter, DEVICE_INFORMATION_RESPONSE setEnum) {
        String setData = ByteUtil.convertBCDByte2String(convartArray);
        if (setData != null
                && !CommandDataConstants.DATE_FORMAT_YYYYMMDD_NOTESET
                        .equals(setData)) {
            try {
                Calendar setCalendar = Calendar.getInstance();
                setCalendar.setTime(dateFormatter.parse(setData));
                return setCalendar;
            } catch (ParseException pe) {
            	pe.printStackTrace();
                return null;
            }
        }
        return null;
    }

    private boolean checkDateCalendar(byte[] convartArray,
            DateFormat dateFormatter, DEVICE_INFORMATION_RESPONSE setEnum) {
        String setData = ByteUtil.convertBCDByte2String(convartArray);
        if (setData != null
                && !CommandDataConstants.DATE_FORMAT_YYYYMMDD_NOTESET
                        .equals(setData)) {
            try {
                Calendar setCalendar = Calendar.getInstance();
                setCalendar.setTime(dateFormatter.parse(setData));
                return true;
            } catch (ParseException pe) {
            	pe.printStackTrace();
                return false;
            }
        } else {
            // 日付変換対象でない
            return true;
        }
    }
}
