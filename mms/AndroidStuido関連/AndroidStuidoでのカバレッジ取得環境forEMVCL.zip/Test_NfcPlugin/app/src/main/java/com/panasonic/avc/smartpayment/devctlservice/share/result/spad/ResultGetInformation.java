
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetInformation extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetInformation(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetInformation() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetInformation> CREATOR = new Parcelable.Creator<ResultGetInformation>() {

        @Override
        public ResultGetInformation createFromParcel(Parcel in) {
            return new ResultGetInformation(in);
        }

        @Override
        public ResultGetInformation[] newArray(int size) {
            return new ResultGetInformation[size];
        }
    };
}
