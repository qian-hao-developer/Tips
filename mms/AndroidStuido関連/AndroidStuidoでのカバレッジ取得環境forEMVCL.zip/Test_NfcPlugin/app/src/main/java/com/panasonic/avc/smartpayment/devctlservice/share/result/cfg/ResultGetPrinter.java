
package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultGetPrinter処理結果データ
 */
public class ResultGetPrinter extends ResultData {

    /** @brief Printerタグ */
    private static final String PRINTER = "printer";

    /** @brief 太字タグ */
    private static final String BOLD = "bold";

    /** @brief 印字濃度タグ */
    private static final String DENSITY = "density";

    /** @brief カット方法タグ */
    private static final String CUTTYPE = "cuttype";

    private boolean mBold;

    private int mDensity;

    private int mCutType;

    /**
     * @brief コンストラクタ
     */
    public ResultGetPrinter(Parcel in) {
        super(in);
        mBold = (in.readInt() == 1) ? true : false;
        mDensity = in.readInt();
        mCutType = in.readInt();
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetPrinter() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetPrinter> CREATOR = new Parcelable.Creator<ResultGetPrinter>() {
        public ResultGetPrinter createFromParcel(Parcel in) {
            return new ResultGetPrinter(in);
        }

        public ResultGetPrinter[] newArray(int size) {
            return new ResultGetPrinter[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mBold ? 1 : 0);
        dest.writeInt(mDensity);
        dest.writeInt(mCutType);
    }

    public boolean getBold() {
        return mBold;
    }

    public void setBold(boolean bold) {
        mBold = bold;
    }

    public int getDensity() {
        return mDensity;
    }

    public void setDensity(int density) {
        mDensity = density;
    }

    public int getCutType() {
        return mCutType;
    }

    public void setCutType(int cutType) {
        mCutType = cutType;
    }

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonPrinter = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonPrinter.put(BOLD, getBold());
            jsonPrinter.put(DENSITY, getDensity());
            jsonPrinter.put(CUTTYPE, getCutType());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(PRINTER, JSONObject.NULL);
            } else {
                json.put(PRINTER, jsonPrinter);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
