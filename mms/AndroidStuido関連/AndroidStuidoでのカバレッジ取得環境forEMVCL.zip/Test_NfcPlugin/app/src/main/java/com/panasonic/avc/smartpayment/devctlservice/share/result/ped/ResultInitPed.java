
package com.panasonic.avc.smartpayment.devctlservice.share.result.ped;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPEDの実行結果データ
 */
public class ResultInitPed extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultInitPed(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitPed() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitPed> CREATOR = new Parcelable.Creator<ResultInitPed>() {
        public ResultInitPed createFromParcel(Parcel in) {
            return new ResultInitPed(in);
        }

        public ResultInitPed[] newArray(int size) {
            return new ResultInitPed[size];
        }
    };
}
