
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_Textの実行結果データ
 */
public class ResultPrintText extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintText(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintText() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintText> CREATOR = new Parcelable.Creator<ResultPrintText>() {
        public ResultPrintText createFromParcel(Parcel in) {
            return new ResultPrintText(in);
        }

        public ResultPrintText[] newArray(int size) {
            return new ResultPrintText[size];
        }
    };
}
