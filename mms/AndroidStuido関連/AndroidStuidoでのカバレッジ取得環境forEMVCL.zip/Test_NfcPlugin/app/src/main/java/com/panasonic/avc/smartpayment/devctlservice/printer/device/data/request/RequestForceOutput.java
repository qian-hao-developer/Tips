
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * 強制印字出力要求
 */
public class RequestForceOutput extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x001C;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x8000;

    /**
     * @brief コンストラクタ
     */
    public RequestForceOutput() {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {
        byte[] dataByte = new byte[3];
        dataByte[0] = 0x1B; /* ESC */
        dataByte[1] = 0x4A; /* J */
        dataByte[2] = 0; /* 0固定 */
        return toCommand(dataByte);
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }

}
