
package com.panasonic.avc.smartpayment.devctlservice.share.result.mgt;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPEDの実行結果データ
 */
public class ResultStartSendFile extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultStartSendFile(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultStartSendFile() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultStartSendFile> CREATOR = new Parcelable.Creator<ResultStartSendFile>() {
        public ResultStartSendFile createFromParcel(Parcel in) {
            return new ResultStartSendFile(in);
        }

        public ResultStartSendFile[] newArray(int size) {
            return new ResultStartSendFile[size];
        }
    };

}
