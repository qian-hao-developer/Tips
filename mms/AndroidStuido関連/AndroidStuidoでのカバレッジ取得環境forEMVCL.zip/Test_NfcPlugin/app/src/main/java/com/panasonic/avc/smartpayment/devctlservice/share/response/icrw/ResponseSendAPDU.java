
package com.panasonic.avc.smartpayment.devctlservice.share.response.icrw;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * APDUEventデータ
 */
public class ResponseSendAPDU extends ResponseData implements Parcelable {

    /** @brief ICカードの応答結果 */
    private int mResult;

    /** @brief ICカードの応答結果タグ */
    private static final String RESULT = "result";

    /** @brief StatusWord */
    private String mSw;

    /** @brief StatusWordタグ */
    private static final String SW = "sw";

    /** @brief ICカードの応答iccresの暗号化状態 */
    private boolean mEncrypt;

    /** @brief ICカードの応答iccresの暗号化状態タグ */
    private static final String ENCRYPT = "encrypt";

    /** @brief 暗号化した結果 */
    private String mIccres;

    /** @brief 暗号化した結果タグ */
    private static final String ICCRES = "iccres";

    /** @brief APDUデータ送信での指定値 */
    private int mApduId;

    /** @brief APDUデータ送信での指定値タグ */
    private static final String ID = "id";

    /** @brief トランザクションキー情報 */
    private String mKsn;

    /** @brief トランザクションキー情報タグ */
    private static final String KSN = "ksn";

    /** @brief マスターコマンド **/
    private static final byte MASTER_COMMAND = 0x30;

    /** @brief サブコマンド **/
    private static final byte SUB_COMMAND = 0x07;

    /** @brief コマンドの長さ **/
    private static final int LENGTH_AND_OVER = 5;

    public static final int PINPAD_RESULT_OK = 0x00;

    private static final int PINPAD_RESULT_TIMEOUT_ERROR = 0x61;

    private static final int PLUGIN_RESULT_OK = 0x00;

    private static final int PLUGIN_RESULT_FAIL = 0x01;

    public static final int PLUGIN_RESULT_TIMEOUT = 0x02;

    private static final int PLUGIN_RESULT_KEY_ERROR = 0x03;

    public static final int PLUGIN_KEY_ERROR = 0x02;

    /**
     * @brief コンストラクタ
     * @param result ICカードの応答結果
     * @param sw StatusWord
     * @param encrypt ICカードの応答iccresの暗号化状態
     * @param iccres 暗号化した結果
     * @param id APDUデータ送信での指定値
     * @param ksn トランザクションキー情報
     */
    public ResponseSendAPDU(int result, String sw, boolean encrypt, String iccres, int id,
            String ksn) {
        mResult = result;
        mSw = sw;
        mEncrypt = encrypt;
        mIccres = iccres;
        mApduId = id;
        mKsn = ksn;
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseSendAPDU(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseSendAPDU() {

    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponseSendAPDU> CREATOR = new Parcelable.Creator<ResponseSendAPDU>() {

        /**
         * @see Parcelable.Creator#createFromParcel(Parcel)
         */
        public ResponseSendAPDU createFromParcel(Parcel in) {
            return new ResponseSendAPDU(in);
        }

        /**
         * @see Parcelable.Creator#newArray(int)
         */
        public ResponseSendAPDU[] newArray(int size) {
            return new ResponseSendAPDU[size];
        }
    };

    /**
     * @see Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mResult);
        dest.writeString(mSw);
        dest.writeInt(mEncrypt ? 1 : 0);
        dest.writeString(mIccres);
        dest.writeInt(mApduId);
        dest.writeString(mKsn);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mResult = in.readInt();
        mSw = in.readString();
        mEncrypt = in.readInt() == 1 ? true : false;
        mIccres = in.readString();
        mApduId = in.readInt();
        mKsn = in.readString();
    }

    /**
     * @brief ICカードの応答結果を取得する
     * @return ICカードの応答結果
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @brief ICカードの応答結果を設定する
     * @param ICカードの応答結果
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * @brief StatusWordを取得する
     * @return StatusWordを設定する
     */
    public String getSw() {
        return mSw;
    }

    /**
     * @brief StatusWordを設定する
     * @param StatusWord
     */
    public void setSw(String sw) {
        mSw = sw;
    }

    /**
     * @brief ICカードの応答iccresの暗号化状態を取得する
     * @return ICカードの応答iccresの暗号化状態
     */
    public boolean isEncrypt() {
        return mEncrypt;
    }

    /**
     * @brief ICカードの応答iccresの暗号化状態を設定する
     * @param ICカードの応答iccresの暗号化状態
     */
    public void setEncrypt(boolean encrypt) {
        mEncrypt = encrypt;
    }

    /**
     * @brief 暗号化した結果を取得する
     * @return 暗号化した結果
     */
    public String getIccres() {
        return mIccres;
    }

    /**
     * @brief 暗号化した結果を設定する
     * @param 暗号化した結果
     */
    public void setIccres(String iccres) {
        mIccres = iccres;
    }

    /**
     * @brief APDUデータ送信での指定値を取得する
     * @return APDUデータ送信での指定値
     */
    public int getApduId() {
        return mApduId;
    }

    /**
     * @brief APDUデータ送信での指定値を設定する
     * @param APDUデータ送信での指定値
     */
    public void setApduId(int id) {
        mApduId = id;
    }

    /**
     * @brief トランザクションキー情報を取得する
     * @return トランザクションキー情報
     */
    public String getKsn() {
        return mKsn;
    }

    /**
     * @brief トランザクションキー情報を設定する
     * @param トランザクションキー情報
     */
    public void setKsn(String ksn) {
        mKsn = ksn;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        int len = CalcUtil
                .toInt(buffer[PinpadDefine.INDEX_LEN_1],
                        buffer[PinpadDefine.INDEX_LEN_2]);
        if (len < LENGTH_AND_OVER) {
            return false;
        }

        byte result = buffer[PinpadDefine.INDEX_PARAMETER];

        if (result == (byte) PINPAD_RESULT_TIMEOUT_ERROR) {
            mResult = PLUGIN_RESULT_TIMEOUT;
        } else if (result == (byte) PINPAD_RESULT_OK) {
            mResult = PLUGIN_RESULT_OK;
        } else if (result == (byte) PLUGIN_KEY_ERROR) {
            mResult = PLUGIN_RESULT_KEY_ERROR;
        } else {
            mResult = PLUGIN_RESULT_FAIL;
        }

        int status = buffer[PinpadDefine.INDEX_PARAMETER + 1];
        int encrypt = buffer[PinpadDefine.INDEX_PARAMETER + 2];
        mEncrypt = (encrypt == (byte) 0x00) ? false : true;
        mApduId = CalcUtil.toInt(buffer[PinpadDefine.INDEX_PARAMETER + 3], (byte) 0x00);
        int num = buffer[PinpadDefine.INDEX_PARAMETER + 4];

        if (mResult != 0) {
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return true;
        }

        byte[] res;
        int swLen = 2 * num;

        if (mEncrypt) {

            // パラメータデータの後ろから10バイト(KSN)をコピーする
            byte[] ksn = new byte[10];
            int ksnIndex = buffer.length - ksn.length - PinpadDefine.ETX_AND_CRC_SIZE;
            if (ksnIndex < 0) {
                return false;
            }
            System.arraycopy(buffer, ksnIndex, ksn, 0, ksn.length);
            mKsn = CalcUtil.toHexString(ksn);

            // SWのINDEX
            int swIndex = buffer.length - ksn.length - PinpadDefine.ETX_AND_CRC_SIZE - swLen;
            byte[] sw = new byte[swLen];
            if (swIndex < 0) {
                return false;
            }

            System.arraycopy(buffer, swIndex, sw, 0, swLen);
            mSw = CalcUtil.toHexString(sw);

            // bufferからRESULT、STATUS、ENCRYPT、NUM、KSN、SWを除いたRESのサイズ
            int resSize = buffer.length - PinpadDefine.ETX_AND_CRC_SIZE
                    - PinpadDefine.INDEX_PARAMETER - 5 - ksn.length - swLen;
            int resIndex = PinpadDefine.INDEX_PARAMETER + 5;
            res = new byte[resSize];
            if ((buffer.length - resIndex) < res.length) {
                return false;
            }
            System.arraycopy(buffer, resIndex, res, 0, res.length);

        } else {
            mKsn = "";

            // SWのINDEX
            int swIndex = buffer.length - PinpadDefine.ETX_AND_CRC_SIZE - swLen;
            byte[] sw = new byte[swLen];
            if (swIndex < 0) {
                return false;
            }
            System.arraycopy(buffer, swIndex, sw, 0, swLen);
            mSw = CalcUtil.toHexString(sw);

            // bufferからRESULT、STATUS、ENCRYPT、NUM、KSN、SWを除いたRESのサイズ
            int resSize = buffer.length - PinpadDefine.ETX_AND_CRC_SIZE
                    - PinpadDefine.INDEX_PARAMETER - 5 - swLen;
            int resIndex = PinpadDefine.INDEX_PARAMETER + 5;
            res = new byte[resSize];
            if ((buffer.length - resIndex) < res.length) {
                return false;
            }
            System.arraycopy(buffer, resIndex, res, 0, res.length);
        }

        mIccres = CalcUtil.toHexString(res);

        return true;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(RESULT, getResult());
            json.put(ENCRYPT, isEncrypt());
            json.put(ID, getApduId());

            if (getSw() == null) {
                json.put(SW, JSONObject.NULL);
            } else {
                JSONArray swArray = new JSONArray();
                String sw = getSw();
                int length = 4;
                int check = sw.length() % length;
                if (check != 0) {
                    json.put(SW, JSONObject.NULL);
                } else {
                    for (int index = 0; index < sw.length(); index += length) {
                        swArray.put(sw.substring(index, (index + length)));
                    }
                    json.put(SW, swArray);
                }
            }

            if (getIccres() == null) {
                json.put(ICCRES, JSONObject.NULL);
            } else {
                json.put(ICCRES, getIccres());
            }

            if (getKsn() == null) {
                json.put(KSN, JSONObject.NULL);
            } else {
                json.put(KSN, getKsn());
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
