
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultSendFeliCaAplOff extends ResultFeliCaApl {

    /**
     * @brief コンストラクタ
     */
    public ResultSendFeliCaAplOff(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendFeliCaAplOff() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendFeliCaAplOff> CREATOR = new Parcelable.Creator<ResultSendFeliCaAplOff>() {

        @Override
        public ResultSendFeliCaAplOff createFromParcel(Parcel in) {
            return new ResultSendFeliCaAplOff(in);
        }

        @Override
        public ResultSendFeliCaAplOff[] newArray(int size) {
            return new ResultSendFeliCaAplOff[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
    }

}
