
package com.panasonic.avc.smartpayment.devctlservice.share.response.spad;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultPenData;

public class ResponseSignpad extends ArrayList<ResultPenData> implements Parcelable {

    /**
     * @brief serialVersionUID
     */
    private static final long serialVersionUID = -8658200018912988759L;

    /** @brief ペンデータ数 tag */
    private static final String SIZE = "size";

    /** @brief ペンデータ tag */
    private static final String PENDATA = "pendata";

    /**
     * コンストラクタ
     */
    public ResponseSignpad() {

    }

    /**
     * コンストラクタ
     * 
     * @param in
     */
    public ResponseSignpad(Parcel in) {
        this();
        readFromParcel(in);
    }

    /**
     * @brief Parcelからデータを読み取ります
     * @param in
     */
    private void readFromParcel(Parcel in) {
        this.clear();

        int listSize = in.readInt();
        for (int i = 0; i < listSize; i++) {
            ResultPenData ret = new ResultPenData(in.readInt(), in.readInt(), in.readInt(),
                    in.readInt());
            this.add(ret);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        int listSize = this.size();
        dest.writeInt(listSize);

        for (int i = 0; i < listSize; i++) {
            ResultPenData data = this.get(i);

            dest.writeInt(data.getX());
            dest.writeInt(data.getY());
            dest.writeInt(data.getSwitch());
            dest.writeInt(data.getPressure());
        }
    }

    /**
     * @brief JSON形式で各フィールドの値を出力します
     * @return 各フィールドの値をJSON形式に整形した文字列（失敗時はnull）
     */
    public String toJSON() {
        int listSize = this.size();

        JSONObject retobj = new JSONObject();
        JSONArray array = new JSONArray();
        try {
            retobj.put(SIZE, listSize);
            for (int i = 0; i < listSize; i++) {
                array.put(this.get(i).toJSON());
            }
            retobj.put(PENDATA, array);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

        return retobj.toString();

    }

    /**
     * @brief CREATOR
     */
    public static final Parcelable.Creator<ResponseSignpad> CREATOR = new Parcelable.Creator<ResponseSignpad>() {

        @Override
        public ResponseSignpad createFromParcel(Parcel arg0) {
            return new ResponseSignpad(arg0);
        }

        @Override
        public ResponseSignpad[] newArray(int arg0) {
            return new ResponseSignpad[arg0];
        }
    };
}
