
package com.panasonic.avc.smartpayment.devctlservice.bcr;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request.RequestInitBCR;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request.RequestScanOFF;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request.RequestScanON;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request.RequestSendBCR;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.NotifyUsbDeviceConnectionListener;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.IBcrServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.bcr.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.bcr.ResponseReceiveBCR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultInitBCR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultScanOFF;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultScanON;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultSendBCR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultTermBCR;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * バーコードリーダ処理部
 */
public class BarcodeReader {

    /** @brief ログ出力用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = BarcodeReader.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static BarcodeReader sInstance = new BarcodeReader();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IBcrServiceListener> mIBcrServiceListenerList = new ConcurrentHashMap<String, IBcrServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief コンテキスト */
    private Context mContext;

    /** @brief 非同期用スレッド(ReceiveBCR) */
    private Thread mReceiveBCRThread;

    /** @brief 接続バーコードリーダに初期化コマンドを送信済み */
    private boolean mIsInitializedDevice = false;

    /** @brief ScanON 実施中 */
    private boolean mIsScanning = false;

    private CountDownLatch mLatch = new CountDownLatch(0);

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 500;

    /** @brief Read時のタイムアウト */
    private static final int READ_TIME_OUT = 500;

    /** @brief ループ間隔 */
    private static final int CYCLE_TIME = 500;

    /**
     * @brief コンストラクタ
     */
    private BarcodeReader() {
    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static BarcodeReader getInstance() {
        return sInstance;
    }

    /**
     * @brief バーコードリーダプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerBcrServiceListener(String tag, IBcrServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIBcrServiceListenerList) {
            mIBcrServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief バーコードリーダプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterBcrServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIBcrServiceListenerList) {
            mIBcrServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief バーコードリーダ Plug-In を初期化します
     * @param model 使用するバーコードリーダを指定[整数型]します
     * @return 実行結果
     */
    public ResultInitBCR initBCR(final int model) {
        ResultInitBCR result = new ResultInitBCR();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setType(0);

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        int productId = mControlDeviceManager.getProductId();
        result.setType(BarcodeReaderUtil.toType(productId));

        clearBuffer();

        switch (model) {
            case BarcodeReaderDefine.MODEL_NOT_SPECIFIED: {
                // NOP
                break;
            }
            case BarcodeReaderDefine.MODEL_M_10_C_40_C_41: {
                // 初期化用コマンドの送信
                RequestInitBCR request = new RequestInitBCR(productId);
                if (!request.isValidValue()) {
                    // Dead Code
                    result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                    return result;
                }
                mControlDeviceManager.write(request, TIME_OUT);
                break;
            }
            default: {
                // 引数不正
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }
        }

        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        mIsInitializedDevice = true;
        mIsScanning = false;

        mControlDeviceManager
                .registerNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListener);

        mReceiveBCRThread = new Thread() {

            @Override
            public void run() {

                // スレッドの多重起動を回避
                while (this.equals(mReceiveBCRThread)) {

                    long start = System.currentTimeMillis();

                    if (!mControlDeviceManager.isActive()) {
                        // バーコードリーダ接続なし
                        sleepReceiveBCRThread(start);
                        continue;
                    }

                    if (!mIsInitializedDevice) {
                        sleepReceiveBCRThread(start);
                        continue;
                    }

                    byte[][] dataArray = (model == BarcodeReaderDefine.MODEL_M_10_C_40_C_41) ?
                            readM10C40C41(READ_TIME_OUT) : readNotSpecified(READ_TIME_OUT);
                    for (byte[] data : dataArray) {
                        ResponseReceiveBCR response = new ResponseReceiveBCR();
                        response.inputBarcodeReaderResult(data);
                        notifyReceiveBCR(response);
                    }
                    sleepReceiveBCRThread(start);

                }
                mLatch.countDown();
            }

        };

        // 既存のスレッドが終了するのを待つ
        try {
            mLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        mLatch = new CountDownLatch(1);
        mReceiveBCRThread.start();

        return result;
    }

    /**
     * @brief BCRにデータを送信します
     * @param[in] datasz 送信データサイズを指定(整数型)します
     * @param[in] data 送信データを指定(文字列型)します
     * @param[in] blocksz ブロック送信する場合のブロックサイズを指定を指定(整数型)します
     * @return 実行結果
     */
    public ResultSendBCR sendBCR(int datasz, String data) {
        ResultSendBCR result = new ResultSendBCR();
        RequestSendBCR request = new RequestSendBCR(datasz, data);

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()
                || !mIsInitializedDevice) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mControlDeviceManager.write(request, TIME_OUT);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

        return result;
    }

    /**
     * @brief バーコードの読み取りを開始します
     * @return 実行結果
     */
    public ResultScanON scanON() {
        ResultScanON result = new ResultScanON();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()
                || !mIsInitializedDevice) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestScanON request = new RequestScanON(mControlDeviceManager.getProductId());

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mControlDeviceManager.write(request, TIME_OUT);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

        mIsScanning = true;

        return result;
    }

    /**
     * @brief バーコードの読み取りを終了します
     * @return 実行結果
     */
    public ResultScanOFF scanOFF() {
        ResultScanOFF result = new ResultScanOFF();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()
                || !mIsInitializedDevice) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestScanOFF request = new RequestScanOFF(mControlDeviceManager.getProductId());

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mControlDeviceManager.write(request, TIME_OUT);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

        mIsScanning = false;

        return result;
    }

    /**
     * @brief Plug-Inのパッケージ情報を取得します。周辺装置とのやり取りは発生しません。
     * @return 実行結果
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer,
            String pluginName, String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, BarcodeReader.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief バーコードリーダ Plug-In をターミネートします
     * @return 実行結果
     */
    public ResultTermBCR termBCR() {
        mReceiveBCRThread = null;

        mControlDeviceManager
                .unregisterNotifyUsbDeviceConnectionListener(mNotifyUsbDeviceConnectionListener);

        ResultTermBCR result = new ResultTermBCR();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        mIsInitializedDevice = false;
        return result;
    }

    /**
     * @brief バーコードリーダからのデータ受信を通知します
     * @param result 通知データ
     */
    private void notifyReceiveBCR(ResponseReceiveBCR result) {
        synchronized (mIBcrServiceListenerList) {
            for (Map.Entry<String, IBcrServiceListener> listener : mIBcrServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onReceiveBCR(result);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief バーコードリーダ間I/Fのエラーを通知します
     * @param result 通知データ
     */
    private void notifyBCRError(ResponseError result) {
        synchronized (mIBcrServiceListenerList) {
            for (Map.Entry<String, IBcrServiceListener> listener : mIBcrServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(result);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * @brief ReceiveBCR用スレッドのスリープ
     * @param start タスク開始時間
     */
    private void sleepReceiveBCRThread(long start) {
        long now = System.currentTimeMillis();
        if ((now - start) < CYCLE_TIME) {
            try {
                Thread.sleep(CYCLE_TIME - (now - start));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @brief データ読み出し(モデル指定なし)
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    private byte[][] readNotSpecified(int timeout) {
        List<byte[]> ret = new ArrayList<byte[]>();
        while (true) {
            byte[] buffer = mControlDeviceManager.read(timeout);
            if (buffer == null || BarcodeReaderUtil.isTimeout(buffer)) {
                break;
            }
            ret.add(buffer);
        }
        return CalcUtil.toMatrix(ret);
    }

    /**
     * @brief データ読み出し(M-10, C-40/41)
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     * @retval ACK 応答
     * @retval NAK 応答
     * @retval 診断コマンド応答(データ + <ACK>)
     * @retval バーコード読み取り結果(データ)【ScanON-ScanOFF間のみ】
     * @retval Empty 受信データなし
     */
    private byte[][] readM10C40C41(int timeout) {
        byte[] buffer = mControlDeviceManager.read(timeout);
        if (buffer == null || BarcodeReaderUtil.isTimeout(buffer)) {
            // 受信データなし
            return new byte[0][0];
        }
        List<Byte> ret = CalcUtil.toList(buffer);
        while (!BarcodeReaderUtil.isReceiveEnd(ret)) {
            buffer = mControlDeviceManager.read(timeout);
            if (buffer == null || BarcodeReaderUtil.isTimeout(buffer)) {
                // 受信エラー
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                notifyBCRError(new ResponseError(PluginDefine.ECODE_EXT_CODE, 0,
                        PluginDefine.ERROR_EXT_CODE_NETWORK, null));
                return new byte[0][0];
            }
            ret.addAll(CalcUtil.toList(buffer));
        }

        if (!mIsScanning && BarcodeReaderUtil.isScanData(ret)) {
            // バーコードスキャン中以外は、バーコード読み取り結果を返却しない
            return new byte[0][0];
        }

        // 受信データを結合後、受信データ通知用に分割
        return BarcodeReaderUtil.splitReceiveData(CalcUtil.toArray(ret));
    }

    /**
     * @brief バーコードリーダデバイスのバッファをクリアする
     */
    private void clearBuffer() {
        while (!BarcodeReaderUtil.isTimeout(
                mControlDeviceManager.read(1))) {
            // NOP
        }
    }

    /** @brief USB コネクションリスナー */
    private NotifyUsbDeviceConnectionListener mNotifyUsbDeviceConnectionListener = new NotifyUsbDeviceConnectionListener() {

        /**
         * @brief バーコードリーダ接続通知
         */
        @Override
        public void onOpened(UsbDevice device) {
            // NOP
        }

        /**
         * @brief バーコードリーダ切断通知
         */
        @Override
        public void onClosed(UsbDevice device) {
            if (mIsInitializedDevice) {
                // BCRは切断時にecode=104を1回だけ通知
                notifyBCRError(new ResponseError(PluginDefine.ECODE_PORT_ERROR, 0, 0, null));
            }
            mIsInitializedDevice = false;
        }

    };

}
