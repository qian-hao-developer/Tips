
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * カード活性化要求クラス
 */
public class RequestActivationIcCard extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x03;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 0x0009;

    /** @brief 通常の活性化/Warmリセット指定 */
    private boolean mReq;

    /** @brief 処理番号 */
    private int mNum;

    /**
     * @brief コンストラクタ
     * @param[in] req 通常の活性化/Warmリセット指定
     * @param[in] req 処理番号
     */
    public RequestActivationIcCard(boolean req, int num) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mReq = req;
        mNum = num;
    }

    /**
     * @brief 通常の活性化/Warmリセット指定を取得します
     * @retun 通常の活性化/Warmリセット指定
     */
    public boolean isReq() {
        return mReq;
    }

    /**
     * @brief 通常の活性化/Warmリセット指定を設定します
     * @param[in] 通常の活性化/Warmリセット指定
     */
    public void setReq(boolean req) {
        mReq = req;
    }

    /**
     * @brief 処理番号を取得する
     * @return 処理番号
     */
    public int getNum() {
        return mNum;
    }

    /**
     * @brief 処理番号を設定する
     * @param[in] 処理番号
     */
    public void setNum(int num) {
        mNum = num;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] paramater = new byte[LENGTH];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);
        paramater[2] = 0;
        paramater[3] = 0;
        paramater[4] = 0;
        paramater[5] = 0;
        paramater[6] = 0;
        paramater[7] = 0;
        paramater[8] = (byte) (mNum & 0xff);

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (!(0 <= mNum && mNum <= 254)) {
            return false;
        }

        if (!mReq) {
            return false;
        }

        return true;
    }

}
