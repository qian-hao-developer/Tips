package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

/**
 * PFダウンロードデータResponseクラス.
 * 
 */
public class PFDownloadDataResponse extends BaseDownloadDataResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = PFDownloadDataResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC1;

    /** Constructor */
    public PFDownloadDataResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
