
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetUID2 extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetUID2(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetUID2() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetUID2> CREATOR = new Parcelable.Creator<ResultGetUID2>() {

        @Override
        public ResultGetUID2 createFromParcel(Parcel in) {
            return new ResultGetUID2(in);
        }

        @Override
        public ResultGetUID2[] newArray(int size) {
            return new ResultGetUID2[size];
        }
    };
}
