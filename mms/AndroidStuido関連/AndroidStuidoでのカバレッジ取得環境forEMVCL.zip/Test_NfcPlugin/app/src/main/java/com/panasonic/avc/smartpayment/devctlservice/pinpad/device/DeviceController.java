
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import android.content.Context;
import android.hardware.usb.UsbDevice;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.DeviceType;

/**
 * デバイスコントロール用抽象化クラス
 */
public class DeviceController {

    /** @brief 利用するデバイスの種類 */
    protected DeviceType mType = DeviceType.NONE;

    /** @brief コンテキスト */
    protected Context mContext;

    /**
     * @brief コンストラクタ
     * @param[in] context コンテキスト
     */
    public DeviceController(Context context) {
        mContext = context;
    }

    protected boolean isStart = false;

    public void setStart(boolean isStart) {
        this.isStart = isStart;
    }

    /**
     * @brief データをデバイスに書き込む
     * @param buffer データ
     * @return 書き込みに成功したかどうか
     */
    public boolean write(byte[] buffer, int timeout) {
        return false;
    }

    /**
     * @brief データをデバイスに読み込む
     * @return 読み込んだデータ
     */
    public byte[] read(int timeout) {
        return null;
    }

    /**
     * データ読み出し(Pinpad)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    public byte[] read(byte[] buffer, int timeout) {
        return null;
    }

    /**
     * @brief デバイスの初期化
     * @return 成功したかどうか
     */
    public boolean init() {
        return false;
    }

    /**
     * @brief デバイスの再初期化
     * @return 成功したかどうか
     */
    public boolean init(UsbDevice device) {
        return false;
    }

    /**
     * @brief デバイスの終了処理
     * @return 成功したかどうか
     */
    public boolean term() {
        return false;
    }

    /**
     * @brief デバイスの終了処理
     * @return 成功したかどうか
     */
    public boolean term(UsbDevice device) {
        return false;
    }

    /**
     * @brief デバイスと接続する
     * @param device 接続するUSBデバイス
     * @return 成功したかどうか
     */
    public boolean connect(UsbDevice device) {
        return false;
    }

    /**
     * @brief デバイスと接続する
     * @return 成功したかどうか
     */
    public boolean connect() {
        return false;
    }

    /**
     * @brief デバイスと切断する
     * @return 成功したかどうか
     */
    public boolean disconnect() {
        return false;
    }

    /**
     * @brief デバイスの種別を取得する
     * @return デバイスの種別
     */
    public DeviceType getType() {
        return mType;
    }

    /**
     * @brief デバイスの種別を設定する
     * @param type デバイスの種別
     */
    public void setType(DeviceType type) {
        mType = type;
    }

    /**
     * @brief デバイスの有無
     * @return 有無
     */
    public boolean isActive() {
        return false;
    }

    /**
     * @brief デバイスのread/write権限をロックする
     */
    public void lock() {
        return;
    }

    /**
     * @brief デバイスのread/write権限を解除する
     */
    public void unlock() {
        return;
    }

    /**
     * @brief デバイスのロック状態を解除する
     */
    public void clearLock() {
        return;
    }

    /**
     * @brief デバイスのread/write権限を取得する
     */
    public boolean isLocked() {
        return false;
    }

    /**
     * @brief デバイスのロックオブジェクトを取得する
     */
    public Object getLockObject() {
        return null;
    }

}
