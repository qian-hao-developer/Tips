
package com.panasonic.avc.smartpayment.devctlservice.share.result;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * デフォルト処理結果データ(PINPADデータ入力)
 */
public class AnalyzeResultData extends ResultData {

    /** @brief STXコード */
    private byte mStx = PinpadDefine.STX_CODE;

    /** @brief ID */
    protected CommandId mId;

    /** @brief メインコマンド */
    protected byte mMainCommand;

    /** @brief サブコマンド */
    protected byte mSubCommand;

    /** @brief ETXコード */
    private byte mEtx = PinpadDefine.ETX_CODE;

    /** @brief CRC */
    private int mCrc;

    /**
     * @brief コンストラクタ
     */
    public AnalyzeResultData(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public AnalyzeResultData() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<AnalyzeResultData> CREATOR = new Parcelable.Creator<AnalyzeResultData>() {
        public AnalyzeResultData createFromParcel(Parcel in) {
            return new AnalyzeResultData(in);
        }

        public AnalyzeResultData[] newArray(int size) {
            return new AnalyzeResultData[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
    }

    /**
     * @brief レスポンスデータを解析する(データ長、CRC)
     * @param bytes チェックしたいバイト列
     * @return 成否
     */
    protected boolean checkResponseData(byte[] bytes) {

        if (bytes == null || bytes.length < PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER) {
            return false;
        }

        if (bytes[0] != mStx) {
            return false;
        }

        if (bytes[bytes.length - PinpadDefine.CRC_SIZE - 1] != mEtx) {
            return false;
        }

        byte[] calcCRC = new byte[bytes.length - PinpadDefine.CRC_NOT_CALC_SIZE];

        System.arraycopy(bytes, PinpadDefine.STX_SIZE, calcCRC, 0, bytes.length
                - PinpadDefine.CRC_NOT_CALC_SIZE);

        int crc = CalcUtil.createCRC(calcCRC);

        int inputCrc = (int) ((bytes[bytes.length - PinpadDefine.CRC_SIZE] & 0xff) << 8)
                | (int) (bytes[bytes.length - PinpadDefine.CRC_SIZE + 1] & 0xff);

        if (crc != inputCrc) {
            return false;
        }

        return true;
    }

    /**
     * @brief PINPADからのレスポンスをデータクラスに反映する
     * @param bytes バイト列
     * @return 反映できたかどうか
     */
    public boolean inputPinpadResult(byte[] bytes) {
        return false;
    }

    // FIXME: サイズチェックは UsbDeviceController レイヤで行ってください
    /**
     * @brief PINPADからのレスポンスをデータサイズにカットする
     * @param bytes レスポンスデータ
     * @return カット後のデータ
     */
    protected byte[] cutPinpadResult(byte[] bytes) {
        if (bytes == null || bytes.length < PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER) {
            return null;
        }

        byte low = bytes[PinpadDefine.INDEX_LEN_1];
        byte high = bytes[PinpadDefine.INDEX_LEN_2];

        int len = CalcUtil.toInt(low, high) + PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER;

        if (bytes.length < len) {
            return null;
        }

        byte[] buffer = new byte[len];

        System.arraycopy(bytes, 0, buffer, 0, len);

        return buffer;
    }

}
