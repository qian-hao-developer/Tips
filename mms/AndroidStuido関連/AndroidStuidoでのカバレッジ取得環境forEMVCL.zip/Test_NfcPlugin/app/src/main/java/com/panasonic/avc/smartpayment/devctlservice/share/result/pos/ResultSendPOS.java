
package com.panasonic.avc.smartpayment.devctlservice.share.result.pos;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * SendPOSの実行結果データ
 */
public class ResultSendPOS extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultSendPOS(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendPOS() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendPOS> CREATOR = new Parcelable.Creator<ResultSendPOS>() {
        public ResultSendPOS createFromParcel(Parcel in) {
            return new ResultSendPOS(in);
        }

        public ResultSendPOS[] newArray(int size) {
            return new ResultSendPOS[size];
        }
    };
}
