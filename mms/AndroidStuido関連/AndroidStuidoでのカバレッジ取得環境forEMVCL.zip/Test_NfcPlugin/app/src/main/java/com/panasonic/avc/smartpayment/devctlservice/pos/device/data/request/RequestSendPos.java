
package com.panasonic.avc.smartpayment.devctlservice.pos.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * 暗証番号入力用チャレンジ取得コマンド
 */
public class RequestSendPos {

    /** @brief ブロックサイズ */
    private int mBlockSize;

    /** @brief 送信データ */
    private String mData;

    /** @brief 送信データサイズ */
    private int mDataSize;

    /**
     * @brief コンストラクタ
     * @param datasz 送信データサイズ
     * @param data 送信データ
     * @param blocksz ブロックサイズ
     */
    public RequestSendPos(int datasz, String data, int blocksz) {
        mDataSize = datasz;
        mData = data;
        mBlockSize = blocksz;
    }

    /**
     * @see RequestData#toCommand()
     */
    public byte[] toCommand() {
        return CalcUtil.toByte(mData);
    }

    /**
     * @see RequestData#isValidValue()
     */
    public boolean isValidValue() {
        if (mDataSize > 32 * 1024) {
            // 32KB を超える
            return false;
        }
        if (mBlockSize != 0 && mBlockSize < mDataSize) {
            // ブロックサイズ指定時、データサイズがブロックサイズを超える
            return false;
        }
        if (mData == null || mData.equals("")) {
            return false;
        }
        try {
            byte[] byteArray = CalcUtil.toByte(mData);
            if (byteArray == null) {
                return false;
            }
            if (byteArray.length != mDataSize) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        if (mBlockSize < 0) {
            return false;
        }

        return true;
    }

    /**
     * @brief ブロックサイズを取得します
     * @return ブロックサイズ
     */
    public int getBlockSize() {
        return mBlockSize;
    }
}
