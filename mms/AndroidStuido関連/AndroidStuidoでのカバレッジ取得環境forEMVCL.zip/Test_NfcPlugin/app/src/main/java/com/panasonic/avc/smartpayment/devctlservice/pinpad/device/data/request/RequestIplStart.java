
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * IPL開始コマンド
 */
public class RequestIplStart extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x03;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x00;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 7;

    private long mFileSize;

    /**
     * @brief コンストラクタ
     */
    public RequestIplStart(long fileSize) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mFileSize = fileSize;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = (byte) (mFileSize & 0xff);
        parameter[3] = (byte) ((mFileSize >> 8) & 0xff);
        parameter[4] = (byte) ((mFileSize >> 16) & 0xff);
        parameter[5] = (byte) ((mFileSize >> 24) & 0xff);
        parameter[6] = (byte) 0xff;

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mFileSize <= 0) {
            return false;
        }

        return true;
    }
}
