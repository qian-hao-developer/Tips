
package com.panasonic.avc.smartpayment.devctlservice;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.msr.MagneticStripeCard;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrService;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseMsData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultTermMSR;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * タンパ予兆監視サービス
 */
public class TamperMonitorService extends Service {

    private static final String TAG = TamperMonitorService.class.getSimpleName();

    /** @brief ログ出力制御 */
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief MSRコントロールクラス */
    private MagneticStripeCard mMagneticStripeCard = MagneticStripeCard.getInstance();
    /** @brief MSRサービス用インターフェース */
    private IMsrService mIMsrService;

    private static final int TAMPER_INDICATION_MONITOR = 0x0FA;

    private static final int TAMPER_OMEM_ERROR = -1;

    private final static int TAMPER_MONITOR_NONE = 0;
    private final static int TAMPER_MONITOR_INIT = 1;
    private final static int TAMPER_MONITOR_NORMAL = 2;

    /** @brief サービスの定期実行の間隔をミリ秒で指定。 処理が終了してから次に呼ばれるまでの時間 */
    private static final long TAMPER_INTERVAL_NORMAL = AlarmManager.INTERVAL_DAY; // 24時間後
    private static final long TAMPER_INTERVAL_SHORT = (60 * 1000); // リトライは省電力設定最短の１分
    private static final long TAMPER_INTERVAL_INSTANT = (1 * 1000); // 起動時のリトライは１秒後

    /** @brief 非同期用スレッド(TamperMonitor) */
    private Thread mTamperMonitorThread;

    private static int mTamperStatus = TAMPER_MONITOR_NONE;

    /**
     * @see Service#onCreate()
     */
    @Override
    public void onCreate() {
        super.onCreate();
        // mLoggingManager.d(TAG, "onCreate");

        Intent tcLogServiceIntent = new Intent(
                "com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogService");

        Intent intent = new Intent(TamperDecideService.class.getName());
        intent.setAction(IMsrService.class.getName());
        this.bindService(intent, mServiceConnectionMsr,
                Activity.BIND_AUTO_CREATE);

    }

    @Override
    public IBinder onBind(Intent intent) {
        // mLoggingManager.d(TAG, "onBind");
        return null;
    }

    /**
     * @see Service#onDestroy()
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        // mLoggingManager.d(TAG, "onDestroy");

        if (mServiceConnectionMsr != null) {
            unbindService(mServiceConnectionMsr);
        }
        /*
         * / アラームで起動するので、削除 startService(new Intent(this,
         * TamperMonitorService.class)); /
         */
    }

    /**
     * サービスの定期実行を解除し，サービスを停止
     */
    public void stopResident(Context context) {
        /*
         * / 仕様上、常に実行予約するので、アラームを停止する処理は必要無としない new Intent(context,
         * this.getClass()); // アラームを解除 PendingIntent pendingIntent =
         * PendingIntent.getService( context, 0, intent,
         * PendingIntent.FLAG_UPDATE_CURRENT ); AlarmManager alarmManager =
         * (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
         * alarmManager.cancel(pendingIntent); } /
         */
    }

    /**
     * 定期実行したいタスクの処理　タスクの実行が完了したら、次回の実行予定を設定
     */
    private void execTask() {
        // mLoggingManager.d(TAG, "execTask");

        long interval = TAMPER_INTERVAL_NORMAL;

        // ※シリアル通信処理が重い場合は、別スレッド実行
        // 1.省電力モード中（で無い場合は、以下実行せずに１分後に再実行）
        // 2.MSR CPUから「タンパ予兆カウント」取得（応答無しは、24時間後に再実行）
        // 3.運用ログ保存（前回保存値と差異有れば、監視ログも保存するのはTcLogServiceにて実現）

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean isScreenOn = pm.isScreenOn();

        if ((!isScreenOn)
                || (mTamperStatus != TAMPER_MONITOR_NORMAL)) {
            // タンパ予兆カウント取得
            int rxCount = 0;
            ResultData result = null;

            // mLoggingManager.d(TAG, "mIMsrService : " + mIMsrService);

            if (mIMsrService == null) {
                // bindService ミスした際の再実行予約は24時間後
                mTamperStatus = TAMPER_MONITOR_NORMAL;
                makeNextPlan(TAMPER_INTERVAL_NORMAL);
                return;
            }

            try {
                result = mIMsrService.initMSR();
                // mLoggingManager.d(TAG, "mIMsrService.initMSR()");
            } catch (RemoteException e) {
                e.printStackTrace();
            }

            // mLoggingManager.d(TAG, "MsrInit : " + result);

            if (result != null) {
                // mLoggingManager.d(TAG, "Mpnitor MsrInit Device : " +
                // result.getDevice());
                // mLoggingManager.d(TAG, "Monitor MsrInit Upos : " +
                // result.getUpos());

                if ((result.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS)
                        && ((result.getUpos() == PluginDefine.RESULT_UPOS_SEQUENCE_ERROR) || (result
                                .getUpos() == PluginDefine.RESULT_UPOS_SCCESS))) {
                    // タンパ予兆カウント取得通信処理(MSR CPUシリアル通信)
                    // ※省電力モード中なので、MSR Read停止処理は不必要
                    rxCount = mMagneticStripeCard.getOmenOfTamper();

                    // mLoggingManager.d(TAG, "ScreenOff : " + rxCount);

                    // 応答エラー以外は、ログ保存
                    if (rxCount != TAMPER_OMEM_ERROR) {
                        mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.MS, -1,
                                rxCount, TAMPER_INDICATION_MONITOR, "tamper_indication_monitor");
                        // mLoggingManager.d(TAG, "putLogDevice : " +
                        // "tamper_indication_monitor");

                        // ログ保存出来た時のみ、電源起動モニタ完了済みとする
                        if (mTamperStatus == TAMPER_MONITOR_NONE) {
                            mTamperStatus = TAMPER_MONITOR_INIT;
                        }
                    }

                    // 自らinitした時以外は、termしない
                    if ((result.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS)
                            && (result.getUpos() == PluginDefine.RESULT_UPOS_SEQUENCE_ERROR)) {
                        try {
                            ResultTermMSR resultTerm = mIMsrService.termMSR();
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        // mLoggingManager.d(TAG, "tamperStatus : " + mTamperStatus);

        if (mTamperStatus == TAMPER_MONITOR_NONE) {
            // 電源起動時のlog.記録出来なかった時は、１秒後に再実行予約
            mTamperStatus = TAMPER_MONITOR_INIT;
            interval = TAMPER_INTERVAL_INSTANT;
        } else if (mTamperStatus == TAMPER_MONITOR_INIT) {
            // 電源起動時のlog.記録完了時は、24時間後に再実行予約
            mTamperStatus = TAMPER_MONITOR_NORMAL;
        } else if (isScreenOn) {
            // 省電力モードで無くlog.記録出来なかった時は、60秒後に再実行予約(ユーザー最短選択が１分）
            interval = TAMPER_INTERVAL_SHORT;
        }

        // 次回の実行予定
        makeNextPlan(interval);
    }

    /**
     * 次回の実行予定を設定
     */
    private void makeNextPlan(long interval) {

        long now = System.currentTimeMillis();
        Intent intent = new Intent(this, this.getClass());

        intent.setAction(TamperBroadcastAction.ACTION_TAMPER_ALARM);

        // アラームをセット
        PendingIntent alarmSender = PendingIntent
                .getService(this, 0, intent, 0);

        // mLoggingManager.d(TAG, "interval : " + interval);

        AlarmManager am = (AlarmManager) this
                .getSystemService(Context.ALARM_SERVICE);
        am.set(AlarmManager.RTC_WAKEUP, // 基本、スリープ時にlog記録するのでWAKEUP指定
                now + interval, alarmSender);
        // 次回登録が完了
    }

    private void tamperMonitor() {
        mTamperMonitorThread = new Thread() {
            @Override
            public void run() {
                // タスクを実行
                execTask();

                // サービス自体を停止
                stopSelf();
            }
        };
        mTamperMonitorThread.start();
    }

    /**
     * @see ServiceConnection
     */
    private ServiceConnection mServiceConnectionMsr = new ServiceConnection() {

        /**
         * @see ServiceConnection#onServiceConnected(ComponentName, IBinder)
         */
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // mLoggingManager.d(TAG, "MSR onServiceConnected");
            mIMsrService = IMsrService.Stub.asInterface(service);
            try {
                mIMsrService.registerMsrServiceListener(
                        TamperMonitorService.class.getName(),
                        mIMsrServiceListener);
            } catch (RemoteException e) {
                e.printStackTrace();
            }

            tamperMonitor();
        }

        /**
         * @see ServiceConnection#onServiceDisconnected(ComponentName)
         */
        @Override
        public void onServiceDisconnected(ComponentName name) {
            // mLoggingManager.d(TAG, "MSR onServiceDisconnected");
            try {
                mIMsrService
                        .unregisterMsrServiceListener(TamperMonitorService.class
                                .getName());
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            mIMsrService = null;
        }

    };

    /**
     * @see mIMsrServiceListener
     */
    private IMsrServiceListener.Stub mIMsrServiceListener = new IMsrServiceListener.Stub() {

        /**
         * @see IMsrServiceListener#onResultMsData(ResponseMsData)
         */
        @Override
        public void onResultMsData(ResponseMsData result)
                throws RemoteException {
            // mLoggingManager.d(TAG, "onResultMsData " + result.toJSON());
        }

        /**
         * @see IMsrServiceListener#onError(com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseError)
         */
        @Override
        public void onError(
                com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseError result)
                throws RemoteException {
            // mLoggingManager.d(TAG, "onError " + result.toJSON());
        }
    };

}
