
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetArea extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetArea(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetArea() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetArea> CREATOR = new Parcelable.Creator<ResultSetArea>() {

        @Override
        public ResultSetArea createFromParcel(Parcel in) {
            return new ResultSetArea(in);
        }

        @Override
        public ResultSetArea[] newArray(int size) {
            return new ResultSetArea[size];
        }
    };
}
