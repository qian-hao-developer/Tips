
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * TermPrnの実行結果データ
 */
public class ResultTermPrn extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermPrn(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermPrn() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermPrn> CREATOR = new Parcelable.Creator<ResultTermPrn>() {
        public ResultTermPrn createFromParcel(Parcel in) {
            return new ResultTermPrn(in);
        }

        public ResultTermPrn[] newArray(int size) {
            return new ResultTermPrn[size];
        }
    };
}
