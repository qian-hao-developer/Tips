
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetUID extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x0a;

    private static final int LENGTH = 5;

    private static final String UID2 = "uid";

    private String mUid2;

    public ResponseGetUID(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mUid2 = String.format("%02x%02x%02x%02x", result[1], result[2], result[3], result[4]);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(UID2, mUid2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

}
