
package com.panasonic.avc.smartpayment.devctlservice.tamper;

import java.io.File;
import java.io.IOException;

/**
 * タンパ検知情報の制御クラス - タンパ検知ファイルの有無で管理する
 */
public class TamperDetectionInfoController {

    /** @brief デバイス種別 */
    public enum DEVICE {
        PINPAD,
        EMCRW,
    }

    /** @brief PINPADのタンパ検知ファイル */
    private static final String PINPAD_TAMPER_FILE = "/log/pinpad_tamper";

    /** @brief EMCRWのタンパ検知ファイル */
    private static final String EMCRW_TAMPER_FILE = "/log/emcrw_tamper";

    /**
     * @brief タンパ検出済みか判定する
     * @param device タンパ検知対象デバイス
     * @return タンパ検出済みかどうか
     */
    public static boolean hasTamper(DEVICE device) {
        File file = getTamperInfoFile(device);
        if (file.exists()) {
            return true;
        }
        return false;
    }

    /**
     * @brief タンパ検出済みファイルを作成する
     * @param device タンパ検知対象デバイス
     */
    public static void saveTamper(DEVICE device) {
        File file = getTamperInfoFile(device);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @brief タンパ検出済みファイルを取得する
     * @param device タンパ検知対象デバイス
     */
    public static File getTamperInfoFile(DEVICE device) {
        switch (device) {
            case PINPAD:
                return new File(PINPAD_TAMPER_FILE);
            case EMCRW:
                return new File(EMCRW_TAMPER_FILE);
            default:
                return null;
        }
    }

}
