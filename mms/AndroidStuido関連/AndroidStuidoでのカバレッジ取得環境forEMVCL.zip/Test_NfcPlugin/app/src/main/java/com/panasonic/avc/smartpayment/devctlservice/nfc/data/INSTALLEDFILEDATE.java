package com.panasonic.avc.smartpayment.devctlservice.nfc.data;

/**
 * 設定されたファイルの日付情報格納クラス<br>
 */
public class INSTALLEDFILEDATE {
    public static final byte[] NOT_SET_KERNELFILE = 
            new byte[]{(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00};
    public static final byte[] NOT_SET_FILEDLL_TAIL = 
            new byte[]{(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00};
    /** YYYYMMDD. */
    public byte[] CommonFile;
    public byte[] KernelC1File;
    public byte[] KernelC2File;
    public byte[] KernelC3File;
    public byte[] KernelC4File;
    public byte[] KernelC5File;
    public byte[] KernelC6File;
    public byte[] KernelC7File;
    public byte[] KernelC8File;
    public byte[] KernelC9File;
    public byte[] KernelC10File;
    public byte[] KernelC11File;
    public byte[] KernelC12File;
    public byte[] KernelC13File;
    public byte[] KernelC14File;
    public byte[] KernelC15File;
    /** 1Byte目はファイル番号を示す。2～5Byte目は日付を示す。 YYYYMMDD.*/
    public byte[] FileDLL1;
    public byte[] FileDLL2;
    public byte[] FileDLL3;
    public byte[] FileDLL4;
    public byte[] FileDLL5;
    public byte[] FileDLL6;
    public byte[] FileDLL7;
    public byte[] FileDLL8;
    public byte[] FileDLL9;
    public byte[] FileDLL10;
    public byte[] FileDLL11;
    public byte[] FileDLL12;
    public byte[] FileDLL13;
    public byte[] FileDLL14;
    public byte[] FileDLL15;
}
