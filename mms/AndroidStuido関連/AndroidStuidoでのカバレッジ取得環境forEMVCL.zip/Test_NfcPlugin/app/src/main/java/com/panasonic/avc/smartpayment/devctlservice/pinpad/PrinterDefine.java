
package com.panasonic.avc.smartpayment.devctlservice.pinpad;

/**
 * プリンター定義
 */
public class PrinterDefine {

    /** @brief コマンドのSTX値 */
    public static final byte STX_CODE = 0x02;

    /** @brief STXサイズ */
    public static final int STX_SIZE = 1;

    /** @brief ヘッダーサイズ */
    public static final int RESERVED_SIZE = 1;

    /** @brief ヘッダーサイズ */
    public static final int COMMAND_ID_SIZE = 2;

    /** @brief ヘッダーサイズ */
    public static final int COMMAND_DETAIL_SIZE = 2;

    /** @brief CRCサイズ */
    public static final int CRC_SIZE = 2;

    /** @brief シーケンスサイズ */
    public static final int SEQUENCE_SIZE = 2;

    /** @brief パラメータ長サイズ */
    public static final int LENGTH_SIZE = 2;

    /** @brief パラメータを除いた固定のデータサイズ */
    public static final int DATA_SIZE_WITHOUT_PARAMETER = STX_SIZE + RESERVED_SIZE
            + COMMAND_ID_SIZE + COMMAND_DETAIL_SIZE + SEQUENCE_SIZE + LENGTH_SIZE + CRC_SIZE;

    /** @brief CRC計算領域におけるパラメータを除いたデータサイズ */
    public static final int CRC_CALC_SIZE_WITHOUT_PARAMETER = COMMAND_ID_SIZE + COMMAND_DETAIL_SIZE
            + SEQUENCE_SIZE + LENGTH_SIZE;

    /** @brief STXの配列要素位置 */
    public static final int INDEX_STX = 0;

    /** @brief コマンド種別(low)の配列要素位置 */
    public static final int INDEX_ID_1 = INDEX_STX + 2;

    /** @brief コマンド種別(high)の配列要素位置 */
    public static final int INDEX_ID_2 = INDEX_ID_1 + 1;

    /** @brief コマンド詳細(low)の配列要素位置 */
    public static final int INDEX_DETAIL_1 = INDEX_ID_2 + 1;

    /** @brief コマンド詳細(high)の配列要素位置 */
    public static final int INDEX_DETAIL_2 = INDEX_DETAIL_1 + 1;

    /** @brief シーケンス(low)の配列要素位置 */
    public static final int INDEX_SEQ_1 = INDEX_DETAIL_2 + 1;

    /** @brief シーケンス(high)の配列要素位置 */
    public static final int INDEX_SEQ_2 = INDEX_SEQ_1 + 1;

    /** @brief データ長(low)の配列要素位置 */
    public static final int INDEX_LEN_1 = INDEX_SEQ_2 + 1;

    /** @brief データ長(high)の配列要素位置 */
    public static final int INDEX_LEN_2 = INDEX_LEN_1 + 1;

    /** @brief パラメータの配列要素位置 */
    public static final int INDEX_PARAMETER = INDEX_LEN_2 + 1;
}
