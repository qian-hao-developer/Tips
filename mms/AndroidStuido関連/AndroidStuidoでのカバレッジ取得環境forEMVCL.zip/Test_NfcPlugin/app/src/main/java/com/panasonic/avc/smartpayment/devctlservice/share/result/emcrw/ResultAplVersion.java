
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import java.util.ArrayList;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultAplVersion extends ResultData {

    ArrayList<String> mAplVersion;

    /**
     * @brief コンストラクタ
     */
    public ResultAplVersion(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultAplVersion() {

    }

    public ArrayList<String> getAplVersion() {
        return mAplVersion;
    }

    public void setAplVersion(ArrayList<String> list) {
        mAplVersion = list;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultAplVersion> CREATOR = new Parcelable.Creator<ResultAplVersion>() {

        @Override
        public ResultAplVersion createFromParcel(Parcel in) {
            return new ResultAplVersion(in);
        }

        @Override
        public ResultAplVersion[] newArray(int size) {
            return new ResultAplVersion[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeStringList(mAplVersion);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mAplVersion = in.createStringArrayList();
    }
}
