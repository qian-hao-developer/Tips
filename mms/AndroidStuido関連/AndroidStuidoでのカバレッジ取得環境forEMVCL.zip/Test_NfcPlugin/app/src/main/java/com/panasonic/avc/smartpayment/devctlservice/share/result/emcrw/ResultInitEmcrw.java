
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultInitEmcrw extends ResultData {

    /** @brief モバイル型 **/
    public static final int MODE_TYPE_M = 1;

    /** @brief 据置型 **/
    public static final int MODE_TYPE_R = 2;

    /** @brief 非接触ICカードリーダライタのタイプ **/
    private int mModelType;

    /**
     * @brief コンストラクタ
     */
    public ResultInitEmcrw(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitEmcrw() {

    }

    public int getModelType() {
        return mModelType;
    }

    public void setModelType(int mModelType) {
        this.mModelType = mModelType;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitEmcrw> CREATOR = new Parcelable.Creator<ResultInitEmcrw>() {

        @Override
        public ResultInitEmcrw createFromParcel(Parcel in) {
            return new ResultInitEmcrw(in);
        }

        @Override
        public ResultInitEmcrw[] newArray(int size) {
            return new ResultInitEmcrw[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mModelType);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mModelType = in.readInt();
    }
}
