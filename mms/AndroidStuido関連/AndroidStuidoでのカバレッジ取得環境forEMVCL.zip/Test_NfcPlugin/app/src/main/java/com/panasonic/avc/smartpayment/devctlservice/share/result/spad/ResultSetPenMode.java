
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetPenMode extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetPenMode(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetPenMode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetPenMode> CREATOR = new Parcelable.Creator<ResultSetPenMode>() {

        @Override
        public ResultSetPenMode createFromParcel(Parcel in) {
            return new ResultSetPenMode(in);
        }

        @Override
        public ResultSetPenMode[] newArray(int size) {
            return new ResultSetPenMode[size];
        }
    };
}
