
package com.panasonic.avc.smartpayment.devctlservice.pinpad.icrw;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestActivationIcCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceProductInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeactivationIcCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDriverReset;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestIcCardStatus;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestSendProtocolData;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAdvanceDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.NotifyStatusListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.PluginType;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.StatusType;
import com.panasonic.avc.smartpayment.devctlservice.share.IIcrwServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.icrw.ResponseActivationIcc;
import com.panasonic.avc.smartpayment.devctlservice.share.response.icrw.ResponseDeactivationIcc;
import com.panasonic.avc.smartpayment.devctlservice.share.response.icrw.ResponseDriverReset;
import com.panasonic.avc.smartpayment.devctlservice.share.response.icrw.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.icrw.ResponseIcCard;
import com.panasonic.avc.smartpayment.devctlservice.share.response.icrw.ResponseSendAPDU;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultActivationIcc;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultDeactivationIcc;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultGetICStatus;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultGetIFDInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultInitICRW;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultSendAPDU;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultTermICRW;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;
import com.panasonic.avc.smartpayment.devctlservice.tamper.TamperDetectionInfoController;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * 接触ICカードリーダライタ処理部
 */
public class ContactIcCard {

    /** @brief デバッグ用タグ */
    private static final String TAG = ContactIcCard.class.getName();

    /** @brief シングルトンインスタンス */
    private static ContactIcCard sInstance = new ContactIcCard();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IIcrwServiceListener> mIIcrwServiceListenerList = new ConcurrentHashMap<String, IIcrwServiceListener>();

    /** @brief 非同期用スレッド(InitICRW) */
    private Thread mInitICRWThread;

    /** @brief 非同期用スレッド(mActivateIccThread) */
    private Thread mActivateIccThread;

    /** @brief 非同期用スレッド(mSendAPDUThread) */
    private Thread mSendAPDUThread;

    /** @brief 非同期用スレッド(mDeactivateIccThread) */
    private Thread mDeactivateIccThread;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 500;

    /** @brief Read時のタイムアウト */
    private static final int READ_TIME_OUT = 500;

    /** @brief ループ間隔 */
    private static final int CYCLE_TIME = 500;

    /** @brief タイムアウト(最小) */
    private static final int TIMEOUT_INIT_MIN = 3;

    /** @brief タイムアウト(最大) */
    private static final int TIMEOUT_INIT_MAX = 180;

    /** @brief データ読み込み終了フラグ */
    private boolean mIsActive;

    /** @brief InitICRWのタイムアウト設定 */
    private int mInitTimeout;

    /** @brief コンテキスト */
    private Context mContext;

    /** @brief 鍵なしイベントのエラー番号 */
    private static final int PLUGIN_RESULT_KEY_ERROR = 0x03;

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief プラグイン状態通知リスナーリスト */
    private ArrayList<NotifyStatusListener> mNotifyStatusListenerList = new ArrayList<NotifyStatusListener>();

    /** @brief 現在のプラグイン状態 */
    private StatusType mStatus = StatusType.TERM;

    /**
     * @brief コンストラクタ
     */
    private ContactIcCard() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static ContactIcCard getInstance() {
        return sInstance;
    }

    /**
     * @brief 接触ICカードリーダライタを初期化します
     * @param[in] ictimeout ICカード応答待ち時間(3〜180秒)
     * @return 実行結果
     */
    public ResultInitICRW initICRW(int ictimeout) {
        final RequestIcCardStatus request = new RequestIcCardStatus();
        ResultInitICRW result = new ResultInitICRW();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!(TIMEOUT_INIT_MIN <= ictimeout && ictimeout <= TIMEOUT_INIT_MAX)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mIsActive = true;
        mInitTimeout = ictimeout * 1000;

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        // ロック状態を初期化する
        mControlDeviceManager.clearLock();

        mInitICRWThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }

                byte[] buf;
                synchronized (mControlDeviceManager.getLockObject()) {
                    mControlDeviceManager.write(request, TIME_OUT);
                    buf = mControlDeviceManager.read(TIME_OUT);
                }

                ResponseIcCard initRes = new ResponseIcCard();
                if (!initRes.inputPinpadResult(buf)) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            PluginDefine.ERROR_EXT_CODE_REJECT, null);
                    if (isShowError(initRes.getDevice())) {
                        SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                    }
                    return;
                }
                boolean isIcCard = initRes.isIcCard();
                while (mIsActive) {

                    // USBが未接続状態の場合はカード検出を行わない
                    if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                        try {
                            sleep(CYCLE_TIME);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        continue;
                    }

                    long start = System.currentTimeMillis();
                    if (!mControlDeviceManager.isLocked()) {

                        byte[] buffer;
                        synchronized (mControlDeviceManager.getLockObject()) {
                            mControlDeviceManager.write(request, TIME_OUT);
                            buffer = mControlDeviceManager.read(TIME_OUT);
                        }

                        ResponseIcCard response = new ResponseIcCard();
                        boolean ret = response.inputPinpadResult(buffer);

                        long now = System.currentTimeMillis();

                        // 通信失敗時、または状態変化無しのときは次の処理が500ms周期になるように待つ
                        if (!ret || response.isIcCard() == isIcCard) {

                            if ((now - start) < CYCLE_TIME) {
                                try {
                                    sleep(CYCLE_TIME - (now - start));
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            continue;
                        }

                        isIcCard = response.isIcCard();

                        synchronized (mIIcrwServiceListenerList) {
                            for (Map.Entry<String, IIcrwServiceListener> listener : mIIcrwServiceListenerList
                                    .entrySet()) {
                                try {
                                    listener.getValue().onResultIcCardEvent(response);
                                } catch (RemoteException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        if (!isIcCard) {
                            sendDriverReset();
                        }

                    } else {
                        long now = System.currentTimeMillis();
                        try {
                            long sleep_time = (CYCLE_TIME - (now - start));
                            if (sleep_time > 0) {
                                sleep(sleep_time);
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        };

        mInitICRWThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        notifyStatus(StatusType.INIT);
        return result;
    }

    /**
     * @brief 装着されているICカードを活性化します
     * @param[in] req 通常の活性化/Warmリセットを指定する
     * @return 実行結果
     */
    public ResultActivationIcc activateIcc(boolean req) {
        final RequestActivationIcCard request = new RequestActivationIcCard(req, 0);

        ResultActivationIcc result = new ResultActivationIcc();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mActivateIccThread != null && mActivateIccThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mActivateIccThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }

                mControlDeviceManager.lock();
                synchronized (mControlDeviceManager.getLockObject()) {
                    mControlDeviceManager.write(request, TIME_OUT);
                }

                long start = System.currentTimeMillis();
                while (true) {

                    byte[] buffer;
                    synchronized (mControlDeviceManager.getLockObject()) {
                        buffer = mControlDeviceManager.read(READ_TIME_OUT);
                    }
                    ResponseActivationIcc response = new ResponseActivationIcc();

                    if (isTimeout(buffer)) {
                        long end = System.currentTimeMillis();
                        if (mInitTimeout > (end - start)) {
                            continue;
                        } else {
                            response.setResult(ResponseActivationIcc.RESULT_TIMEOUT);
                        }
                    } else {
                        boolean ret = response.inputPinpadResult(buffer);
                        if (!ret) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    PluginDefine.ERROR_EXT_CODE_REJECT, null);
                            mControlDeviceManager.unlock();
                            if (isShowError(response.getDevice())) {
                                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                            }
                            return;
                        }
                    }

                    synchronized (mIIcrwServiceListenerList) {
                        for (Map.Entry<String, IIcrwServiceListener> listener : mIIcrwServiceListenerList
                                .entrySet()) {
                            try {
                                listener.getValue().onResultActivation(response);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    mControlDeviceManager.unlock();
                    break;
                }
            }
        };
        mActivateIccThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief 接触ICカードにAPDUデータを送信します
     * @param[in] encrypt APDUデータの暗号化状態を指定
     * @param[in] num apduのデータ数(1以上32以下)
     * @param[in] apdu 暗号化した結果
     * @param[in] id データを識別するための番号
     * @return 実行結果
     */
    public ResultSendAPDU sendAPDU(boolean encrypt, int num, String apdu, int id) {
        final RequestSendProtocolData request = new RequestSendProtocolData(encrypt, num, apdu, id);

        ResultSendAPDU result = new ResultSendAPDU();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mSendAPDUThread != null && mSendAPDUThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mSendAPDUThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }

                mControlDeviceManager.lock();
                synchronized (mControlDeviceManager.getLockObject()) {
                    mControlDeviceManager.write(request, TIME_OUT);
                }
                long start = System.currentTimeMillis();

                while (true) {

                    byte[] buffer;
                    synchronized (mControlDeviceManager.getLockObject()) {
                        buffer = mControlDeviceManager.read(READ_TIME_OUT);
                    }
                    ResponseSendAPDU response = new ResponseSendAPDU();

                    if (isTimeout(buffer)) {
                        long end = System.currentTimeMillis();
                        if (mInitTimeout > (end - start)) {
                            continue;
                        } else {
                            response.setApduId(request.getSendAPDUId());
                            response.setResult(ResponseSendAPDU.PLUGIN_RESULT_TIMEOUT);
                        }
                    } else {
                        boolean ret = response.inputPinpadResult(buffer);
                        if (!ret) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    PluginDefine.ERROR_EXT_CODE_REJECT, null);
                            mControlDeviceManager.unlock();
                            if (isShowError(response.getDevice())) {
                                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                            }
                            return;
                        }
                    }

                    if (response.getResult() == PLUGIN_RESULT_KEY_ERROR) {
                        // FIXME 処理としてはResponseSendAPDU内部でログを表示する処理を書くべき
                        SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                PluginDefine.ERROR_EXT_CODE_REJECT, null);
                        mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.PED,
                                1, -1, buffer[PinpadDefine.INDEX_MC],
                                buffer[PinpadDefine.INDEX_SC],
                                null);
                        mControlDeviceManager.unlock();
                        return;
                    }

                    synchronized (mIIcrwServiceListenerList) {
                        for (Map.Entry<String, IIcrwServiceListener> listener : mIIcrwServiceListenerList
                                .entrySet()) {
                            try {
                                listener.getValue().onSentAPDU(response);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    mControlDeviceManager.unlock();
                    break;
                }
            }
        };

        mSendAPDUThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief 装着されているICカードを非活性化します
     * @return 実行結果
     */
    public ResultDeactivationIcc deactivateIcc() {

        final RequestDeactivationIcCard request = new RequestDeactivationIcCard();
        ResultDeactivationIcc result = new ResultDeactivationIcc();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mDeactivateIccThread != null && mDeactivateIccThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mDeactivateIccThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }

                mControlDeviceManager.lock();
                synchronized (mControlDeviceManager.getLockObject()) {
                    mControlDeviceManager.write(request, TIME_OUT);
                }

                long start = System.currentTimeMillis();

                while (true) {

                    byte[] buffer;
                    synchronized (mControlDeviceManager.getLockObject()) {
                        buffer = mControlDeviceManager.read(READ_TIME_OUT);
                    }
                    ResponseDeactivationIcc response = new ResponseDeactivationIcc();

                    if (isTimeout(buffer)) {
                        long end = System.currentTimeMillis();
                        if (mInitTimeout > (end - start)) {
                            continue;
                        } else {
                            response.setResult(ResponseDeactivationIcc.RESULT_TIMEOUT);
                        }
                    } else {
                        boolean ret = response.inputPinpadResult(buffer);
                        if (!ret) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    PluginDefine.ERROR_EXT_CODE_REJECT, null);
                            mControlDeviceManager.unlock();
                            if (isShowError(response.getDevice())) {
                                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                            }
                            return;
                        }
                    }

                    synchronized (mIIcrwServiceListenerList) {
                        for (Map.Entry<String, IIcrwServiceListener> listener : mIIcrwServiceListenerList
                                .entrySet()) {
                            try {
                                listener.getValue().onResultDeactivation(response);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    mControlDeviceManager.unlock();
                    break;
                }
            }
        };

        mDeactivateIccThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ICカードドライバをリセットします
     * @return 実行結果
     */
    public synchronized boolean sendDriverReset() {

        RequestDriverReset request = new RequestDriverReset();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            return false;
        }

        if (!request.isValidValue()) {
            return false;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(mInitTimeout);
        }
        ResponseDriverReset response = new ResponseDriverReset();
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            return false;
        } else {
            boolean ret = response.inputPinpadResult(buffer);
            if (!ret) {
                return false;
            } else if (response.getRes() != 0x00) {
                return false;
            }
        }

        return true;
    }

    /**
     * @brief 接触ICカードリーダライタをターミネートします
     * @return 実行結果
     */
    public ResultTermICRW termICRW() {
        mIsActive = false;

        sendDriverReset();

        ResultTermICRW result = new ResultTermICRW();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        notifyStatus(StatusType.TERM);
        return result;
    }

    /**
     * @brief ContactIcCardプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerContactIcCardServiceListener(String tag, IIcrwServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIIcrwServiceListenerList) {
            mIIcrwServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief ContactIcCardプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterContactIcCardServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIIcrwServiceListenerList) {
            mIIcrwServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief 接触ICカードリーダライタの製品品番、シリアル番号、ハード構成情報、APL Version、PF Versionを取得します
     * @return 実行結果
     */
    public ResultGetVersionInfo getVersionInfo() {
        // 機器情報要求
        RequestDeviceInformation requestDeviceInfo = new RequestDeviceInformation();
        ResponseDeviceInformation responseDeviceInfo = new ResponseDeviceInformation();

        // 拡張製品情報取得
        RequestAdvanceDeviceInformation requestAdvanceDevInfo = new RequestAdvanceDeviceInformation();
        ResponseAdvanceDeviceInformation responseAdvanceDevInfo = new ResponseAdvanceDeviceInformation();

        ResultGetVersionInfo result = new ResultGetVersionInfo();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        // 機器情報要求コマンド
        if (!requestDeviceInfo.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] bufferDevInfo;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestDeviceInfo, TIME_OUT);
            bufferDevInfo = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(bufferDevInfo)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseDeviceInfo.inputPinpadResult(bufferDevInfo)) {
            result.setDevice(responseDeviceInfo.getDevice());
            result.setUpos(responseDeviceInfo.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        // タンパ検出時に ICRW/PED の GetVersionInfoを 実行した場合、正常終了(SUCCESS)とする
        // [背景]
        // 顧客アプリがタンパ検出処理を実行する際に、
        // Init→GetVersionInfo→ChkHealth→Term の順にAPI呼出を行う挙動となっている。
        // ChkHealthでタンパ検知有無を判別する前のGetVersionInfoではエラーを返すと
        // 処理が終了してしまうため。
        if (!responseDeviceInfo.isTamper()) {
            // タンパ検知あり
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            result.setModel(null);
            result.setSno(null);
            result.setHdInfo(null);
            result.setAplVer(null);
            result.setPfVer(null);
            return result;
        }

        // 拡張製品情報取得コマンド
        if (!requestAdvanceDevInfo.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] bufferAdvance;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestAdvanceDevInfo, TIME_OUT);
            bufferAdvance = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(bufferAdvance)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseAdvanceDevInfo.inputPinpadResult(bufferAdvance)) {
            result.setDevice(responseAdvanceDevInfo.getDevice());
            result.setUpos(responseAdvanceDevInfo.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setModel(responseAdvanceDevInfo.getProduct());
        result.setSno(responseAdvanceDevInfo.getSerial());
        result.setHdInfo(null);
        result.setAplVer(responseDeviceInfo.getIfd());
        result.setPfVer(responseDeviceInfo.getFirmwareVersion());

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return 実行結果
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, ContactIcCard.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief EMV処理用IFDシリアル番号を取得します
     * @return 実行結果
     */
    public ResultGetIFDInfo getIFDInfo() {
        final RequestAdvanceProductInformation request = new RequestAdvanceProductInformation();
        ResultGetIFDInfo result = new ResultGetIFDInfo();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ICカードの状態を取得します
     * @return 実行結果
     */
    public ResultGetICStatus getICStatus() {
        final RequestIcCardStatus request = new RequestIcCardStatus();
        ResultGetICStatus result = new ResultGetICStatus();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief 接触ICカードリーダライタ利用可否情報を取得します
     * @return 実行結果
     */
    public ResultCheckHealth checkHealth() {
        final RequestDeviceInformation request = new RequestDeviceInformation();
        ResultCheckHealth result = new ResultCheckHealth();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        TamperDetectionInfoController.DEVICE device = TamperDetectionInfoController.DEVICE.PINPAD;
        if (TamperDetectionInfoController.hasTamper(device)) {
            result.setTamper(false);
        } else {
            if (!result.isTamper()) {
                TamperDetectionInfoController.saveTamper(device);
            }
        }
        if (!result.isTamper()) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @brief エラーを送信する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private void sendError(int ecode, int vcode, int extcode, String extinfo) {
        ResponseError error = new ResponseError();
        error.setEcode(ecode);
        error.setVcode(vcode);
        error.setExtcode(extcode);
        error.setExtinfo(extinfo);

        synchronized (mIIcrwServiceListenerList) {
            for (Map.Entry<String, IIcrwServiceListener> listener : mIIcrwServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(error);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param device deviceの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int device) {
        if (device != PluginDefine.RESULT_DEVICE_SCCESS) {
            return true;
        }

        return false;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * @brief プラグイン状態通知リスナーを登録します
     * @param[in] listener リスナー
     */
    public boolean registerNotifyStatusListener(NotifyStatusListener listener) {
        synchronized (mNotifyStatusListenerList) {
            if (!mNotifyStatusListenerList.contains(listener)) {
                return mNotifyStatusListenerList.add(listener);
            }
            return false;
        }
    }

    /**
     * @brief プラグイン状態通知リスナーを解除します
     * @param[in] listener リスナー
     */
    public boolean unregisterNotifyStatusListener(NotifyStatusListener listener) {
        synchronized (mNotifyStatusListenerList) {
            return mNotifyStatusListenerList.remove(listener);
        }
    }

    /**
     * @brief プラグイン状態の通知を要求します
     * @param[in] listener リスナー
     */
    public void requestNotifyStatus() {
        notifyStatus(mStatus);
    }

    public boolean isEnableDevice() {
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            return false;
        }
        return true;
    }

    /**
     * @brief プラグイン状態を通知します
     * @param[in] status プラグイン状態
     */
    private void notifyStatus(StatusType status) {
        mStatus = status;
        synchronized (mNotifyStatusListenerList) {
            for (NotifyStatusListener listener : mNotifyStatusListenerList) {
                listener.notifyStatus(PluginType.ICRW, status);
            }
        }
    }

}
