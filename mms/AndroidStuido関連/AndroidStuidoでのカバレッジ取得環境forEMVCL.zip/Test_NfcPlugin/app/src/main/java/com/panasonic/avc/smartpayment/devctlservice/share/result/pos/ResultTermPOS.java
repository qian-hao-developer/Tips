
package com.panasonic.avc.smartpayment.devctlservice.share.result.pos;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * TermPOSの実行結果データ
 */
public class ResultTermPOS extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermPOS(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermPOS() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermPOS> CREATOR = new Parcelable.Creator<ResultTermPOS>() {
        public ResultTermPOS createFromParcel(Parcel in) {
            return new ResultTermPOS(in);
        }

        public ResultTermPOS[] newArray(int size) {
            return new ResultTermPOS[size];
        }
    };
}
