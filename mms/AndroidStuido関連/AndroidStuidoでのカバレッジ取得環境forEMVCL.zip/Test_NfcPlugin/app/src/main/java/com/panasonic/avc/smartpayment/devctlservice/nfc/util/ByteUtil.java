package com.panasonic.avc.smartpayment.devctlservice.nfc.util;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.BitSet;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.DecoderException;

/**
 * Byte系処理のutilityクラス.
 * 
 */
public class ByteUtil {

    /**
     * 指定チェックbyte配列で適合するデータであるか確認する.
     * 
     * @param checkByte
     *            チェック対象byteデータ
     * @param targetArray
     *            チェック対象
     * @return 適合する場合true(指定配列が無い場合はtrueを返す)
     */
    public static boolean checkTargetValueByte(byte checkByte, byte... targetArray) {

        if (targetArray == null) {
            return true;
        }

        boolean matchFlg = false;
        for (byte targetByte : targetArray) {
            if (checkByte == targetByte) {
                matchFlg = true;
                break;
            }
        }
        return matchFlg;
    }

    /**
     * 指定byte配列がASCII文字データのみであるかチェックするメソッド.
     * 
     * 
     * @param checkBytes
     *            チェック対象byte配列
     * @return すべてASCII型のデータの場合true(NullはtrueでUTF-8以外の文字ではfalseを返す)
     */
    public static boolean checkASCIICharacterByteArray(byte[] checkBytes) {
        if (checkBytes == null || checkBytes.length == 0) {
            return true;
        } else {
            try {
                return new String(checkBytes, CommandDataConstants.CHARSETS_UTF_8).matches("^[\\u0000-\\u007E]+$");
            } catch (UnsupportedEncodingException ue) {  // PT_IMPOSSIBLE_BRANCH
                return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
        }
    }

    /**
     * 指定Byte配列がすべてBCD変換できる値かをチェックする.
     * 
     * @param checkBytes
     *            チェック対象byte配列
     * @return 変換できる場合はtrue
     */
    public static boolean checkBCDByteArray(byte[] checkBytes) {
        if (checkBytes == null || checkBytes.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            return true;
        } else {
            for (byte targetByte : checkBytes) {
                if ((targetByte & 0x0f) > 0x09) {
                    return false;
                }
                if ((targetByte & 0xf0) > 0x90) {
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * 指定BCD形式byte配列を数値文字列に変換する.
     * 
     * @param convertData
     *            変換対象のbyte配列（BCDデータ想定）
     * @return 変換された数値文字列（nullもしくはBCDデータで無かった場合はnullを返却する）
     */
    public static String convertBCDByte2String(byte[] convertData) {
        if (convertData == null) {
            return null;
        }

        StringBuilder returnBuilder = new StringBuilder();

        for (int i = 0; i < convertData.length * 2; i++) {
            if (i % 2 == 0) {
                int checkData = (convertData[i / 2] & 0xf0) / 16;
                if (checkData > 9) {
                    return null;
                } else {
                    returnBuilder.append(String.valueOf(checkData));
                }
            } else {
                int checkData = convertData[i / 2] & 0x0f;
                if (checkData > 9) {
                    return null;
                } else {
                    returnBuilder.append(String.valueOf(checkData));
                }
            }
        }

        if (returnBuilder.length() > 0) {
            return returnBuilder.toString();
        } else {
            return null;
        }
    }

    /**
     * 指定数字文字列をBCDByte配列に変換する.<br>
     * 数字文字列長の長さに合わせたByte配列を返却する,<br>
     *
     * @param convertData
     *            変換対象の数値文字列
     * @return 変換されたBCD形式byte配列（nullもしくは数値変換できない場合はnullを返却）
     */
    public static byte[] convertBCDData(String convertData) {
        if (convertData == null || convertData.length() == 0) {
            return null;
        }

        int dataLength = convertData.length();
        if (dataLength % 2 != 0) {
            dataLength = (dataLength + 1) / 2;
        } else {
            dataLength = dataLength / 2;
        }

        long convertLong;
        try {
            convertLong = Long.parseLong(convertData);
        } catch (Exception e) {
            return null;
        }

        byte[] returnArray = new byte[dataLength];

        for (int i = 0; i < returnArray.length; i++) {
            long mod = convertLong % 100;
            long digit2 = mod % 10;
            long digit1 = (mod - digit2) / 10;
            returnArray[returnArray.length - i - 1] = (byte) ((digit1 * 16) + digit2);
            convertLong = (convertLong - mod) / 100;
        }

        return returnArray;
    }

    /**
     * 指定byte配列を指定順で結合して返却するメソッド.
     * 
     * 
     * @param byteArrays
     *            byte配列オブジェクトの可変引数
     * @return 指定順で結合されたbyte配列オブジェクト（1個もなかった場合はnullを返す）
     */
    public static byte[] mergeByteArray(byte[]... byteArrays) {
        if (byteArrays == null || byteArrays.length < 1) {  // PT_IMPOSSIBLE_BRANCH
            return null;
        }

        int mergeLength = 0;
        // 全体配列長を取得する
        for (byte[] targetBytes : byteArrays) {
            if (targetBytes != null) {
                mergeLength = mergeLength + targetBytes.length;
            }
        }
        if (mergeLength == 0) {
            // 配列の合計が全部0配列だった場合なので空配列を返す
            return new byte[0];
        }

        byte[] mergeBytes = new byte[mergeLength];
        int indexPosition = 0;
        for (byte[] targetBytes : byteArrays) {
            if (targetBytes != null && targetBytes.length > 0) {
                System.arraycopy(targetBytes, 0, mergeBytes, indexPosition,
                        targetBytes.length);
                indexPosition = indexPosition + targetBytes.length;
            }
        }
        return mergeBytes;
    }

    /**
     * 指定長のbyte配列に成型して返す.<br>
     * <br>
     * 前trim、前Padding<br>
     * @param baseArray 整形元byte配列
     * @param targetLength 指定長さ
     * @return 整形済みbyte配列
     */
    public static byte[] targetLengthTrimPaddingByteArray(byte[] baseArray, int targetLength) {
        if (baseArray == null || baseArray.length < 1) {  // PT_IMPOSSIBLE_BRANCH
            return null;
        }

        if (baseArray.length == targetLength) {
            return baseArray;
        } else if (baseArray.length > targetLength) {
            return Arrays.copyOfRange(baseArray, baseArray.length - targetLength, baseArray.length);
        } else {
            return mergeByteArray(new byte[targetLength - baseArray.length], baseArray);
        }
    }

    /**
     * 指定byte配列（指定データ長）をlongに換算して返却する.<br>
     * <br>
     * @param bigByteArray 変換元byte配列
     * @param dataSize 指定データ長
     * @return byte配列から変換したlongデータ
     */
    public static long convertBigBytes2Long(byte[] bigByteArray, long dataSize) {
        if (bigByteArray == null) {
            return 0L;
        }

        long returnLong = 0L;

        if (dataSize == 2) {
            int arrayInt0 = bigByteArray[0] & 0xff;
            int arrayInt1 = bigByteArray[1] & 0xff;
            returnLong = (arrayInt0 << 8) | arrayInt1;
        } else if (dataSize == 4) {
            int arrayInt0 = bigByteArray[0] & 0xff;
            int arrayInt1 = bigByteArray[1] & 0xff;
            int arrayInt2 = bigByteArray[2] & 0xff;
            int arrayInt3 = bigByteArray[3] & 0xff;
            returnLong = (arrayInt0 << 24) | (arrayInt1 << 16)
                    | (arrayInt2 << 8) | arrayInt3;
        }

        return returnLong;
    }

    /**
      *  16進数文字列をbyte配列に変換する.<br>
      *
      * @param hex 変換対象16進数文字列
      * @return 変換byte配列
      */
    public static byte[] hex2bin(String hex) {
        if (hex == null || hex.length() == 0) {
            return null;
        }
        byte[] bytes;
        try {
            bytes = Hex.decodeHex(hex.toCharArray());
        } catch (DecoderException e) {
            return null;
        }
        return bytes;
    }

    /**
      *  byte配列を16進数文字列に変換する.<br>
      *
      * @param data 変換対象byte配列
      * @return 変換16進数文字列
      */
    public static String bin2hex(byte[] data) {
        StringBuffer sb = new StringBuffer();
        for (byte b : data) {
            String s = Integer.toHexString(0xff & b);
            if (s.length() == 1) {
                sb.append("0");
            }
            sb.append(s);
        }
        return sb.toString();
    }

    /**
     * @brief バイト列をASCII文字列に変換する
     * @param data バイト列
     * @return ASCII文字列
     */
    public static String toAscii(byte[] data) {
        if (data == null) {
            return null;
        }

        try {
            String str = new String(data, "US-ASCII");
            return str.trim();
        } catch (UnsupportedEncodingException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
    }
}
