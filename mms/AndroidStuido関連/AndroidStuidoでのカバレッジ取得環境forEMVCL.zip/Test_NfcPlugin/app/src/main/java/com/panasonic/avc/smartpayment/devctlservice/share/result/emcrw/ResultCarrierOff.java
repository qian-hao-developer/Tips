
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultCarrierOff extends ResultFeliCaApl {

    /**
     * @brief コンストラクタ
     */
    public ResultCarrierOff(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultCarrierOff() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCarrierOff> CREATOR = new Parcelable.Creator<ResultCarrierOff>() {

        @Override
        public ResultCarrierOff createFromParcel(Parcel in) {
            return new ResultCarrierOff(in);
        }

        @Override
        public ResultCarrierOff[] newArray(int size) {
            return new ResultCarrierOff[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
    }

}
