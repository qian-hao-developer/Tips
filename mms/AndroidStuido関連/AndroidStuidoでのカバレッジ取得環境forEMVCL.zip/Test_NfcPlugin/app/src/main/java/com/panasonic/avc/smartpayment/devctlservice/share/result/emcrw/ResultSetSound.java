
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultSetSound extends ResultFeliCaApl {

    /**
     * @brief コンストラクタ
     */
    public ResultSetSound(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetSound() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetSound> CREATOR = new Parcelable.Creator<ResultSetSound>() {

        @Override
        public ResultSetSound createFromParcel(Parcel in) {
            return new ResultSetSound(in);
        }

        @Override
        public ResultSetSound[] newArray(int size) {
            return new ResultSetSound[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

}
