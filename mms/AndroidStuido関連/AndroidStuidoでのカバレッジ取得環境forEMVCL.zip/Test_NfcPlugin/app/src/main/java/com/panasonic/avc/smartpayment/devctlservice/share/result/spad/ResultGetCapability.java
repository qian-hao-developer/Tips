
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetCapability extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetCapability(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetCapability() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetCapability> CREATOR = new Parcelable.Creator<ResultGetCapability>() {

        @Override
        public ResultGetCapability createFromParcel(Parcel in) {
            return new ResultGetCapability(in);
        }

        @Override
        public ResultGetCapability[] newArray(int size) {
            return new ResultGetCapability[size];
        }
    };
}
