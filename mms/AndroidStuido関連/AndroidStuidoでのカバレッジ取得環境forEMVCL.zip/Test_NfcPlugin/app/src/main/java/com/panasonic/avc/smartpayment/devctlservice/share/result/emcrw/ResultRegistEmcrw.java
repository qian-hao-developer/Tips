
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultRegistEmcrw extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultRegistEmcrw(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultRegistEmcrw() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultRegistEmcrw> CREATOR = new Parcelable.Creator<ResultRegistEmcrw>() {

        @Override
        public ResultRegistEmcrw createFromParcel(Parcel in) {
            return new ResultRegistEmcrw(in);
        }

        @Override
        public ResultRegistEmcrw[] newArray(int size) {
            return new ResultRegistEmcrw[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
    }
}
