
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetCapability extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x09;

    private static final int LENGTH = 17;

    private static final String X = "x";

    private int mX;

    private static final String Y = "y";

    private int mY;

    private static final String PRESSURE = "pressure";

    private int mPressure;

    private static final String WIDTH = "width";

    private int mWidth;

    private static final String HEIGHT = "height";

    private int mHeight;

    private static final String RATE = "rate";

    private int mRate;

    private static final String RESOLUTION = "resolution";

    private int mResolution;

    private static final String BIT1 = "1bit";

    private int mBit1;

    private static final String BIT16 = "16bit";

    private int mBit16;

    private static final String BIT24 = "24bit";

    private int mBit24;

    private static final String ZLIB = "zlib";

    private int mZlib;

    public ResponseGetCapability(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mX = CalcUtil.toInt(result[2], result[1]);
        mY = CalcUtil.toInt(result[4], result[3]);
        mPressure = CalcUtil.toInt(result[6], result[5]);
        mWidth = CalcUtil.toInt(result[8], result[7]);
        mHeight = CalcUtil.toInt(result[10], result[9]);
        mRate = (int) (result[11] & 0xff);
        mResolution = CalcUtil.toInt(result[13], result[12]);
        mBit1 = (int) ((result[14] & 0x08) >> 3);
        mBit16 = (int) ((result[14] & 0x04) >> 2);
        mBit24 = (int) ((result[14] & 0x02) >> 1);
        mZlib = (int) (result[14] & 0x01);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(X, mX);
            json.put(Y, mY);
            json.put(PRESSURE, mPressure);
            json.put(WIDTH, mWidth);
            json.put(HEIGHT, mHeight);
            json.put(RATE, mRate);
            json.put(RESOLUTION, mResolution);
            json.put(BIT1, mBit1);
            json.put(BIT16, mBit16);
            json.put(BIT24, mBit24);
            json.put(ZLIB, mZlib);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

}
