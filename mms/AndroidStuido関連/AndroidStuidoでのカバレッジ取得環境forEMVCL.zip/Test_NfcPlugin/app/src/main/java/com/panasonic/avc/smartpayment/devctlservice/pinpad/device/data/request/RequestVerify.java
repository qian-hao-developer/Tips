
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * Verify要求コマンド
 */
public class RequestVerify extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x07;

    public enum VerifyPinType {
        NormalPin(0),
        CodePin(1),
        TestMode(2),
        CodePinNonEPin(3);

        private final int mNum;

        private VerifyPinType(int num) {
            mNum = num;
        }

        public int getNum() {
            return mNum;
        }
    }

    private VerifyPinType mPinType;

    private String mRandam;

    private String mMod;

    private String mExp;

    private String mDummy;

    public RequestVerify() {

        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;

    }

    /**
     * @return the pinType
     */
    public VerifyPinType getPinType() {
        return mPinType;
    }

    /**
     * @param pinType the pinType to set
     */
    public void setPinType(VerifyPinType pinType) {
        mPinType = pinType;
    }

    /**
     * @return the randam
     */
    public String getRandam() {
        return mRandam;
    }

    /**
     * @param randam the randam to set
     */
    public void setRandam(String randam) {
        mRandam = randam;
    }

    /**
     * @return the mod
     */
    public String getMod() {
        return mMod;
    }

    /**
     * @param mod the mod to set
     */
    public void setMod(String mod) {
        mMod = mod;
    }

    /**
     * @return the exp
     */
    public String getExp() {
        return mExp;
    }

    /**
     * @param exp the exp to set
     */
    public void setExp(String exp) {
        mExp = exp;
    }

    /**
     * @return the dummy
     */
    public String getDummy() {
        return mDummy;
    }

    /**
     * @param dummy the dummy to set
     */
    public void setDummy(String dummy) {
        mDummy = dummy;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {
        byte[] paramater = new byte[PinpadDefine.SEQUENCE_SIZE + 7 + mRandam.length()
                + mMod.length() + mExp.length() + mDummy.length()];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);
        paramater[2] = (byte) mPinType.getNum();

        paramater[3] = (byte) (mRandam.length() & 0xff);
        paramater[4] = (byte) ((mRandam.length() >> 8) & 0xff);

        byte[] randam = CalcUtil.toByte(mRandam);
        if (randam == null) {
            return null;
        }

        System.arraycopy(randam, 0, paramater, 5, randam.length);

        paramater[5 + randam.length] = (byte) (mRandam.length() & 0xff);
        paramater[6 + randam.length] = (byte) ((mRandam.length() >> 8) & 0xff);

        byte[] mod = CalcUtil.toByte(mMod);
        System.arraycopy(mod, 0, paramater, 7 + randam.length, mod.length);

        paramater[7 + randam.length + mod.length] = (byte) (mExp.length() & 0xff);
        paramater[8 + randam.length + mod.length] = (byte) ((mExp.length() >> 8) & 0xff);

        byte[] exp = CalcUtil.toByte(mExp);
        System.arraycopy(exp, 0, paramater, 9 + randam.length + mod.length, exp.length);

        if (mPinType == VerifyPinType.CodePin) {
            byte[] dummy = CalcUtil.toByte(mDummy);
            System.arraycopy(dummy, 0, paramater, 10 + randam.length + mod.length + exp.length,
                    dummy.length);
        }

        return toCommand(paramater);
    }
}
