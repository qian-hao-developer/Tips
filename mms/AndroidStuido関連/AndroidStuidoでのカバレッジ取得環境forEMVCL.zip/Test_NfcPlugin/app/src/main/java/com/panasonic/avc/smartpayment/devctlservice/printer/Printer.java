
package com.panasonic.avc.smartpayment.devctlservice.printer;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.os.RemoteException;
import android.util.Log;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.contesnts.ManagementData;
import com.panasonic.avc.smartpayment.devctlservice.contesnts.ManagementDatabase;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.PrinterDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.PrinterImageData;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.ResponsePrinterData;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestBasicInformation;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestCut;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestFirmwareVersion;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestFirmwareVersion.Firmware;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestForceOutput;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestPrintChar;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestPrintImage;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestStartComunication;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestStartPrint;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request.RequestStopComunication;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponseBasicInformation;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponseCut;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponseFirmwareVersion;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponseForceOutput;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponsePrintChar;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponsePrintImage;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponseStartComunication;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response.ResponseStartPrint;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.IPrnServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.printer.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultInitPrn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintCheckImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintCutPaper;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintEscText;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintFlush;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintLineFeed;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintQrCode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintSetImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintText;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultTermPrn;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * プリンタ処理部
 */
public class Printer {

    /** @brief ログ出力用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = Printer.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static Printer sInstance = new Printer();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IPrnServiceListener> mIPrnServiceListenerList = new ConcurrentHashMap<String, IPrnServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 20000;

    /** @brief Read時のリトライタイムアウト */
    private static final int RETRY_TIME_OUT = 1000;

    /** @brief Read時のリトライ時のスリープタイム */
    private static final int RETRY_SLEEP_TIME = 10;

    /** @brief 非同期用スレッド(mCutPaperThread) */
    private Thread mCutPaperThread;

    /** @brief 管理画像量 */
    private static final int IMAGE_DATA_SIZE = 20;

    /** @brief 管理画像 */
    private PrinterImageData[] mPrinterImageData = new PrinterImageData[IMAGE_DATA_SIZE];

    /** @brief 管理QR画像 */
    private PrinterImageData[] mPrinterQRImageData = new PrinterImageData[IMAGE_DATA_SIZE];

    /** @brief 印字スケール(標準) */
    private static final int SCALE_NORMAL = 1;

    /** @brief 印字スケール(縦倍) */
    private static final int SCALE_HEIGHT = 2;

    /** @brief 印字スケール(横倍) */
    private static final int SCALE_WIDTH = 3;

    /** @brief 印字スケール(縦横倍) */
    private static final int SCALE_HEIGHT_WIDTH = 4;

    /** @brief 太字有効無効 */
    private boolean mBold = BOLD_DEFAULT_VALUE;

    /** @brief 太字有効無効デフォルト値 */
    private final static boolean BOLD_DEFAULT_VALUE = false;

    /** @brief 印字濃度 */
    private int mDensity = RequestStartPrint.DENSITY_DEFAULT;

    /** @brief 文字セット */
    private int mCharset = CHARSET_SJIS;

    /** @brief 印字幅 */
    private int mWidth = WIDTH_DEFAULT;

    /** @brief 印字幅デフォルト値 */
    private static final int WIDTH_DEFAULT = 1;

    /** @brief 文字セット最小の値 */
    private static final int CHARSET_SJIS = 1;

    /** @brief 文字セット最大の値 */
    private static final int CHARSET_UTF8 = 2;

    /** @brief 太字設定を反映しない値 */
    private static final int BOLD_NO_SETTING = 0;

    /** @brief 太字設定の値 */
    private static final int BOLD_FALSE = 1;

    /** @brief ノーマル設定の値 */
    private static final int BOLD_TRUE = 2;

    /** @brief 印字濃度を反映しない値 */
    private static final int DENSITY_NO_SETTING = 0;

    /** @brief 印字濃度の最小値 */
    private static final int DENSITY_MIN = DENSITY_NO_SETTING;

    /** @brief 印字濃度の最大値 */
    private static final int DENSITY_MAX = 5;

    /** @brief 印字幅 - 通常 */
    private static final int WIDTH_384 = 1;

    /** @brief 印字幅 - 全幅 */
    private static final int WIDTH_432 = 2;

    /** @brief カットタイプ */
    private int mCutType = RequestCut.PLUGIN_PARTIAL_CUT;

    /** @brief 印字濃度を反映しない値 */
    private static final int CUT_TYPE_NO_SETTING = 0;

    /** @brief Charset - Shift-JIS */
    Charset Shift_JIS = Charset.forName("Shift-JIS");

    /** @brief Charset - UTF-8 */
    Charset UTF_8 = Charset.forName("UTF-8");

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief カット処理中かどうか */
    private boolean mCutSequence;

    /** @brief データベースアクセス */
    private ManagementDatabase mManagementDatabase = ManagementDatabase.getInstance();

    /** @brief コンテキスト */
    private Context mContext;

    private boolean isActive = false;

    /** 一回に印刷できる高さの最大値 */
    private static final int PRINTER_MAX_HIGHT = 192;

    /**
     * @brief コンストラクタ
     */
    private Printer() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static Printer getInstance() {
        return sInstance;
    }

    /**
     * @brief プリンタプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerPrnServiceListener(String tag, IPrnServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIPrnServiceListenerList) {
            mIPrnServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief プリンタプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterPrnServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIPrnServiceListenerList) {
            mIPrnServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief プリンタを初期化します
     * @param[in] bold 太字印字するか否かを指定
     * @param[in] density 印字濃度を指定
     * @return 処理結果
     */
    public ResultInitPrn initPrn(int bold, int density, int charset, int width) {
        ResultInitPrn result = new ResultInitPrn();
        RequestStartComunication requestStartComunication = new RequestStartComunication();
        ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (charset != CHARSET_SJIS && charset != CHARSET_UTF8) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }
        ManagementData data = mManagementDatabase.query();

        switch (bold) {
            case BOLD_NO_SETTING:
                if (data != null) {
                    mBold = data.getFont();
                } else {
                    mBold = BOLD_DEFAULT_VALUE;
                }
                break;
            case BOLD_FALSE:
                mBold = false;
                break;
            case BOLD_TRUE:
                mBold = true;
                break;
            default:
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
        }

        if (density < DENSITY_MIN || DENSITY_MAX < density) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        } else if (density != DENSITY_NO_SETTING) {
            mDensity = density;
        } else if (data != null) {
            mDensity = data.getDensity();
        } else {
            mDensity = RequestStartPrint.DENSITY_DEFAULT;
        }

        if (width != WIDTH_384 && width != WIDTH_432) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mCharset = charset;
        mWidth = width;

        if (!isActive) {
            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();

            ResultData res = request(requestStartComunication, recieveStartComunication);

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(),
                            null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                mControlDeviceManager.setSequence(seq);
                return result;
            }

            RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true,
                    mWidth);
            ResponseStartPrint responseStartPrint = new ResponseStartPrint();

            res = request(requestStartPrint, responseStartPrint);
            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0, responseStartPrint.getExtCode(),
                            null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
            isActive = true;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief テキスト文字列を印字データに追加します
     * @param[in] text 印字したい任意の文字列
     * @return 処理結果
     */
    public ResultPrintEscText printEscText(String text) {
        ResultData ret = printText(text);
        ResultPrintEscText result = new ResultPrintEscText();

        result.setDevice(ret.getDevice());
        result.setUpos(ret.getUpos());
        if (isShowError(result.getDevice())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief テキスト文字列を印字データに追加します
     * @param[in] text 印字したい任意の文字列
     * @param[in] scale 出力倍率
     * @return 処理結果
     */
    public ResultPrintText printText(String text, int scale) {
        ResultPrintText result = new ResultPrintText();
        switch (scale) {
            case SCALE_NORMAL:
                text = "\u001bt" + text;
                break;
            case SCALE_HEIGHT:
                text = "\u001bT" + text;
                break;
            case SCALE_WIDTH:
                text = "\u001bY" + text;
                break;
            case SCALE_HEIGHT_WIDTH:
                text = "\u001bQ" + text;
                break;
            default:
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
        }

        ResultData ret = printText(text);
        result.setDevice(ret.getDevice());
        result.setUpos(ret.getUpos());
        if (isShowError(result.getDevice())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief 指定イメージを印字データに追加します
     * @param[in] image イメージデータの登録番号
     * @param[in] scale 出力倍率
     * @param[in] posx イメージ出力開始位置
     * @return 処理結果
     */
    public ResultPrintImage printImage(int image, int scale, int posx, boolean qr_code) {
        ResultPrintImage result = new ResultPrintImage();
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        RequestBasicInformation requestBasic = new RequestBasicInformation();
        ResponseBasicInformation responseBasic = new ResponseBasicInformation();

        ResultData res = request(requestBasic, responseBasic);

        if (responseBasic.isSequenceError()) {
            RequestStartComunication requestStartComunication = new RequestStartComunication();
            ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();
            res = request(requestStartComunication, recieveStartComunication);

            if (recieveStartComunication.isDeviceError()) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0,
                        recieveStartComunication.getExtCode(), null);
            }
            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                mControlDeviceManager.setSequence(seq);
                return result;
            }
        }

        RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true, mWidth);
        ResponseStartPrint responseStartPrint = new ResponseStartPrint();

        res = request(requestStartPrint, responseStartPrint);

        if (responseStartPrint.isDeviceError()) {
            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                    responseStartPrint.getExtCode(), null);
        }

        if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
            if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0,
                        responseStartPrint.getExtCode(), null);
            }
            result.setDevice(res.getDevice());
            result.setUpos(res.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        // 参照番号が1から20までとなっているため配列の要素番号0から19に変換する
        int num = image - 1;

        PrinterImageData[] printerImageData = qr_code ? mPrinterQRImageData : mPrinterImageData;
        if (num < 0 || num >= IMAGE_DATA_SIZE || printerImageData[num] == null ||
                !printerImageData[num].isValidValue(mWidth, scale)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }
        PrinterImageData data = printerImageData[num];
        int x = data.getX(scale);
        int line = x / 8;
        if (x % 8 != 0) {
            line++;
        }

        byte[] imageData = data.getImage(scale);
        int max = imageData.length / (line * 200);
        if (imageData.length % (line * 200) != 0) {
            max++;
        }

        int offset = 0;
        int len = imageData.length;
        int sectorSize = 0;
        ResponsePrintImage response = new ResponsePrintImage();
        boolean retry = false;
        mControlDeviceManager.clearBuffer();
        for (int i = 0; i < max; i++) {
            if ((len - offset) < (line * 200)) {
                sectorSize = len - offset;
            } else {
                sectorSize = line * 200;
            }
            byte[] buffer = new byte[sectorSize];
            System.arraycopy(imageData, offset, buffer, 0, buffer.length);

            int cpLen = 0;
            if (buffer.length > 96) {
                // 初回
                byte[] tmpBuff = new byte[96];
                System.arraycopy(buffer, 0, tmpBuff, 0, tmpBuff.length);
                int l = 200;
                if (max == 1) {
                    l = data.getY();
                }

                RequestPrintImage request = new RequestPrintImage(true, posx,
                        x, l, tmpBuff, true, mWidth);

                if (!request.isValidValue()) {
                    result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                    result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                    return result;
                }
                mControlDeviceManager.write(request, TIME_OUT);
                cpLen += tmpBuff.length;

                // バースト送信
                int count = (buffer.length - 96) / 100;

                // バースト転送で全て送りきってしまうと終了時にパラメータエラーになるので、最後のデータは送らないようにする
                int length = (buffer.length - 96) % 100;
                if (length == 0) {
                    count--;
                }

                for (int j = 0; j < count; j++) {
                    tmpBuff = new byte[100];
                    System.arraycopy(buffer, cpLen, tmpBuff, 0, tmpBuff.length);
                    request = new RequestPrintImage(true, posx, x, l, tmpBuff, false,
                            mWidth);

                    if (!request.isValidValue()) {
                        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                        result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                        return result;
                    }
                    mControlDeviceManager.write(request, TIME_OUT);
                    cpLen += tmpBuff.length;
                }

                // 終了
                tmpBuff = new byte[buffer.length - cpLen];
                System.arraycopy(buffer, cpLen, tmpBuff, 0, tmpBuff.length);
                request = new RequestPrintImage(false, posx, x, l, tmpBuff, false,
                        mWidth);
                offset += buffer.length;

                res = request(request, response);

                if (response.isDeviceError()) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            response.getExtCode(), null);
                }

                if (isPaperLess(response)) {
                    SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
                }
                if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                    if (retry || (res.getDevice() != PluginDefine.ERROR_EXT_PRINTER_SEQUENCE)) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    response.getExtCode(), null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        if (isShowError(result.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        return result;
                    }
                    mControlDeviceManager.read(TIME_OUT);

                    RequestStartComunication requestStartComunication = new RequestStartComunication();
                    ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

                    int seq = mControlDeviceManager.getSequence();
                    mControlDeviceManager.clearSequence();
                    res = request(requestStartComunication, recieveStartComunication);

                    if (recieveStartComunication.isDeviceError()) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                recieveStartComunication.getExtCode(), null);
                    }

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    recieveStartComunication.getExtCode(),
                                    null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        if (isShowError(result.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        mControlDeviceManager.setSequence(seq);
                        return result;
                    }

                    requestStartPrint = new RequestStartPrint(mBold, mDensity,
                            true, mWidth);
                    responseStartPrint = new ResponseStartPrint();

                    res = request(requestStartPrint, responseStartPrint);

                    if (responseStartPrint.isDeviceError()) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0, responseStartPrint.getExtCode(),
                                null);
                    }

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    responseStartPrint.getExtCode(), null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        if (isShowError(result.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        return result;
                    }
                    retry = true;
                    i--;
                    continue;
                }
            } else {
                // 終了
                byte[] tmpBuff = new byte[buffer.length - cpLen];
                System.arraycopy(buffer, cpLen, tmpBuff, 0, tmpBuff.length);
                RequestPrintImage request = new RequestPrintImage(false, posx, data.getX(scale),
                        data.getY(scale) % 200 == 0 ? 200 : data.getY(scale) % 200, tmpBuff, true,
                        mWidth);

                if (!request.isValidValue()) {
                    result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                    result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                    return result;
                }
                offset += buffer.length;

                res = request(request, response);

                if (response.isDeviceError()) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0, response.getExtCode(), null);
                }

                if (isPaperLess(response)) {
                    SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
                }
                if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                    if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0, response.getExtCode(), null);
                    }
                    result.setDevice(res.getDevice());
                    result.setUpos(res.getUpos());
                    if (isShowError(result.getDevice())) {
                        SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                    }
                    return result;
                }
            }
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief 改行を印字データに追加します
     * @return 処理結果
     */
    public ResultPrintLineFeed printLineFeed() {
        ResultPrintLineFeed result = new ResultPrintLineFeed();
        ResultData ret = printText("\n");
        result.setDevice(ret.getDevice());
        result.setUpos(ret.getUpos());
        if (isShowError(result.getDevice())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief プリンタデバイスに用紙カットを要求します
     * @param[in] type 用紙カット方法の指定
     * @return 処理結果
     */
    public ResultPrintCutPaper printCutPaper(int type) {
        ManagementData data = mManagementDatabase.query();
        if (type != CUT_TYPE_NO_SETTING) {
            mCutType = type;
        } else if (data != null) {
            mCutType = data.getSlip();
        } else {
            mCutType = RequestCut.PLUGIN_PARTIAL_CUT;
        }
        final RequestCut request = new RequestCut(mCutType);
        ResultPrintCutPaper result = new ResultPrintCutPaper();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mCutPaperThread != null && mCutPaperThread.isAlive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        mCutPaperThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }
                mCutSequence = true;
                RequestBasicInformation requestBasic = new RequestBasicInformation();
                ResponseBasicInformation responseBasic = new ResponseBasicInformation();

                ResultData res = request(requestBasic, responseBasic);

                if (responseBasic.isSequenceError()) {
                    RequestStartComunication requestStartComunication = new RequestStartComunication();
                    ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

                    int seq = mControlDeviceManager.getSequence();
                    mControlDeviceManager.clearSequence();
                    res = request(requestStartComunication, recieveStartComunication);

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    recieveStartComunication.getExtCode(), null);
                        } else {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    PluginDefine.ERROR_EXT_CODE_REJECT, null);
                            if (isShowError(recieveStartComunication.getDevice())) {
                                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                            }
                        }
                        mCutSequence = false;
                        mControlDeviceManager.setSequence(seq);
                        return;
                    }

                    RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity,
                            true, mWidth);
                    ResponseStartPrint responseStartPrint = new ResponseStartPrint();

                    res = request(requestStartPrint, responseStartPrint);
                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    responseStartPrint.getExtCode(), null);
                        }
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                PluginDefine.ERROR_EXT_CODE_REJECT, null);
                        if (isShowError(responseStartPrint.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        mCutSequence = false;
                        return;
                    }

                    RequestForceOutput requestForceOutput = new RequestForceOutput();
                    ResponseForceOutput responseForceOutput = new ResponseForceOutput();

                    res = request(requestForceOutput, responseForceOutput);
                    if (isPaperLess(responseForceOutput)) {
                        SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
                    }

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    responseForceOutput.getExtCode(), null);
                        }
                        if (isShowError(responseForceOutput.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        mCutSequence = false;
                        return;
                    }
                }

                ResponseCut responseCut = new ResponseCut();
                res = request(request, responseCut);
                if (isPaperLess(responseCut)) {
                    SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
                }
                if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                    if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                responseCut.getExtCode(), null);
                    }
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            PluginDefine.ERROR_EXT_CODE_REJECT, null);
                    if (isShowError(responseCut.getDevice())) {
                        SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                    }
                    mCutSequence = false;
                    return;
                }
                mCutSequence = false;

                synchronized (mIPrnServiceListenerList) {
                    for (Map.Entry<String, IPrnServiceListener> listener : mIPrnServiceListenerList
                            .entrySet()) {
                        try {
                            listener.getValue().onCutEnd();
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        };
        mCutPaperThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief イメージデータを登録/削除します
     * @param[in] num イメージ登録/削除番号
     * @param[in] image 画像データ(削除の場合はnull)
     * @param[in] isRemove 削除要求かどうか
     * @param[in] name イメージデータ識別用
     * @param[in] x イメージデータの横サイズ
     * @param[in] y イメージデータの縦サイズ
     * @return 処理結果
     */
    public ResultPrintSetImage printSetImage(int num, String image, boolean isRemove, String name,
            int x, int y, boolean qr_code) {

        ResultPrintSetImage result = new ResultPrintSetImage();

        // 参照番号が1から20までとなっているため配列の要素番号0から19に変換する
        int index = num - 1;

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (index < 0 || index >= IMAGE_DATA_SIZE) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        PrinterImageData[] printerImageData = qr_code ? mPrinterQRImageData : mPrinterImageData;
        if (isRemove) {
            printerImageData[index] = null;
        } else {
            PrinterImageData data = new PrinterImageData(x, y, CalcUtil.toByte(image), name);
            if (!data.isValidValue(mWidth, PrinterImageData.SCALE_NORMAL)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }
            printerImageData[index] = data;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief イメージデータを確認します
     * @param[in] num イメージ番号
     * @return 処理結果
     */
    public ResultPrintCheckImage printCheckImage(int num, boolean qr_code) {
        ResultPrintCheckImage result = new ResultPrintCheckImage();

        // 参照番号が1から20までとなっているため配列の要素番号0から19に変換する
        int index = num - 1;

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (index < 0 || index >= IMAGE_DATA_SIZE) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        PrinterImageData[] printerImageData = qr_code ? mPrinterQRImageData : mPrinterImageData;
        if (printerImageData[index] == null) {
            result.setValid(false);
        } else {
            result.setValid(true);
            result.setX(printerImageData[index].getX());
            result.setY(printerImageData[index].getY());
            int crc = CalcUtil.createCRC(printerImageData[index].getImage());
            byte[] tmpCrc = new byte[2];
            tmpCrc[0] = (byte) (crc & 0xff);
            tmpCrc[1] = (byte) (crc >> 8 & 0xff);
            result.setCrc(CalcUtil.toHexString(tmpCrc));

            result.setName(printerImageData[index].getName());
        }
        return result;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return 処理結果
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, Printer.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief プリンタデバイス利用可否情報を取得します
     * @return 処理結果
     */
    public ResultCheckHealth checkHealth() {
        RequestBasicInformation request = new RequestBasicInformation();
        ResultCheckHealth result = new ResultCheckHealth();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        RequestBasicInformation requestBasic = new RequestBasicInformation();
        ResponseBasicInformation responseBasic = new ResponseBasicInformation();

        ResultData res = request(requestBasic, responseBasic);

        if (responseBasic.isSequenceError()) {
            RequestStartComunication requestStartComunication = new RequestStartComunication();
            ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();
            res = request(requestStartComunication, recieveStartComunication);

            if (recieveStartComunication.isDeviceError()) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0,
                        recieveStartComunication.getExtCode(), null);
            }

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                mControlDeviceManager.setSequence(seq);
                return result;
            }

            RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true,
                    mWidth);
            ResponseStartPrint responseStartPrint = new ResponseStartPrint();

            res = request(requestStartPrint, responseStartPrint);

            if (responseStartPrint.isDeviceError()) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0, responseStartPrint.getExtCode(), null);
            }

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            responseStartPrint.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        ResponseBasicInformation recieve = new ResponseBasicInformation();

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mControlDeviceManager.clearBuffer();
        mControlDeviceManager.write(request, TIME_OUT);

        byte[] buffer = mControlDeviceManager.read(TIME_OUT);

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        }

        boolean comRes = recieve.inputPrinterResult(buffer);
        if (!comRes) {
            if (recieve.lackDataSize()) {
                long start = System.currentTimeMillis();
                while (true) {
                    try {
                        Thread.sleep(RETRY_SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    byte[] buf = mControlDeviceManager.read(RETRY_TIME_OUT);
                    buffer = concat(buffer, buf);
                    comRes = recieve.inputPrinterResult(buffer);
                    if (comRes) {
                        break;
                    }
                    long now = System.currentTimeMillis();
                    if ((now - start) > TIME_OUT) {
                        break;
                    }
                }
            }

            if (!comRes) {
                if (recieve.isDeviceError()) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0, recieve.getExtCode(), null);
                }
                if (recieve.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0, recieve.getExtCode(), null);
                }

                if (isPaperLess(recieve)) {
                    SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
                } else {
                    SystemNotification.notifyDismissIcon(mContext, IconType.PRINTER_DEVICE);
                }

                if (isOutputLog(recieve)) {
                    // FIXME 処理としてはResponseBasicInformation内部でログを表示する処理を書くべき
                    mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.PRT,
                            recieve.getExtCode(), -1,
                            CalcUtil.toInt(buffer[PrinterDefine.INDEX_ID_1],
                                    buffer[PrinterDefine.INDEX_ID_2]), null);
                }

                result.parseStatus(recieve.getStatus());
                result.setDevice(recieve.getDevice());
                result.setUpos(recieve.getUpos());
                if (isShowNotification(recieve)) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        if (isPaperLess(recieve)) {
            SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
        } else {
            SystemNotification.notifyDismissIcon(mContext, IconType.PRINTER_DEVICE);
        }
        result.parseStatus(recieve.getStatus());
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief プリンタデバイスの製品品番、シリアル番号、ハード構成情報、APL Version、PF Versionを取得します
     * @return 処理結果
     */
    public ResultGetVersionInfo getVersionInfo() {
        UsbDevice device = mControlDeviceManager.getUsbDevice();
        RequestFirmwareVersion request = new RequestFirmwareVersion(Firmware.FIRMWARE);
        ResponseFirmwareVersion recieve = new ResponseFirmwareVersion();
        ResultGetVersionInfo result = new ResultGetVersionInfo();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        RequestBasicInformation requestBasic = new RequestBasicInformation();
        ResponseBasicInformation responseBasic = new ResponseBasicInformation();

        ResultData res = request(requestBasic, responseBasic);

        if (responseBasic.isSequenceError()) {
            RequestStartComunication requestStartComunication = new RequestStartComunication();
            ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();
            res = request(requestStartComunication, recieveStartComunication);

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                mControlDeviceManager.setSequence(seq);
                return result;
            }

            RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true,
                    mWidth);
            ResponseStartPrint responseStartPrint = new ResponseStartPrint();

            res = request(requestStartPrint, responseStartPrint);
            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            responseStartPrint.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        mControlDeviceManager.clearBuffer();
        mControlDeviceManager.write(request, TIME_OUT);

        byte[] buffer = mControlDeviceManager.read(TIME_OUT);

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        }

        boolean comRes = recieve.inputPrinterResult(buffer);
        if (!comRes) {
            if (recieve.lackDataSize()) {
                long start = System.currentTimeMillis();
                while (true) {
                    try {
                        Thread.sleep(RETRY_SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    byte[] buf = mControlDeviceManager.read(RETRY_TIME_OUT);
                    buffer = concat(buffer, buf);
                    comRes = recieve.inputPrinterResult(buffer);
                    if (comRes) {
                        break;
                    }
                    long now = System.currentTimeMillis();
                    if ((now - start) > TIME_OUT) {
                        break;
                    }
                }
            }

            if (!comRes) {
                if (isPaperLess(recieve)) {
                    SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
                }
                if (isShowError(recieve.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        if (isPaperLess(recieve)) {
            SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
        }
        result.setModel(CalcUtil.searchUsbDeviceInformation(device.getVendorId(),
                device.getProductId(), PluginDefine.USB_DEVICE_INFORMATION_PRDUCT));
        result.setSno(CalcUtil.searchUsbDeviceInformation(device.getVendorId(),
                device.getProductId(), PluginDefine.USB_DEVICE_INFORMATION_SERIAL));
        result.setHdInfo(null);
        result.setAplVer(null);
        result.setPfVer(recieve.getFirmwareVersion());

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief プリンタデバイスをターミネートします
     * @return 処理結果
     */
    public ResultTermPrn termPrn() {
        RequestStopComunication request = new RequestStopComunication();
        ResultTermPrn result = new ResultTermPrn();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mControlDeviceManager.clearBuffer();
        mControlDeviceManager.write(request, TIME_OUT);
        isActive = false;

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief フラッシュする
     * @return 処理結果
     */
    public ResultPrintFlush printFlush() {
        ResultPrintFlush result = new ResultPrintFlush();
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        RequestBasicInformation requestBasic = new RequestBasicInformation();
        ResponseBasicInformation responseBasic = new ResponseBasicInformation();

        ResultData res = request(requestBasic, responseBasic);

        if (responseBasic.isSequenceError()) {
            RequestStartComunication requestStartComunication = new RequestStartComunication();
            ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();
            res = request(requestStartComunication, recieveStartComunication);

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                mControlDeviceManager.setSequence(seq);
                return result;
            }

            RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true,
                    mWidth);
            ResponseStartPrint responseStartPrint = new ResponseStartPrint();

            res = request(requestStartPrint, responseStartPrint);
            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            responseStartPrint.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }
        for (int i = 0; i < 2; i++) {
            RequestForceOutput requestForceOutput = new RequestForceOutput();
            ResponseForceOutput responseForceOutput = new ResponseForceOutput();

            res = request(requestForceOutput, responseForceOutput);
            if (isPaperLess(responseForceOutput)) {
                SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
            }

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            responseForceOutput.getExtCode(), null);
                }
                if (i == 1) {
                    result.setDevice(res.getDevice());
                    result.setUpos(res.getUpos());
                    return result;
                } else {
                    RequestStartComunication requestStartComunication = new RequestStartComunication();
                    ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

                    int seq = mControlDeviceManager.getSequence();
                    mControlDeviceManager.clearSequence();
                    res = request(requestStartComunication, recieveStartComunication);

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    recieveStartComunication.getExtCode(), null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        if (isShowError(result.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        mControlDeviceManager.setSequence(seq);
                        return result;
                    }

                    RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity,
                            true, mWidth);
                    ResponseStartPrint responseStartPrint = new ResponseStartPrint();

                    res = request(requestStartPrint, responseStartPrint);
                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    responseStartPrint.getExtCode(), null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        if (isShowError(result.getDevice())) {
                            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                        }
                        return result;
                    }
                    continue;
                }
            }
            break;
        }
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * JIS X 0201、JIS X 0208 で定義されない文字を黒豆腐にする
     */
    protected String replaceBlackTofu(String text) {
        CharsetEncoder sjisEncoder = Shift_JIS.newEncoder();

        for (int i = 0; i < text.length(); i = text.offsetByCodePoints(i, 1)) {

            int codePoint = text.codePointAt(i);
            if (Character.isSupplementaryCodePoint(codePoint)) {
                // サロゲートペア(複数のcharで1文字を表現)
                // JIS第3水準、JIS第4水準で構成されるため変換
                text = text.replace(new String(Character.toChars(codePoint)), "■");
                continue;
            }

            char c = text.charAt(i);

            if (!sjisEncoder.canEncode(c)) {
                // Shift_JIS に定義のない文字
                text = text.replace(c, '■');
                continue;
            }

            byte[] wordbyte = Character.toString(c).getBytes(Shift_JIS);

            if (wordbyte.length == 1) {
                // 1byte文字
                // JIS X 0201
                continue;
            }

            // 2byte文字
            // JIS X 0208
            int code = CalcUtil.toInt(wordbyte[1], wordbyte[0]);

            if (code > 0xEAA4) {
                // 第 1 水準, 第 2 水準漢字の領域外
                text = text.replace(c, '■');
            }

            if ((code & 0xFF00) == 0x8700) {
                // JIS X 0208 に定義されない非漢字
                // ①〜⑳、Ⅰ〜Ⅹ など
                text = text.replace(c, '■');
            }

        }

        return text;
    }

    /**
     * @brief 文字列印刷をする
     * @param text 印刷文字列
     * @return 実行結果
     */
    private ResultData printText(String text) {
        ResultData result = new ResultData();
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        RequestBasicInformation requestBasic = new RequestBasicInformation();
        ResponseBasicInformation responseBasic = new ResponseBasicInformation();

        ResultData res = request(requestBasic, responseBasic);

        if (responseBasic.isSequenceError()) {
            RequestStartComunication requestStartComunication = new RequestStartComunication();
            ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();
            res = request(requestStartComunication, recieveStartComunication);

            if (recieveStartComunication.isDeviceError()) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0, recieveStartComunication.getExtCode(),
                        null);
            }

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                mControlDeviceManager.setSequence(seq);
                return result;
            }
        }

        RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true,
                mWidth);
        ResponseStartPrint responseStartPrint = new ResponseStartPrint();

        res = request(requestStartPrint, responseStartPrint);

        if (responseStartPrint.isDeviceError()) {
            sendError(PluginDefine.ECODE_EXT_CODE, 0, responseStartPrint.getExtCode(), null);
        }

        if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
            if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0,
                        responseStartPrint.getExtCode(), null);
            }
            result.setDevice(res.getDevice());
            result.setUpos(res.getUpos());
            return result;
        }

        mControlDeviceManager.clearBuffer();
        for (int i = 0; i < 2; i++) {
            ResponsePrintChar responsePrintChar = new ResponsePrintChar();
            byte[] str;

            // Shift-JIS に無い文字や第3,第4水準漢字を黒豆腐変換
            text = replaceBlackTofu(text);

            if (mCharset == CHARSET_UTF8) {
                if (!text.equals(new String(text.getBytes(Shift_JIS), Shift_JIS))) {
                    str = new String(text.getBytes(UTF_8), Shift_JIS).getBytes();
                } else {
                    str = text.getBytes(Shift_JIS);
                }
            } else {
                str = text.getBytes(Shift_JIS);
            }

            int count = str.length / 100;
            for (int j = 0; j < count; j++) {
                byte[] txt = new byte[100];
                System.arraycopy(str, j * 100, txt, 0, txt.length);

                RequestPrintChar request = new RequestPrintChar(true, txt);
                if (!request.isValidValue()) {
                    result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                    result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                    return result;
                }
                mControlDeviceManager.write(request, TIME_OUT);
            }

            int end = str.length % 100;
            byte[] txt = new byte[end];
            System.arraycopy(str, count * 100, txt, 0, txt.length);

            RequestPrintChar request = new RequestPrintChar(false, txt);
            res = request(request, responsePrintChar);
            if (isPaperLess(responsePrintChar)) {
                SystemNotification.notifyShowIcon(mContext, IconType.PRINTER_DEVICE);
            }

            if (responsePrintChar.isDeviceError()) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0, responsePrintChar.getExtCode(), null);
            }

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (i == 1 || (res.getDevice() != PluginDefine.ERROR_EXT_PRINTER_SEQUENCE)) {
                    if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                responsePrintChar.getExtCode(), null);
                    }
                    result.setDevice(res.getDevice());
                    result.setUpos(res.getUpos());
                    return result;
                } else {
                    RequestStartComunication requestStartComunication = new RequestStartComunication();
                    ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

                    int seq = mControlDeviceManager.getSequence();
                    mControlDeviceManager.clearSequence();
                    res = request(requestStartComunication, recieveStartComunication);

                    if (recieveStartComunication.isDeviceError()) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                recieveStartComunication.getExtCode(), null);
                    }

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    recieveStartComunication.getExtCode(), null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        mControlDeviceManager.setSequence(seq);
                        return result;
                    }

                    requestStartPrint = new RequestStartPrint(mBold, mDensity,
                            true, mWidth);
                    responseStartPrint = new ResponseStartPrint();

                    res = request(requestStartPrint, responseStartPrint);

                    if (responseStartPrint.isDeviceError()) {
                        sendError(PluginDefine.ECODE_EXT_CODE, 0, responseStartPrint.getExtCode(),
                                null);
                    }

                    if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                        if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                            sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                    responseStartPrint.getExtCode(), null);
                        }
                        result.setDevice(res.getDevice());
                        result.setUpos(res.getUpos());
                        return result;
                    }
                    continue;
                }
            }
            break;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * コマンドリクエスト
     * 
     * @param request リクエスト
     * @param response レスポンス
     * @return 実行結果
     */
    private ResultData request(RequestPrinterData request, ResponsePrinterData response) {
        ResultData result = new ResultData();
        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mControlDeviceManager.clearBuffer();
        mControlDeviceManager.write(request, TIME_OUT);
        byte[] buffer = mControlDeviceManager.read(TIME_OUT);

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        }

        boolean res = response.inputPrinterResult(buffer);
        if (!res) {
            if (response.lackDataSize()) {
                long start = System.currentTimeMillis();
                while (true) {
                    try {
                        Thread.sleep(RETRY_SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    byte[] buf = mControlDeviceManager.read(RETRY_TIME_OUT);
                    buffer = concat(buffer, buf);
                    res = response.inputPrinterResult(buffer);
                    if (res) {
                        break;
                    }
                    long now = System.currentTimeMillis();
                    if ((now - start) > TIME_OUT) {
                        break;
                    }
                }
            }

            if (!res) {
                result.setDevice(response.getDevice());
                result.setUpos(response.getUpos());
                return result;
            }
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @brief エラーを送信する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private void sendError(int ecode, int vcode, int extcode, String extinfo) {
        ResponseError error = new ResponseError();
        error.setEcode(ecode);
        error.setVcode(vcode);
        error.setExtcode(extcode);
        error.setExtinfo(extinfo);

        synchronized (mIPrnServiceListenerList) {
            for (Map.Entry<String, IPrnServiceListener> listener : mIPrnServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(error);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param device deviceの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int device) {
        if (device == PluginDefine.ERROR_EXT_PRINTER_CRC) {
            return true;
        }

        return false;
    }

    /**
     * 異常アイコン表示ステータス確認
     * 
     * @param info
     * @return 表示/非表示
     */
    private boolean isShowNotification(ResponseBasicInformation info) {
        boolean font = (info.getStatus() & 0x02) > 0;
        boolean cutter = (info.getStatus() & 0x800) > 0;
        boolean mark = (info.getStatus() & 0x1000) > 0;
        boolean fatal = (info.getStatus() & 0x2000) > 0;
        boolean terminal = (info.getStatus() & 0x1000000) > 0;

        return font | cutter | mark | fatal | terminal;
    }

    /**
     * 用紙なしアイコン表示ステータス確認
     * 
     * @param info
     * @return 表示/非表示
     */
    private boolean isPaperLess(ResponsePrinterData info) {
        return (info.getStatus() & 0x40000) > 0;
    }

    /**
     * ログ表示するかどうか
     * 
     * @param info
     * @return 表示/非表示
     */
    private boolean isOutputLog(ResponsePrinterData info) {
        boolean font = (info.getStatus() & 0x02) > 0;
        boolean autoPaper = (info.getStatus() & 0x10) > 0;
        boolean reveive = (info.getStatus() & 0x200) > 0;
        boolean cutter = (info.getStatus() & 0x800) > 0;
        boolean mark = (info.getStatus() & 0x1000) > 0;
        boolean fatal = (info.getStatus() & 0x2000) > 0;
        boolean terminal = (info.getStatus() & 0x1000000) > 0;
        boolean param = (info.getStatus() & 0x2000000) > 0;

        return font | autoPaper | reveive | cutter | mark | fatal | terminal | param;
    }

    protected byte[] concat(byte[] src, byte[] dest) {
        if (src == null || dest == null) {
            return src;
        }

        byte[] buffer = new byte[src.length + dest.length];

        System.arraycopy(src, 0, buffer, 0, src.length);
        System.arraycopy(dest, 0, buffer, src.length, dest.length);

        return buffer;
    }

    /**
     * QRコードの生成及び印刷
     * 
     * @param qrVer QRコードのバージョン
     * @param qrSize QRコードのサイズ
     * @param qrData QRコードにするデータ
     * @param posx 印刷開始x座標
     * @return
     */
    public ResultPrintQrCode printQrCode(int qrVer, int qrSize, String qrData,
            int posx) {
        ResultPrintQrCode result = new ResultPrintQrCode();
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (mCutSequence) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        RequestBasicInformation requestBasic = new RequestBasicInformation();
        ResponseBasicInformation responseBasic = new ResponseBasicInformation();

        ResultData res = request(requestBasic, responseBasic);

        if (responseBasic.isSequenceError()) {
            RequestStartComunication requestStartComunication = new RequestStartComunication();
            ResponseStartComunication recieveStartComunication = new ResponseStartComunication();

            int seq = mControlDeviceManager.getSequence();
            mControlDeviceManager.clearSequence();
            res = request(requestStartComunication, recieveStartComunication);

            if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
                if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                    sendError(PluginDefine.ECODE_EXT_CODE, 0,
                            recieveStartComunication.getExtCode(), null);
                }
                result.setDevice(res.getDevice());
                result.setUpos(res.getUpos());
                mControlDeviceManager.setSequence(seq);
                return result;
            }
        }

        RequestStartPrint requestStartPrint = new RequestStartPrint(mBold, mDensity, true, mWidth);
        ResponseStartPrint responseStartPrint = new ResponseStartPrint();

        res = request(requestStartPrint, responseStartPrint);
        if (!((res.getUpos() == PluginDefine.RESULT_UPOS_SCCESS) && (res.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS))) {
            if (res.getUpos() == PluginDefine.RESULT_UPOS_FATAL) {
                sendError(PluginDefine.ECODE_EXT_CODE, 0, responseStartPrint.getExtCode(), null);
            }
            result.setDevice(res.getDevice());
            result.setUpos(res.getUpos());
            return result;
        }

        QRCodeData data = new QRCodeData(qrVer, qrSize, qrData);

        /* パラメータチェック */
        if (!data.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        /* QRコードの1辺の長さを設定(pixel) */
        // int qrPixels = data.get8Multiple(data.getImageLength());
        int qrPixels = data.getImageLength();
        Log.e(TAG, " qr Image length = " + qrPixels);

        if (qrPixels < 0) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        /* QRコード作成 */
        Hashtable hints = new Hashtable();
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.CHARACTER_SET, "ISO-8859-1");
        hints.put(DecodeHintType.TRY_HARDER, true);
        hints.put(EncodeHintType.MARGIN, 4);

        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bm = writer.encode(qrData, BarcodeFormat.QR_CODE, qrPixels, qrPixels, hints);
            int width = bm.getWidth();
            int height = bm.getHeight();

            /**
             * 生成したQRコードの高さが一回で印刷できるかチェック。 高さが192を越えている場合は2回に分けて印刷する
             */
            boolean isHeightOver = false;
            if (height > PRINTER_MAX_HIGHT) {
                isHeightOver = true;
            }

            /* 1辺のpixel数が8の倍数になっていない場合、8の倍数にする(プリンターの仕様) */
            int extraWidth = 0;
            if (width % 8 != 0) {
                while ((width + extraWidth) % 8 != 0) {
                    extraWidth++;
                }
            }

            int bitWidth = (width + extraWidth) / 8;

            byte[] bitInPixels = null;
            byte[] bitInPixels2 = null;

            if (isHeightOver) {
                /* 分割して印刷する場合 */
                bitInPixels = makePrintQRByteArray(width, PRINTER_MAX_HIGHT, bitWidth, bm,
                        extraWidth);

                int byteCount = 0;
                bitInPixels2 = new byte[bitWidth * (height - PRINTER_MAX_HIGHT)];
                for (int y = PRINTER_MAX_HIGHT, offsetY = 0; y < height; y++, offsetY++) {
                    int offsetForBit = offsetY * bitWidth;
                    for (int x = 0, moveBit = 0; x < width + extraWidth; x++) {
                        /* 1辺を8の倍数に変更した際の追加部分は白にする */
                        if (x > width) {
                            bitInPixels2[offsetForBit + moveBit] |= (byte) (((byte) 0) << (7 - byteCount));
                        } else {
                            bitInPixels2[offsetForBit + moveBit] |= bm.get(x, y) ? (byte) (((byte) 1) << (7 - byteCount))
                                    : (byte) (((byte) 0) << (7 - byteCount));
                        }

                        byteCount++;
                        if (byteCount % 8 == 0) {
                            byteCount = 0;
                            moveBit++;
                        }
                    }
                }
            } else {
                /* 分割しないで印刷する場合 */
                bitInPixels = makePrintQRByteArray(width, height, bitWidth, bm, extraWidth);
            }

            /* 印刷 */
            String txt = "";
            ResultData printResult;
            if (isHeightOver) {
                txt += CalcUtil.toHexString(bitInPixels);
                printResult = printSetImage(1, txt, false, "QR", bitWidth, PRINTER_MAX_HIGHT, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }

                printResult = printImage(1, 1, posx, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }

                printResult = printFlush();
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }

                txt = "" + CalcUtil.toHexString(bitInPixels2);
                printResult = printSetImage(2, txt, false, "QR2", bitWidth, height
                        - PRINTER_MAX_HIGHT, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }

                printResult = printImage(2, 1, posx, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }
            } else {
                txt += CalcUtil.toHexString(bitInPixels);

                printResult = printSetImage(1, txt, false, "QR", bitWidth, height, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }

                printResult = printCheckImage(1, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }

                printResult = printImage(1, 1, posx, true);
                if (printResult.getUpos() != PluginDefine.RESULT_UPOS_SCCESS
                        || printResult.getDevice() != PluginDefine.RESULT_DEVICE_SCCESS) {
                    result.setDevice(printResult.getDevice());
                    result.setUpos(printResult.getUpos());
                    return result;
                }
            }
        } catch (WriterException e) {
            e.printStackTrace();
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * QRコードのbitの二次元配列を印刷用の一次元配列に変換
     * 
     * @param width QRコードの幅(pixel)
     * @param height QRコードの高さ(pixel)
     * @param bitWidth 印刷用
     * @param qrBitMatrix QRコードのbitの二次元配列
     * @param extraWidth QRコードの1辺の長さが8の倍数じゃなかった際に追加した幅
     * @return
     */
    private byte[] makePrintQRByteArray(int width, int height, int bitWidth, BitMatrix qrBitMatrix,
            int extraWidth) {
        byte[] ret = new byte[bitWidth * height];

        int byteCount = 0;

        for (int y = 0; y < height; y++) {
            int offsetForBit = y * bitWidth;
            for (int x = 0, moveBit = 0; x < width + extraWidth; x++) {
                if (x > width) {
                    /* 1辺を8の倍数に変更した際の追加部分は白にする */
                    ret[offsetForBit + moveBit] |= (byte) (((byte) 0) << (7 - byteCount));
                } else {
                    ret[offsetForBit + moveBit] |= qrBitMatrix.get(x, y) ? (byte) (((byte) 1) << (7 - byteCount))
                            : (byte) (((byte) 0) << (7 - byteCount));
                }

                byteCount++;
                if (byteCount % 8 == 0) {
                    byteCount = 0;
                    moveBit++;
                }
            }
        }

        return ret;
    }

    /**
     * QRコードのサイズを設定(pixel)
     * 
     * @param qrVer QRコードのバージョン
     * @param qrSize QRコードのサイズ
     * @return 1辺のpixel数(マージン無し)
     */
    private int setQRSize(int qrVer, int qrSize) {
        return -1;
    }

    /**
     * QRコードにするためのデータのデータ長チェック
     * 
     * @param version QRコードのバージョン
     * @param size QRコードのサイズ
     * @param length QRコードにするデータの長さ
     * @return false: パラメータ異常
     */
    private boolean checkQRSize(int version, int size) {
        if (version > 25 || version < 0) {
            return false;
        }

        return true;
    }
}
