
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * 文字列印字要求
 */
public class RequestPrintChar extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x001A;

    /** @brief コマンド詳細(バーストあり) */
    private static final int COMMAND_DETAIL_BRUST = 0xA000;

    /** @brief コマンド詳細(バーストなし) */
    private static final int COMMAND_DETAIL_BRUST_END = 0xE000;

    /** @brief 印字文字列 */
    private byte[] mText;

    /**
     * @brief コンストラクタ
     * @param brust バーストモードかどうか
     * @param text 印字文字列
     */
    public RequestPrintChar(boolean brust, byte[] text) {
        mCommandId = COMMAND_ID;
        mCommandDetail = brust ? COMMAND_DETAIL_BRUST : COMMAND_DETAIL_BRUST_END;
        mText = text;
    }

    /**
     * @brief 印字文字列を取得する
     * @return 印字文字列
     */
    public byte[] getText() {
        return mText;
    }

    /**
     * @brief 印字文字列を設定する
     * @param text 印字文字列
     */
    public void setText(byte[] text) {
        mText = text;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        return toCommand(mText);
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mText == null || mText.length > 100) {
            return false;
        }

        return true;
    }

}
