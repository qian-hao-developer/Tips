package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants;
import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.RW_INFORMATION_RESPONSE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * RW情報要求Responseクラス.
 */
public class RWInformationResponse extends BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = RWInformationResponse.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x00;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x00;

    /** @brief データ長データ2桁目（フォーマット１版）(LittleEndian) */
    private static byte DATALENGTH_HIGH_FORMAT1 = (byte) 0x20;
    /** @brief データ長データ2桁目（フォーマット２版）(LittleEndian) */
    private static byte DATALENGTH_HIGH_FORMAT2 = (byte) 0x10;
    /** @brief データ長データ1桁目(LittleEndian) */
    private static byte DATALENGTH_LOW = (byte) 0x00;

    /** @brief RW状態フラグ . */
    private byte mStatusFlg;
    /** @brief RW状態番号 . */
    private byte mStatusNo;
    /** @brief 音量設定値 . */
    private byte mVolume;
    /** @brief コントラスト . */
    private byte mContrast;
    /** @brief バックライト . */
    private byte mBacklight;
    /** @brief RW製品品番 . */
    private byte[] mProductNo;
    /** @brief RW製造番号 . */
    private byte[] mSerialNo;

    /**
     * RW状態フラグを返却する.
     * 
     * @return RW状態フラグ
     */
    public byte getStatusFlg() {
        return mStatusFlg;
    }

    /**
     * RW状態番号を返却する.
     * 
     * @return RW状態番号
     */
    public byte getStatusNo() {
        return mStatusNo;
    }

    /**
     * 音量設定値を返却する.
     * 
     * @return 音量設定値
     */
    public byte getVolume() {
        return mVolume;
    }

    /**
     * コントラストを返却する.
     * 
     * @return コントラスト
     */
    public byte getContrast() {
        return mContrast;
    }

    /**
     * バックライトを返却する.
     * 
     * @return バックライト
     */
    public byte getBacklight() {
        return mBacklight;
    }

    /**
     * RW製品品番を返却する.
     * 
     * @return RW製品品番
     */
    public byte[] getProductNo() {
        return mProductNo;
    }

    /**
     * RW製造番号を返却する.
     * 
     * @return RW製造番号
     */
    public byte[] getSerialNo() {
        return mSerialNo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {  // PT_IMPOSSIBLE_BRANCH
            return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return (cutDeviceResult(bytes) != null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MAINCOMMAND) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND mismatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND) {
            Logger.e(TAG, "checkResponseData SUBCOMMAND mismatch = "
                    + bytes[SUBCOMMAND_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHHIGH_INDEX] != DATALENGTH_HIGH_FORMAT1
                && bytes[DATALENGTHHIGH_INDEX] != DATALENGTH_HIGH_FORMAT2) {
            Logger.e(TAG, "checkResponseData DATALENGTH_HIGH mismatch = "
                    + bytes[DATALENGTHHIGH_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHLOW_INDEX] != DATALENGTH_LOW) {
            Logger.e(TAG, "checkResponseData DATALENGTH_LOW mismatch = "
                    + bytes[DATALENGTHLOW_INDEX]);
            return false;
        }

        RW_INFORMATION_RESPONSE[] dataConstArray = RW_INFORMATION_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (RW_INFORMATION_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* RW状態フラグ */
            case STATUSFLG:
                // 格納前チェック不要
                break;
            /* RW状態番号 */
            case STATUSNO:
                // 格納前チェック不要
                break;
            /* 音量設定値 */
            case VOLUME:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                // 0～2
                if (!ByteUtil.checkTargetValueByte(checkByteArray[0],
                        (byte) 0x00, (byte) 0x01, (byte) 0x02)) {
                    Logger.e(TAG, "checkResponseData " + dataConst.name()
                            + " mismatch =" + checkByteArray[0]);
                    return false;
                }
                break;
            /* コントラスト */
            case CONTRAST:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                // 0x00~0x0f or 0xff
                int checkData = new BigInteger(new byte[] { (byte) 0x00,
                        checkByteArray[0] }).intValue();
                if (checkData > 0x0f && checkData != 0xff) {
                    Logger.e(TAG, "checkResponseData " + dataConst.name()
                            + " mismatch =" + checkByteArray[0]);
                    return false;
                }

                break;
            /* バックライト */
            case BACKLIGHT:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                // 0～2
                if (!ByteUtil.checkTargetValueByte(checkByteArray[0],
                        (byte) 0x00, (byte) 0x01, (byte) 0x02)) {
                    Logger.e(TAG, "checkResponseData " + dataConst.name()
                            + " mismatch =" + checkByteArray[0]);
                    return false;
                }
                break;
            /* RW製品品番 */
            case PRODUCTNO:
                // フォーマット１の場合のみ抽出してチェックする
                if (DATA_INDEX + (DATALENGTH_HIGH_FORMAT1 & 0xff) == bytes.length) {
                    checkByteArray = new byte[dataConst.getDataLength()];
                    System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                            dataConst.getDataLength());

                    // ASCII文字チェック
                    if (!ByteUtil.checkASCIICharacterByteArray(checkByteArray)) {
                        Logger.e(TAG,
                                "checkResponseData " + dataConst.name()
                                        + " mismatch ="
                                        + Arrays.toString(checkByteArray));
                        return false;
                    }
                }
                break;
            /* RW製造番号 */
            case SERIALNO:
                // フォーマット１の場合のみ抽出してチェックする
                if (DATA_INDEX + (DATALENGTH_HIGH_FORMAT1 & 0xff) == bytes.length) {
                    checkByteArray = new byte[dataConst.getDataLength()];
                    System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                            dataConst.getDataLength());
                    // ASCII文字チェック
                    if (!ByteUtil.checkASCIICharacterByteArray(checkByteArray)) {
                        Logger.e(TAG,
                                "checkResponseData " + dataConst.name()
                                        + " mismatch ="
                                        + Arrays.toString(checkByteArray));
                        return false;
                    }
                }
                break;

            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ格納を行う
        RW_INFORMATION_RESPONSE[] dataConstArray = RW_INFORMATION_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (RW_INFORMATION_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* RW状態フラグ */
            case STATUSFLG:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mStatusFlg = checkByteArray[0];
                break;
            /* RW状態番号 */
            case STATUSNO:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mStatusNo = checkByteArray[0];
                break;
            /* 音量設定値 */
            case VOLUME:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mVolume = checkByteArray[0];
                break;
            /* コントラスト */
            case CONTRAST:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mContrast = checkByteArray[0];
                break;
            /* バックライト */
            case BACKLIGHT:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mBacklight = checkByteArray[0];
                break;
            /* RW製品品番 */
            case PRODUCTNO:
                // フォーマット１の場合のみ抽出する
                if (getDataLength() == (DATALENGTH_HIGH_FORMAT1 & 0xff)) {
                    checkByteArray = new byte[dataConst.getDataLength()];
                    System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                            dataConst.getDataLength());
                    mProductNo = checkByteArray;
                }
                break;
            /* RW製造番号 */
            case SERIALNO:
                // フォーマット１の場合のみ抽出する
                if (getDataLength() == (DATALENGTH_HIGH_FORMAT1 & 0xff)) {
                    checkByteArray = new byte[dataConst.getDataLength()];
                    System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                            dataConst.getDataLength());
                    mSerialNo = checkByteArray;
                }
                break;
            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return bytes;
    }

}
