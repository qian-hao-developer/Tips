package com.panasonic.avc.smartpayment.devctlservice.nfc;

import com.panasonic.avc.smartpayment.devctlservice.nfc.data.DEINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.INSTALLEDFILEDATE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.RESULTINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.SETTINGINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.TRANSACTIONDATA;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.VERSIONINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.AsyncTransaction;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.PlatformConfig;
import com.panasonic.avc.smartpayment.devctlservice.nfc.request.*;
import com.panasonic.avc.smartpayment.devctlservice.nfc.response.*;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.checkBCDByteArray;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.convertBCDByte2String;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.convertBCDData;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.convertBigBytes2Long;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.hex2bin;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.mergeByteArray;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil.targetLengthTrimPaddingByteArray;

/**
 * 非接触EMV独自API-JavaIFクラス.<br>
 */
public class NFCInterfaceImpl {

    /**
     * ログ用タグ.
     */
    private static final String TAG = NFCInterfaceImpl.class
            .getSimpleName();

    private static NFCInterfaceImpl sInstance = new NFCInterfaceImpl();

    private static PlatformConfig mPlatformConfig = PlatformConfig.getInstance();

    private NFCCompleteEventHandler m_CompleteEvent = null;

    /** BitMap転送用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_BITMAP = 30000;
    /** トレーニング用BitMap転送用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_BITMAP_TR = 7000;
    /** DataExchange用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_DATA_ECXCHANGE = 10000;
    /** RW設定変更用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_RWCHANGE = 30000;
    /** 暗号鍵設定用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_ENCRYPTIONKEY = 10000;
    /** 決済通貨表示用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_CURRENCY_DISPLAY = 10000;
    /** 処理キャンセル用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_CLEAR = 10000;
    /** 結果通知用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_SET_RESULT = 5000;

    /** AP切替用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_APSWITCHING = 11000;
    /** RW切替用タイムアウト設定値. */
    private static final int RESPONSE_TIMER_RWSWITCHING = 11000;

    /** DataExchange状態. */
    private boolean mIsDataExchange = false;

    /** DataExchange後の売上レスポンスで拡張データが必要かどうかのフラグ. */
    private boolean mIsNeedExpand = false;

    /** 送信カウンタ保持用. */
    private byte[] mSendCounter = null;

    /** 保持状態status. */
    private EMVStatus m_EMVStatus = EMVStatus.EMVCL_CLOSED;

    /** EMV状態Status. */
    enum EMVStatus {
        /** 初期状態. */
        EMVCL_CLOSED,
        /** Open状態. */
        EMVCL_OPENED,
        /** CLAIM状態. */
        EMVCL_CLAIMED,
        /** BUSY状態. */
        EMVCL_BUSY
    }

    /**
     * @brief コンストラクタ
     */
    private NFCInterfaceImpl() {

    }

    /**
     * @brief シングルトンインスタンス取得
     */
    public static NFCInterfaceImpl getInstance() {
        return sInstance;
    }

    /**
     * @brief プラットフォーム依存部分を取得する。
     */
    public static PlatformConfig getPlatformConfig() {
        return mPlatformConfig;
    }

    /**
     * 非同期Transaction処理クラス用インスタンス変数<br>
     */
    private TransactionTask doTransactionTask;

    /**
     * 非同期DataExchange処理クラス用インスタンス変数<br>
     */
    private DataExchangeTask doDataExchangeTask;

    /**
     * 現在チェック時開始処理に合うステータスかをチェックする.<br>
     * Open、Close、Claim、Cancel以外の共通チェック<br>
     *
     * @return 実行結果コード数値
     */
    private int checkStatus() {
        final String METHOD_NAME = "checkStatus";
        startLog(METHOD_NAME);
        int checkResultApiReturn = ApiReturnValues.E_ILLEGAL;


        // 端末連携（Transaction、FileDLL、SetEMV等）
        switch (m_EMVStatus) {  // PT_IMPOSSIBLE_BRANCH
        case EMVCL_CLOSED:
            Logger.d(TAG, METHOD_NAME
                    + " m_EMVStatus = "
                    + m_EMVStatus.name());
            checkResultApiReturn = ApiReturnValues.E_CLOSED;
            break;
        case EMVCL_OPENED:
            Logger.d(TAG, METHOD_NAME
                    + " m_EMVStatus = "
                    + m_EMVStatus.name());
            checkResultApiReturn = ApiReturnValues.E_NOTCLAIMED;
            break;
        case EMVCL_BUSY:
            Logger.d(TAG, METHOD_NAME
                    + " m_EMVStatus = "
                    + m_EMVStatus.name());
            checkResultApiReturn = ApiReturnValues.E_BUSY;
            break;
        case EMVCL_CLAIMED:
            checkResultApiReturn = ApiReturnValues.SUCCESS;
            break;
        }

        endLog(METHOD_NAME, String.valueOf(checkResultApiReturn));
        return checkResultApiReturn;
    }

    /**
     * 現在チェック時開始処理に合うステータスかをチェックする.<br>
     * Open、Close、Claim、Cancel以外の共通チェック<br>
     *
     * @return 実行結果コード数値
     */
    private int checkStatus_RWVer() {
        final String METHOD_NAME = "checkStatus_RWVer";
        startLog(METHOD_NAME);
        int checkResultApiReturn = ApiReturnValues.E_ILLEGAL;

        // 端末連携（Transaction、FileDLL、SetEMV等）
        switch (m_EMVStatus) {  // PT_IMPOSSIBLE_BRANCH
        case EMVCL_CLOSED:
            Logger.d(TAG, METHOD_NAME
                    + " m_EMVStatus = "
                    + m_EMVStatus.name());
            checkResultApiReturn = ApiReturnValues.E_CLOSED;
            break;
        case EMVCL_OPENED:
            checkResultApiReturn = ApiReturnValues.SUCCESS;
            break;
        case EMVCL_BUSY:
            Logger.d(TAG, METHOD_NAME
                    + " m_EMVStatus = "
                    + m_EMVStatus.name());
            checkResultApiReturn = ApiReturnValues.E_BUSY;
            break;
        case EMVCL_CLAIMED:
            Logger.d(TAG, METHOD_NAME
                    + " m_EMVStatus = "
                    + m_EMVStatus.name());
            checkResultApiReturn = ApiReturnValues.E_ILLEGAL;
            break;
        }

        endLog(METHOD_NAME, String.valueOf(checkResultApiReturn));
        return checkResultApiReturn;
    }


    /**
     * EMVステータスを指定されたステータスに変更する.<br>
     *
     * @param changeStatus 変更するStatus値
     * @return 処理結果コード
     */
    private synchronized int changeStatus(EMVStatus changeStatus) {
        final String METHOD_NAME = "changeStatus";
        startLog(METHOD_NAME);
        Logger.d(TAG, METHOD_NAME + "() status=" + m_EMVStatus + " -> " + changeStatus);

        int result = ApiReturnValues.E_ILLEGAL;

        if (changeStatus != null) {
            m_EMVStatus = changeStatus;
            result = ApiReturnValues.SUCCESS;
        }

        endLog(METHOD_NAME, String.valueOf(result));
        return result;
    }

    /**
     * 非接触EMV独自APIの処理を開始するAPI。.<br>
     * <br>
     *
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     */
    public int EMVCL_Open() {
        final String METHOD_NAME = "EMVCL_Open";
        startLog(METHOD_NAME);
        ApiReturnValues.Open returnStatus = ApiReturnValues.Open.SUCCESS;

        // 状態チェック
        if (m_EMVStatus != EMVStatus.EMVCL_CLOSED) {
            Logger.d(TAG, METHOD_NAME
                    + "m_EMVStatus = "
                    + m_EMVStatus.name());
            returnStatus = ApiReturnValues.Open.E_ILLEGAL;
        }

        if (returnStatus == ApiReturnValues.Open.SUCCESS) {
            // FIXME:未実装 初期化処理（内部保持フラグ、暗号化ライブラリ？）
            // デバイス層でopen時に実行する処理が有れば記載

            // Status変更
            changeStatus(EMVStatus.EMVCL_OPENED);
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 非接触EMV独自APIの処理を終了するAPI。.<br>
     * <br>
     *
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_Close() {
        final String METHOD_NAME = "EMVCL_Close";
        startLog(METHOD_NAME);
        ApiReturnValues.Close returnStatus = ApiReturnValues.Close.SUCCESS;

        // 状態チェック
        switch (m_EMVStatus) {  // PT_IMPOSSIBLE_BRANCH
        case EMVCL_CLOSED:
            Logger.d(TAG, METHOD_NAME
                    + "m_EMVStatus = "
                    + m_EMVStatus.name());
            returnStatus = ApiReturnValues.Close.E_CLOSED;
            break;
        case EMVCL_OPENED:
            // 排他をせずに終了
            returnStatus = ApiReturnValues.Close.SUCCESS;
            break;
        case EMVCL_CLAIMED:
            // EMVCL_Releaseを実行する
            int[] resultCode = new int[1];
            int[] resultCodeExtends = new int[1];
            int result = EMVCL_Release(resultCode, resultCodeExtends);
            if (result != ApiReturnValues.SUCCESS) {
                Logger.d(TAG, METHOD_NAME
                        + "EMVCL_Release not success = "
                        + String.valueOf(result));
                returnStatus = ApiReturnValues.Close.E_BUSY;
            } else {
                returnStatus = ApiReturnValues.Close.SUCCESS;
            }
            break;
        case EMVCL_BUSY:
            Logger.d(TAG, METHOD_NAME
                    + "m_EMVStatus = "
                    + m_EMVStatus.name());
            returnStatus = ApiReturnValues.Close.E_BUSY;
            break;
        }

        if (returnStatus == ApiReturnValues.Close.SUCCESS) {
            // Status変更
            changeStatus(EMVStatus.EMVCL_CLOSED);
            // 非同期処理部クリア
            m_CompleteEvent = null;
        }
        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 取引、各種設定を実施する際に実行するAPI。.<br>
     * <br>
     *
     * @param Timeout
     *            排他権を獲得するまでの最大待ち時間（単位：ms）<br>
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - タイムアウト：E_TIMEOUT(112)<br>
     */
    public int EMVCL_Claim(int Timeout, int[] ResultCode,
                           int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_Claim";
        startLog(METHOD_NAME, Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));
        ApiReturnValues.Claim returnStatus = ApiReturnValues.Claim.SUCCESS;

        // 入力チェック
        if (inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            returnStatus = ApiReturnValues.Claim.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 排他取得処理
        if (m_EMVStatus == EMVStatus.EMVCL_OPENED || m_EMVStatus == EMVStatus.EMVCL_CLAIMED) {

            // AP切替
            int result = changeAP();
            if (result != ApiReturnValues.SUCCESS) {
                Logger.d(TAG, METHOD_NAME
                        + "() AP Change IF error =" + result);
                returnStatus = ApiReturnValues.Claim.E_FAILURE;
            } else {
                changeStatus(EMVStatus.EMVCL_CLAIMED);
            }
        } else if (m_EMVStatus == EMVStatus.EMVCL_CLOSED) {
            returnStatus = ApiReturnValues.Claim.E_CLOSED;
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 取引、各種設定を終了する際に実行するAPI。.<br>
     * <br>
     *
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_Release(int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_Release";
        startLog(METHOD_NAME, Arrays.toString(ResultCode),
                Arrays.toString(ResultCodeExtended));
        ApiReturnValues.Release returnStatus = ApiReturnValues.Release.SUCCESS;

        // 入力チェック
        if (inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            returnStatus = ApiReturnValues.Release.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult == ApiReturnValues.E_NOTCLAIMED) {
            // 排他等をしていない状態なのでRW切替等を行わず終了する
            returnStatus = ApiReturnValues.Release.SUCCESS;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        } else if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.Release.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // RW切替
        int resultValue = changeRW();
        if (resultValue != ApiReturnValues.SUCCESS) {
            Logger.d(TAG, METHOD_NAME
                    + "() RW Change IF error =" + resultValue);
            returnStatus = ApiReturnValues.Release.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // Status変更
        changeStatus(EMVStatus.EMVCL_OPENED);

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 非接触EMVライブラリのバージョンを取得するAPI。.<br>
     * <br>
     *
     * @param VersionSize
     *            呼び出し側指定バージョン格納エリアバッファサイズ
     * @param Version
     *            EMVCLライブラリバージョン格納エリア（バッファサイズに合わせる）
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_GetLibraryVersion(int VersionSize, String Version) {
        final String METHOD_NAME = "EMVCL_GetLibraryVersion";
        startLog(METHOD_NAME, String.valueOf(VersionSize), Version);
        ApiReturnValues.GetLibraryVersion returnStatus = ApiReturnValues.GetLibraryVersion.SUCCESS;

        // FIXME:ライブラリバージョンの取得先を確認する

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 取引に必要な運用情報を設定するAPI。.<br>
     * <br>
     *
     * @param FileNumber
     *            設定ファイル番号
     * @param FileDataLength
     *            設定ファイル長
     * @param FileData
     *            設定ファイルデータ
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_FileDLL(byte FileNumber, int FileDataLength,
                             byte[] FileData, int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_FileDLL";
        startLog(METHOD_NAME, Byte.toString(FileNumber),
                Integer.toString(FileDataLength), Arrays.toString(FileData),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));
        ApiReturnValues.FileDll returnStatus = inputCheckEMVCL_FileDLL(
                FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended
        );

        if (returnStatus == ApiReturnValues.FileDll.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkState = checkStatus();
        if (checkState != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.FileDll.getTargetStatus(checkState);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // bitmap転送
        // 分割有無
        int sendDataItemCount = 1;
        if (FileDataLength > CommandDataConstants.FILE_DLL_DATA_MAX) {
            if (FileDataLength % CommandDataConstants.FILE_DLL_DATA_MAX == 0) {  // PT_IMPOSSIBLE_BRANCH
                sendDataItemCount = FileDataLength / CommandDataConstants.FILE_DLL_DATA_MAX;  // PT_IMPOSSIBLE_INSTRUCTIONS
            } else {
                sendDataItemCount = 1 + FileDataLength / CommandDataConstants.FILE_DLL_DATA_MAX;
            }
        }

        // 送信済みのデータサイズ
        int sentSize = 0;
        // 今回送信するデータサイズ
        int nowSendSize;
        // BitMapデータ：項目１レングス設定値
        int colLength;
        byte[] colLengthByte;
        // BitMapデータ：項目４
        byte[] bitMapPrimaryBytes = new byte[8];
        bitMapPrimaryBytes[0] = (byte) 0x82;
        // BitMapデータ：項目５
        byte[] bitMapSecondaryBytes = new byte[8];
        bitMapSecondaryBytes[0] = (byte) 0xA0;
        // BitMapデータ：項目６
        byte[] bitMapThirdBytes = new byte[8];
        bitMapThirdBytes[0] = (byte) 0x80;
        // BitMapデータ：項目７
        byte[] bitMapFourthBytes = new byte[8];
        bitMapFourthBytes[7] = (byte) 0x18;
        // BitMapデータ：項目９ブロック通番設定値
        byte[] blockNumByte;
        // BitMapデータ：項目１２通信ファイル総サイズ
        byte[] fileDataLengthByte = convertBCDData(String.valueOf(FileDataLength));
        // BitMapデータ：項目１３送信ブロック総数
        byte[] blockCountByte = convertBCDData(String.valueOf(sendDataItemCount));
        // BitMapデータ：項目１４ファイルデータレングス設定値
        byte[] nowSendDataSizeByte;
        // BitMapデータ：項目１５ファイルデータ
        byte[] sendBitMapData;

        Calendar nowDate = Calendar.getInstance();
        DateFormat sendDateFormat = new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYMMDDHHMMSS);
        DateFormat fileDateFormat = new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYYYMMDD);
        // BitMapデータ：項目８送信日時
        byte[] sendBCDDateByte = convertBCDData(sendDateFormat.format(nowDate.getTime()));
        // BitMapデータ：項目１１ファイル日付
        byte[] fileBCDDateByte = convertBCDData(fileDateFormat.format(nowDate.getTime()));

        BitmapTransferRequest bitmapTransferRequest;
        BitmapTransferResponse bitmapTransferResponse;

        for (int i = 0; i < sendDataItemCount; i++) {
            if (FileDataLength - sentSize > CommandDataConstants.FILE_DLL_DATA_MAX) {
                nowSendSize = CommandDataConstants.FILE_DLL_DATA_MAX;
            } else {
                nowSendSize = FileDataLength - sentSize;
            }

            colLength = CommandDataConstants.FILE_HEADER_LENGTH_EMV
                    + nowSendSize - CommandDataConstants.FILE_HEADER_LENGTH_COL_LENGTH;

            colLengthByte = ByteBuffer.allocate(4).putInt(colLength).array();
            blockNumByte = ByteBuffer.allocate(4).putInt(i + 1).array();
            nowSendDataSizeByte = ByteBuffer.allocate(4).putInt(nowSendSize).array();

            sendBitMapData = mergeByteArray(
                    targetLengthTrimPaddingByteArray(colLengthByte, 2)
                    , new byte[]{(byte) 0x11, (byte) 0x94}
                    , new byte[]{(byte) 0x00, (byte) 0x00}
                    , bitMapPrimaryBytes
                    , bitMapSecondaryBytes
                    , bitMapThirdBytes
                    , bitMapFourthBytes
                    , targetLengthTrimPaddingByteArray(sendBCDDateByte, 6)
                    , targetLengthTrimPaddingByteArray(blockNumByte, 2)
                    , new byte[]{FileNumber}
                    , targetLengthTrimPaddingByteArray(fileBCDDateByte, 4)
                    , targetLengthTrimPaddingByteArray(fileDataLengthByte, 3)
                    , targetLengthTrimPaddingByteArray(blockCountByte, 2)
                    , targetLengthTrimPaddingByteArray(nowSendDataSizeByte, 2)
                    , Arrays.copyOfRange(FileData, sentSize, sentSize + nowSendSize)
            );

            bitmapTransferRequest = new BitmapTransferRequest();
            bitmapTransferResponse = new BitmapTransferResponse();

            bitmapTransferRequest.setBitMapData(sendBitMapData);
            returnStatus = ApiReturnValues.FileDll.E_ILLEGAL;
            if (bitmapTransferRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
                byte[] resp = mPlatformConfig.deviceSendReceive(
                        bitmapTransferRequest.toCommand(), RESPONSE_TIMER_BITMAP);
                if (resp == null) {
                    // R550が抜けたか故障(Statusを)
                    Logger.d(TAG, METHOD_NAME + "() BitmapTransfer request resp null");
                    changeStatus(EMVStatus.EMVCL_CLOSED);
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    returnStatus = ApiReturnValues.FileDll.E_FAILURE;
                    setResultCodeExtendedData(ResultCodeExtended,
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                    break;
                } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                    Logger.d(TAG, METHOD_NAME + "() BitmapTransfer errorResponse");
                    break;
                } else if (!bitmapTransferResponse.inputDeviceResult(resp)) {
                    Logger.d(TAG, METHOD_NAME + "() BitmapTransfer request error inputDeviceResult");
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    setResultCodeExtendedData(ResultCodeExtended,
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                    break;
                } else {
                    // responseデータ内の処理結果を確認する
                    if (bitmapTransferResponse.getDispose_result() == null) {
                        Logger.d(TAG, METHOD_NAME + "() response bitmapData nothing");
                        ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                        setResultCodeExtendedData(ResultCodeExtended,
                                        CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                        break;
                    } else {
                        byte[] resultCode;
                        byte[] resultCodeExtended;
                        resultCode = bitmapTransferResponse.getDispose_result();
                        resultCodeExtended = bitmapTransferResponse.getDetailed_err_code();

                        int checkResult = checkBitmapResultCode(resultCode, null,
                                ResultCode, ResultCodeExtended);

                        if (checkResult == CommandDataConstants.RESULT_CODE_SUCCESS) {
                            returnStatus = ApiReturnValues.FileDll.SUCCESS;
                        }
                    }
                }
            } else {
                Logger.d(TAG, METHOD_NAME + "() request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
                break;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }

            sentSize = sentSize + nowSendSize;
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * EMVCL_FileDLLの入力チェック処理.<br>
     * <br>
     *
     * @param FileNumber         設定ファイル番号
     * @param FileDataLength     設定ファイル長
     * @param FileData           設定ファイルデータ
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return 処理結果
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    private ApiReturnValues.FileDll inputCheckEMVCL_FileDLL(
            byte FileNumber, int FileDataLength, byte[] FileData,
            int[] ResultCode, int[] ResultCodeExtended) {

        final String METHOD_NAME = "inputCheckEMVCL_FileDLL";
        startLog(METHOD_NAME);
        ApiReturnValues.FileDll returnStatus = ApiReturnValues.FileDll.E_ILLEGAL;

        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        }

        if (FileData == null || FileData.length == 0) {
            Logger.d(TAG, METHOD_NAME + "() FileData not set");
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        } else {
            if (FileData.length > 58000) {
                Logger.d(TAG, METHOD_NAME
                        + "() FileData max length over =" + FileData.length);
                endLog(METHOD_NAME,returnStatus.name());
                return returnStatus;
            } else if (FileData.length != FileDataLength) {
                Logger.d(TAG, METHOD_NAME
                        + "() FileData.length mismatch =" + FileData.length
                        + ",FileDataLength=" + FileDataLength);
                endLog(METHOD_NAME,returnStatus.name());
                return returnStatus;
            } else {
                if (FileNumber == (byte) 0x21) {
                    if (FileDataLength % 55 != 0 || FileDataLength / 55 > 50) {
                        Logger.d(TAG, METHOD_NAME
                                + "() FileNumber Data length mismatch FileNumber = " + FileNumber
                                + ":FileDataLength =" + FileDataLength);
                        endLog(METHOD_NAME,returnStatus.name());
                        return returnStatus;
                    }
                } else if (FileNumber == (byte) 0x22) {
                    if (FileDataLength % 290 != 0 || FileDataLength / 290 > 100) {
                        Logger.d(TAG, METHOD_NAME
                                + "() FileNumber Data length mismatch FileNumber = " + FileNumber
                                + ":FileDataLength =" + FileDataLength);
                        endLog(METHOD_NAME,returnStatus.name());
                        return returnStatus;
                    }
                } else if (FileNumber == (byte) 0x23) {
                    if (FileDataLength != 160) {
                        Logger.d(TAG, METHOD_NAME
                                + "() FileNumber Data length mismatch FileNumber = " + FileNumber
                                + ":FileDataLength =" + FileDataLength);
                        endLog(METHOD_NAME,returnStatus.name());
                        return returnStatus;
                    }
                } else {
                    Logger.d(TAG, METHOD_NAME + "() FileNumber fault data =" + FileNumber);
                    endLog(METHOD_NAME,returnStatus.name());
                    return returnStatus;
                }
            }
        }

        returnStatus = ApiReturnValues.FileDll.SUCCESS;
        endLog(METHOD_NAME,returnStatus.name());
        return returnStatus;
    }

    /**
     * 取引に必要なEMV情報を設定するAPI。.<br>
     * <br>
     *
     * @param FileNumber
     *            設定ファイル番号
     * @param FileDataLength
     *            設定ファイル長
     * @param FileData
     *            設定ファイルデータ
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_SetEMV(byte FileNumber, int FileDataLength,
                            byte[] FileData, int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_SetEMV";
        startLog(METHOD_NAME, Byte.toString(FileNumber),
                Integer.toString(FileDataLength), Arrays.toString(FileData),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));
        byte[] serviceCode = new byte[]{(byte) 0x00, (byte) 0x00};

        ApiReturnValues.SetEMV returnStatus = EMVCL_SetEMVCommon(
                FileNumber, FileDataLength, FileData, ResultCode,
                ResultCodeExtended, serviceCode);

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 取引に必要なEMV情報を設定するAPI。(一時変更用).<br>
     * <br>
     *
     * @param FileNumber
     *            設定ファイル番号
     * @param FileDataLength
     *            設定ファイル長
     * @param FileData
     *            設定ファイルデータ
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_SetEMVTemp(byte FileNumber, int FileDataLength,
                                byte[] FileData, int[] ResultCode, int[] ResultCodeExtended) {
        // ReturnValuesはEMVCL_SetEMVと共通で使用する
        final String METHOD_NAME = "EMVCL_SetEMVTemp";
        startLog(METHOD_NAME, Byte.toString(FileNumber),
                Integer.toString(FileDataLength), Arrays.toString(FileData),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));
        byte[] serviceCode = new byte[]{(byte) 0x00, (byte) 0x10};

        ApiReturnValues.SetEMV returnStatus = EMVCL_SetEMVCommon(
                FileNumber, FileDataLength, FileData, ResultCode,
                ResultCodeExtended, serviceCode);

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * EMV設定ファイル系API共通処理,<br>
     * <br>
     *
     * @param FileNumber         設定ファイル番号
     * @param FileDataLength     設定ファイル長
     * @param FileData           設定ファイルデータ
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @param serviceCode        サービスコード
     * @return 処理結果enum
     */
    private ApiReturnValues.SetEMV EMVCL_SetEMVCommon(
            byte FileNumber, int FileDataLength, byte[] FileData
            , int[] ResultCode, int[] ResultCodeExtended, byte[] serviceCode) {
        final String METHOD_NAME = "EMVCL_SetEMVCommon";
        startLog(METHOD_NAME, Byte.toString(FileNumber),
                Integer.toString(FileDataLength), Arrays.toString(FileData),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));
        ApiReturnValues.SetEMV returnStatus = inputCheckEMVCL_SetEMV(
                FileNumber, FileDataLength, FileData,
                ResultCode, ResultCodeExtended, serviceCode);

        if (returnStatus == ApiReturnValues.SetEMV.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus;
        }

        // 状態チェック
        int checkStatus = checkStatus();
        if (checkStatus != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.SetEMV.getTargetStatus(checkStatus);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus;
        }

        // BitMap送信
        // 分割有無
        int sendDataItemCount = 1;
        if (FileDataLength > CommandDataConstants.FILE_DLL_DATA_MAX) {  // PT_IMPOSSIBLE_BRANCH
            if (FileDataLength % CommandDataConstants.FILE_DLL_DATA_MAX == 0) {  // PT_IMPOSSIBLE_INSTRUCTIONS
                sendDataItemCount = FileDataLength / CommandDataConstants.FILE_DLL_DATA_MAX;  // PT_IMPOSSIBLE_INSTRUCTIONS
            } else {
                sendDataItemCount = 1 + FileDataLength / CommandDataConstants.FILE_DLL_DATA_MAX;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
        }

        // 送信済みのデータサイズ
        int sentSize = 0;
        // 今回送信するデータサイズ
        int nowSendSize;
        // BitMapデータ：項目１レングス設定値
        int colLength;
        byte[] colLengthByte;
        // BitMapデータ：項目４
        byte[] bitMapPrimaryBytes = new byte[8];
        bitMapPrimaryBytes[0] = (byte) 0x82;
        // BitMapデータ：項目５
        byte[] bitMapSecondaryBytes = new byte[8];
        bitMapSecondaryBytes[0] = (byte) 0xA0;
        // BitMapデータ：項目６
        byte[] bitMapThirdBytes = new byte[8];
        bitMapThirdBytes[0] = (byte) 0x80;
        // BitMapデータ：項目７
        byte[] bitMapFourthBytes = new byte[8];
        bitMapFourthBytes[7] = (byte) 0x18;
        // BitMapデータ：項目９ブロック通番設定値
        byte[] blockNumByte;
        // BitMapデータ：項目１２通信ファイル総サイズ(BCD)
        byte[] fileDataLengthByte = convertBCDData(String.valueOf(FileDataLength));
        // BitMapデータ：項目１３送信ブロック総数(BCD)
        byte[] blockCountByte = convertBCDData(String.valueOf(sendDataItemCount));
        // BitMapデータ：項目１４ファイルデータレングス設定値
        byte[] nowSendDataSizeByte;
        // BitMapデータ：項目１５ファイルデータ
        byte[] sendBitMapData;

        Calendar nowDate = Calendar.getInstance();
        DateFormat sendDateFormat = new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYMMDDHHMMSS);
        DateFormat fileDateFormat = new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYYYMMDD);
        // BitMapデータ：項目８送信日時
        byte[] sendBCDDateByte = convertBCDData(sendDateFormat.format(nowDate.getTime()));
        // BitMapデータ：項目１１ファイル日付
        byte[] fileBCDDateByte = convertBCDData(fileDateFormat.format(nowDate.getTime()));

        BitmapTransferRequest bitmapTransferRequest;
        BitmapTransferResponse bitmapTransferResponse;

        for (int i = 0; i < sendDataItemCount; i++) {
            if (FileDataLength - sentSize > CommandDataConstants.FILE_DLL_DATA_MAX) {
                nowSendSize = CommandDataConstants.FILE_DLL_DATA_MAX;  // PT_IMPOSSIBLE_INSTRUCTIONS
            } else {
                nowSendSize = FileDataLength - sentSize;
            }

            colLength = CommandDataConstants.FILE_HEADER_LENGTH_EMV
                    + nowSendSize - CommandDataConstants.FILE_HEADER_LENGTH_COL_LENGTH;

            colLengthByte = ByteBuffer.allocate(4).putInt(colLength).array();
            blockNumByte = ByteBuffer.allocate(4).putInt(i + 1).array();
            nowSendDataSizeByte = ByteBuffer.allocate(4).putInt(nowSendSize).array();

            sendBitMapData = mergeByteArray(
                    targetLengthTrimPaddingByteArray(colLengthByte, 2)
                    , new byte[]{(byte) 0x11, (byte) 0x96}
                    , serviceCode
                    , bitMapPrimaryBytes
                    , bitMapSecondaryBytes
                    , bitMapThirdBytes
                    , bitMapFourthBytes
                    , targetLengthTrimPaddingByteArray(sendBCDDateByte, 6)
                    , targetLengthTrimPaddingByteArray(blockNumByte, 2)
                    , new byte[]{FileNumber}
                    , targetLengthTrimPaddingByteArray(fileBCDDateByte, 4)
                    , targetLengthTrimPaddingByteArray(fileDataLengthByte, 3)
                    , targetLengthTrimPaddingByteArray(blockCountByte, 2)
                    , targetLengthTrimPaddingByteArray(nowSendDataSizeByte, 2)
                    , Arrays.copyOfRange(FileData, sentSize, sentSize + nowSendSize)
                );

            bitmapTransferRequest = new BitmapTransferRequest();
            bitmapTransferResponse = new BitmapTransferResponse();

            bitmapTransferRequest.setBitMapData(sendBitMapData);
            returnStatus = ApiReturnValues.SetEMV.E_ILLEGAL;
            if (bitmapTransferRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
                byte[] resp = mPlatformConfig.deviceSendReceive(
                        bitmapTransferRequest.toCommand(), RESPONSE_TIMER_BITMAP);
                if (resp == null) {
                    // R550が抜けたか故障(Statusを)
                    Logger.d(TAG, METHOD_NAME + "() BitmapTransfer request resp null");
                    changeStatus(EMVStatus.EMVCL_CLOSED);
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    returnStatus = ApiReturnValues.SetEMV.E_FAILURE;
                    setResultCodeExtendedData(ResultCodeExtended,
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                    break;
                } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                    Logger.d(TAG, METHOD_NAME + "() BitmapTransfer errorResponse");
                    break;
                } else if (!bitmapTransferResponse.inputDeviceResult(resp)) {
                    Logger.d(TAG, METHOD_NAME
                            + "() BitmapTransfer request error inputDeviceResult");
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    setResultCodeExtendedData(ResultCodeExtended,
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                    break;
                } else {
                    // responseデータ内の処理結果を確認する
                    byte[] resultCode;
                    byte[] resultCodeExtended;
                    if (bitmapTransferResponse.getDispose_result() == null) {
                        Logger.d(TAG, METHOD_NAME
                                + "() response bitmapData nothing");
                        ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                        setResultCodeExtendedData(ResultCodeExtended,
                                        CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                        break;
                    } else {
                        resultCode = bitmapTransferResponse.getDispose_result();
                        resultCodeExtended = bitmapTransferResponse.getDetailed_err_code();

                        int checkResult = checkBitmapResultCode(resultCode, null,
                                ResultCode, ResultCodeExtended);

                        if (checkResult == CommandDataConstants.RESULT_CODE_SUCCESS) {
                            returnStatus = ApiReturnValues.SetEMV.SUCCESS;
                        }
                    }
                }
            } else {
                Logger.d(TAG, METHOD_NAME + "() request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
                break;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }

            sentSize = sentSize + nowSendSize;
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus;
    }

    /**
     * EMVCL_SetEMVの入力チェック処理.<br>
     * <br>
     *
     * @param FileNumber         設定ファイル番号
     * @param FileDataLength     設定ファイル長
     * @param FileData           設定ファイルデータ
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @param serviceCode        サービスコード
     * @return チェック結果
     */
    private ApiReturnValues.SetEMV inputCheckEMVCL_SetEMV(
            byte FileNumber, int FileDataLength, byte[] FileData,
            int[] ResultCode, int[] ResultCodeExtended, byte[] serviceCode) {
        final String METHOD_NAME = "inputCheckEMVCL_SetEMV";
        ApiReturnValues.SetEMV returnStatus = ApiReturnValues.SetEMV.E_ILLEGAL;
        startLog(METHOD_NAME, String.valueOf(FileNumber),
                Integer.toString(FileDataLength), Arrays.toString(FileData),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));

        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        }

        if (FileData == null || FileData.length == 0) {
            Logger.d(TAG, METHOD_NAME + "() FileData not set");
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        } else if (FileData.length != FileDataLength) {
            Logger.d(TAG, METHOD_NAME
                    + "() FileData.length mismatch =" + FileData.length
                    + ",FileDataLength=" + FileDataLength);
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        }

        if (serviceCode == null || serviceCode.length != 2) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() serviceCode.length mismatch ="
                    + Arrays.toString(serviceCode));
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        } else {
            if (serviceCode[0] == (byte) 0x00 && serviceCode[1] == (byte) 0x10) {
                if (FileNumber < CheckEMVCL_SetEMV.KERNEL_C1.fileNumber
                        || FileNumber > CheckEMVCL_SetEMV.KERNEL_C7.fileNumber) {
                    Logger.d(TAG, METHOD_NAME
                            + "() mismatch EMVTemp FileNumber =" + FileNumber);
                    endLog(METHOD_NAME,returnStatus.name());
                    return returnStatus;
                }
            }
        }

        CheckEMVCL_SetEMV[] checkDataArray = CheckEMVCL_SetEMV.values();
        boolean isCheck = false;
        for (CheckEMVCL_SetEMV checkType : checkDataArray) {
            if (checkType.fileNumber == FileNumber) {
                if (checkType.isCheck) {
                    if (FileDataLength < checkType.minLength
                            || FileDataLength > checkType.maxLength) {  // PT_IMPOSSIBLE_BRANCH
                        Logger.d(TAG, METHOD_NAME + "() over FileDataLength =" + FileDataLength);
                        endLog(METHOD_NAME,returnStatus.name());
                        return returnStatus;
                    }
                } else {
                    Logger.d(TAG, METHOD_NAME + "() disallowed FileNumber =" + (int) FileNumber);
                    endLog(METHOD_NAME,returnStatus.name());
                    return returnStatus;
                }
                isCheck = true;
                break;
            }
        }

        if (!isCheck) {
            Logger.d(TAG, METHOD_NAME + "() mismatch  FileNumber =" + (int) FileNumber);
            endLog(METHOD_NAME,returnStatus.name());
            return returnStatus;
        }

        returnStatus = ApiReturnValues.SetEMV.SUCCESS;

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus;
    }

    /**
     * EMV設定ファイルチェック項目Enum.
     */
    private enum CheckEMVCL_SetEMV {

        KERNEL_COMMON((byte) 0x00, true, 80, 80),
        KERNEL_C1((byte) 0x01, true, 1, 8066),
        KERNEL_C2((byte) 0x02, true, 1, 7960),
        KERNEL_C3((byte) 0x03, true, 1, 8040),
        KERNEL_C4((byte) 0x04, true, 1, 8065),
        KERNEL_C5((byte) 0x05, true, 1, 8065),
        KERNEL_C6((byte) 0x06, true, 1, 8065),
        KERNEL_C7((byte) 0x07, true, 1, 8065),
        KERNEL_C8((byte) 0x08, false, 0, 0),
        KERNEL_C9((byte) 0x09, false, 0, 0),
        KERNEL_C10((byte) 0x0A, false, 0, 0),
        KERNEL_C11((byte) 0x0B, false, 0, 0),
        KERNEL_C12((byte) 0x0C, false, 0, 0),
        KERNEL_C13((byte) 0x0D, false, 0, 0),
        KERNEL_C14((byte) 0x0E, false, 0, 0),
        KERNEL_C15((byte) 0x0F, false, 0, 0),
        KERNEL_C16((byte) 0x10, false, 0, 0),
        KERNEL_C17((byte) 0x11, false, 0, 0),
        KERNEL_C18((byte) 0x12, false, 0, 0),
        KERNEL_C19((byte) 0x13, false, 0, 0),
        KERNEL_C20((byte) 0x14, false, 0, 0),
        KERNEL_C21((byte) 0x15, false, 0, 0),
        MAINTENANCE_01((byte) 0xFE, true, 1, 256),
        MAINTENANCE_02((byte) 0xFF, true, 1, 159);

        private byte fileNumber;
        private boolean isCheck;
        private int minLength;
        private int maxLength;

        CheckEMVCL_SetEMV(byte fileNumber, boolean isCheck, int minLength, int maxLength) {
            this.fileNumber = fileNumber;
            this.isCheck = isCheck;
            this.minLength = minLength;
            this.maxLength = maxLength;
        }
    }

    /**
     * 決済デバイスの音量、EMVCL_Clearのレスポンスが返却されるまでの時間と、メッセージ表示有無を設定するAPI。.<br>
     * <br>
     *
     * @param VolumeOfSound         設定決済デバイス音量
     * @param RemovalProcedureTimer EMVCL_Clearレスポンス返却時間（単位：10ms）
     * @param MessageStatus         特定メッセージ表示有無設定
     * @param ResultCode            決済デバイスの結果コード
     * @param ResultCodeExtended    決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_DeviceSetting(byte VolumeOfSound,
                                   int RemovalProcedureTimer, byte MessageStatus,
                                   int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_DeviceSetting";
        startLog(METHOD_NAME, String.valueOf(VolumeOfSound),
                String.valueOf(RemovalProcedureTimer), String.valueOf(MessageStatus),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));

        ApiReturnValues.DeviceSetting returnStatus = inputCheckEMVCL_DeviceSetting(
                VolumeOfSound, RemovalProcedureTimer, MessageStatus,
                ResultCode, ResultCodeExtended
        );

        if (returnStatus == ApiReturnValues.DeviceSetting.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.DeviceSetting.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // RW設定変更

        RWSettingChangeRequest rwSettingChangeRequest = new RWSettingChangeRequest();
        RWSettingChangeResponse rwSettingChangeResponse = new RWSettingChangeResponse();

        rwSettingChangeRequest.setVolume(VolumeOfSound);
        // タイマ設定値
        rwSettingChangeRequest.setTimerSetting1(
                new byte[]{(byte) 0x01, (byte)0xC8, (byte)0});
        rwSettingChangeRequest.setTimerSetting2(
                new byte[]{(byte) 0x02, (byte)0x64, (byte)0});
        rwSettingChangeRequest.setTimerSetting3(
                new byte[]{(byte) 0x03, (byte)0x90, (byte)0x01});
        rwSettingChangeRequest.setTimerSetting4(
                new byte[]{(byte) 0x04, (byte)0x58, (byte)0x02});
        rwSettingChangeRequest.setTimerSetting5(
                new byte[]{(byte) 0x05, (byte)0x64, (byte)0x00});
        rwSettingChangeRequest.setLcdMessageData((byte) (
                (MessageStatus & 0x1d) | 0x02));
        // 表示言語（日本語：0x00,英語：0x01：初期値0）
        rwSettingChangeRequest.setMessageLanguage((byte) 0x00);
        rwSettingChangeRequest.setOperationMode((byte) 0x00);
        returnStatus = ApiReturnValues.DeviceSetting.E_ILLEGAL;
        if (rwSettingChangeRequest.isValidValue()) { // PT_IMPOSSIBLE_BRANCH
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    rwSettingChangeRequest.toCommand(), RESPONSE_TIMER_RWCHANGE);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() RWSettingChange request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.DeviceSetting.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() RWSettingChange errorResponse");
            } else if (!rwSettingChangeResponse.inputDeviceResult(resp)) {
                Logger.d(TAG, METHOD_NAME
                        + "() RWSettingChange request error inputDeviceResult");
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else {
                ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                returnStatus = ApiReturnValues.DeviceSetting.SUCCESS;
            }
        } else {
            Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                    + "() RWSettingChange request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * EMVCL_DeviceSettingの入力チェック処理.<br>
     * <br>
     *
     * @param VolumeOfSound         設定決済デバイス音量
     * @param RemovalProcedureTimer EMVCL_Clearレスポンス返却時間（単位：10ms）
     * @param MessageStatus         特定メッセージ表示有無設定
     * @param ResultCode            決済デバイスの結果コード
     * @param ResultCodeExtended    決済デバイスの結果コード詳細
     * @return チェック結果
     */
    private ApiReturnValues.DeviceSetting inputCheckEMVCL_DeviceSetting(
            byte VolumeOfSound, int RemovalProcedureTimer,
            byte MessageStatus, int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "inputCheckEMVCL_DeviceSetting";
        ApiReturnValues.DeviceSetting checkStatus = ApiReturnValues.DeviceSetting.E_ILLEGAL;
        startLog(METHOD_NAME, String.valueOf(VolumeOfSound),
                String.valueOf(RemovalProcedureTimer), String.valueOf(MessageStatus),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));

        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        }

        if (VolumeOfSound != (byte) 0x00
                && VolumeOfSound != (byte) 0x01
                && VolumeOfSound != (byte) 0x02) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME
                    + "() RW Change IF error =" + VolumeOfSound);
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        }

        if (ResultCode == null || ResultCode.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() ResultCode not set");
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        }

        if (ResultCodeExtended == null || ResultCodeExtended.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() ResultCodeExtended not set");
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        }

        if (RemovalProcedureTimer > 65535) {
            Logger.d(TAG, METHOD_NAME
                    + "() RemovalProcedureTimer range over ="
                    + RemovalProcedureTimer);
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        }

        checkStatus = ApiReturnValues.DeviceSetting.SUCCESS;

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;
    }

    /**
     * 設定されたパラメータ情報を削除するAPI。.<br>
     * <br>
     *
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_ClearSetting(int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_ClearSetting";
        startLog(METHOD_NAME, Arrays.toString(ResultCode),
                Arrays.toString(ResultCodeExtended));
        ApiReturnValues.ClearSetting returnStatus = ApiReturnValues.ClearSetting.SUCCESS;

        if (inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            returnStatus = ApiReturnValues.ClearSetting.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.ClearSetting.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // RW設定変更

        RWSettingClearRequest rwSettingClearRequest = new RWSettingClearRequest();
        RWSettingClearResponse rwSettingClearResponse = new RWSettingClearResponse();
        returnStatus = ApiReturnValues.ClearSetting.E_ILLEGAL;
        if (rwSettingClearRequest.isValidValue()) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    rwSettingClearRequest.toCommand(), RESPONSE_TIMER_RWCHANGE);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() RWSettingClear request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.ClearSetting.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() RWSettingClear errorResponse");
            } else if (!rwSettingClearResponse.inputDeviceResult(resp)) {
                Logger.d(TAG, METHOD_NAME
                        + "() RWSettingClear request error inputDeviceResult");
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else {
                ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                returnStatus = ApiReturnValues.ClearSetting.SUCCESS;
            }
        } else {
            Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                    + "() RWSettingClear request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 決済デバイスに設定されている情報を取得するAPI。.<br>
     * <br>
     *
     * @param GetAppVersion
     *            非接触EMVアプリバージョン取得有無<br>
     *            00H：取得なし<br>
     *            01H：取得あり<br>
     *            上記以外：取得なしとする<br>
     * @param SettingInfo
     *            決済デバイス設定情報
     * @param VersionInfo
     *            非接触EMVアプリバージョンとチェックサム情報
     * @param InstalledFileDate
     *            設定ファイル日付情報
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_GetInfo(byte GetAppVersion, SETTINGINFO SettingInfo,
                             VERSIONINFO VersionInfo, INSTALLEDFILEDATE InstalledFileDate,
                             int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_GetInfo";
        startLog(METHOD_NAME,
                String.valueOf(GetAppVersion), String.valueOf(SettingInfo),
                String.valueOf(VersionInfo), String.valueOf(InstalledFileDate),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));

        ApiReturnValues.GetInfo returnStatus = inputCheckEMVCL_GetInfo(
                SettingInfo, VersionInfo, InstalledFileDate,
                ResultCode, ResultCodeExtended);

        if (returnStatus == ApiReturnValues.GetInfo.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            returnStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.GetInfo.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        boolean isNoKernelData = false;
        if (GetAppVersion == (byte) 0x00) {
            // バージョン取得無し
            isNoKernelData = true;
        }
        DeviceInformationRequest deviceInformationRequest =
                DeviceInformationRequest.getDeviceInformationRequest(isNoKernelData);
        DeviceInformationResponse deviceInformationResponse =
                new DeviceInformationResponse();
        deviceInformationResponse.setNoKernelData(isNoKernelData);
        deviceInformationRequest.setCommDateTime(Calendar.getInstance());
        returnStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
        if (deviceInformationRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    deviceInformationRequest.toCommand(), RESPONSE_TIMER_RWCHANGE);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() RWInformation request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.GetInfo.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() RWInformation errorResponse");
            } else if (!deviceInformationResponse.inputDeviceResult(resp)) {
                Logger.d(TAG, METHOD_NAME
                        + "() RWInformation request error inputDeviceResult");
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else {
                returnStatus = setResponseData(deviceInformationResponse,
                        SettingInfo, VersionInfo, InstalledFileDate);
                if (returnStatus == ApiReturnValues.GetInfo.SUCCESS) {
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                    setResultCodeExtendedData(ResultCodeExtended,
                            CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                            CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                } else {
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    setResultCodeExtendedData(ResultCodeExtended,
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                }
            }
        } else {
            Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                    + "() RWInformation request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * バージョン情報を取得するAPI。.<br>
     * <br>
     *
     * @param SettingInfo
     *            決済デバイス設定情報
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     */
    public int EMVCL_GetRWVerInfo(byte GetAppVersion, SETTINGINFO SettingInfo,
                                  INSTALLEDFILEDATE InstalledFileDate, 
                                  int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_GetRWVerInfo";
        startLog(METHOD_NAME,
                String.valueOf(GetAppVersion), String.valueOf(SettingInfo),
                String.valueOf(InstalledFileDate), Arrays.toString(ResultCode),
                Arrays.toString(ResultCodeExtended));

        ApiReturnValues.GetInfo returnStatus = inputCheckEMVCL_GetRWVerInfo(
                SettingInfo, InstalledFileDate, ResultCode, ResultCodeExtended);
        if (returnStatus == ApiReturnValues.GetInfo.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            returnStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus_RWVer();
        if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.GetInfo.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        RWInformationRequest rwInfoReq = new RWInformationRequest();
        RWInformationResponse rwInfoResp = new RWInformationResponse();
        rwInfoReq.setCommDateTime(getCalendar());
        PFDetailInformationRequest  pfInfoReq  = new PFDetailInformationRequest();
        PFDetailInformationResponse pfInfoResp = new PFDetailInformationResponse();
        returnStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
        if (rwInfoReq.isValidValue() && pfInfoReq.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
            byte[] rwResp = mPlatformConfig.deviceSendReceive(rwInfoReq.toCommand(), 5000);
            byte[] pfResp = mPlatformConfig.deviceSendReceive(pfInfoReq.toCommand(), 5000);

            if (rwResp == null) {
                Logger.d(TAG, METHOD_NAME + "() RWInformation request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.GetInfo.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (pfResp == null) {
                Logger.d(TAG, METHOD_NAME + "() PFDetailInformation request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.GetInfo.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(rwResp, ResultCode, ResultCodeExtended)) {
                    Logger.d(TAG, METHOD_NAME + "() RWInformation errorResponse");
            } else if (checkErrorResponse(pfResp, ResultCode, ResultCodeExtended)) {
                    Logger.d(TAG, METHOD_NAME + "() PFDetailInformation errorResponse");
            } else if (!rwInfoResp.inputDeviceResult(rwResp)) {
                    Logger.d(TAG, METHOD_NAME
                            + "() RWInformation request error inputDeviceResult");
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    setResultCodeExtendedData(ResultCodeExtended,
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (!pfInfoResp.inputDeviceResult(pfResp)) {  // PT_IMPOSSIBLE_BRANCH
                    Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                            + "() PFDetailInformation request error inputDeviceResult");  // PT_IMPOSSIBLE_INSTRUCTIONS
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;  // PT_IMPOSSIBLE_INSTRUCTIONS
                    setResultCodeExtendedData(ResultCodeExtended,  // PT_IMPOSSIBLE_INSTRUCTIONS
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,  // PT_IMPOSSIBLE_INSTRUCTIONS
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);  // PT_IMPOSSIBLE_INSTRUCTIONS
            } else {
                returnStatus = setVerResponseData(rwInfoResp, pfInfoResp, SettingInfo);
                if (returnStatus == ApiReturnValues.GetInfo.SUCCESS) {  // PT_IMPOSSIBLE_BRANCH
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                    setResultCodeExtendedData(ResultCodeExtended,
                            CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                            CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                } else {
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;  // PT_IMPOSSIBLE_INSTRUCTIONS
                    setResultCodeExtendedData(ResultCodeExtended,  // PT_IMPOSSIBLE_INSTRUCTIONS
                                    CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,  // PT_IMPOSSIBLE_INSTRUCTIONS
                                    CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);  // PT_IMPOSSIBLE_INSTRUCTIONS
                }
            }
        } else {
            Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                    + "() RWInformation request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * バージョン情報要求Responseデータから各Responseデータを設定する.<br>
     * <br>
     *
     * @param rwInfoResp   RW情報要求Responseクラス
     * @param pfInfoResp   プラットフォーム情報要求Responseクラス
     * @param SettingInfo   決済デバイス設定情報
     * @return レスポンスデータ設定結果
     */
    private ApiReturnValues.GetInfo setVerResponseData(
            RWInformationResponse rwInfoResp, PFDetailInformationResponse pfInfoResp,
            SETTINGINFO SettingInfo){
        final String METHOD_NAME = "setVerResponseData";
        startLog(METHOD_NAME);
        ApiReturnValues.GetInfo setStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
        try {
            SettingInfo.Model = rwInfoResp.getProductNo();
            SettingInfo.SNo = rwInfoResp.getSerialNo();
            SettingInfo.AplVer = pfInfoResp.cloneVersion();
            SettingInfo.AplId = pfInfoResp.cloneApId();

            setStatus = ApiReturnValues.GetInfo.SUCCESS;
        } catch (Exception e) {
            Logger.e(TAG, METHOD_NAME
                    + "() response data set error =" + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            pw.flush();
            Logger.d(TAG, METHOD_NAME + "() response data set error" + pw.toString());
        }
        endLog(METHOD_NAME, setStatus.name());
        return setStatus;
    }

    // get current time
    private Calendar getCalendar() {

        Date date = new Date(System.currentTimeMillis());
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        return cal;
    }

    /**
     * 指定機器情報要求Responseデータから各Responseデータを設定する.<br>
     * <br>
     *
     * @param deviceInformationResponse 機器情報要求Responseクラス
     * @param SettingInfo              決済デバイス設定情報
     * @param VersionInfo              非接触EMVアプリバージョンとチェックサム情報
     * @param InstalledFileDate        設定ファイル日付情報
     * @return レスポンスデータ設定結果
     */
    private ApiReturnValues.GetInfo setResponseData(
            DeviceInformationResponse deviceInformationResponse, SETTINGINFO SettingInfo,
            VERSIONINFO VersionInfo, INSTALLEDFILEDATE InstalledFileDate) {
        final String METHOD_NAME = "setResponseData";
        startLog(METHOD_NAME);
        ApiReturnValues.GetInfo setStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
        try {
            SettingInfo.VolumeOfSound = deviceInformationResponse.getVolume();
            SettingInfo.Timer1 = deviceInformationResponse.getTimerSetting1();
            SettingInfo.Timer2 = deviceInformationResponse.getTimerSetting2();
            SettingInfo.Timer3 = deviceInformationResponse.getTimerSetting3();
            SettingInfo.Timer4 = deviceInformationResponse.getTimerSetting4();
            SettingInfo.Timer5 = deviceInformationResponse.getTimerSetting5();
            SettingInfo.LCDSettings =deviceInformationResponse.getLcdMessageData();
            SettingInfo.Language = deviceInformationResponse.getMessageLanguage();
            SettingInfo.StatusNumber = deviceInformationResponse.getStatusNo(); 
            SettingInfo.StatusFlag = deviceInformationResponse.getStatusFlg();

            VersionInfo.ReaderVersion = deviceInformationResponse.getReadApVer();
            VersionInfo.EntryPointVersion = deviceInformationResponse.getEntryPointAPVer();
            VersionInfo.KernelC1Version = deviceInformationResponse.getKernelC1ApVer();
            VersionInfo.KernelC2Version = deviceInformationResponse.getKernelC2ApVer();
            VersionInfo.KernelC3Version = deviceInformationResponse.getKernelC3ApVer();
            VersionInfo.KernelC4Version = deviceInformationResponse.getKernelC4ApVer();
            VersionInfo.KernelC5Version = deviceInformationResponse.getKernelC5ApVer();
            VersionInfo.KernelC6Version = deviceInformationResponse.getKernelC6ApVer();
            VersionInfo.KernelC7Version = deviceInformationResponse.getKernelC7ApVer();
            VersionInfo.KernelC8Version = deviceInformationResponse.getKernelC8ApVer();
            VersionInfo.KernelC9Version = deviceInformationResponse.getKernelC9ApVer();
            VersionInfo.KernelC10Version = deviceInformationResponse.getKernelC10ApVer();
            VersionInfo.KernelC11Version = deviceInformationResponse.getKernelC11ApVer();
            VersionInfo.KernelC12Version = deviceInformationResponse.getKernelC12ApVer();
            VersionInfo.KernelC13Version = deviceInformationResponse.getKernelC13ApVer();
            VersionInfo.KernelC14Version = deviceInformationResponse.getKernelC14ApVer();
            VersionInfo.KernelC15Version = deviceInformationResponse.getKernelC15ApVer();
            VersionInfo.EntryPointChecksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumEntryPoint(), 4);
            VersionInfo.KernelC1Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC1(), 4);
            VersionInfo.KernelC2Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC2(), 4);
            VersionInfo.KernelC3Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC3(), 4);
            VersionInfo.KernelC4Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC4(), 4);
            VersionInfo.KernelC5Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC5(), 4);
            VersionInfo.KernelC6Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC6(), 4);
            VersionInfo.KernelC7Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC7(), 4);
            VersionInfo.KernelC8Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC8(), 4);
            VersionInfo.KernelC9Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC9(), 4);
            VersionInfo.KernelC10Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC10(), 4);
            VersionInfo.KernelC11Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC11(), 4);
            VersionInfo.KernelC12Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC12(), 4);
            VersionInfo.KernelC13Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC13(), 4);
            VersionInfo.KernelC14Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC14(), 4);
            VersionInfo.KernelC15Checksum = convertBigBytes2Long(
                    deviceInformationResponse.getCheckSumKernelC15(), 4);

            InstalledFileDate.CommonFile = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelCommon());
            InstalledFileDate.KernelC1File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC1());
            InstalledFileDate.KernelC2File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC2());
            InstalledFileDate.KernelC3File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC3());
            InstalledFileDate.KernelC4File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC4());
            InstalledFileDate.KernelC5File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC5());
            InstalledFileDate.KernelC6File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC6());
            InstalledFileDate.KernelC7File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC7());
            InstalledFileDate.KernelC8File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC8());
            InstalledFileDate.KernelC9File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC9());
            InstalledFileDate.KernelC10File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC10());
            InstalledFileDate.KernelC11File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC11());
            InstalledFileDate.KernelC12File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC12());
            InstalledFileDate.KernelC13File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC13());
            InstalledFileDate.KernelC14File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC14());
            InstalledFileDate.KernelC15File = getFileDate(
                    deviceInformationResponse.getEmvSettingDateKernelC15());

            // FileDLLは1byte目にファイル番号を設定する(後ろに日付BCDデータ)
            // ICカードテーブル:ファイル番号0x21
            if (deviceInformationResponse.getFileDLLDate1() != null) {
                InstalledFileDate.FileDLL1 = mergeByteArray(new byte[]{(byte) 0x21},
                        getFileDate(deviceInformationResponse.getFileDLLDate1()));
            } else {
                InstalledFileDate.FileDLL1 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            // CA公開鍵ファイル:ファイル番号0x22
            if (deviceInformationResponse.getFileDLLDate2() != null) {
                InstalledFileDate.FileDLL2 = mergeByteArray(new byte[]{(byte) 0x22},
                        getFileDate(deviceInformationResponse.getFileDLLDate2()));
            } else {
                InstalledFileDate.FileDLL2 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            // Merchantテーブル:ファイル番号0x23
            if (deviceInformationResponse.getFileDLLDate3() != null) {
                InstalledFileDate.FileDLL3 = mergeByteArray(new byte[]{(byte) 0x23},
                        getFileDate(deviceInformationResponse.getFileDLLDate3()));
            } else {
                InstalledFileDate.FileDLL3 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            // 以下予備（ファイル番号は予備で設定無しの為0x00指定）
            if (deviceInformationResponse.getFileDLLDate4() != null) {
                InstalledFileDate.FileDLL4 = mergeByteArray(new byte[]{(byte) 0x34},
                        getFileDate(deviceInformationResponse.getFileDLLDate4()));
            } else {
                InstalledFileDate.FileDLL4 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate5() != null) {
                InstalledFileDate.FileDLL5 = mergeByteArray(new byte[]{(byte) 0x35},
                        getFileDate(deviceInformationResponse.getFileDLLDate5()));
            } else {
                InstalledFileDate.FileDLL5 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate6() != null) {
                InstalledFileDate.FileDLL6 = mergeByteArray(new byte[]{(byte) 0x36},
                        getFileDate(deviceInformationResponse.getFileDLLDate6()));
            } else {
                InstalledFileDate.FileDLL6 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate7() != null) {
                InstalledFileDate.FileDLL7 = mergeByteArray(new byte[]{(byte) 0x37},
                        getFileDate(deviceInformationResponse.getFileDLLDate7()));
            } else {
                InstalledFileDate.FileDLL7 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate8() != null) {
                InstalledFileDate.FileDLL8 = mergeByteArray(new byte[]{(byte) 0x38},
                        getFileDate(deviceInformationResponse.getFileDLLDate8()));
            } else {
                InstalledFileDate.FileDLL8 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate9() != null) {
                InstalledFileDate.FileDLL9 = mergeByteArray(new byte[]{(byte) 0x39},
                        getFileDate(deviceInformationResponse.getFileDLLDate9()));
            } else {
                InstalledFileDate.FileDLL9 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate10() != null) {
                InstalledFileDate.FileDLL10 = mergeByteArray(new byte[]{(byte) 0x40},
                        getFileDate(deviceInformationResponse.getFileDLLDate10()));
            } else {
                InstalledFileDate.FileDLL10 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate11() != null) {
                InstalledFileDate.FileDLL11 = mergeByteArray(new byte[]{(byte) 0x41},
                        getFileDate(deviceInformationResponse.getFileDLLDate11()));
            } else {
                InstalledFileDate.FileDLL11 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate12() != null) {
                InstalledFileDate.FileDLL12 = mergeByteArray(new byte[]{(byte) 0x42},
                        getFileDate(deviceInformationResponse.getFileDLLDate12()));
            } else {
                InstalledFileDate.FileDLL12 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate13() != null) {
                InstalledFileDate.FileDLL13 = mergeByteArray(new byte[]{(byte) 0x43},
                        getFileDate(deviceInformationResponse.getFileDLLDate13()));
            } else {
                InstalledFileDate.FileDLL13 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate14() != null) {
                InstalledFileDate.FileDLL14 = mergeByteArray(new byte[]{(byte) 0x44},
                        getFileDate(deviceInformationResponse.getFileDLLDate14()));
            } else {
                InstalledFileDate.FileDLL14 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            if (deviceInformationResponse.getFileDLLDate15() != null) {
                InstalledFileDate.FileDLL15 = mergeByteArray(new byte[]{(byte) 0x45},
                        getFileDate(deviceInformationResponse.getFileDLLDate15()));
            } else {
                InstalledFileDate.FileDLL15 = mergeByteArray(new byte[]{(byte) 0x00},
                        INSTALLEDFILEDATE.NOT_SET_FILEDLL_TAIL);
            }
            setStatus = ApiReturnValues.GetInfo.SUCCESS;
        } catch (Exception e) {
            Logger.e(TAG, METHOD_NAME
                    + "() response data set error =" + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            pw.flush();
            Logger.d(TAG, METHOD_NAME + "() response data set error" + pw.toString());
        }

        endLog(METHOD_NAME, setStatus.name());
        return setStatus;
    }

    /**
     * 指定CalendarをYYYYMMDDのBCD形式byte配列（長さ4）で返す.<br>
     *     <br>
     * @param getCalendar 変換元Calendar
     * @return YYYYMMDDのBCD形式byte配列、Calendarがnullの場合は0x00で設定
     */
    private static byte[] getFileDate(Calendar getCalendar) {
        DateFormat fileDateFormat = new SimpleDateFormat(
                CommandDataConstants.DATE_FORMAT_YYYYMMDD);
        if (getCalendar == null) {
            return new byte[4];
        }
        return convertBCDData(fileDateFormat.format(getCalendar.getTime()));
    }

    /**
     * EMVCL_GetInfoの入力チェック<br>
     * <br>
     *
     * @param SettingInfo        決済デバイス設定情報
     * @param VersionInfo        非接触EMVアプリバージョンとチェックサム情報
     * @param InstalledFileDate  設定ファイル日付情報
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return チェック結果
     */
    private ApiReturnValues.GetInfo inputCheckEMVCL_GetInfo(
            SETTINGINFO SettingInfo, VERSIONINFO VersionInfo,
            INSTALLEDFILEDATE InstalledFileDate,
            int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "inputCheckEMVCL_GetInfo";
        ApiReturnValues.GetInfo checkStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
        boolean isError = false;
        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            isError = true;
        }

        if (SettingInfo == null) {
            Logger.d(TAG, METHOD_NAME + "() SettingInfo not set");
            isError = true;
        }

        if (VersionInfo == null) {
            Logger.d(TAG, METHOD_NAME + "() VersionInfo not set");
            isError = true;
        }

        if (InstalledFileDate == null) {
            Logger.d(TAG, METHOD_NAME + "() InstalledFileDate not set");
            isError = true;
        }

        if (ResultCode == null || ResultCode.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() ResultCode not set");
            isError = true;
        }

        if (ResultCodeExtended == null || ResultCodeExtended.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() ResultCodeExtended not set");
            isError = true;
        }

        if (!isError) {
            checkStatus = ApiReturnValues.GetInfo.SUCCESS;
        }

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;

    }

    /**
     * EMVCL_GetRWVerInfoの入力チェック<br>
     * <br>
     *
     * @param SettingInfo        決済デバイス設定情報
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return チェック結果
     */
    private ApiReturnValues.GetInfo inputCheckEMVCL_GetRWVerInfo(
            SETTINGINFO SettingInfo, INSTALLEDFILEDATE InstalledFileDate,
            int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "inputCheckEMVCL_GetRWVerInfo";
        ApiReturnValues.GetInfo checkStatus = ApiReturnValues.GetInfo.E_ILLEGAL;
        boolean isError = false;
        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            Logger.d(TAG, METHOD_NAME + "() ResultCode or ResultCodeExtended is null");
            isError = true;
        }

        if (SettingInfo == null) {
            Logger.d(TAG, METHOD_NAME + "() SettingInfo not set");
            isError = true;
        }

        if (InstalledFileDate == null) {
            Logger.d(TAG, METHOD_NAME + "() InstalledFileDate not set");
            isError = true;
        }

        if (ResultCode == null || ResultCode.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() ResultCode not set");
            isError = true;
        }

        if (ResultCodeExtended == null || ResultCodeExtended.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "() ResultCodeExtended not set");
            isError = true;
        }

        if (!isError) {
            checkStatus = ApiReturnValues.GetInfo.SUCCESS;
        }

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;

    }

    /**
     * 取引のオペレーションを実施するAPI。.<br>
     * <br>
     *
     * @param TransactionData
     *            取引情報
     * @param RetryTimeout
     *            カードかざし待ち状態継続時間(単位：秒)
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_Transaction(TRANSACTIONDATA TransactionData,
                                 int RetryTimeout) {
        final String METHOD_NAME = "EMVCL_Transaction";
        startLog(METHOD_NAME, String.valueOf(TransactionData),
                String.valueOf(RetryTimeout));

        ApiReturnValues.Transaction returnStatus = inputCheckEMVCL_Transaction(TransactionData);

        if (mIsDataExchange) {
            Logger.d(TAG, METHOD_NAME + "() Data Exchange sequence.");
            returnStatus = ApiReturnValues.Transaction.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        if (RetryTimeout > 65535) {
            Logger.d(TAG, METHOD_NAME
                    + "() RetryTimeout over data =" + RetryTimeout);
            returnStatus = ApiReturnValues.Transaction.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        if (returnStatus == ApiReturnValues.Transaction.SUCCESS) {
            // 状態チェック
            int checkResult = checkStatus();
            if (checkResult != ApiReturnValues.SUCCESS) {
                returnStatus = ApiReturnValues.Transaction.getTargetStatus(checkResult);
                endLog(METHOD_NAME, returnStatus.name());
                return returnStatus.getStatus();
            }
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        //ウインドウハンドルが登録されていない場合
        if (m_CompleteEvent == null) {
            returnStatus = ApiReturnValues.Transaction.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        changeStatus(EMVStatus.EMVCL_BUSY);
        // 非同期処理開始
        doTransactionTask = new TransactionTask();
        doTransactionTask.retryTimeout = RetryTimeout;
        doTransactionTask.execute(TransactionData);

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 非同期Threadクラス
     */
    class TransactionTask extends AsyncTransaction<TRANSACTIONDATA, Void, Integer> {
        /**
         * キャンセル指示Flg：カードかざし待ち状態の中断要求フラグ.
         */
        boolean isCancel = false;

        /**
         * 取引中止可否フラグ
         */
        boolean isTranCancelEnable = false;

        /**
         * トレーニングモードであるか.
         */
        boolean isTraining = false;

        /**
         * トランザクションが完了したかどうか.
         */
        boolean isFin = false;

        /**
         * 致命的なエラーが発生したかどうか
         */
        boolean isFatalError = false;

        /**
         * RESULTINFOデータ.
         */
        RESULTINFO resultInfo;

        /**
         * DEINFOデータ.
         */
        DEINFO deInfo;

        /**
         * 取引処理結果.
         */
        int[] setResultCode = {111};
        /**
         * 取引処理結果コード詳細.
         */
        int[] setResultCodeExtended = {0xFFFF0000};

        /**
         * カードかざし待ち状態を継続する時間（秒）.
         */
        int retryTimeout = 0;

        /**
         * 実行TASKのキャンセル指示を行う.<br>
         *
         * @return キャンセル指示に成功した場合true
         */
        public boolean doCancel() {
            boolean resultFlg = false;
            if (isTranCancelEnable && !isCancel) {
                isCancel = true;
                resultFlg = true;
            }
            return resultFlg;
        }

        @Override
        protected Integer doInBackground(TRANSACTIONDATA... params) {
            // バックグラウンド処理
            final String METHOD_NAME = "doInBackground";
            startLog(METHOD_NAME);

            Integer resultValue = ApiReturnValues.E_ILLEGAL;
            // 取引中止可否フラグを可能にする
            isTranCancelEnable = true;
            if (params == null || params.length == 0) {  // PT_IMPOSSIBLE_BRANCH
                Logger.d(TAG, METHOD_NAME + "() TRANSACTIONDATA Data not set");
                return resultValue;
            }

            BitmapTransferRequest bitmapTransferRequest;
            BitmapTransferResponse bitmapTransferResponse;
            DataExchangeResponse dataExchangeResponse = new DataExchangeResponse();
            // BitMap送信
            if (!isTraining) {
                // 非トレーニングモード
                bitmapTransferRequest = new BitmapTransferRequest();
                bitmapTransferResponse = new BitmapTransferResponse();
            } else {
                // トレーニングモード
                bitmapTransferRequest = new TRBitmapTransferRequest();
                bitmapTransferResponse = new TRBitmapTransferResponse();
            }

            bitmapTransferRequest.setBitMapData(createBitMap(params[0]));
            if ((params[0].MerchantSpecificData & 0x80) != 0) {
                bitmapTransferResponse.isNeedExpand(true);
                mIsNeedExpand = true;
            } else {
                mIsNeedExpand = false;
            }
            // 送信ループ処理（メインループ処理）
            Calendar endTime = Calendar.getInstance();
            endTime.setTimeInMillis(endTime.getTimeInMillis() + retryTimeout * 1000);

            while (true) {

                if (bitmapTransferRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
                    resultInfo = null;
                    deInfo = null;
                    byte[] resp = mPlatformConfig.deviceSendReceive(
                            bitmapTransferRequest.toCommand(), RESPONSE_TIMER_BITMAP);
                    if (resp == null) {
                        // R550が抜けたか故障(Statusを)
                        Logger.d(TAG, METHOD_NAME + "() BitmapTransfer request resp null");
                        resultValue = ApiReturnValues.E_ILLEGAL;
                        isFatalError = true;
                        break;
                    } else if (checkErrorResponse(resp, setResultCode, setResultCodeExtended)) {
                        Logger.d(TAG, METHOD_NAME + "() BitmapTransfer errorResponse");
                        resultValue = ApiReturnValues.E_ILLEGAL;
                        if (resp[9] == (byte)0xFF) {
                            isFatalError = true;
                        }
                        break;
                    } else if (bitmapTransferResponse.inputDeviceResult(resp)) {
                        // レスポンスデータパース
                        resultValue = checkSetBitMapData(bitmapTransferResponse);
                        if (resultValue != CommandDataConstants.RESULT_CODE_NETWORK_ERROR) {
                            break;
                        }
                    } else if (dataExchangeResponse.inputDeviceResult(resp)) {
                        // Data Exchangeリクエストが返った場合、Data Exchangeのシーケンスに入る
                        // このシーケンスが終わる(フラグがおりる)のは、DataExchangeTaskで
                        // エラーレスポンスまたはビットマップ転送(売上)レスポンスが返る
                        // タイミングとなる
                        mIsDataExchange = true;
                        checkSetExchangeData(dataExchangeResponse);
                        break;
                    } else {
                        Logger.d(TAG, METHOD_NAME
                                + "() BitmapTransfer request error inputDeviceResult");
                        resultValue = ApiReturnValues.E_ILLEGAL;
                        break;
                    }

                    // Timeout判定
                    if (endTime.getTimeInMillis() < Calendar.getInstance().getTimeInMillis() + 1000) {
                        Logger.d(TAG, METHOD_NAME + "() is time out");
                        break;
                    }
                } else {
                    Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                            + "() BitmapTransfer request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
                    resultValue = ApiReturnValues.E_ILLEGAL;  // PT_IMPOSSIBLE_INSTRUCTIONS
                    break;  // PT_IMPOSSIBLE_INSTRUCTIONS
                }

                // 処理キャンセル指示確認
                if (isCancel) {
                    Logger.d(TAG, METHOD_NAME + "() is Interrupt transaction");
                    break;
                }

            }
            // 取引中止可否フラグを不可にする
            isTranCancelEnable = false;

            return resultValue;
        }

        /**
         * ResponseBitMap情報からRESULTINFOを設定する.<br>
         * <br>
         *
         * @param responseBitMap  ResponseBitMap
         * @param transactionData 取引情報
         * @return 設定処理結果
         */
        private Integer checkSetBitMapData(BitmapTransferResponse responseBitMap) {
            Integer resultValue;
            byte[] resultCode = responseBitMap.getDispose_result();
            byte[] errorCode =  responseBitMap.getDetailed_err_code();

            int[] tempResultCode = new int[1];
            int[] tempResultCodeExtended = new int[2];

            int checkResult = checkBitmapResultCode(resultCode,
                    errorCode, tempResultCode, tempResultCodeExtended);

            setResultCode = tempResultCode;
            setResultCodeExtended = tempResultCodeExtended;

            // 取引結果インスタンスを作成してセットする
            RESULTINFO tempResultInfo = new RESULTINFO();
            tempResultInfo.TransactionResultBit =
                            responseBitMap.getTran_result_bit();
            tempResultInfo.MemberNumber = responseBitMap.getMember_num();
            tempResultInfo.ExpirationDate = responseBitMap.getExpiration_date();
            tempResultInfo.CardHolderName = responseBitMap.getCardholder_name();
            tempResultInfo.ApplicationPANSequenceNumber = responseBitMap.getApp_pan_num();
            tempResultInfo.CardBrandIdentifier = responseBitMap.getBrand_identifier();
            tempResultInfo.OUTCOMEParameter = responseBitMap.getOutcome();
            tempResultInfo.TLVData = responseBitMap.getTlv();
            // 業務指定ビット7が1だった場合拡張部を取得する
            tempResultInfo.TLVDataExtended = responseBitMap.getTlvExpand();
            tempResultInfo.TLVDataExtended2 = responseBitMap.getTlvExpand2();

            resultInfo = tempResultInfo;
            resultValue = checkResult;
            return resultValue;
        }

        /**
         * DataExchangeレスポンスからDEINFOを設定する.<br>
         * <br>
         *
         * @param dataExchangeResponse  DataExchangeレスポンス
         * @return 設定処理結果
         */
        private Integer checkSetExchangeData(DataExchangeResponse dataExchangeResponse) {
            int[] tempResultCode = {CommandDataConstants.RESULT_CODE_SUCCESS};
            int[] tempResultCodeExtended = {0x00000000};

            setResultCode = tempResultCode;
            setResultCodeExtended = tempResultCodeExtended;

            // DataExchangeデータを作成してセットする
            DEINFO tempDeInfo = new DEINFO();
            mSendCounter = dataExchangeResponse.getSendCounter();
            tempDeInfo.ContinueFlag = dataExchangeResponse.getContinueFlag();
            tempDeInfo.Result = dataExchangeResponse.getResult();
            tempDeInfo.DataExchangeData = dataExchangeResponse.getExchangeData();

            deInfo = tempDeInfo;
            return CommandDataConstants.RESULT_CODE_SUCCESS;
        }

        /**
         * TRANSACTIONDATAからBitmapデータを生成する.<br>
         * <br>
         *
         * @param transactiondata 指定TRANSACTIONDATA
         * @return 生成したBitMapデータ
         */
        private byte[] createBitMap(TRANSACTIONDATA transactiondata) {
            byte[] sendBitMapData;

            // BitMapデータ：項目１レングス設定値
            int colLength = CommandDataConstants.TRANSACTION_BITMAP_DATA_LENGTH
                    - CommandDataConstants.TRANSACTION_BITMAP_HEADER_COL_LENGTH;
            byte[] colLengthByte = ByteBuffer.allocate(4).putInt(colLength).array();

            // BitMapデータ：項目２拡張サービスコード設定値
            byte[] serviceExtendCode = TransactionTypeEnum.PURCHASE.serviceExtendCode;
            for (TransactionTypeEnum checkType : TransactionTypeEnum.values()) {
                if (transactiondata.TransactionType == checkType.code) {
                    serviceExtendCode = checkType.serviceExtendCode;
                }
            }
            // BitMapデータ：項目３サービスコード設定値(DCC等)
            byte[] serviceCode;
            serviceCode = hex2bin(String.format("%04X",transactiondata.FunctionMode));
            // BitMapデータ：項目４
            byte[] bitMapPrimaryBytes = new byte[8];
            bitMapPrimaryBytes[0] = (byte) 0x82;
            // BitMapデータ：項目５
            byte[] bitMapSecondaryBytes = new byte[8];
            bitMapSecondaryBytes[0] = (byte) 0xA0;
            // BitMapデータ：項目６
            byte[] bitMapThirdBytes = new byte[8];
            bitMapThirdBytes[0] = (byte) 0x80;
            // BitMapデータ：項目７
            byte[] bitMapFourthBytes = new byte[8];
            bitMapFourthBytes[3] = (byte) 0x02;
            bitMapFourthBytes[4] = (byte) 0x03;
            bitMapFourthBytes[5] = (byte) 0x80;
            bitMapFourthBytes[7] = (byte) 0x64;
            // BitMapデータ：項目８：通信日時（BCD）オール0の場合システム日時をセット
            byte[] sendBCDDateByte;
            String sendDayByte = ByteUtil.convertBCDByte2String(transactiondata.CommunicationTime);
            if (sendDayByte == null || Long.parseLong(sendDayByte) == 0L) {
                Calendar nowDate = Calendar.getInstance();
                DateFormat sendDateFormat =
                        new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYMMDDHHMMSS);
                sendBCDDateByte = convertBCDData(sendDateFormat.format(nowDate.getTime()));
            } else {
                sendBCDDateByte = transactiondata.CommunicationTime;
            }
            // BitMapデータ：項目９：ブロック通番
            byte[] blockNumByte = new byte[2];
            if (transactiondata.BlockNumber == 0x8000) {
                blockNumByte[0] = (byte) 0x80;
            }

            // BitMapデータ：項目１２：業務指定ビット
            byte[] merchantSpecificDataByte = new byte[]{transactiondata.MerchantSpecificData};
            // BitMapデータ：項目１３：入力KID
            byte[] entryKIDByte = new byte[3];
            entryKIDByte[0] = (byte) 0x30;
            entryKIDByte[1] = (byte) 0x30;
            entryKIDByte[2] = (byte) 0x30;

            // BitMapデータ：項目１５：データ交換情報
            byte[] dataChangeInfoByte = new byte[256];
            // BitMapデータ：項目１６：支払方法
            byte[] paymentMethodByte = new byte[1];

            sendBitMapData = mergeByteArray(
                    targetLengthTrimPaddingByteArray(colLengthByte, 2)
                    , serviceExtendCode
                    , serviceCode
                    , bitMapPrimaryBytes
                    , bitMapSecondaryBytes
                    , bitMapThirdBytes
                    , bitMapFourthBytes
                    , targetLengthTrimPaddingByteArray(sendBCDDateByte, 6)
                    , blockNumByte
                    , transactiondata.AmountAuthorised
                    , transactiondata.AmountOther
                    , merchantSpecificDataByte
                    , entryKIDByte
                    , transactiondata.TLVData
                    , entryKIDByte
                    , dataChangeInfoByte
                    , paymentMethodByte
            );

            return sendBitMapData;
        }

        @Override
        protected void onPostExecute(Integer resultValue) {
            final String METHOD_NAME = "onPostExecute";
            startLog(METHOD_NAME, String.valueOf(resultValue));
            // 終了後処理：ハンドラIFを実行する
            if (m_CompleteEvent != null) {
                isFin = true;
                m_CompleteEvent.WM_CompleteEvent();
            }
        }
    }

    /**
     * 取引のデータ交換を実施するAPI。.<br>
     * <br>
     *
     * @param deInfo
     *            データ交換情報
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     */
    public int EMVCL_DataExchange(DEINFO deInfo) {
        final String METHOD_NAME = "EMVCL_DataExchange";
        startLog(METHOD_NAME, String.valueOf(deInfo));

        ApiReturnValues.DataExchange returnStatus = inputCheckEMVCL_DataExchange(deInfo);

        if (!mIsDataExchange) {
            Logger.d(TAG, METHOD_NAME + "() not Data Exchange sequence.");
            returnStatus = ApiReturnValues.DataExchange.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        if (returnStatus == ApiReturnValues.DataExchange.SUCCESS) {
            // 状態チェック
            int checkResult = checkStatus();
            if (checkResult != ApiReturnValues.E_BUSY) {
                returnStatus = ApiReturnValues.DataExchange.E_ILLEGAL;
                endLog(METHOD_NAME, returnStatus.name());
                return returnStatus.getStatus();
            }
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        //ウインドウハンドルが登録されていない場合
        if (m_CompleteEvent == null) {
            returnStatus = ApiReturnValues.DataExchange.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 非同期処理開始
        doDataExchangeTask = new DataExchangeTask();
        doDataExchangeTask.execute(deInfo);

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 非同期Threadクラス
     */
    class DataExchangeTask extends AsyncTransaction<DEINFO, Void, Integer> {

        /**
         * DEINFOデータ.
         */
        DEINFO deInfo;

        /**
         * RESULTINFOデータ.
         */
        RESULTINFO resultInfo;

        /**
         * DataExchangeが完了したかどうか.
         */
        boolean isFin = false;

        /**
         * 致命的なエラーが発生したかどうか
         */
        boolean isFatalError = false;

        /**
         * 取引処理結果.
         */
        int[] setResultCode = {111};
        /**
         * 取引処理結果コード詳細.
         */
        int[] setResultCodeExtended = {0xFFFF0000};

        @Override
        protected Integer doInBackground(DEINFO... params) {
            // バックグラウンド処理
            final String METHOD_NAME = "doInBackground";
            startLog(METHOD_NAME);

            Integer resultValue = ApiReturnValues.E_ILLEGAL;
            if (params == null || params.length == 0) {  // PT_IMPOSSIBLE_BRANCH
                Logger.d(TAG, METHOD_NAME + "() DEINFO Data not set");
                return resultValue;
            }

            DataExchangeResponse dataExchangeResponse = new DataExchangeResponse();
            DataExchangeRequest dataExchangeRequest = new DataExchangeRequest();
            dataExchangeRequest.setDataExchangeInfo(createDataExchangeInfo(params[0]));

            BitmapTransferResponse bitmapTransferResponse = new BitmapTransferResponse();
            if (mIsNeedExpand) {
                bitmapTransferResponse.isNeedExpand(true);
            }

            // 送受信処理
            do {
                if (dataExchangeRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
                    resultInfo = null;
                    byte[] resp = mPlatformConfig.deviceSendReceive(
                            dataExchangeRequest.toCommand(), RESPONSE_TIMER_DATA_ECXCHANGE);
                    if (resp == null) {
                        // R550が抜けたか故障(Statusを)
                        Logger.d(TAG, METHOD_NAME + "() DataExchange resp null");
                        resultValue = ApiReturnValues.E_ILLEGAL;
                        mIsDataExchange = false;
                        isFatalError = true;
                        break;
                    } else if (checkErrorResponse(resp, setResultCode, setResultCodeExtended)) {
                        Logger.d(TAG, METHOD_NAME + "() DataExchange errorResponse");
                        resultValue = ApiReturnValues.E_ILLEGAL;
                        mIsDataExchange = false;
                        if (resp[9] == (byte)0xFF) {
                            isFatalError = true;
                        }
                        break;
                    } else if (dataExchangeResponse.inputDeviceResult(resp)) {
                        checkSetExchangeData(dataExchangeResponse);
                        break;
                    } else if (bitmapTransferResponse.inputDeviceResult(resp)) {
                        // 売上レスポンス
                        resultValue = checkSetBitMapData(bitmapTransferResponse);
                        // 「処理実行結果=2511 かつ 詳細エラーコード=7111～7119」の場合
                        byte[] resultCode = bitmapTransferResponse.getDispose_result();
                        byte[] errorCode = bitmapTransferResponse.getDetailed_err_code();
                        if (resultCode[0] == (byte)0x25 && resultCode[1] == (byte)0x11 &&
                                errorCode[0] == (byte)0x71 &&
                                ((byte)0x11 <= errorCode[1] && errorCode[1] <= (byte)0x19)) {
                            // Data Exchangeでタイムアウトが発生した場合は遅れて送信した
                            // Data Exchangeコマンドに対するレスポンスがたまっているため
                            // 読み捨て処理を行う (復帰値は参照しない)
                            mPlatformConfig.deviceReceive(RESPONSE_TIMER_DATA_ECXCHANGE);
                        }
                        // Data Exchangeシーケンスに移行後、カードを離した場合は
                        // カードかざし待ちタイムアウトではなくエラーとなるため、
                        // リトライの考慮は不要
                        mIsDataExchange = false;
                        break;
                    } else {
                        Logger.d(TAG, METHOD_NAME
                                + "() DataExchange request error inputDeviceResult");
                        resultValue = ApiReturnValues.E_ILLEGAL;
                        mIsDataExchange = false;
                        break;
                    }
                } else {
                    Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                            + "() DataExchange request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
                    resultValue = ApiReturnValues.E_ILLEGAL;  // PT_IMPOSSIBLE_INSTRUCTIONS
                    mIsDataExchange = false;  // PT_IMPOSSIBLE_INSTRUCTIONS
                    break;  // PT_IMPOSSIBLE_INSTRUCTIONS
                }
            } while (false);

            return resultValue;
        }

        /**
         * ResponseBitMap情報からRESULTINFOを設定する.<br>
         * <br>
         *
         * @param responseBitMap  ResponseBitMap
         * @param transactionData 取引情報
         * @return 設定処理結果
         */
        private Integer checkSetBitMapData(BitmapTransferResponse responseBitMap) {
            Integer resultValue;
            byte[] resultCode = responseBitMap.getDispose_result();
            byte[] errorCode =  responseBitMap.getDetailed_err_code();

            int[] tempResultCode = new int[1];
            int[] tempResultCodeExtended = new int[2];

            int checkResult = checkBitmapResultCode(resultCode,
                    errorCode, tempResultCode, tempResultCodeExtended);

            setResultCode = tempResultCode;
            setResultCodeExtended = tempResultCodeExtended;

            // 取引結果インスタンスを作成してセットする
            RESULTINFO tempResultInfo = new RESULTINFO();
            tempResultInfo.TransactionResultBit =
                    responseBitMap.getTran_result_bit();
            tempResultInfo.MemberNumber = responseBitMap.getMember_num();
            tempResultInfo.ExpirationDate = responseBitMap.getExpiration_date();
            tempResultInfo.CardHolderName = responseBitMap.getCardholder_name();
            tempResultInfo.ApplicationPANSequenceNumber = responseBitMap.getApp_pan_num();
            tempResultInfo.CardBrandIdentifier = responseBitMap.getBrand_identifier();
            tempResultInfo.OUTCOMEParameter = responseBitMap.getOutcome();
            tempResultInfo.TLVData = responseBitMap.getTlv();
            // 業務指定ビット7が1だった場合拡張部を取得する
            tempResultInfo.TLVDataExtended = responseBitMap.getTlvExpand();
            tempResultInfo.TLVDataExtended2 = responseBitMap.getTlvExpand2();

            resultInfo = tempResultInfo;
            resultValue = checkResult;
            return resultValue;
        }

        /**
         * DataExchangeレスポンスからDEINFOを設定する.<br>
         * <br>
         *
         * @param dataExchangeResponse  DataExchangeレスポンス
         * @return 設定処理結果
         */
        private Integer checkSetExchangeData(DataExchangeResponse dataExchangeResponse) {
            int[] tempResultCode = {CommandDataConstants.RESULT_CODE_SUCCESS};
            int[] tempResultCodeExtended = {0x00000000};

            setResultCode = tempResultCode;
            setResultCodeExtended = tempResultCodeExtended;

            // DataExchangeデータを作成してセットする
            DEINFO tempDeInfo = new DEINFO();
            mSendCounter = dataExchangeResponse.getSendCounter();
            tempDeInfo.ContinueFlag = dataExchangeResponse.getContinueFlag();
            tempDeInfo.Result = dataExchangeResponse.getResult();
            tempDeInfo.DataExchangeData = dataExchangeResponse.getExchangeData();

            deInfo = tempDeInfo;
            return CommandDataConstants.RESULT_CODE_SUCCESS;
        }

        /**
         * DEINFOからDataExchangeデータを生成する.<br>
         * <br>
         *
         * @param deInfo 指定DEINFO
         * @return 生成したDataExchangeデータ
         */
        private byte[] createDataExchangeInfo(DEINFO deInfo) {
            byte[] sendDataExchangeInfo;

            // DataExchangeデータ：予備2
            byte[] reserve2 = new byte[3];
            Arrays.fill(reserve2, (byte)0xFF);

            sendDataExchangeInfo = mergeByteArray(
                    mSendCounter
                    , new byte[] { deInfo.ContinueFlag }
                    , deInfo.Result
                    , reserve2
                    , deInfo.DataExchangeData
            );

            return sendDataExchangeInfo;
        }

        @Override
        protected void onPostExecute(Integer resultValue) {
            final String METHOD_NAME = "onPostExecute";
            startLog(METHOD_NAME, String.valueOf(resultValue));
            // 終了後処理：ハンドラIFを実行する
            if (m_CompleteEvent != null) {
                isFin = true;
                m_CompleteEvent.WM_CompleteEvent();
            }
        }
    }

    /**
     * Responseの指定コードを確認して拡張コードを編集する.<br>
     * <br>
     * @param resultCode 指定処理結果
     * @param errorCode 取得エラーコード(null指定可能：拡張コード下2桁は初期値)
     * @param respResultCode 返却用処理結果
     * @param respResultCodeExtended 返却用処理拡張コード
     * @return エラーコード
     */
    private int checkBitmapResultCode(byte[] resultCode, byte[] errorCode
            , int[] respResultCode, int[] respResultCodeExtended) {
        final String METHOD_NAME = "checkBitmapkResultCode";
        startLog(METHOD_NAME, "resultCode=", Arrays.toString(resultCode));
        int resultApi;
        int resultInt = resultCode[0] & 0xff;
        if ((resultInt & 0xf0) == 0xe0) {
            // エラー結果
            if (resultCode[0] == (byte) 0xe1 && resultCode[1] == (byte) 0x00) {  // PT_IMPOSSIBLE_BRANCH
                // トレーニング正常終了
                resultApi = CommandDataConstants.RESULT_CODE_SUCCESS;
            } else if (resultCode[0] == CommandDataConstants.RESULT_ERROR_RESULT_COLLISION[0]
                    && resultCode[1] == CommandDataConstants.RESULT_ERROR_RESULT_COLLISION[1]) {  // PT_IMPOSSIBLE_BRANCH
                // 衝突検知
                resultApi = CommandDataConstants.RESULT_CODE_NETWORK_ERROR;
            } else if (resultCode[0] == CommandDataConstants.RESULT_ERROR_RESULT_TIMEOUT[0]
                    && resultCode[1] == CommandDataConstants.RESULT_ERROR_RESULT_TIMEOUT[1]) {  // PT_IMPOSSIBLE_BRANCH
                // タイムアウト
                resultApi = CommandDataConstants.RESULT_CODE_NETWORK_ERROR;
            } else {
                // 決済デバイスのEMV処理エラー
                resultApi = CommandDataConstants.RESULT_CODE_EMV_PROC_ERROR;
            }
        // コードの下2桁目がFFで有れば異常レスポンス
        } else if ((resultCode[0] & 0x0f) == CommandDataConstants.RESULT_ERROR_INTERNAL_ERROR[0]
                 && resultCode[1] == CommandDataConstants.RESULT_ERROR_INTERNAL_ERROR[1]) {  // PT_IMPOSSIBLE_BRANCH
            // 決済デバイスのEMV処理エラー
            resultApi = CommandDataConstants.RESULT_CODE_EMV_PROC_ERROR;
        } else {
            // 正常終了
            resultApi = CommandDataConstants.RESULT_CODE_SUCCESS;
        }

        // 返却用処理結果
        if (respResultCode != null && respResultCodeExtended != null) {
            // 処理結果
            respResultCode[0] = resultApi;
            // 拡張コード
            if (errorCode != null) {
                setResultCodeExtendedData(
                        respResultCodeExtended,
                        resultCode,
                        errorCode);
            } else {
                setResultCodeExtendedData(
                        respResultCodeExtended,
                        resultCode,
                        new byte[2]);
            }
        }

        return resultApi;
    }

    /**
     * TransactionTypeの定数設定Enum.
     */
    enum TransactionTypeEnum {
        /** 売上. */
        PURCHASE((byte) 0x00, new byte[]{(byte) 0x11, (byte) 0x90}),
        /** 割引売上. */
        PURCHASE_WITH_CASHBACK((byte) 0x01, new byte[]{(byte) 0x11, (byte) 0x92}),
        /** キャッシング. */
        CASH_ADVANCE((byte) 0x09, new byte[]{(byte) 0x11, (byte) 0x93}),
        /** 取消. */
        REFUND((byte) 0x20, new byte[]{(byte) 0x11, (byte) 0x91});

        /** TRANSACTIONDATAでのコード値. */
        private byte code;
        /** RequestBitMap拡張サービスコード. */
        private byte[] serviceExtendCode;

        TransactionTypeEnum(byte code, byte[] serviceExtendCode) {
            this.code = code;
            this.serviceExtendCode = serviceExtendCode;
        }
    }

    /**
     * EMVCL_Transactionの入力チェック処理.<br>
     * <br>
     *
     * @param TransactionData 取引情報
     * @return チェック結果
     */
    private ApiReturnValues.Transaction inputCheckEMVCL_Transaction(
            TRANSACTIONDATA TransactionData) {
        final String METHOD_NAME = "inputCheckEMVCL_Transaction";
        startLog(METHOD_NAME);
        ApiReturnValues.Transaction checkStatus = ApiReturnValues.Transaction.E_ILLEGAL;

        boolean isError = false;
        if (TransactionData == null) {
            Logger.d(TAG, METHOD_NAME + "() TransactionData not set");
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        } else {
            // FunctionMode
            if (TransactionData.FunctionMode != 0x0000
                    && TransactionData.FunctionMode != 0x0010) {  // PT_IMPOSSIBLE_BRANCH
                Logger.d(TAG, METHOD_NAME
                        + "() TransactionData.FunctionMode mismatch data ="
                        + TransactionData.FunctionMode);
                isError = true;
            }

            // CommunicationTime
            if (TransactionData.CommunicationTime == null) {
                Logger.d(TAG, METHOD_NAME
                        + "() TransactionData.CommunicationTime not set");
                isError = true;
            } else if (!checkBCDByteArray(TransactionData.CommunicationTime)) {
                Logger.d(TAG, METHOD_NAME
                        + "() TransactionData.CommunicationTime mismatch data ="
                        + Arrays.toString(TransactionData.CommunicationTime));
                isError = true;
            }

            // BlockNumber
            if (TransactionData.BlockNumber != 0x0000
                    && TransactionData.BlockNumber != 0x8000) {
                Logger.d(TAG, METHOD_NAME
                        + "() TransactionData.BlockNumber mismatch data ="
                        + TransactionData.BlockNumber);
                isError = true;
            }

            // AmountAuthorised
            if (TransactionData.AmountAuthorised == null) {
                Logger.d(TAG, METHOD_NAME
                        + "() TransactionData.AmountAuthorised not set");
                isError = true;
            } else {
                if (!checkBCDByteArray(TransactionData.AmountAuthorised)) {
                    Logger.d(TAG, METHOD_NAME
                            + "() TransactionData.AmountAuthorised mismatch data ="
                            + Arrays.toString(TransactionData.AmountAuthorised));
                    isError = true;
                } else {
                    String convertAmount =
                            convertBCDByte2String(TransactionData.AmountAuthorised);
                    if (convertAmount == null
                            || convertAmount.length() > "999999999999".length()) {  // PT_IMPOSSIBLE_BRANCH
                        Logger.d(TAG, METHOD_NAME
                                + "() TransactionData.AmountAuthorised mismatch length ="
                                + Arrays.toString(TransactionData.AmountAuthorised));
                        isError = true;
                    }
                }
            }

            // AmountOther
            if (TransactionData.AmountOther == null) {
                Logger.d(TAG, METHOD_NAME
                        + "() TransactionData.AmountOther not set");
                isError = true;
            } else {
                if (!checkBCDByteArray(TransactionData.AmountOther)) {
                    Logger.d(TAG, METHOD_NAME
                            + "() TransactionData.AmountOther mismatch data ="
                            + Arrays.toString(TransactionData.AmountOther));
                    isError = true;
                } else {
                    String convertAmount = convertBCDByte2String(TransactionData.AmountOther);
                    if (convertAmount == null
                            || convertAmount.length() > "999999999999".length()) {  // PT_IMPOSSIBLE_BRANCH
                        Logger.d(TAG, METHOD_NAME
                                + "() TransactionData.AmountOther mismatch length ="
                                + Arrays.toString(TransactionData.AmountOther));
                        isError = true;
                    }
                }
            }

            // TLVData
            if (TransactionData.TLVData == null) {
                Logger.d(TAG, METHOD_NAME + "() TransactionData.TLVData not set");
                isError = true;
            }
        }

        if (!isError) {
            checkStatus = ApiReturnValues.Transaction.SUCCESS;
        }

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;
    }

    /**
     * EMVCL_DataExchangeの入力チェック処理.<br>
     * <br>
     *
     * @param DataExchangeInfo データ交換情報
     * @return チェック結果
     */
    private ApiReturnValues.DataExchange inputCheckEMVCL_DataExchange(DEINFO DataExchangeInfo) {
        final String METHOD_NAME = "inputCheckEMVCL_DataExchange";
        startLog(METHOD_NAME);
        ApiReturnValues.DataExchange checkStatus = ApiReturnValues.DataExchange.E_ILLEGAL;

        boolean isError = false;
        if (DataExchangeInfo == null) {
            Logger.d(TAG, METHOD_NAME + "() DataExchangeInfo not set");
            endLog(METHOD_NAME, checkStatus.name());
            return checkStatus;
        } else {
            // ContinueFlag
            if (DataExchangeInfo.ContinueFlag != 0x00
                    && DataExchangeInfo.ContinueFlag != 0x01) {
                Logger.d(TAG, METHOD_NAME
                        + "() DataExchangeInfo.ContinueFlag mismatch data ="
                        + DataExchangeInfo.ContinueFlag);
                isError = true;
            }

            // Result
            if (DataExchangeInfo.Result == null) {
                Logger.d(TAG, METHOD_NAME
                        + "() DataExchangeInfo.Result not set");
                isError = true;
            } else {
                if (DataExchangeInfo.Result.length != 2) {
                    Logger.d(TAG, METHOD_NAME
                            + "() DataExchangeInfo.Result mismatch length ="
                            + Arrays.toString(DataExchangeInfo.Result));
                    isError = true;
                }
            }

            // DataExchangeData
            if (DataExchangeInfo.DataExchangeData == null) {
                Logger.d(TAG, METHOD_NAME
                        + "() DataExchangeInfo.DataExchangeData not set");
                isError = true;
            } else {
                if (DataExchangeInfo.DataExchangeData.length < 3) {
                    Logger.d(TAG, METHOD_NAME
                            + "() DataExchangeInfo.DataExchangeData mismatch length ="
                            + Arrays.toString(DataExchangeInfo.DataExchangeData));
                    isError = true;
                }
            }
        }

        if (!isError) {
            checkStatus = ApiReturnValues.DataExchange.SUCCESS;
        }

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;
    }

    /**
     * 取引のオペレーションを擬似的に実施するAPI。.<br>
     * <br>
     *
     * @param TransactionData
     *            取引情報
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_TRTransaction(TRANSACTIONDATA TransactionData) {
        // ReturnValuesはEMVCL_Transactionと共通で使用する
        final String METHOD_NAME = "EMVCL_TRTransaction";
        startLog(METHOD_NAME, String.valueOf(TransactionData));
        ApiReturnValues.Transaction returnStatus = inputCheckEMVCL_Transaction(TransactionData);

        // 状態チェック
        if (returnStatus == ApiReturnValues.Transaction.SUCCESS) {
            int checkResult = checkStatus();
            if (checkResult != ApiReturnValues.SUCCESS) {
                returnStatus = ApiReturnValues.Transaction.getTargetStatus(checkResult);
                endLog(METHOD_NAME, returnStatus.name());
                return returnStatus.getStatus();
            }
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        //ウインドウハンドルが登録されていない場合
        if (m_CompleteEvent == null) {
            returnStatus = ApiReturnValues.Transaction.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        changeStatus(EMVStatus.EMVCL_BUSY);
        // 非同期処理開始
        doTransactionTask = new TransactionTask();
        doTransactionTask.isTraining = true;
        doTransactionTask.retryTimeout = 60;
        doTransactionTask.execute(TransactionData);

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 決済デバイスの取引情報を初期化するAPI。.<br>
     * <br>
     *
     * @param CardPresence
     *            カードが決済デバイスのかざし部に存在するかを示す。<br>
     *            00H：Card not present<br>
     *            01H：Card present<br>
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_Clear(byte[] CardPresence, int[] ResultCode,
                           int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_Clear";
        startLog(METHOD_NAME, Arrays.toString(CardPresence),
                Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));
        ApiReturnValues.Clear returnStatus = ApiReturnValues.Clear.SUCCESS;

        if (inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            returnStatus = ApiReturnValues.Clear.E_ILLEGAL;
            return returnStatus.getStatus();
        }

        // 入力チェック
        if (CardPresence == null || CardPresence.length == 0) {  // PT_IMPOSSIBLE_BRANCH
            Logger.d(TAG, METHOD_NAME + "()  CardPresence not set");
            returnStatus = ApiReturnValues.Clear.E_ILLEGAL;
            return returnStatus.getStatus();
        }

        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            ResultCode[0] = checkResult;
            returnStatus = ApiReturnValues.Clear.getTargetStatus(checkResult);
            return returnStatus.getStatus();
        }

        ProcessingCancelRequest processingCancelRequest = new ProcessingCancelRequest();
        ProcessingCancelResponse processingCancelResponse = new ProcessingCancelResponse();

        returnStatus = ApiReturnValues.Clear.E_ILLEGAL;
        if (processingCancelRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    processingCancelRequest.toCommand(), RESPONSE_TIMER_CLEAR);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() ProcessingCancel request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                returnStatus = ApiReturnValues.Clear.E_FAILURE;
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() ProcessingCancel errorResponse");
            } else if (!processingCancelResponse.inputDeviceResult(resp)) {
                Logger.d(TAG, METHOD_NAME + "() ProcessingCancel request error inputDeviceResult");
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else {
                // パラメータデータコピーを行う
                CardPresence[0] = processingCancelResponse.getCardPresence();
                ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                returnStatus = ApiReturnValues.Clear.SUCCESS;
            }

        } else {
            Logger.d(TAG, METHOD_NAME + "() ProcessingCancel request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 取引結果を取得するAPI。.<br>
     * <br>
     *
     * @param ResultInfo
     *            取引結果情報
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     *         - 成功時：SUCCESS(00)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     */
    public int EMVCL_GetTransactionResult(RESULTINFO ResultInfo, DEINFO DeInfo,
                                          int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_GetTransactionResult";
        startLog(METHOD_NAME, Arrays.toString(ResultCode)
                , Arrays.toString(ResultCodeExtended));
        ApiReturnValues.GetTransactionResult returnStatus =
                ApiReturnValues.GetTransactionResult.SUCCESS;

        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            returnStatus = ApiReturnValues.GetTransactionResult.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        ResultCode[0] = 111;
        ResultCodeExtended[0] = 0xFFFF0000;

        if (ResultInfo == null) {
            Logger.d(TAG, METHOD_NAME + "() RESULTINFO not set");
            returnStatus = ApiReturnValues.GetTransactionResult.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        if (DeInfo == null) {
            Logger.d(TAG, METHOD_NAME + "() DeInfo not set");
            returnStatus = ApiReturnValues.GetTransactionResult.E_ILLEGAL;
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        resultCodeInit(ResultCode, ResultCodeExtended);

        if (doDataExchangeTask != null && doDataExchangeTask.isFin) {

            if (doDataExchangeTask.setResultCode != null) {
                ResultCode[0] = doDataExchangeTask.setResultCode[0];
            }

            if (doDataExchangeTask.setResultCodeExtended != null) {
                ResultCodeExtended[0] = doDataExchangeTask.setResultCodeExtended[0];
            }

            if (doDataExchangeTask.resultInfo != null) {
                // 状態をEMVCL_CLAIMEDに戻すのは売り上げレスポンスと
                // エラーレスポンス返却時のみ
                // Data Exchangeのシーケンス中は状態を維持する
                changeStatus(EMVStatus.EMVCL_CLAIMED);

                ResultInfo.CardBrandIdentifier = doDataExchangeTask.resultInfo.CardBrandIdentifier;
                ResultInfo.TLVDataExtended = doDataExchangeTask.resultInfo.TLVDataExtended;
                ResultInfo.TLVDataExtended2 = doDataExchangeTask.resultInfo.TLVDataExtended2;
                ResultInfo.TLVData = doDataExchangeTask.resultInfo.TLVData;
                ResultInfo.TransactionResultBit = doDataExchangeTask.resultInfo.TransactionResultBit;
                ResultInfo.OUTCOMEParameter = doDataExchangeTask.resultInfo.OUTCOMEParameter;
                ResultInfo.MemberNumber = doDataExchangeTask.resultInfo.MemberNumber;
                ResultInfo.ExpirationDate = doDataExchangeTask.resultInfo.ExpirationDate;
                ResultInfo.CardHolderName = doDataExchangeTask.resultInfo.CardHolderName;
                ResultInfo.ApplicationPANSequenceNumber = doDataExchangeTask.resultInfo.ApplicationPANSequenceNumber;
                ResultInfo.isSet = true;
            } else if (doDataExchangeTask.deInfo != null) {
                DeInfo.ContinueFlag = doDataExchangeTask.deInfo.ContinueFlag;
                DeInfo.Result = doDataExchangeTask.deInfo.Result;
                DeInfo.DataExchangeData = doDataExchangeTask.deInfo.DataExchangeData;
                DeInfo.isSet = true;
            } else {
                // 状態をEMVCL_CLAIMEDに戻すのは売り上げレスポンスと
                // エラーレスポンス返却時のみ
                // Data Exchangeのシーケンス中は状態を維持する
                if (doDataExchangeTask.isFatalError) {
                    changeStatus(EMVStatus.EMVCL_CLOSED);
                } else {
                    changeStatus(EMVStatus.EMVCL_CLAIMED);
                }
            }
            returnStatus = ApiReturnValues.GetTransactionResult.SUCCESS;
            doDataExchangeTask = null;

        } else if (doTransactionTask != null && doTransactionTask.isFin) {

            if (doTransactionTask.setResultCode != null) {
                ResultCode[0] = doTransactionTask.setResultCode[0];
            }

            if (doTransactionTask.setResultCodeExtended != null) {
                ResultCodeExtended[0] = doTransactionTask.setResultCodeExtended[0];
            }

            if (doTransactionTask.resultInfo != null) {
                // 状態をEMVCL_CLAIMEDに戻すのは売り上げレスポンス返却時のみ
                // Data Exchangeのシーケンス中は状態を維持する
                changeStatus(EMVStatus.EMVCL_CLAIMED);

                ResultInfo.CardBrandIdentifier = doTransactionTask.resultInfo.CardBrandIdentifier;
                ResultInfo.TLVDataExtended = doTransactionTask.resultInfo.TLVDataExtended;
                ResultInfo.TLVDataExtended2 = doTransactionTask.resultInfo.TLVDataExtended2;
                ResultInfo.TLVData = doTransactionTask.resultInfo.TLVData;
                ResultInfo.TransactionResultBit = doTransactionTask.resultInfo.TransactionResultBit;
                ResultInfo.OUTCOMEParameter = doTransactionTask.resultInfo.OUTCOMEParameter;
                ResultInfo.MemberNumber = doTransactionTask.resultInfo.MemberNumber;
                ResultInfo.ExpirationDate = doTransactionTask.resultInfo.ExpirationDate;
                ResultInfo.CardHolderName = doTransactionTask.resultInfo.CardHolderName;
                ResultInfo.ApplicationPANSequenceNumber = doTransactionTask.resultInfo.ApplicationPANSequenceNumber;
                ResultInfo.isSet = true;
            } else if (doTransactionTask.deInfo != null) {
                DeInfo.ContinueFlag = doTransactionTask.deInfo.ContinueFlag;
                DeInfo.Result = doTransactionTask.deInfo.Result;
                DeInfo.DataExchangeData = doTransactionTask.deInfo.DataExchangeData;
                DeInfo.isSet = true;
            } else {
                // 状態をEMVCL_CLAIMEDに戻すのは売り上げレスポンスと
                // エラーレスポンス返却時のみ
                // Data Exchangeのシーケンス中は状態を維持する
                if (doTransactionTask.isFatalError) {
                    changeStatus(EMVStatus.EMVCL_CLOSED);
                } else {
                    changeStatus(EMVStatus.EMVCL_CLAIMED);
                }
            }
            returnStatus = ApiReturnValues.GetTransactionResult.SUCCESS;
            doTransactionTask = null;

        } else {
            // 状態チェック後で非同期TASKが無かった場合は想定外
            Logger.d(TAG, METHOD_NAME + "() doTransactionTask not instance");
            changeStatus(EMVStatus.EMVCL_CLOSED);
            returnStatus = ApiReturnValues.GetTransactionResult.E_ILLEGAL;
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * オンラインオーソリゼーションを実施した場合、オーソリゼーションの結果を表示するAPI。.<br>
     * <br>
     *
     * @param HostResult
     *            オンラインオーソリゼーション結果
     * @param ShowTime
     *            結果を表示する時間
     * @param ResultCode
     *            決済デバイスの結果コード
     * @param ResultCodeExtended
     *            決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_SetResult(byte HostResult, byte ShowTime, int[] ResultCode,
                               int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_SetResult";
        startLog(METHOD_NAME);
        ApiReturnValues.SetResult returnStatus = ApiReturnValues.SetResult.E_ILLEGAL;

        // 入力チェック
        boolean isError = false;

        if (inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            isError = true;
        }

        // ShowTimeはbyte型の範囲すべてが有効値であるためチェック処理を省略する
        if (HostResult != (byte) 0x00
                && HostResult != (byte) 0x01
                && HostResult != (byte) 0x02) {
            Logger.d(TAG, METHOD_NAME + "()  HostResult mismatch = " + HostResult);
            isError = true;
        }

        if (isError) {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            ResultCode[0] = checkResult;
            returnStatus = ApiReturnValues.SetResult.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 結果通知通信
        byte[] setResultInfo = mergeByteArray(new byte[] { HostResult }, new byte[] { ShowTime });
        SetResultRequest setResultRequest = new SetResultRequest();
        SetResultResponse setResultResponse = new SetResultResponse();
        setResultRequest.setSetResultInfo(setResultInfo);

        int waitTime = RESPONSE_TIMER_SET_RESULT + ((ShowTime & 0xFF) * 100);
        Logger.d(TAG, METHOD_NAME + "() waitTime=" + waitTime);
        if (setResultRequest.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    setResultRequest.toCommand(), waitTime);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() SetResult request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.SetResult.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() SetResult errorResponse");
            } else if (!setResultResponse.inputDeviceResult(resp)) {
                Logger.d(TAG, METHOD_NAME
                        + "() SetResult request error inputDeviceResult");
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else {
                ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                returnStatus = ApiReturnValues.SetResult.SUCCESS;
            }
        } else {
            Logger.d(TAG, METHOD_NAME  // PT_IMPOSSIBLE_INSTRUCTIONS
                    + "() SetResult request error isValidValue");  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * カードかざし待ち状態の中断要求をする場合に実行するAPI。.<br>
     * <br>
     *
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     */
    public int EMVCL_Cancel() {
        final String METHOD_NAME = "EMVCL_Cancel";
        startLog(METHOD_NAME);
        ApiReturnValues.Cancel returnStatus = ApiReturnValues.Cancel.SUCCESS;

        Logger.d(TAG, METHOD_NAME
                + "m_EMVStatus = "
                + m_EMVStatus.name());
        // 状態チェック
        switch (m_EMVStatus) {  // PT_IMPOSSIBLE_BRANCH
        case EMVCL_CLOSED:
            returnStatus = ApiReturnValues.Cancel.E_CLOSED;
            break;
        case EMVCL_OPENED:
            returnStatus = ApiReturnValues.Cancel.E_NOTCLAIMED;
            break;
        case EMVCL_CLAIMED:
            returnStatus = ApiReturnValues.Cancel.E_ILLEGAL;
            break;
        case EMVCL_BUSY:
            returnStatus = ApiReturnValues.Cancel.E_ILLEGAL;
            if (doTransactionTask != null && doTransactionTask.doCancel()) {
                // キャンセル実行成功
                returnStatus = ApiReturnValues.Cancel.SUCCESS;
                // ステータスを変更する
                changeStatus(EMVStatus.EMVCL_CLAIMED);
            }
            break;
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * EMVCL_TransactionまたはEMVCL_TRtransactionが終了した際に通知されるハンドラ登録API.<br>
     * <br>
     *
     * @param hwnd
     *            登録するアプリケーションの完了時EventHandler
     * @return 処理結果
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     */
    public int EMVCL_SetCompleteEvent(NFCCompleteEventHandler hwnd) {
        final String METHOD_NAME = "EMVCL_SetCompleteEvent";
        startLog(METHOD_NAME);
        ApiReturnValues.SetCompleteEvent returnStatus = ApiReturnValues.SetCompleteEvent.SUCCESS;

        // 状態チェック
        EMVStatus checkEMVStatus = this.m_EMVStatus;
        if (checkEMVStatus != null) {
            switch (checkEMVStatus) {
                case EMVCL_CLOSED:
                    Logger.d(TAG, METHOD_NAME
                            + "m_EMVStatus = "
                            + m_EMVStatus.name());
                    returnStatus = ApiReturnValues.SetCompleteEvent.E_CLOSED;
                    break;
                case EMVCL_OPENED:
                    Logger.d(TAG, METHOD_NAME
                            + "m_EMVStatus = "
                            + m_EMVStatus.name());
                    returnStatus = ApiReturnValues.SetCompleteEvent.E_NOTCLAIMED;
                    break;
                case EMVCL_CLAIMED:
                    break;
                case EMVCL_BUSY:
                    break;
            }
        } else {
            Logger.d(TAG, METHOD_NAME + "m_EMVStatus is null ");
            returnStatus = ApiReturnValues.SetCompleteEvent.E_ILLEGAL;
        }

        if (hwnd == null) {
            returnStatus = ApiReturnValues.SetCompleteEvent.E_ILLEGAL;
        } else if (m_EMVStatus == EMVStatus.EMVCL_CLOSED) {
            returnStatus = ApiReturnValues.SetCompleteEvent.E_CLOSED;
        } else if (m_EMVStatus == EMVStatus.EMVCL_OPENED) {
            returnStatus = ApiReturnValues.SetCompleteEvent.E_NOTCLAIMED;
        } else if (returnStatus != ApiReturnValues.SetCompleteEvent.E_ILLEGAL) {
            m_CompleteEvent = hwnd;
            returnStatus = ApiReturnValues.SetCompleteEvent.SUCCESS;
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * 取引実施時の個人情報（会員番号、有効期限、TLVデータ等）を暗号化したい場合に、使用する暗号鍵を送信するAPI。.<br>
     * <br>
     *
     * @param RSAModulusData     暗号化で使用するモジュラス（RSA-2048bit）
     * @param RSAExponentData    暗号化で使用するエクスポーネント
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_SetEncryptionKey(
            byte[] RSAModulusData, byte[] RSAExponentData,
            int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_SetEncryptionKey";
        startLog(METHOD_NAME, Arrays.toString(RSAModulusData), Arrays.toString(RSAExponentData)
                , Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));

        ApiReturnValues.SetEncryptionKey returnStatus =
                inputCheckEMVCL_SetEncryptionKey(
                        RSAModulusData, RSAExponentData, ResultCode, ResultCodeExtended
                );

        if (returnStatus == ApiReturnValues.SetEncryptionKey.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.SetEncryptionKey.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 暗号鍵設定
        EncryptionKeySettingRequest encryptionKeySettingRequest =
                new EncryptionKeySettingRequest();

        EncryptionKeySettingResponse encryptionKeySettingResponse =
                new EncryptionKeySettingResponse();

        encryptionKeySettingRequest.setModulusData(RSAModulusData);
        encryptionKeySettingRequest.setExponentData(RSAExponentData);

        returnStatus = ApiReturnValues.SetEncryptionKey.E_ILLEGAL;
        if (encryptionKeySettingRequest.isValidValue()) {
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    encryptionKeySettingRequest.toCommand(),
                    RESPONSE_TIMER_ENCRYPTIONKEY);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() SetEncryptionKey request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.SetEncryptionKey.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() SetEncryptionKey errorResponse");
            } else if (!encryptionKeySettingResponse.inputDeviceResult(resp)) {
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                Logger.d(TAG, METHOD_NAME
                        + "() SetEncryptionKey request error inputDeviceResult");
            } else {
                ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                returnStatus = ApiReturnValues.SetEncryptionKey.SUCCESS;
            }
        } else {
            Logger.d(TAG, METHOD_NAME
                    + "() SetEncryptionKey request error isValidValue");
        }
        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * EMVCL_SetEncryptionKeyの入力値チェック処理。.<br>
     * <br>
     *
     * @param RSAModulusData     暗号化で使用するモジュラス（RSA-2048bit）
     * @param RSAExponentData    暗号化で使用するエクスポーネント
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return チェック結果
     */
    private ApiReturnValues.SetEncryptionKey inputCheckEMVCL_SetEncryptionKey(
            byte[] RSAModulusData, byte[] RSAExponentData
            , int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "inputCheckEMVCL_SetEncryptionKey";
        startLog(METHOD_NAME);
        ApiReturnValues.SetEncryptionKey checkStatus = ApiReturnValues.SetEncryptionKey.E_ILLEGAL;
        boolean isError = false;
        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            isError = true;
        }

        if (RSAModulusData == null) {
            Logger.d(TAG, METHOD_NAME + "() RSAModulusData not set");
            isError = true;
        } else if (RSAModulusData.length != 256) {
            Logger.d(TAG, METHOD_NAME + "() RSAModulusData not set");
            isError = true;
        }

        if (RSAExponentData == null) {
            Logger.d(TAG, METHOD_NAME + "() RSAExponentData not set");
            isError = true;
        } else if (RSAExponentData.length != 3) {
            Logger.d(TAG, METHOD_NAME + "() RSAExponentData not set");
            isError = true;
        }

        if (!isError) {
            checkStatus = ApiReturnValues.SetEncryptionKey.SUCCESS;
        }

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;
    }

    /**
     * 外貨で決済する場合などに、RW画面にて取引金額に表示したい通貨の名称を設定するAPI。.<br>
     * <br>
     *
     * @param CurrencyAbbData    決済する通貨名称の文字列byte配列
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return 処理結果：<br>
     *         - 成功時：SUCCESS(00)<br>
     *         - OPEN状態ではない：E_CLOSED(101)<br>
     *         - Claim状態ではない：E_NOTCLAIMED(103)<br>
     *         - イリーガルエラー：E_ILLEGAL(106)<br>
     *         - 通信エラー：E_FAILURE(111)<br>
     *         - 決済処理中：E_BUSY(113)<br>
     */
    public int EMVCL_SetCurrencyAbbreviation(byte[] CurrencyAbbData,
                                             int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "EMVCL_SetCurrencyAbbreviation";
        startLog(METHOD_NAME, Arrays.toString(CurrencyAbbData)
                , Arrays.toString(ResultCode), Arrays.toString(ResultCodeExtended));

        ApiReturnValues.SetCurrencyAbbreviation returnStatus =
                inputCheckEMVCL_SetCurrencyAbbreviation(
                        CurrencyAbbData, ResultCode, ResultCodeExtended
                );

        if (returnStatus == ApiReturnValues.SetCurrencyAbbreviation.SUCCESS) {
            resultCodeInit(ResultCode, ResultCodeExtended);
        } else {
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 状態チェック
        int checkResult = checkStatus();
        if (checkResult != ApiReturnValues.SUCCESS) {
            returnStatus = ApiReturnValues.SetCurrencyAbbreviation.getTargetStatus(checkResult);
            endLog(METHOD_NAME, returnStatus.name());
            return returnStatus.getStatus();
        }

        // 決済通貨表示設定
        CurrencyDisplaySettingRequest currencyDisplaySettingRequest =
                new CurrencyDisplaySettingRequest();

        CurrencyDisplaySettingResponse currencyDisplaySettingResponse =
                new CurrencyDisplaySettingResponse();

        currencyDisplaySettingRequest.setCurrencyAbbData(CurrencyAbbData);

        returnStatus = ApiReturnValues.SetCurrencyAbbreviation.E_ILLEGAL;
        if (currencyDisplaySettingRequest.isValidValue()) {
            byte[] resp = mPlatformConfig.deviceSendReceive(
                    currencyDisplaySettingRequest.toCommand(),
                    RESPONSE_TIMER_CURRENCY_DISPLAY);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                Logger.d(TAG, METHOD_NAME + "() CurrencyDisplaySetting request resp null");
                changeStatus(EMVStatus.EMVCL_CLOSED);
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                returnStatus = ApiReturnValues.SetCurrencyAbbreviation.E_FAILURE;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else if (checkErrorResponse(resp, ResultCode, ResultCodeExtended)) {
                Logger.d(TAG, METHOD_NAME + "() CurrencyDisplaySetting errorResponse");
            } else if (!currencyDisplaySettingResponse.inputDeviceResult(resp)) {
                Logger.d(TAG, METHOD_NAME
                        + "() CurrencyDisplaySetting request error inputDeviceResult");
                ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                setResultCodeExtendedData(ResultCodeExtended,
                                CommandDataConstants.RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR,
                                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
            } else {
                ResultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS;
                setResultCodeExtendedData(ResultCodeExtended,
                        CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                        CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
                returnStatus = ApiReturnValues.SetCurrencyAbbreviation.SUCCESS;
            }
        } else {
            Logger.d(TAG, METHOD_NAME
                    + "() CurrencyDisplaySetting request error isValidValue");
        }

        endLog(METHOD_NAME, returnStatus.name());
        return returnStatus.getStatus();
    }

    /**
     * EMVCL_SetCurrencyAbbreviationの入力チェック<br>
     * <br>
     *
     * @param CurrencyAbbData    決済する通貨名称の文字列byte配列
     * @param ResultCode         決済デバイスの結果コード
     * @param ResultCodeExtended 決済デバイスの結果コード詳細
     * @return チェック結果
     */
    private ApiReturnValues.SetCurrencyAbbreviation inputCheckEMVCL_SetCurrencyAbbreviation(
            byte[] CurrencyAbbData, int[] ResultCode, int[] ResultCodeExtended) {
        final String METHOD_NAME = "inputCheckEMVCL_SetCurrencyAbbreviation";
        startLog(METHOD_NAME);
        ApiReturnValues.SetCurrencyAbbreviation checkStatus = ApiReturnValues.SetCurrencyAbbreviation.E_ILLEGAL;
        boolean isError = false;
        if (!inputCheckResultCode(ResultCode, ResultCodeExtended)) {
            isError = true;
        }

        if (CurrencyAbbData == null) {
            // 無効文字チェックは別層で行う
            Logger.d(TAG, METHOD_NAME + "() CurrencyAbbData not set");
            isError = true;
        }

        if (!isError) {
            checkStatus = ApiReturnValues.SetCurrencyAbbreviation.SUCCESS;
        }

        endLog(METHOD_NAME, checkStatus.name());
        return checkStatus;
    }

    /**
     * R550のFWVersionを取得するAPI。.<br>
     * <br>
     *
     * @return 処理結果：<br>
     *         - 取得した文字列<br>
     */
    public byte[] EMVCL_GetVersion() {
        // 詳細取得
        PFGetStatusRequest  request  = new PFGetStatusRequest();
        PFGetStatusResponse response = new PFGetStatusResponse();

        if (request.isValidValue()) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            byte[] resp;
            resp = mPlatformConfig.deviceSendReceive(request.toCommand(), 5000);
            if (response.inputDeviceResult(resp)) {
                return response.getMemoryStatusInfo();
            }
        }
        return null;
    }

    /**
     * PFの更新を行うAPI。.<br>
     * <br>
     *
     * @param FilePath
     *            PFのファームウェアのファイルパス
     * @return 処理結果：<br>
     *         - 成功:0 失敗:-1<br>
     */
    public int EMVCL_UpdatePF(String FilePath, UpdateNotify callback) {
        return commonUpdate(FilePath, callback, true);
    }

    /**
     * APのアンインストールを行うAPI。.<br>
     * <br>
     *
     * @param id
     *            AP-ID
     * @return 処理結果：<br>
     *         - 成功:0 失敗:-1<br>
     */
    public int EMVCL_UninstallAP(byte id) {
        int ret = -1;
        // 強制アンインストール
        APUninstallForceRequest  request  = new APUninstallForceRequest();
        APUninstallForceResponse response = new APUninstallForceResponse();
        // セットID
        request.setApId(id);

        if (request.isValidValue()) {
            byte[] resp;
            resp = mPlatformConfig.deviceSendReceive(request.toCommand(), 5000);
            if (resp == null) {
                // R550が抜けたか故障(Statusを)
                changeStatus(EMVStatus.EMVCL_CLOSED);
            } else if (response.inputDeviceResult(resp)) {
                ret = 0;
            }
        }
        return ret;
    }

    /**
     * APの更新を行うAPI。.<br>
     * <br>
     *
     * @param FilePath
     *            APのファームウェアのファイルパス
     * @return 処理結果
     */
    public int EMVCL_UpdateAP(String FilePath, UpdateNotify callback) {
        return commonUpdate(FilePath, callback, false);
    }

    private int commonUpdate(String FilePath, final UpdateNotify callback, boolean isPF) {
        if (FilePath == null || callback == null) {
            return -1;
        }
        BaseDownloadStartRequest  startReq;
        BaseDownloadStartResponse startRes;
        BaseDownloadDataRequest   dataReq;
        BaseDownloadDataResponse  dataRes;
        BaseDownloadEndRequest    endReq;
        BaseDownloadEndResponse   endRes;
        BaseDownloadStopRequest   stopReq;
        BaseDownloadStopResponse  stopRes;

        if (isPF) {
            startReq = new PFDownloadStartRequest();
            startRes = new PFDownloadStartResponse();
            dataReq  = new PFDownloadDataRequest();
            dataRes  = new PFDownloadDataResponse();
            endReq   = new PFDownloadEndRequest();
            endRes   = new PFDownloadEndResponse();
            stopReq  = new PFDownloadStopRequest();
            stopRes  = new PFDownloadStopResponse();
        } else {
            startReq = new APDownloadStartRequest();
            startRes = new APDownloadStartResponse();
            dataReq  = new APDownloadDataRequest();
            dataRes  = new APDownloadDataResponse();
            endReq   = new APDownloadEndRequest();
            endRes   = new APDownloadEndResponse();
            stopReq  = new APDownloadStopRequest();
            stopRes  = new APDownloadStopResponse();
        }

        int size;
        FileInputStream input = null;
        try {
            input = new FileInputStream(FilePath);
            size = input.available();
        } catch (IOException e) {
            e.printStackTrace();
            if (input != null) {
                try {
                    input.close();
                } catch (IOException ex) {
                }
            }
            return -1;
        }

        if (size < 1000) {
            return -1;
        }

        byte[] sizeByte = new byte[4];
        sizeByte[0] = (byte) ((size >> 24) & 0x000000ff);
        sizeByte[1] = (byte) ((size >> 16) & 0x000000ff);
        sizeByte[2] = (byte) ((size >> 8) & 0x000000ff);
        sizeByte[3] = (byte) (size & 0x000000ff);
        startReq.setDataSize(sizeByte);
        if (startReq.isValidValue()) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            byte[] resp;
            resp = mPlatformConfig.deviceSendReceive(startReq.toCommand(), 5000);
            if (!startRes.inputDeviceResult(resp)) {
                return -1;
            }
        }

        int len;
        int recordNo = 0;
        int dataSize = (size + 8189) / 8190; 
        int sendNum = 0; 
        int percentage = 90 * 1000 / dataSize;
        int progress = 0;
        byte[] buf = new byte[8190];
        byte[] recordNoByte = new byte[2];
        try {
            while ((len = input.read(buf)) != -1) {
                sendNum++;
                progress = (percentage * sendNum) / 1000;
                callback.notifyProgress(progress);
                recordNoByte[0] = (byte) (((recordNo) >> 8) & 0x00ff);
                recordNoByte[1] = (byte) ((recordNo)  & 0x00ff);
                dataReq.setSendRecordNo(recordNoByte);
                byte[] fwData = new byte[len];
                System.arraycopy(buf, 0, fwData, 0, len);
                dataReq.setRecordData(fwData);
                if (dataReq.isValidValue()) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                    byte[] resp;
                    resp = mPlatformConfig.deviceSendReceive(dataReq.toCommand(), 5000);
                    if (resp == null) {
                        Logger.d(TAG, "commonUpdate() DownloadData request resp null");
                        return -1;
                    } else if (!dataRes.inputDeviceResult(resp)
                      || dataRes.getReceiveRecordNo()[0] != recordNoByte[0]
                      || dataRes.getReceiveRecordNo()[1] != recordNoByte[1]) {
                        Logger.d(TAG, "commonUpdate() result failed");
                        resp = mPlatformConfig.deviceSendReceive(stopReq.toCommand(), 5000);
                        return -1;
                    }
                }
                Arrays.fill(buf, (byte)0x00);
                recordNo++;
            }
        } catch (IOException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
            mPlatformConfig.deviceSendReceive(stopReq.toCommand(), 5000);  // PT_IMPOSSIBLE_INSTRUCTIONS
            return -1;  // PT_IMPOSSIBLE_INSTRUCTIONS
        } finally {
            try {
                input.close();
            } catch (IOException e) {
            }
        }

        if (endReq.isValidValue()) {  // PT_IMPOSSIBLE_BRANCH
            // スレッドを開始させる
            Thread waitThread = new Thread() {
                    @Override
                    public void run() {
                        for (int i = 1; i < 10; i++) {
                            if (isInterrupted()) {
                                break;
                            }
                            callback.notifyProgress(90 + i);
                            try {
                                Thread.sleep(1500);
                            } catch (InterruptedException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                                e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
                                break;
                            }
                        }
                    }
                };
            waitThread.start();
            byte[] resp;
            resp = mPlatformConfig.deviceSendReceive(endReq.toCommand(), 60000);
            if (!endRes.inputDeviceResult(resp)) {
                // スレッド終了させる
                waitThread.interrupt();
                return -1;
            }
            try {
                waitThread.join();
            } catch (InterruptedException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            callback.notifyProgress(100);
        }

        return 0;
    }

    private boolean checkErrorResponse(byte[] checkData, int[] ResultCode, int[] ResultCodeExtended) {
         Logger.d(TAG, "checkData="+ Arrays.toString(checkData));

        // エラーレスポンスかどうかをチェック
        if (checkData == null || ResultCode == null || ResultCodeExtended == null) {
            // dead code
            return true;
        } else if (checkData[1] == (byte)0xff && checkData[2] == (byte)0xff) {
            ResultCode[0] = CommandDataConstants.RESULT_CODE_EMV_PROC_ERROR;
            // errorレスポンス解析
            if (checkData.length > 12) {
                byte mRWStatusFlg = checkData[5];
                byte[] mErrorCode = new byte[2];
                mErrorCode[0] = checkData[9];
                mErrorCode[1] = checkData[10];

                // RW状態フラグ確認
                // タンパ検知
                if ((mRWStatusFlg & CommandDataConstants.ERRES_RW_STS_TAMPER_DETECTION) != 0x00) {
                    ResultCodeExtended[0] = CommandDataConstants.RESULT_CODE_EX_TAMPER_DETECTION;
                    Logger.d(TAG, "TAMPER_DETECTION");
                    return true;
                }

                if (mErrorCode[0] == CommandDataConstants.ERROR_CODE_RESPONSE_SEQ[0]
                        && mErrorCode[1] == CommandDataConstants.ERROR_CODE_RESPONSE_SEQ[1]) {
                    // シーケンスエラー
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_EMV_SEQUENCE_ERROR;
                    Logger.d(TAG, "EMV_SEQUENCE_ERROR");
                } else if ((mErrorCode[0] == CommandDataConstants.ERROR_CODE_RESPONSE_F_TAMPA[0]
                        && mErrorCode[1] == CommandDataConstants.ERROR_CODE_RESPONSE_F_TAMPA[1])
                        ||(mErrorCode[0] == CommandDataConstants.ERROR_CODE_RESPONSE_F_WRITE[0]
                        && mErrorCode[1] == CommandDataConstants.ERROR_CODE_RESPONSE_F_WRITE[1])
                        ||(mErrorCode[0] == CommandDataConstants.ERROR_CODE_RESPONSE_F_INIT[0]
                        && mErrorCode[1] == CommandDataConstants.ERROR_CODE_RESPONSE_F_INIT[1])
                        ||(mErrorCode[0] == CommandDataConstants.ERROR_CODE_RESPONSE_F_KERNEL[0]
                        && mErrorCode[1] == CommandDataConstants.ERROR_CODE_RESPONSE_F_KERNEL[1])) {
                    // 決済デバイスの致命的エラー：イベント実行不可異常（タンパ発生）
                    // 決済デバイスの致命的エラー：FROM書込み異常
                    // 決済デバイスの致命的エラー：FROM初期化エラー
                    // 決済デバイスの致命的エラー：カーネル起動失敗
                    ResultCode[0] = CommandDataConstants.RESULT_CODE_FATAL_ERROR;
                    Logger.d(TAG, "FATAL_ERROR errorCode:" + Arrays.toString(mErrorCode) );
                }

                //拡張エラーコードを格納する(上位バイト：エラーコード、下位バイト0固定)
                long longValue = 0L;

                for (byte setValue : mErrorCode) {
                    longValue = (longValue << 8) + (setValue & 0xff);
                }
                longValue = longValue << 16;
                ResultCodeExtended[0] = (int) longValue;
            }

            return true;
        }
        return false;
    }


    /**
     * AP切替。.<br>
     * <br>
     *
     * @return 処理結果
     */
    private int changeAP() {
        int returnStatus = ApiReturnValues.E_FAILURE;
        APSwitchingRequest apSwitchingRequest = new APSwitchingRequest();
        APSwitchingResponse apSwitchingResponse = new APSwitchingResponse();
        apSwitchingRequest.setApId((byte) 0xD0);

        if (apSwitchingRequest.isValidValue()) {
            byte[] resp;
            resp = mPlatformConfig.deviceSendReceive(apSwitchingRequest.toCommand(), RESPONSE_TIMER_APSWITCHING);
            if (apSwitchingResponse.inputDeviceResult(resp)) {
                returnStatus = ApiReturnValues.SUCCESS;
            }
        }
        return returnStatus;
    }

    /**
     * RW切替。.<br>
     * <br>
     *
     * @return 処理結果
     */
    private int changeRW() {
        int returnStatus = ApiReturnValues.E_FAILURE;
        RWSwitchingRequest rwSwitchingRequest = new RWSwitchingRequest();
        RWSwitchingResponse rwSwitchingResponse = new RWSwitchingResponse();

        if (rwSwitchingRequest.isValidValue()) {
            byte[] resp;
            resp = mPlatformConfig.deviceSendReceive(rwSwitchingRequest.toCommand(), RESPONSE_TIMER_RWSWITCHING);
            if (rwSwitchingResponse.inputDeviceResult(resp)) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                returnStatus = ApiReturnValues.SUCCESS;
            }
        }
        return returnStatus;
    }


    /**
     * 入力された結果コードと詳細コードが正しい値かチェックする,<br>
     * <br>
     *
     * @param resultCode         決済デバイスの結果コード
     * @param resultCodeExtended 決済デバイスの結果コード詳細
     * @return 入力値として正しい場合true
     */
    private boolean inputCheckResultCode(int[] resultCode, int[] resultCodeExtended) {
        final String METHOD_NAME = "inputCheckResultCode";
        startLog(METHOD_NAME);
        boolean isError = false;

        if (resultCode == null) {
            Logger.d(TAG, METHOD_NAME + "() ResultCode not set");
            isError = true;
        }

        if (resultCodeExtended == null) {
            Logger.d(TAG, METHOD_NAME + "() ResultCodeExtended not set");
            isError = true;
        }

        endLog(METHOD_NAME, Boolean.toString(isError));
        return !isError;
    }

    /**
     * 結果コード、詳細を初期化設定(正常)する.<br>
     * <br>
     *
     * @param resultCode         決済デバイスの結果コード
     * @param resultCodeExtended 決済デバイスの結果コード詳細
     */
    private void resultCodeInit(int[] resultCode, int[] resultCodeExtended) {
        resultCode[0] = CommandDataConstants.RESULT_CODE_SUCCESS ;
        setResultCodeExtendedData(resultCodeExtended,
                CommandDataConstants.RESULT_EXTENDED_SUCCESS,
                CommandDataConstants.RESULT_EXTENDED_DETAILED_SUCCESS);
    }

    /**
     * 結果コード、詳細を入力値エラー設定する.<br>
     * <br>
     *
     * @param resultCode         決済デバイスの結果コード
     * @param resultCodeExtended 決済デバイスの結果コード詳細
     */
    private void resultCodeInputError(int[] resultCode, int[] resultCodeExtended) {
        if (resultCode != null && resultCode.length > 0) {
            resultCode[0] = CommandDataConstants.RESULT_CODE_NOT_EMV_PROC_ERROR;
        }
        if (resultCodeExtended != null && resultCodeExtended.length > 0) {
            resultCodeExtended[0] = 0xFFFC0000;
        }
    }

    /**
     * 拡張コード配列に２値の値を設定する.<br>
     *
     * @param resultCodeExtended 設定対象拡張コード配列
     * @param transactionCode 上位２バイトのTransactionCode
     * @param detailCode 下位２バイトのDetailedCode
     */
    private void setResultCodeExtendedData(
            int[] resultCodeExtended, byte[] transactionCode, byte[] detailCode){
        long longValue = 0L;

        for (byte setValue : transactionCode) {
            longValue = (longValue << 8) + (setValue & 0xff);
        }
        for (byte setValue : detailCode) {
            longValue = (longValue << 8) + (setValue & 0xff);
        }
        resultCodeExtended[0] = (int)longValue;
    }

    /**
     * メソッド開始ログ処理.<br>
     * <br>
     * @param methodName メソッド名文字列
     * @param paramArray ログ出力文字配列
     */
    private void startLog(String methodName, String... paramArray) {
        if (paramArray == null || paramArray.length == 0) {
            Logger.d(TAG, methodName + "() Call");
        } else {
            StringBuilder stBuilder = new StringBuilder();
            for (int i = 0; i < paramArray.length; i++) {
                if (i == 0) {
                    stBuilder.append(paramArray[i]);
                } else {
                    stBuilder.append(", ").append(paramArray[i]);
                }
            }
            Logger.d(TAG, methodName + "(" + stBuilder.toString() + ") Call");
        }
    }

    /**
     * メソッド終了ログ処理.<br>
     * <br>
     *
     * @param methodName   メソッド名文字列
     * @param returnName   返却値
     * @param messageArray ログ出力文字配列
     */
    private void endLog(String methodName, String returnName,
                        String... messageArray) {
        StringBuilder messageBuilder = new StringBuilder();
        messageBuilder.append(methodName).append("() End =[")
                .append(returnName).append("]:");
        for (String message : messageArray) {
            messageBuilder.append(message).append(" ");
        }
        Logger.d(TAG, messageBuilder.toString());
    }

    public interface UpdateNotify {
        void notifyProgress(int progress);
    }


    /**
     * 非接触EMV独自APIの状態を強制的にClose状態にするAPI。
     * USBケーブル抜き等により状態不整合になることを回避するために使用する.<br>
     */
    public void EMVCL_ForceClose() {
        // Status変更
        changeStatus(EMVStatus.EMVCL_CLOSED);
        m_CompleteEvent = null;
    }

}
