
package com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.RequestBarcodeReaderData;

/**
 * バーコードリーダを初期化します
 */
public class RequestInitBCR extends RequestBarcodeReaderData {

    /** @brief コマンド種別 - シリアルコマンド後の ACK/NAK 送信を有効 */
    private static final String COMMAND_ID_WC = "WC";

    /** @brief コマンド種別 - 2 次元メニューコードを無効 */
    private static final String COMMAND_ID_D1Z = "D1Z";

    /** @brief コマンド種別 - オートトリガを無効 */
    private static final String COMMAND_ID_PLUS_F = "+F";

    /** @brief コマンド種別 - スキャナの読み取り動作を無効 */
    private static final String COMMAND_ID_EAU = "EAU";

    /** @brief コマンド種別 - コード別プリフィックス設定コマンド(全コード) */
    private static final String COMMAND_ID_RY = "RY";

    /** @brief コマンド種別 - コード別サフィックス設定コマンド(全コード) */
    private static final String COMMAND_ID_RZ = "RZ";

    /** @brief コマンド種別 - コモンプリフィックス設定コマンド */
    private static final String COMMAND_ID_MZ = "MZ";

    /** @brief コマンド種別 - コモンサフィックス設定コマンド */
    private static final String COMMAND_ID_PS = "PS";

    /** @brief コールサイン - CR */
    private static final String CALLSIGN_CR = "1M";

    /** @brief コールサイン - EOT */
    private static final String CALLSIGN_EOT = "1D";

    /**
     * @brief コンストラクタ
     * @param productId プロダクトID
     */
    public RequestInitBCR(int productId) {
        addCommand(COMMAND_ID_WC);
        addCommand(COMMAND_ID_PLUS_F);
        addCommand(COMMAND_ID_RY);
        addCommand(COMMAND_ID_RZ, CALLSIGN_CR);
        addCommand(COMMAND_ID_MZ);
        addCommand(COMMAND_ID_PS, CALLSIGN_EOT);
        if (productId != BarcodeReaderDefine.PID_C_40_C_41) {
            // 一次元バーコードでは定義されないコマンド
            addCommand(COMMAND_ID_D1Z);
            addCommand(COMMAND_ID_EAU);
        }
    }
}
