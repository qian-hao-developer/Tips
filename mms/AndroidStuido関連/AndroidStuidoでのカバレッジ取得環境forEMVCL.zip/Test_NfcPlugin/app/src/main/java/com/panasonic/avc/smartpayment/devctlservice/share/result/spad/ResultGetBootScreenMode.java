
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetBootScreenMode extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetBootScreenMode(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetBootScreenMode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetBootScreenMode> CREATOR = new Parcelable.Creator<ResultGetBootScreenMode>() {

        @Override
        public ResultGetBootScreenMode createFromParcel(Parcel in) {
            return new ResultGetBootScreenMode(in);
        }

        @Override
        public ResultGetBootScreenMode[] newArray(int size) {
            return new ResultGetBootScreenMode[size];
        }
    };
}
