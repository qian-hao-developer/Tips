
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetStatus extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetStatus(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetStatus() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetStatus> CREATOR = new Parcelable.Creator<ResultGetStatus>() {

        @Override
        public ResultGetStatus createFromParcel(Parcel in) {
            return new ResultGetStatus(in);
        }

        @Override
        public ResultGetStatus[] newArray(int size) {
            return new ResultGetStatus[size];
        }
    };
}
