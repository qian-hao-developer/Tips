
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitHMIの実行結果データ
 */
public class ResultInitHMI extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultInitHMI(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitHMI() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitHMI> CREATOR = new Parcelable.Creator<ResultInitHMI>() {
        public ResultInitHMI createFromParcel(Parcel in) {
            return new ResultInitHMI(in);
        }

        public ResultInitHMI[] newArray(int size) {
            return new ResultInitHMI[size];
        }
    };
}
