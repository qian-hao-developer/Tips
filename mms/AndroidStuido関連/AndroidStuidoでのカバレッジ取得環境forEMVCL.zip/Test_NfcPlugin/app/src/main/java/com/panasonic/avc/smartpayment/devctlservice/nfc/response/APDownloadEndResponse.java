package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

/**
 * APダウンロード終了Responseクラス.
 * 
 */
public class APDownloadEndResponse extends BaseDownloadEndResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = APDownloadEndResponse.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x82;

    /** Constructor */
    public APDownloadEndResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }

}

