
package com.panasonic.avc.smartpayment.devctlservice.contesnts;

import com.panasonic.avc.smartpayment.devctlservice.pos.PosSettingsData;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

/**
 * 管理用データベースアクセスクラス
 */
public class ManagementDatabase {

    /** @brief データベースアクセス用インスタンス **/
    private static ManagementDatabase sInstance = new ManagementDatabase();

    /** @brief コンテンツ検索用インスタンス **/
    private ContentResolver mContentResolver;

    /** @brief authority **/
    public static final String AUTHORITY = "com.panasonic.avc.smartpayment.home.launcher.contentprovider";

    /** @brief コンテントURI(プリンタ) **/
    public static final Uri CONTENT_URI_PRINTER = Uri.parse("content://" + AUTHORITY + "/printer");

    public static final Uri CONTENT_URI_LAN = Uri.parse("content://" + AUTHORITY + "/lan");

    public static final String DB_COLUMN_LAN_TYPE = "lan_type";

    /** @brief Density **/
    public static final String DB_COLUMN_PRINTER_DENSITY = "printer_density";

    /** @brief font **/
    public static final String DB_COLUMN_PRINTER_FONT = "printer_font";

    /** @brief cut **/
    public static final String DB_COLUMN_PRINTER_CUT_SLIP = "printer_cut_slip";

    /** @brief コンテントURI(POS) **/
    public static final Uri CONTENT_URI_POS = Uri.parse("content://" + AUTHORITY + "/pos");

    /** @brief interface **/
    public static final String DB_COLUMN_POS_INTERFACE = "pos_interface";

    /** @brief baudrate **/
    public static final String DB_COLUMN_POS_SERIAL_BAUDRATE = "pos_serial_baudrate";

    /** @brief parity **/
    public static final String DB_COLUMN_POS_SERIAL_PARITY = "pos_serial_parity";

    /** @brief block size **/
    public static final String DB_COLUMN_POS_BLOCK_SIZE = "pos_serial_block_size";

    /** @brief settings **/
    public static final Uri CONTENT_URI_SETTINGS = Uri
            .parse("content://" + AUTHORITY + "/settings");

    /** @brief **/
    public static final String DB_COLUMN_SETTINGS_VOLUME = "settings_volume";

    private static final int WIRED = 0;

    /**
     * コンストラクタ
     */
    private ManagementDatabase() {

    }

    /**
     * インスタンスを取得する
     * 
     * @return インスタンス
     */
    public static ManagementDatabase getInstance() {
        return sInstance;
    }

    /**
     * コンテンツ検索用インスタンスを設定する
     * 
     * @param contentResolver
     */
    public void setContentResolver(ContentResolver contentResolver) {
        mContentResolver = contentResolver;
    }

    /**
     * 検索
     * 
     * @return 検索結果
     */
    public ManagementData query() {
        if (mContentResolver == null) {
            return null;
        }

        String[] projection = {
                DB_COLUMN_PRINTER_DENSITY,
                DB_COLUMN_PRINTER_FONT,
                DB_COLUMN_PRINTER_CUT_SLIP
        };
        String selection = "";
        String[] selectionArgs = {};
        int density = 0;
        int font = 0;
        int slip = 0;

        Cursor cursor = mContentResolver.query(CONTENT_URI_PRINTER, projection,
                selection, selectionArgs, null);

        if (cursor == null) {
            return null;
        }

        ManagementData data = null;
        while (cursor.moveToNext()) {
            data = new ManagementData();
            density = cursor.getInt(cursor.getColumnIndex(DB_COLUMN_PRINTER_DENSITY));
            data.setDensity(density);
            font = cursor.getInt(cursor.getColumnIndex(DB_COLUMN_PRINTER_FONT));
            data.setFont(font);
            slip = cursor.getInt(cursor.getColumnIndex(DB_COLUMN_PRINTER_CUT_SLIP));
            data.setSlip(slip);
            break;
        }
        cursor.close();

        return data;
    }

    public boolean getSettingIsWired() {

        String column = DB_COLUMN_LAN_TYPE;

        String[] projection = {
                column
        };
        String selection = "";
        String[] selectionArgs = {};
        int result = 0;

        Cursor cursor = mContentResolver.query(CONTENT_URI_LAN,
                projection,
                selection, selectionArgs,
                null);
        while (cursor.moveToNext()) {
            result = cursor.getInt(cursor.getColumnIndex(column));
        }
        cursor.close();

        return result == WIRED ? true : false;
    }

    /**
     * 検索(POS)
     * 
     * @return 検索結果
     */
    public PosSettingsData queryPosSettings() {
        if (mContentResolver == null) {
            return null;
        }

        String[] projection = {
                DB_COLUMN_POS_INTERFACE,
                DB_COLUMN_POS_SERIAL_BAUDRATE,
                DB_COLUMN_POS_SERIAL_PARITY,
                DB_COLUMN_POS_BLOCK_SIZE
        };
        String selection = "";
        String[] selectionArgs = {};
        int pos_interface = 0;
        int pos_serial_baudrate = 0;
        int pos_serial_parity = 0;
        int pos_block_size = 0;

        Cursor cursor = mContentResolver.query(CONTENT_URI_POS, projection,
                selection, selectionArgs, null);

        if (cursor == null) {
            return null;
        }

        PosSettingsData data = null;
        while (cursor.moveToNext()) {
            pos_interface = cursor.getInt(cursor.getColumnIndex(DB_COLUMN_POS_INTERFACE));
            pos_serial_baudrate = cursor.getInt(cursor
                    .getColumnIndex(DB_COLUMN_POS_SERIAL_BAUDRATE));
            pos_serial_parity = cursor.getInt(cursor.getColumnIndex(DB_COLUMN_POS_SERIAL_PARITY));
            pos_block_size = cursor.getInt(cursor.getColumnIndex(DB_COLUMN_POS_BLOCK_SIZE));
            data = new PosSettingsData(pos_interface, pos_serial_baudrate, pos_serial_parity,
                    pos_block_size);
            break;
        }
        cursor.close();

        return data;
    }

    /**
     * 音量を設定する
     * 
     * @param volume 音量
     */
    public void updateSettingsVolume(int volume) {
        if (mContentResolver == null) {
            return;
        }

        ContentValues values = new ContentValues();
        values.put(DB_COLUMN_SETTINGS_VOLUME, volume);
        mContentResolver.update(CONTENT_URI_SETTINGS, values, null, null);
    }

    /**
     * 「端末設定：音量」を取得
     * 
     * @return int 音量
     */
    public int getSettingsVolume() {
        if (mContentResolver == null) {
            return 0;
        }

        String column = DB_COLUMN_SETTINGS_VOLUME;

        String[] projection = {
                column
        };
        String selection = "";
        String[] selectionArgs = {};
        int result = 0;

        Cursor cursor = mContentResolver.query(CONTENT_URI_SETTINGS,
                projection, selection, selectionArgs, null);
        while (cursor.moveToNext()) {
            result = cursor.getInt(cursor.getColumnIndex(column));
        }
        cursor.close();

        return result;
    }

}
