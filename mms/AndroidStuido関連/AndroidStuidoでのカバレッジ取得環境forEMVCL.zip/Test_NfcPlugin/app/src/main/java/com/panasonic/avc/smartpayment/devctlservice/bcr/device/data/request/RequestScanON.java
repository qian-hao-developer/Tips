
package com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.RequestBarcodeReaderData;

/**
 * バーコードの読み取りを開始します
 */
public class RequestScanON extends RequestBarcodeReaderData {

    /** @brief コマンド種別 - オートトリガを有効 */
    private static final String COMMAND_ID_PLUS_I = "+I";

    /** @brief コマンド種別 - スキャナの読み取り動作を有効 */
    private static final String COMMAND_ID_EAT = "EAT";

    /**
     * @brief コンストラクタ
     * @param productId プロダクトID 
     */
    public RequestScanON(int productId) {
        addCommand(COMMAND_ID_PLUS_I);
        if (productId != BarcodeReaderDefine.PID_C_40_C_41) {
            // 一次元バーコードでは定義されないコマンド
            addCommand(COMMAND_ID_EAT);
        }
    }

}
