
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 拡張LCD設定リクエスト
 */
public class RequestAdvanceLcdSetting extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x02;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 3;

    /** @brief 反転するかどうか */
    private int mReverse;

    /** @brief 反転の設定を変更しない */
    public static final int REVERSE_NO_CHANGE = 0;

    /** @brief 反転OFF */
    private static final int REVERSE_OFF = 1;

    /** @brief 反転ON */
    private static final int REVERSE_ON = 2;

    /**
     * @brief コンストラクタ
     * @param isReverse 反転するかどうか
     */
    public RequestAdvanceLcdSetting(int reverse) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mReverse = reverse;
    }

    /**
     * @brief 反転するかどうかを取得する
     * @return 反転するかどうか
     */
    public int getReverse() {
        return mReverse;
    }

    /**
     * @brief 反転するかどうか設定する
     * @param isReverse 反転するかどうか
     */
    public void setReverse(int reverse) {
        mReverse = reverse;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        if (mReverse == REVERSE_OFF) {
            parameter[2] = (byte) 0x00;
        } else {
            parameter[2] = (byte) 0x01;
        }

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (!(0 <= mReverse && mReverse <= 2)) {
            return false;
        }
        return true;
    }

}
