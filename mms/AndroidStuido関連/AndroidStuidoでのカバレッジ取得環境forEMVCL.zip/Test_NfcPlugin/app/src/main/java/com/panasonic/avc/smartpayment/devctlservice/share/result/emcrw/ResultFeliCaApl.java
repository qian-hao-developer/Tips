
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultFeliCaApl extends ResultData {

    /** @brief 終了コード **/
    private int mEndCode;

    /** @brief 終了サブコード **/
    private int mEndSubCode;

    /**
     * @brief コンストラクタ
     */
    public ResultFeliCaApl(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultFeliCaApl() {

    }

    /**
     * @brief 終了コードを返します
     **/
    public int getEndCode() {
        return mEndCode;
    }

    /**
     * @brief 終了コードを設定します
     **/
    public void setEndCode(int mEndCode) {
        this.mEndCode = mEndCode;
    }

    /**
     * @brief 終了サブコードを返します
     **/
    public int getEndSubCode() {
        return mEndSubCode;
    }

    /**
     * @brief 終了サブコードを設定します
     **/
    public void setEndSubCode(int mEndSubCode) {
        this.mEndSubCode = mEndSubCode;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultFeliCaApl> CREATOR = new Parcelable.Creator<ResultFeliCaApl>() {

        @Override
        public ResultFeliCaApl createFromParcel(Parcel in) {
            return new ResultFeliCaApl(in);
        }

        @Override
        public ResultFeliCaApl[] newArray(int size) {
            return new ResultFeliCaApl[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mEndCode);
        dest.writeInt(mEndSubCode);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mEndCode = in.readInt();
        mEndSubCode = in.readInt();
    }

}
