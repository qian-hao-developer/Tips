package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_SIZE_WITHOUT_PARAMETER;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.ID_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

/**
 * デバイスへのRequestBaseクラス.
 * 
 */
abstract public class BaseRequest {

    /** @brief ログ用タグ */
    protected static final String TAG = BaseRequest.class.getSimpleName();

    /** @brief ID */
    private byte mId = (byte) 0x02;

    /** @brief MC */
    private byte mMainCommand;

    /** @brief SC */
    private byte mSubCommand;

    /** @brief データ部Length */
    private int mDataLength;

    /** Constructor */
    public BaseRequest(byte MainCommand, byte SubCommand) {
        mMainCommand = MainCommand;
        mSubCommand = SubCommand;
    }

    public byte getMainCommand() {
        return mMainCommand;
    }

    public byte getSubCommand() {
        return mSubCommand;
    }

    public int getDataLength() {
        return mDataLength;
    }

    /**
     * @brief データの範囲チェック
     * @return true:正常 false:問題あり
     */
    public boolean isValidValue() {
        return true;
    }

    protected byte[] toCommand(byte[] parameter) {
        // コマンドの全体長取得
        int len = 0;
        if (parameter != null) {
            len = (parameter.length + 15) / 16 * 16;
        }
        mDataLength = len;

        // 配列を確保
        byte[] data = new byte[DATA_SIZE_WITHOUT_PARAMETER + mDataLength];
        // 値を入力
        data[ID_INDEX] = mId;
        data[MAINCOMMAND_INDEX] = mMainCommand;
        data[SUBCOMMAND_INDEX] = mSubCommand;
        data[DATALENGTHHIGH_INDEX] = (byte) (mDataLength & 0x00ff);
        data[DATALENGTHLOW_INDEX] = (byte) ((mDataLength >> 8) & 0x00ff);
        if (mDataLength != 0) {
            System.arraycopy(parameter, 0, data, 5, parameter.length);
        }
        return data;
    }
}
