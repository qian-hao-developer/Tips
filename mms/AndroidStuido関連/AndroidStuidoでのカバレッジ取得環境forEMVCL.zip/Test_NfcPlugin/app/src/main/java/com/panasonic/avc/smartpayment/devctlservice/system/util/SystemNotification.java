
package com.panasonic.avc.smartpayment.devctlservice.system.util;

import android.content.Context;
import android.content.Intent;

import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;

/**
 * Notification用のアイコン表示クラス
 */
public class SystemNotification {
    /** @brief タグ */
    private static final String TAG = "SystemNotification";

    /** @brief ログインスタンス */
    private static LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief 用紙切れアイコン表示アクション */
    public static final String PRINTER_DEVICE_SHOW = "com.panasonic.avc.smartpayment.notification.NoPrinterPaper";

    /** @brief 用紙切れアイコン非表示アクション */
    public static final String PRINTER_DEVICE_DISMISS = "com.panasonic.avc.smartpayment.notification.remove.NoPrinterPaper";

    /** @brief デバイス異常アイコン表示アクション */
    public static final String OTHER_DEVICE_SHOW = "com.panasonic.avc.smartpayment.notification.DeviceInfo";

    /** @brief デバイス異常アイコン非表示アクション */
    public static final String OTHER_DEVICE_DISMISS = "com.panasonic.avc.smartpayment.notification.remove.DeviceInfo";

    /** @brief アイコンタイプ */
    public enum IconType {
        PRINTER_DEVICE,
        OTHER_DEVICE
    }

    /**
     * 通知アイコン表示
     * 
     * @param context コンテキスト
     * @param type 種類
     */
    public static void notifyShowIcon(Context context, IconType type) {
        if (context == null) {
            return;
        }

        Intent intent = null;
        switch (type) {
            case PRINTER_DEVICE:
                intent = new Intent(PRINTER_DEVICE_SHOW);
                break;
            case OTHER_DEVICE:
                intent = new Intent(OTHER_DEVICE_SHOW);
                break;
            default:
                break;
        }

        if (intent != null) {
            context.sendBroadcast(intent);
        }
    }

    /**
     * 通知アイコン非表示
     * 
     * @param context コンテキスト
     * @param type 種類
     */
    public static void notifyDismissIcon(Context context, IconType type) {
        if (context == null) {
            return;
        }

        Intent intent = null;
        switch (type) {
            case PRINTER_DEVICE:
                intent = new Intent(PRINTER_DEVICE_DISMISS);
                break;
            case OTHER_DEVICE:
                intent = new Intent(OTHER_DEVICE_DISMISS);
                break;
            default:
                break;
        }

        if (intent != null) {
            context.sendBroadcast(intent);
        }
    }

}
