
package com.panasonic.avc.smartpayment.devctlservice.bcr.device.data;

import java.util.ArrayList;
import java.util.List;

import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;

/**
 * バーコードリーダ要求データ
 */
public class RequestBarcodeReaderData {

    /** @brief コマンド種別リスト */
    private List<String> mCommandIdList = new ArrayList<String>();

    /** @brief コマンド引数リスト */
    private List<String> mCommandArgsList = new ArrayList<String>();

    /**
     * @brief コンストラクタ
     */ 
    public RequestBarcodeReaderData() {

    }

    /**
     * @brief コマンド追加
     * @param commandId コマンド種別
     */
    protected void addCommand(String commandId) {
        addCommand(commandId, "");
    }

    /**
     * @brief コマンド追加
     * @param commandId コマンド種別
     * @param commandArgs コマンド引数
     */
    protected void addCommand(String commandId, String commandArgs) {
        switch (commandId.length()) {
            case 3:
                mCommandIdList.add("[" + commandId);
                break;
            case 4:
                mCommandIdList.add("]" + commandId);
                break;
            case 5:
                mCommandIdList.add("{" + commandId);
                break;
            default:
                mCommandIdList.add(commandId);
                break;
        }
        mCommandArgsList.add(commandArgs);
    }

    /**
     * @brief コマンドパケットを作成する
     * @return コマンドパケット
     */
    public byte[] toCommand() {

        byte[] data = new byte[calcCommandLength()];

        data[0] = BarcodeReaderDefine.STX_CODE;
        int index = BarcodeReaderDefine.STX_SIZE;
        for (int i = 0; i < mCommandIdList.size(); i++) {
            byte[] commandId = mCommandIdList.get(i).getBytes();
            System.arraycopy(commandId, 0, data, index, commandId.length);
            index += commandId.length;
            byte[] commandArgs = mCommandArgsList.get(i).getBytes();
            System.arraycopy(commandArgs, 0, data, index, commandArgs.length);
            index += commandArgs.length;
        }
        data[data.length - 1] = BarcodeReaderDefine.ETX_CODE;

        return data;
    }

    /**
     * @brief データの上限下限チェック
     * @return 問題があるかどうか
     */
    public boolean isValidValue() {
        if (mCommandIdList.isEmpty()) {
            // 送信するコマンドがありません
            return false;
        }
        if (mCommandIdList.size() > 1) {
            for (int i = 0; i < mCommandIdList.size(); i++) {
                byte[] commandId = mCommandIdList.get(i).getBytes();
                if (commandId.length == 1) {
                    // シングルコマンド (1 桁) は複数続けて送信できません
                    return false;
                }
            }
        }
        if (calcCommandLength() > 1000) {
            // コマンドパケットバッファの最大サイズは 1000 文字です
            return false;
        }
        return true;
    }

    /**
     * @brief コマンドパケットの長さを計算する
     * @return コマンドパケットの長さ
     */
    private int calcCommandLength() {
        int ret = BarcodeReaderDefine.STX_SIZE + BarcodeReaderDefine.ETX_SIZE;
        for (int i = 0; i < mCommandIdList.size(); i++) {
            byte[] commandId = mCommandIdList.get(i).getBytes();
            ret += commandId.length;
            byte[] commandArgs = mCommandArgsList.get(i).getBytes();
            ret += commandArgs.length;
        }
        return ret;
    }

}
