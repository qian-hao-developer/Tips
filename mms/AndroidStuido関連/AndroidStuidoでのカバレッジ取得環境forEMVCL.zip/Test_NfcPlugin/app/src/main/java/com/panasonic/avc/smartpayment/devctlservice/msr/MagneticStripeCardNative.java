
package com.panasonic.avc.smartpayment.devctlservice.msr;

import com.panasonic.avc.smartpayment.devctlservice.msr.data.arg.ArgmentStartGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseMsData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultMakeTransactionKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultCancelGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultInitMSR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultStartGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultTermMSR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultGetSignatureKey;

/**
 * Nativeコール用クラス
 */
public class MagneticStripeCardNative {

    static {
        System.loadLibrary("msrx");
    }

    /** @brief コールバック用インターフェース */
    public interface OnMsrListener {
        /**
         * @brief 磁気データを通知します
         * @param[in] result 磁気データ
         */
        public void onResultMsData(ResponseMsData result, int device_error);

        /**
         * @brief 周辺装置からのエラーを通知します
         * @param[in] result 周辺装置からのエラーイベント結果
         */
        public void onError(ResponseError result);

        /**
         * @see LoggingManager#putLogDevice(int, int, int, int, String)
         */
        public void onLogDevice(int deviceType, int errorCode, int extraData,
                int cmdCode, String info);

    }

    /** @brief コールバック用インターフェース */
    public interface OnMsrTamperListener {
        /**
         * @brief 磁気トラックデータ読み取り停止完了を通知します
         */
        public void onPausedGetMSRead();

    }

    /** @brief 磁気カードリーダを初期化 */
    public native void nativeInitMSR(ResultInitMSR result);

    /** @brief 磁気カード読み取り開始 */
    public native void nativeStartGetMSRead(ResultStartGetMSRead result, ArgmentStartGetMSRead arg);

    /** @brief 磁気カードの読み取りを解除 */
    public native void nativeCancelGetMSRead(ResultCancelGetMSRead result);

    /** @brief 磁気カードリーダ利用可否情報 */
    public native void nativeCheckHealth(ResultCheckHealth result);

    /** @brief 磁気カードリーダの製品品番、シリアル番号、ハード構成情報、APL Version、PF Version情報を取得 */
    public native void nativeGetVersionInfo(ResultGetVersionInfo reslut);

    /** @brief 磁気カードリーダをターミネート */
    public native void nativeTermMSR(ResultTermMSR result);

    /** @brief DUKPT 生成を要求 */
    public native void nativeMakeTransactionKey(ResultMakeTransactionKey result);

    /** @brief 耐タンパメモリから署名用の鍵を取得する */
    public native void nativeGetSignatureKey(ResultGetSignatureKey result);

    /** @brief Emcrw 用元マスターキーを取得する */
    public native byte[] nativeGetEmcrwMasterKeySeeds(int index);

    /** @brief タンパ要因を取得します */
    public native int nativeGetFactorOfTamper();

    /** @brief タンパ予兆情報を取得します */
    public native int nativeGetOmenOfTamper();

    /** @brief 磁気カード読み取りを一時停止します（タンパ割り込み処理用） */
    public native int nativeSuspendGetMSRead();

    /** @brief 磁気カード読み取りを再開します（タンパ割り込み処理用） */
    public native int nativeResumeGetMSRead();

    /** @brief インスタンス */
    private static MagneticStripeCardNative sInstance = new MagneticStripeCardNative();

    /** @brief 磁気カードイベントリスナー */
    private OnMsrListener mOnMsrListener;

    /** @brief タンパイベントリスナー */
    private OnMsrTamperListener mOnMsrTamperListener;

    /**
     * @brief コンストラクタ
     */
    protected MagneticStripeCardNative() {

    }

    /**
     * @brief シングルトンインスタンスを取得する
     * @return インスタンス
     */
    public static MagneticStripeCardNative getInstance() {
        return sInstance;
    }

    /**
     * @brief 磁気カードイベントリスナーをセットする
     * @param[in] listener リスナー
     */
    public void setOnMsrListener(OnMsrListener listener) {
        mOnMsrListener = listener;
    }

    /**
     * @brief タンパイベントリスナーをセットする
     * @param[in] listener リスナー
     */
    public void setOnMsrTamperListener(OnMsrTamperListener listener) {
        mOnMsrTamperListener = listener;
    }

    /**
     * @brief 磁気カードを通知します
     * @param mode 読み取りオプション
     * @param result 磁気カード読み取り操作情報
     * @param sts_jis2 トラックデータ(JIS-Ⅱ)の状態
     * @param sts_jis1track1 トラックデータ(JIS-ⅠTrack1)の状態
     * @param sts_jis1track2 トラックデータ(JIS-ⅠTrack2)の状態
     * @param trackdata 暗号化されたトラックデータ
     * @param ksn トランザクションキー情報
     * @param len_jis2 トラックデータ(JIS-Ⅱ)のデータ長
     * @param len_jis1track1 トラックデータ(JIS-ⅠTrack1)のデータ長
     * @param len_jis1track2 トラックデータ(JIS-ⅠTrack2)のデータ長
     * @param chk_jis2 トラックデータ(JIS-Ⅱ)の検査結果
     * @param chk_jis1track1 トラックデータ(JIS-ⅠTrack1)の検査結果
     * @param chk_jis1track2 トラックデータ(JIS-ⅠTrack2)の検査結果
     */
    public void notifyMsData(int mode, int result, int sts_jis2, int sts_jis1track1,
            int sts_jis1track2,
            String trackdata, String ksn, int len_jis2, int len_jis1track1, int len_jis1track2,
            int chk_jis2, int chk_jis1track1, int chk_jis1track2, int device_error) {
        if (mOnMsrListener == null) {
            return;
        }
        ResponseMsData resultData = new ResponseMsData(mode, result, sts_jis2, sts_jis1track1,
                sts_jis1track2, trackdata, ksn, len_jis2, len_jis1track1, len_jis1track2, chk_jis2,
                chk_jis1track1, chk_jis1track2);
        mOnMsrListener.onResultMsData(resultData, device_error);
    }

    /**
     * @brief 磁気カードイベントのコールバック
     * @param mode 読み取りオプション
     * @param result 磁気カード読み取り操作情報
     * @param sts_jis2 トラックデータ(JIS-Ⅱ)の状態
     * @param sts_jis1track1 トラックデータ(JIS-ⅠTrack1)の状態
     * @param sts_jis1track2 トラックデータ(JIS-ⅠTrack2)の状態
     * @param trackdata 暗号化されたトラックデータ
     * @param ksn トランザクションキー情報
     * @param len_jis2 トラックデータ(JIS-Ⅱ)のデータ長
     * @param len_jis1track1 トラックデータ(JIS-ⅠTrack1)のデータ長
     * @param len_jis1track2 トラックデータ(JIS-ⅠTrack2)のデータ長
     * @param chk_jis2 トラックデータ(JIS-Ⅱ)の検査結果
     * @param chk_jis1track1 トラックデータ(JIS-ⅠTrack1)の検査結果
     * @param chk_jis1track2 トラックデータ(JIS-ⅠTrack2)の検査結果
     */
    private static void nativeNotifyMsData(int mode, int result, int sts_jis2, int sts_jis1track1,
            int sts_jis1track2,
            String trackdata, String ksn, int len_jis2, int len_jis1track1, int len_jis1track2,
            int chk_jis2, int chk_jis1track1, int chk_jis1track2, int device_error) {
        getInstance().notifyMsData(mode, result, sts_jis2, sts_jis1track1, sts_jis1track2,
                trackdata, ksn, len_jis2, len_jis1track1, len_jis1track2, chk_jis2, chk_jis1track1,
                chk_jis1track2, device_error);
    }

    /**
     * @brief エラーイベントを通知する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    public void notifyError(int ecode, int vcode, int extcode, String extinfo) {
        if (mOnMsrListener == null) {
            return;
        }
        ResponseError result = new ResponseError(ecode, vcode, extcode, extinfo);
        mOnMsrListener.onError(result);
    }

    /**
     * @brief エラーイベントのコールバック
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private static void nativeNotifyError(int ecode, int vcode, int extcode, String extinfo) {
        getInstance().notifyError(ecode, vcode, extcode, extinfo);
    }

    /**
     * @see LoggingManager#putLogDevice(int, int, int, int, String)
     */
    public void notifyLogDevice(int deviceType, int errorCode, int extraData,
            int cmdCode, String info) {
        if (mOnMsrListener == null) {
            return;
        }
        mOnMsrListener.onLogDevice(deviceType, errorCode, extraData, cmdCode, info);
    }

    /**
     * @see LoggingManager#putLogDevice(int, int, int, int, String)
     */
    private static void nativeNotifyLogDevice(int deviceType, int errorCode, int extraData,
            int cmdCode, String info) {
        getInstance().notifyLogDevice(deviceType, errorCode, extraData, cmdCode, info);
    }

    /**
     * @brief 磁気トラックデータ読み取り停止完了を通知する
     */
    public void notifyPausedGetMSRead() {
        if (mOnMsrTamperListener == null) {
            return;
        }
        mOnMsrTamperListener.onPausedGetMSRead();
    }

    /**
     * @brief 磁気トラックデータ読み取り停止完了を通知する
     */
    private static void nativeNotifyPausedGetMSRead() {
        getInstance().notifyPausedGetMSRead();
    }

}
