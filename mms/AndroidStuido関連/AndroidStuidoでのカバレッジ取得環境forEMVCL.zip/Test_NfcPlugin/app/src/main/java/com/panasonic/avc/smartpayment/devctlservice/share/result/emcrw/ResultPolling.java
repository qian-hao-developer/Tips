
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultPolling extends ResultFeliCaApl {

    /** @brief 検出した枚数 **/
    private int mNum;

    /** @brief 検出したカードのIDm **/
    private String mIdm;

    /** @brief 検出したカードのPmm **/
    private String mPmm;

    /**
     * @brief コンストラクタ
     */
    public ResultPolling(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPolling() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPolling> CREATOR = new Parcelable.Creator<ResultPolling>() {

        @Override
        public ResultPolling createFromParcel(Parcel in) {
            return new ResultPolling(in);
        }

        @Override
        public ResultPolling[] newArray(int size) {
            return new ResultPolling[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mNum);
        dest.writeString(mIdm);
        dest.writeString(mPmm);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mNum = in.readInt();
        mIdm = in.readString();
        mPmm = in.readString();
    }

    /**
     * @brief 検出した枚数を返します
     **/
    public int getNum() {
        return mNum;
    }

    /**
     * @brief 検出した枚数を設定します
     **/
    public void setNum(int mNum) {
        this.mNum = mNum;
    }

    /**
     * @brief 検出したカードのIDmを返します
     **/
    public String getIdm() {
        return mIdm;
    }

    /**
     * @brief 検出したカードのIDmを設定します
     **/
    public void setIdm(String idm) {
        mIdm = idm;
    }

    /**
     * @brief 検出したカードのPmmを返します
     **/
    public String getPmm() {
        return mPmm;
    }

    /**
     * @brief 検出したカードのPmmを設定します
     **/
    public void setPmm(String pmm) {
        mPmm = pmm;
    }
}
