
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * StartGetFuncKeyの実行結果データ
 */
public class ResultStartGetFuncKey extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultStartGetFuncKey(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultStartGetFuncKey() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultStartGetFuncKey> CREATOR = new Parcelable.Creator<ResultStartGetFuncKey>() {
        public ResultStartGetFuncKey createFromParcel(Parcel in) {
            return new ResultStartGetFuncKey(in);
        }

        public ResultStartGetFuncKey[] newArray(int size) {
            return new ResultStartGetFuncKey[size];
        }
    };
}
