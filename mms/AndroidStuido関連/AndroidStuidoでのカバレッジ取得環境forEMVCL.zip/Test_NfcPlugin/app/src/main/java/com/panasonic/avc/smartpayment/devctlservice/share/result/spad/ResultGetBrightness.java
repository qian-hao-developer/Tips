
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetBrightness extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetBrightness(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetBrightness() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetBrightness> CREATOR = new Parcelable.Creator<ResultGetBrightness>() {

        @Override
        public ResultGetBrightness createFromParcel(Parcel in) {
            return new ResultGetBrightness(in);
        }

        @Override
        public ResultGetBrightness[] newArray(int size) {
            return new ResultGetBrightness[size];
        }
    };
}
