package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * RWリセットRequestクラス.
 * 
 */
public class RWResetRequest extends BaseRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = RWResetRequest.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x20;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x00;

    /** Constructor */
    public RWResetRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        // データ部なし
        return super.toCommand(null);
    }
}
