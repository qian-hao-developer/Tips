
package com.panasonic.avc.smartpayment.devctlservice.share;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.log.Logger;
import com.panasonic.avc.smartpayment.devctlservice.log.Logger.LogLevel;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogService;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * シンクラ端末ログ管理サービスへログを送信
 */
public class LoggingManager {

    /** @brief シングルトンインスタンス */
    private static LoggingManager sInstance = new LoggingManager();

    /** @brief TcLogサービス用インターフェース */
    private ITcLogService mITcLogService;

    /** @brief Android ログ表示クラス */
    private Logger mLogger;

    /**
     * @brief コンストラクタ
     */
    private LoggingManager() {
        mLogger = new Logger(LogLevel.DEBUG);
    }

    /**
     * @brief シングルトンインスタンス取得
     */
    public static LoggingManager getInstance() {
        return sInstance;
    }

    /**
     * @brief 初期化
     */
    public void init(Context context) {
        if (mITcLogService != null) {
            return;
        }
        Intent intent = new Intent(ITcLogService.class.getName());
        context.bindService(intent, mTcLogServiceConnection, Activity.BIND_AUTO_CREATE);
    }

    /**
     * @brief 終了処理
     */
    public void term(Context context) {
        if (mITcLogService == null) {
            return;
        }
        context.unbindService(mTcLogServiceConnection);
        mITcLogService = null;
    }

    /**
     * @brief 端末情報表示ログを送信（スレッドセーフ）
     * @param infoString 端末情報
     */
    @SuppressWarnings("deprecation")
    public void putLogInfoString(String infoString) {
        if (mITcLogService == null) {
            return;
        }
        synchronized (mITcLogService) {
            try {
                mITcLogService.putLogTerminalStatus(infoString);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @brief デバイス異常のログを送信（スレッドセーフ）
     * @param deviceType デバイス略称
     * @param extraData ステータスコードまたは数値(-1:指定なし)
     * @see ITcLogServiceConstants.DeviceType
     */
    public void putLogSecurity(int deviceType, int extraData) {
        if (mITcLogService == null) {
            return;
        }
        synchronized (mITcLogService) {
            try {
                mITcLogService.putLogSecurity(deviceType, extraData);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @brief デバイス異常のログを送信（スレッドセーフ）
     * @param deviceType デバイス略称
     * @param errorCode エラーコード
     * @param extraData ステータスコードまたは数値(-1:指定なし)
     * @param cmdCode 応答電文のコマンド種別
     * @param info 発生事象の説明(null:指定なし)
     * @see ITcLogServiceConstants.DeviceType
     */
    public void putLogDevice(int deviceType, int errorCode, int extraData,
            int cmdCode, String info) {
        if (mITcLogService == null) {
            return;
        }
        synchronized (mITcLogService) {
            try {
                mITcLogService.putLogDevice(deviceType, errorCode, extraData, cmdCode, info);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @brief デバイス異常のログを送信（スレッドセーフ）
     * @param deviceType デバイス略称
     * @param errorCode エラーコード
     * @param extraData ステータスコードまたは数値(-1:指定なし)
     * @param mainCmdCode 応答電文のメインコマンド
     * @param subCmdCode 応答電文のサブコマンド
     * @param info 発生事象の説明(null:指定なし)
     * @see ITcLogServiceConstants.DeviceType
     */
    public void putLogDevice(int deviceType, int errorCode, int extraData, int mainCmdCode,
            int subCmdCode, String info) {
        int cmdCode = subCmdCode << 8 | mainCmdCode;
        putLogDevice(deviceType, errorCode, extraData, cmdCode, info);
    }

    /**
     * @see Logger#v(String, String)
     */
    public void v(String tag, String text) {
        mLogger.v(tag, text);
    }

    /**
     * @see Logger#d(String, String)
     */
    public void d(String tag, String text) {
        mLogger.d(tag, text);
    }

    /**
     * @see Logger#i(String, String)
     */
    public void i(String tag, String text) {
        mLogger.i(tag, text);
    }

    /**
     * @see Logger#w(String, String)
     */
    public void w(String tag, String text) {
        mLogger.w(tag, text);
    }

    /**
     * @see Logger#e(String, String)
     */
    public void e(String tag, String text) {
        mLogger.e(tag, text);
    }

    /**
     * @see Logger#a(String, String)
     */
    public void a(String tag, String text) {
        mLogger.a(tag, text);
    }

    /**
     * @see Logger#getLogLevel()
     */
    public LogLevel getLogLevel() {
        return mLogger.getLogLevel();
    }

    /**
     * @see Logger#setLogLevel(LogLevel)
     */
    public void setLogLevel(LogLevel logLevel) {
        mLogger.setLogLevel(logLevel);
    }

    /**
     * @see ServiceConnection
     */
    private ServiceConnection mTcLogServiceConnection = new ServiceConnection() {

        /**
         * @see ServiceConnection#onServiceConnected(ComponentName, IBinder)
         */
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mITcLogService = ITcLogService.Stub.asInterface(service);
        }

        /**
         * @see ServiceConnection#onServiceDisconnected(ComponentName)
         */
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mITcLogService = null;
        }
    };

}
