
package com.panasonic.avc.smartpayment.devctlservice.pos;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.contesnts.ManagementDatabase;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pos.device.data.request.RequestSendPos;
import com.panasonic.avc.smartpayment.devctlservice.share.IPosServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.pos.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.pos.ResponseReceivePOS;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.pos.ResultInitPOS;
import com.panasonic.avc.smartpayment.devctlservice.share.result.pos.ResultSendPOS;
import com.panasonic.avc.smartpayment.devctlservice.share.result.pos.ResultTermPOS;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * POS 連動処理部
 */
public class PointOfSaleSystem {

    /** @brief ログ出力用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = PointOfSaleSystem.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static PointOfSaleSystem sInstance = new PointOfSaleSystem();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IPosServiceListener> mIPosServiceListenerList = new ConcurrentHashMap<String, IPosServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief コンテキスト */
    private Context mContext;

    /** @brief データ読み込み終了フラグ */
    private boolean mIsActive;

    /** @brief データベース用インスタンス */
    private ManagementDatabase mManagementDatabase = ManagementDatabase.getInstance();

    /** @brief 非同期用スレッド(ReceivePOS) */
    private Thread mReceivePOSThread;

    /** @brief ループ間隔 */
    private static final int CYCLE_TIME = 500;

    /**
     * @brief コンストラクタ
     */
    private PointOfSaleSystem() {
    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static PointOfSaleSystem getInstance() {
        return sInstance;
    }

    /**
     * @brief POS 連動プラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerPosServiceListener(String tag, IPosServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIPosServiceListenerList) {
            mIPosServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief POS 連動プラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterPosServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIPosServiceListenerList) {
            mIPosServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief POS 連動 Plug-In を初期化します
     * @return 実行結果
     */
    public ResultInitPOS initPOS() {
        ResultInitPOS result = new ResultInitPOS();

        if (mControlDeviceManager == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        // DB から POS の設定値を取得
        PosSettingsData setting = mManagementDatabase.queryPosSettings();
        int deviceInterface = setting.getInterface();
        int baudrate = setting.getBaudrate();
        int parity = setting.getParity();
        int blocksz = setting.getBlockSize();

        if (mReceivePOSThread != null && mReceivePOSThread.isAlive()) {
            try {
                mIsActive = false;
                mReceivePOSThread.join();
            } catch (InterruptedException e) {
            }
        }

        if (mControlDeviceManager.isActive()) {
            mControlDeviceManager.term();
        }

        if (!mControlDeviceManager.init(deviceInterface, baudrate, parity)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        result.setBlockSize(blocksz);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

        mIsActive = true;

        mReceivePOSThread = new Thread() {
            @Override
            public void run() {
                while (mIsActive) {
                    long start = System.currentTimeMillis();

                    if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                        notifyPOSError(new ResponseError(PluginDefine.ECODE_PORT_ERROR, 0,
                                PluginDefine.ERROR_EXT_CODE_NULL, null));
                        return;
                    }

                    // 読み込みタイムアウト時間は libposx.so で定義
                    byte[] buf = mControlDeviceManager.read(-1);
                    ResponseReceivePOS response = new ResponseReceivePOS();

                    if (!mIsActive) {
                        // 受信中に term された場合は、受信結果を通知しない
                        return;
                    }

                    if (!isTimeout(buf)) {
                        if (response.inputPinpadResult(buf)) {
                            notifyReceivePOS(response);
                        }
                    }

                    long now = System.currentTimeMillis();
                    if ((now - start) < CYCLE_TIME) {
                        try {
                            sleep(CYCLE_TIME - (now - start));
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                }
            }
        };

        mReceivePOSThread.start();

        return result;
    }

    /**
     * @brief POSにデータを送信します
     * @param[in] datasz 送信データサイズを指定(整数型)します
     * @param[in] data 送信データを指定(文字列型)します
     * @param[in] blocksz ブロック送信する場合のブロックサイズを指定を指定(整数型)します
     * @return 実行結果
     */
    public ResultSendPOS sendPOS(int datasz, String data, int blocksz) {
        ResultSendPOS result = new ResultSendPOS();

        RequestSendPos requestSendPos = new RequestSendPos(datasz, data, blocksz);

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!requestSendPos.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        boolean ret = mControlDeviceManager.write(requestSendPos);
        if (ret) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        } else {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        }

        return result;
    }

    /**
     * @brief Plug-Inのパッケージ情報を取得します。周辺装置とのやり取りは発生しません。
     * @return 実行結果
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer,
            String pluginName, String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, PointOfSaleSystem.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief POS 連動 Plug-In をターミネートします
     * @return 実行結果
     */
    public ResultTermPOS termPOS() {
        mIsActive = false;

        ResultTermPOS result = new ResultTermPOS();

        mControlDeviceManager.term();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        if (isShowError(result.getUpos())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    private void notifyReceivePOS(ResponseReceivePOS result) {
        synchronized (mIPosServiceListenerList) {
            for (Map.Entry<String, IPosServiceListener> listener : mIPosServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onReceivePOS(result);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void notifyPOSError(ResponseError result) {
        synchronized (mIPosServiceListenerList) {
            for (Map.Entry<String, IPosServiceListener> listener : mIPosServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(result);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer.length == 0) {
            return true;
        }
        return false;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param upos UPOSの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int upos) {
        if (upos == PluginDefine.RESULT_UPOS_FATAL) {
            return true;
        }

        return false;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }
}
