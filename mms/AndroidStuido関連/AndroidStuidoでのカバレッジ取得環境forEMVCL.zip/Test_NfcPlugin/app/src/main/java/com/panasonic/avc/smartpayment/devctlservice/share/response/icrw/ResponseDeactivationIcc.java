
package com.panasonic.avc.smartpayment.devctlservice.share.response.icrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * DeactivationEventデータ
 */
public class ResponseDeactivationIcc extends ResponseData implements Parcelable {

    /** @brief 非活性化処理結果 */
    private int mResult;

    /** @brief 非活性化処理結果タグ */
    private static final String RESULT = "result";
    /** @brief マスターコマンド **/
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド **/
    private static final byte SUB_COMMAND = 0x04;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x0008;

    /** @brief 活性化状態 **/
    private static final int PINPAD_ACTIVATION = 0x0a;

    /** @brief 非活性化状態 **/
    private static final int PINPAD_DEACTIVATION = 0x0d;

    /** @brief 非活性化できた場合 **/
    public static final int RESULT_SUCCESS_DEACTIVATION = 0;

    /** @brief 非活性化できなかった場合 **/
    public static final int RESULT_FAIL_DEACTIVATION = 1;

    /** @brief タイムアウト場合 **/
    public static final int RESULT_TIMEOUT = 2;

    /**
     * @brief コンストラクタ
     * @param result 非活性化処理結果
     */
    public ResponseDeactivationIcc(int result) {
        mResult = result;
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseDeactivationIcc(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseDeactivationIcc() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponseDeactivationIcc> CREATOR = new Parcelable.Creator<ResponseDeactivationIcc>() {

        /**
         * @see Parcelable.Creator#createFromParcel(Parcel)
         */
        public ResponseDeactivationIcc createFromParcel(Parcel in) {
            return new ResponseDeactivationIcc(in);
        }

        /**
         * @see Parcelable.Creator#newArray(int)
         */
        public ResponseDeactivationIcc[] newArray(int size) {
            return new ResponseDeactivationIcc[size];
        }
    };

    /**
     * @see Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mResult);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mResult = in.readInt();
    }

    /**
     * @brief 非活性化処理結果を取得する
     * @return 非活性化処理結果
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @brief 非活性化処理結果を設定する
     * @param 非活性化処理結果
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            return false;
        }

        int error = buffer[PinpadDefine.INDEX_PARAMETER + 5];
        int sensor = buffer[PinpadDefine.INDEX_PARAMETER + 6];
        int status = buffer[PinpadDefine.INDEX_PARAMETER + 7];

        switch (status) {
            case PINPAD_ACTIVATION:
                mResult = RESULT_FAIL_DEACTIVATION;
                break;
            case PINPAD_DEACTIVATION:
                mResult = RESULT_SUCCESS_DEACTIVATION;
                break;
            default:
                return false;
        }

        return true;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(RESULT, getResult());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
