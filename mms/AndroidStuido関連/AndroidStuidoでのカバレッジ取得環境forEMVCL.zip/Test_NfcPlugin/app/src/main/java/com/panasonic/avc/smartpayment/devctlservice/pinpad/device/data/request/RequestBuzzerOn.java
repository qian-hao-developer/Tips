
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * ブザー鳴動コマンド
 */
public class RequestBuzzerOn extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x20;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x04;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 4;

    /** @brief 短鳴動(100ms) */
    private static final int BUZZER_TYPE_1 = 1;

    /** @brief 短鳴動(200ms) */
    private static final int BUZZER_TYPE_2 = 2;

    /** @brief 長鳴動(1s) */
    private static final int BUZZER_TYPE_3 = 3;

    /** @brief 周期鳴動(100ms×3) */
    private static final int BUZZER_TYPE_4 = 4;

    /** @brief 周期鳴動(100ms×4) */
    private static final int BUZZER_TYPE_5 = 5;

    /** @brief カード排出ガイダンス音声 */
    private static final int SOUND_TYPE_1 = 1;

    /** @brief 選択誘導ガイダンス音声 */
    private static final int SOUND_TYPE_2 = 2;

    /** @brief 音声切り替えを行わない */
    public static final int SOUND_NO_CHANGE = 0;

    /** @brief 音量大 **/
    private static final int VOLUME_LARGE = 4;

    /** @brief 音量中 **/
    private static final int VOLUME_MIDIUM = 3;

    /** @brief 音量小 **/
    private static final int VOLUME_SMALL = 2;

    /** @brief 消音 **/
    private static final int VOLUME_SILENT = 1;

    /** @brief デフォルト **/
    public static final int VOLUME_DEFAULT = 0;

    /**
     * @brief ブザー設定
     */
    private enum BuzzerONVolume {
        VOLUME_DEFAULT((byte) 0x04),
        VOLUME_LARGE((byte) 0x03),
        VOLUME_MIDIUM((byte) 0x02),
        VOLUME_SMALL((byte) 0x01),
        VOLUME_SILENT((byte) 0x00);

        private final byte mValue;

        private BuzzerONVolume(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }
    }

    /**
     * @brief ブザーパターン
     */
    public enum BuzzerPattern {
        STOP((byte) 0x00),
        PATTERN1((byte) 0x01),
        PATTERN2((byte) 0x02),
        PATTERN3((byte) 0x03),
        PATTERN4((byte) 0x04),
        PATTERN5((byte) 0x05),
        PATTERN6((byte) 0x06),
        PATTERN7((byte) 0x07),
        PIN((byte) 0x20),
        REMOVE((byte) 0x21),
        SELECT((byte) 0x22);

        private final byte mValue;

        private BuzzerPattern(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }
    }

    /** @brief ブザー鳴動音量 */
    private BuzzerONVolume mBuzzerONVolume;

    /** @brief ブザーパターン */
    private BuzzerPattern mBuzzerPattern;

    /**
     * @brief コンストラクタ
     */
    public RequestBuzzerOn(int volume, boolean isBuzzer, int type) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;

        switch (volume) {
            case VOLUME_LARGE:
                mBuzzerONVolume = BuzzerONVolume.VOLUME_LARGE;
                break;
            case VOLUME_MIDIUM:
                mBuzzerONVolume = BuzzerONVolume.VOLUME_MIDIUM;
                break;
            case VOLUME_SMALL:
                mBuzzerONVolume = BuzzerONVolume.VOLUME_SMALL;
                break;
            case VOLUME_SILENT:
                mBuzzerONVolume = BuzzerONVolume.VOLUME_SILENT;
                break;
            case VOLUME_DEFAULT:
            default:
                mBuzzerONVolume = BuzzerONVolume.VOLUME_DEFAULT;
                break;
        }

        if (isBuzzer) {
            switch (type) {
                case BUZZER_TYPE_1:
                    mBuzzerPattern = BuzzerPattern.PATTERN1;
                    break;
                case BUZZER_TYPE_2:
                    mBuzzerPattern = BuzzerPattern.PATTERN2;
                    break;
                case BUZZER_TYPE_3:
                    mBuzzerPattern = BuzzerPattern.PATTERN3;
                    break;
                case BUZZER_TYPE_4:
                    mBuzzerPattern = BuzzerPattern.PATTERN4;
                    break;
                case BUZZER_TYPE_5:
                    mBuzzerPattern = BuzzerPattern.PATTERN6;
                    break;
                default:
                    mBuzzerPattern = BuzzerPattern.STOP;
                    break;
            }
        } else {
            switch (type) {
                case SOUND_TYPE_1:
                    mBuzzerPattern = BuzzerPattern.REMOVE;
                    break;
                case SOUND_TYPE_2:
                    mBuzzerPattern = BuzzerPattern.SELECT;
                    break;
                case SOUND_NO_CHANGE:
                    mBuzzerPattern = BuzzerPattern.STOP;
                    break;
                default:
                    mBuzzerPattern = null;
                    break;
            }
        }

    }

    /**
     * @brief ブザー鳴動音量設定を取得する
     * @return ブザー鳴動音量
     */
    public BuzzerONVolume getBuzzerONVolume() {
        return mBuzzerONVolume;
    }

    /**
     * @brief ブザー鳴動音量設定を設定する
     * @param buzzerONVolume ブザー鳴動音量
     */
    public void setBuzzerONVolume(BuzzerONVolume buzzerONVolume) {
        mBuzzerONVolume = buzzerONVolume;
    }

    /**
     * @brief ブザーパターンを取得する
     * @return ブザーパターン
     */
    public BuzzerPattern getBuzzerPattern() {
        return mBuzzerPattern;
    }

    /**
     * @brief ブザーパターンを設定する
     * @param buzzerPattern ブザーパターン
     */
    public void setBuzzerPattern(BuzzerPattern buzzerPattern) {
        mBuzzerPattern = buzzerPattern;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = mBuzzerONVolume.getValue();
        parameter[3] = mBuzzerPattern.getValue();

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mBuzzerONVolume == null) {
            return false;
        }

        if (mBuzzerPattern == null) {
            return false;
        }

        return true;
    }

}
