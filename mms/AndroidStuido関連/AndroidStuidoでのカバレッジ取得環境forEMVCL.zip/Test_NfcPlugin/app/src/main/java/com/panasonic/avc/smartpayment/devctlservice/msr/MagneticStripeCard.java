
package com.panasonic.avc.smartpayment.devctlservice.msr;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.msr.MagneticStripeCardNative.OnMsrListener;
import com.panasonic.avc.smartpayment.devctlservice.msr.data.arg.ArgmentStartGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseMsData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultMakeTransactionKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultCancelGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultInitMSR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultStartGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultTermMSR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultGetSignatureKey;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * 磁気カードリーダ処理部
 */
public class MagneticStripeCard {

    /** @brief ログ出力用タグ */
    private static final String TAG = MagneticStripeCard.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static MagneticStripeCard sInstance = new MagneticStripeCard();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IMsrServiceListener> mIMsrServiceListenerList = new ConcurrentHashMap<String, IMsrServiceListener>();

    /** @brief Native管理クラス */
    private MagneticStripeCardNative mNative = MagneticStripeCardNative.getInstance();

    /** @brief コンテキスト */
    private Context mContext;

    /**
     * @brief コンストラクタ
     */
    private MagneticStripeCard() {
    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static MagneticStripeCard getInstance() {
        return sInstance;
    }

    /**
     * @brief 磁気カードリーダプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerMsrServiceListener(String tag, IMsrServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIMsrServiceListenerList) {
            mIMsrServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief 磁気カードリーダプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterMsrServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIMsrServiceListenerList) {
            mIMsrServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief 磁気カードリーダを初期化します
     * @return 実行結果
     */
    public synchronized ResultInitMSR initMSR() {
        ResultInitMSR result = new ResultInitMSR();
        mNative.setOnMsrListener(mOnMsrListener);
        mNative.nativeInitMSR(result);
        return result;
    }

    /**
     * @brief 磁気カード読み取り開始します
     * @param[in] mode 読み取り対象とするデータを指定(整数型)します
     * @param[in] timeout 磁気カード読み取り待ちタイムアウト値(秒)を指定(整数型)します
     * @return 実行結果
     */
    public synchronized ResultStartGetMSRead startGetMSRead(int mode, int timeout) {
        ResultStartGetMSRead result = new ResultStartGetMSRead();
        ArgmentStartGetMSRead arg = new ArgmentStartGetMSRead(mode, timeout);
        mNative.nativeStartGetMSRead(result, arg);
        if (mode != 0 && isShowError(result.getUpos())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief 磁気カードの読み取りを解除します
     * @return 実行結果
     */
    public synchronized ResultCancelGetMSRead cancelGetMSRead() {
        ResultCancelGetMSRead result = new ResultCancelGetMSRead();
        mNative.nativeCancelGetMSRead(result);
        return result;
    }

    /**
     * @brief Plug-Inのパッケージ情報を取得します。周辺装置とのやり取りは発生しません。
     * @return 実行結果
     */
    public synchronized ResultGetPackageInfo getPackageInfo(String jsName, String jsVer,
            String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, MagneticStripeCard.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief 磁気カードリーダ利用可否情報を取得します
     * @return 実行結果
     */
    public synchronized ResultCheckHealth checkHealth() {
        ResultCheckHealth result = new ResultCheckHealth();
        mNative.nativeCheckHealth(result);
        if (result.getUpos() == PluginDefine.RESULT_UPOS_SCCESS
                && result.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS
                && result.isTamper() == false) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief 磁気カードリーダの製品品番、シリアル番号、ハード構成情報、APL Version、PF Version情報を取得します
     * @return 実行結果
     */
    public synchronized ResultGetVersionInfo getVersionInfo() {
        ResultGetVersionInfo result = new ResultGetVersionInfo();
        mNative.nativeGetVersionInfo(result);
        result.setAplVer(null);
        result.setHdInfo(null);
        result.setModel(null);
        result.setSno(null);
        return result;
    }

    /**
     * @brief 磁気カードリーダをターミネートします
     * @return 実行結果
     */
    public synchronized ResultTermMSR termMSR() {
        ResultTermMSR result = new ResultTermMSR();
        mNative.nativeTermMSR(result);
        return result;
    }

    /**
     * @brief DUKPT 生成を要求します
     * @return JSON形式[device,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval upos UPOS処理結果[整数型]
     */
    public synchronized ResultMakeTransactionKey makeTransactionKey() {
        ResultMakeTransactionKey result = new ResultMakeTransactionKey();
        mNative.nativeMakeTransactionKey(result);
        if (isShowErrorMakeTransacktion(result.getDevice())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief 耐タンパメモリから署名用の鍵を取得する
     * @return 処理結果
     * @retval key 鍵情報
     */
    public synchronized ResultGetSignatureKey getSignatureKey() {
        ResultGetSignatureKey result = new ResultGetSignatureKey();
        mNative.nativeGetSignatureKey(result);
        if (isShowError(result.getUpos())) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }
        return result;
    }

    /**
     * @brief Emcrw 用元マスターキーを取得する
     * @return 元マスターキー
     */
    public synchronized byte[][] getEmcrwMasterKeySeeds() {
        byte[][] result = new byte[10][];
        for (int i = 0; i < result.length; i++) {
            result[i] = mNative.nativeGetEmcrwMasterKeySeeds(i);
        }
        return result;
    }

    /**
     * @brief タンパ要因を取得します
     * @retval >=0 タンパ要因
     * @retval -1 失敗
     */
    public synchronized int getFactorOfTamper() {
        return mNative.nativeGetFactorOfTamper();
    }

    /**
     * @brief タンパ予兆情報を取得します
     * @retval >=0 タンパ予兆データ
     * @retval -1 失敗
     */
    public synchronized int getOmenOfTamper() {
        return mNative.nativeGetOmenOfTamper();
    }

    /**
     * @brief 磁気カード読み取りを一時停止します（タンパ割り込み処理用）
     * @retval 0 成功
     * @retval -1 失敗
     * @retval -2 磁気カード読み取り実行中でない
     */
    public synchronized int suspendGetMSRead() {
        return mNative.nativeSuspendGetMSRead();
    }

    /**
     * @brief 磁気カード読み取りを再開します（タンパ割り込み処理用）
     * @retval 0 成功
     * @retval -1 失敗
     * @retval -2 磁気カード読み取り開始不可状態
     */
    public synchronized int resumeGetMSRead() {
        return mNative.nativeResumeGetMSRead();
    }

    /**
     * @see OnMsrListener
     */
    private OnMsrListener mOnMsrListener = new OnMsrListener() {
        /**
         * @see OnMsrListener#onResultMsData(ResponseMsData)
         */
        @Override
        public void onResultMsData(ResponseMsData result, int device_error) {
            final int error = device_error;
            synchronized (mIMsrServiceListenerList) {
                for (Map.Entry<String, IMsrServiceListener> listener : mIMsrServiceListenerList
                        .entrySet()) {
                    try {
                        listener.getValue().onResultMsData(result);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (error == 1) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
        }

        /**
         * @see OnMsrListener#onError(ResponseError)
         */
        @Override
        public void onError(ResponseError result) {
            synchronized (mIMsrServiceListenerList) {
                for (Map.Entry<String, IMsrServiceListener> listener : mIMsrServiceListenerList
                        .entrySet()) {
                    try {
                        listener.getValue().onError(result);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        /**
         * @see LoggingManager#putLogDevice(int, int, int, int, String)
         */
        @Override
        public void onLogDevice(int deviceType, int errorCode, int extraData, int cmdCode,
                String info) {
            LoggingManager.getInstance().putLogDevice(deviceType, errorCode, extraData, cmdCode,
                    info);
        }

    };

    /**
     * エラーアイコン表示確認
     * 
     * @param upos UPOSの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int upos) {
        if (upos == PluginDefine.RESULT_UPOS_FATAL) {
            return true;
        }

        return false;
    }

    /**
     * エラーアイコン表示確認(MakeTransaction用)
     * 
     * @param upos UPOSの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowErrorMakeTransacktion(int device) {
        if (device == 132 || device == 134) {
            return true;
        }

        return false;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }
}
