package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * APダウンロード中止Requestクラス.
 * 
 */
public class APDownloadStopRequest extends BaseDownloadStopRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = APDownloadStopRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x83;

    /** Constructor */
    public APDownloadStopRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
