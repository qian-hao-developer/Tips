
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Print_ChkImageの実行結果データ
 */
public class ResultPrintCheckImage extends ResultPrnData {

    /** @brief イメージデータ情報タグ */
    protected static final String IMG_INFO = "imginfo";

    /** @brief イメージデータ情報タグ */
    protected static final String SZX = "szx";

    /** @brief 画像の横幅 */
    private int mX;

    /** @brief イメージデータ情報タグ */
    protected static final String SZY = "szy";

    /** @brief 画像の縦幅 */
    private int mY;

    /** @brief イメージデータ情報タグ */
    protected static final String CRC = "crc";

    /** @brief 画像のデータのCRC */
    private String mCrc;

    /** @brief イメージデータ情報タグ */
    protected static final String NAME = "name";

    /** @brief 名前 */
    private String mName;

    /** @brief 画像データ有無 */
    private boolean mIsValid;

    /**
     * @brief コンストラクタ
     */
    public ResultPrintCheckImage(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintCheckImage() {

    }

    /**
     * @brief 画像の横幅を取得する
     * @return 画像の横幅
     */
    public int getX() {
        return mX;
    }

    /**
     * @brief 画像の横幅を設定する
     * @param x 画像の横幅
     */
    public void setX(int x) {
        mX = x;
    }

    /**
     * @brief 画像の縦幅を取得する
     * @return 画像の縦幅
     */
    public int getY() {
        return mY;
    }

    /**
     * @brief 画像の縦幅を設定する
     * @param y 画像の縦幅
     */
    public void setY(int y) {
        mY = y;
    }

    /**
     * @brief 名前を取得する
     * @return 名前
     */
    public String getName() {
        return mName;
    }

    /**
     * @brief 名前を設定する
     * @param name 名前
     */
    public void setName(String name) {
        mName = name;
    }

    /**
     * @brief 画像データのCRCを取得する
     * @return CRC
     */
    public String getCrc() {
        return mCrc;
    }

    /**
     * @brief 画像データのCRCを設定する
     * @param crc CRC
     */
    public void setCrc(String crc) {
        mCrc = crc;
    }

    /**
     * @brief データが有効かどうか取得する
     * @return 有効無効
     */
    public boolean isValid() {
        return mIsValid;
    }

    /**
     * @brief データが有効かどうか設定する
     * @param isValid 有効無効
     */
    public void setValid(boolean isValid) {
        mIsValid = isValid;
    }

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(mName);
        dest.writeString(mCrc);
        dest.writeInt(mX);
        dest.writeInt(mY);
        dest.writeInt(mIsValid ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    @Override
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mName = in.readString();
        mCrc = in.readString();
        mX = in.readInt();
        mY = in.readInt();
        mIsValid = in.readInt() != 0;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintCheckImage> CREATOR = new Parcelable.Creator<ResultPrintCheckImage>() {
        public ResultPrintCheckImage createFromParcel(Parcel in) {
            return new ResultPrintCheckImage(in);
        }

        public ResultPrintCheckImage[] newArray(int size) {
            return new ResultPrintCheckImage[size];
        }
    };

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonImageInfo = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            if (mIsValid) {
                jsonImageInfo.put(NAME, getName());
                jsonImageInfo.put(SZX, getX());
                jsonImageInfo.put(SZY, getY());
                jsonImageInfo.put(CRC, getCrc());
            } else {
                jsonImageInfo.put(NAME, JSONObject.NULL);
                jsonImageInfo.put(SZX, JSONObject.NULL);
                jsonImageInfo.put(SZY, JSONObject.NULL);
                jsonImageInfo.put(CRC, JSONObject.NULL);
            }
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(IMG_INFO, JSONObject.NULL);
            } else {
                json.put(IMG_INFO, jsonImageInfo);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
