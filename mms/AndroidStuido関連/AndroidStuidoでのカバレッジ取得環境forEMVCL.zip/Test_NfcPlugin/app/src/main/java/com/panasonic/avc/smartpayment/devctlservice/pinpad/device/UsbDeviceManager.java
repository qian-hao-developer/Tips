
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.content.Context;
import android.hardware.usb.UsbDevice;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.DeviceTracker.OnDeviceUsbTrackerListener;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprDataListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;

/**
 * USBデバイス管理クラス
 */
public class UsbDeviceManager extends ControlDeviceManager {

    /** @brief ログ用タグ */
    private static final String TAG = UsbDeviceManager.class.getSimpleName();

    /** @brief デバイスパス */
    private static final String PATH_DEVICES = "/sys/bus/usb/devices";

    /** @brief USB1 のデバイス */
    private static final File DEVICES_DIR_USB1 = new File(PATH_DEVICES, "2-1.1");

    /** @brief USB2 のデバイス */
    private static final File DEVICES_DIR_USB2 = new File(PATH_DEVICES, "2-1.2");

    /** @brief USB3 のデバイス */
    private static final File DEVICES_DIR_USB3 = new File(PATH_DEVICES, "3-1");

    /** @brief ログ表示 */
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief マルチデバイス対応機器【マルチデバイス対応】 */
    private boolean mMultiDevice = false;

    /** @brief 前回のデバイス【マルチデバイス対応】 */
    private int mLastMultiDeviceProductID = 0;

    /** @brief 接続を容認するデバイスの PID リスト【マルチデバイス対応】 */
    private int[] mProductIds = new int[0];

    /** @brief 接続先ポートを USB1 に限定するか【バスパワー対応】 */
    private boolean[] mBusPower = new boolean[0];

    /** @brief USBの状態監視用リスナー */
    public interface OnUsbDeviceListener {
        /**
         * @brief USB接続イベント
         * @param device 接続デバイス
         */
        public void onConnected(UsbDevice device);

        /**
         * @brief USB切断イベント
         * @param device 切断デバイス
         */
        public void onDisconnected(UsbDevice device);
    }

    /** @brief リスナーリスト */
    protected ArrayList<OnUsbDeviceListener> mOnDeviceListenerList = new ArrayList<OnUsbDeviceListener>();

    /**
     * @brief コンストラクタ
     * @param context コンテキスト
     */
    public UsbDeviceManager(Context context) {
        mContext = context;
        mDeviceController = new UsbDeviceController(mContext);

        DeviceTracker.getInstance().registerUsbListener(mOnDeviceUsbTrackerListener);
    }

    /**
     * @see ControlDeviceManager#init(int)
     */
    @Override
    public boolean init(int venderId, int[] productIds, boolean[] busPower) {
        mMultiDevice = true;
        mProductIds = productIds;
        if (busPower == null || busPower.length < productIds.length) {
            // バスパワー非対応
            busPower = new boolean[productIds.length];
            Arrays.fill(busPower, false);
        }
        mBusPower = busPower;
        mLastMultiDeviceProductID = getCurrentDeviceProductID(venderId);
        return init(venderId, mLastMultiDeviceProductID);
    }

    /**
     * @see ControlDeviceManager#init(int, int)
     */
    @Override
    public boolean init(int venderId, int productId) {
        if (mStatus != ManagerStatus.NONE) {
            return false;
        }
        ((UsbDeviceController) mDeviceController).setProductId(productId);
        ((UsbDeviceController) mDeviceController).setVendorId(venderId);
        ((UsbDeviceController) mDeviceController).setManager(this);

        init();

        return true;
    }

    /**
     * @see ControlDeviceManager#init(int, int, int)
     */
    @Override
    public boolean init(int deviceInterface, int baudrate, int parity) {
        return false;
    }

    /**
     * @brief USBの状態監視用リスナーを設定する
     * @param onUsbDeviceListener リスナー
     */
    public void registerOnUsbDeviceListener(OnUsbDeviceListener onUsbDeviceListener) {
        synchronized (mOnDeviceListenerList) {
            if (!mOnDeviceListenerList.contains(onUsbDeviceListener)) {
                mOnDeviceListenerList.add(onUsbDeviceListener);
            }
        }
    }

    /**
     * @brief USBの状態監視用リスナーを設定する
     * @param onUsbDeviceListener リスナー
     */
    public void unregisterOnUsbDeviceListener(OnUsbDeviceListener onUsbDeviceListener) {
        synchronized (mOnDeviceListenerList) {
            mOnDeviceListenerList.remove(onUsbDeviceListener);
        }
    }

    /**
     * @brief USBデバイス管理クラス用通知リスナー
     */
    private OnDeviceUsbTrackerListener mOnDeviceUsbTrackerListener = new OnDeviceUsbTrackerListener() {

        /**
         * @see OnDeviceUsbTrackerListener#onConnected(UsbDevice)
         */
        @Override
        public void onConnected(UsbDevice device) {
            mLoggingManager.d(
                    TAG,
                    "UsbDevice VID: " + device.getVendorId() + " PID: " + device.getProductId()
                            + " connected.");
            UsbDeviceController controller = (UsbDeviceController) mDeviceController;
            if (isChangedTargetDevice(controller.getVendorId())) {
                controller.setProductId(mLastMultiDeviceProductID);
            }
            synchronized (mOnDeviceListenerList) {
                for (OnUsbDeviceListener listener : mOnDeviceListenerList) {
                    listener.onConnected(device);
                }
            }
        }

        /**
         * @see OnDeviceUsbTrackerListener#onDisconnected(UsbDevice)
         */
        @Override
        public void onDisconnected(UsbDevice device) {
            mLoggingManager.d(
                    TAG,
                    "UsbDevice VID: " + device.getVendorId() + " PID: " + device.getProductId()
                            + " disconnected. ManagerStatus returned to INIT.");
            synchronized (mOnDeviceListenerList) {
                for (OnUsbDeviceListener listener : mOnDeviceListenerList) {
                    listener.onDisconnected(device);
                }
            }
            UsbDeviceController controller = (UsbDeviceController) mDeviceController;
            if (isChangedTargetDevice(controller.getVendorId())) {
                controller.setProductId(mLastMultiDeviceProductID);
                init();
            }
        }

        /**
         * @see OnDeviceUsbTrackerListener#onPermitted(UsbDevice)
         */
        @Override
        public void onPermitted(UsbDevice device) {
            mLoggingManager
                    .e(TAG,
                            "onUsbPermission VID:" + device.getVendorId() + " PID:"
                                    + device.getProductId());

            if (connect(device)) {
                synchronized (mNotifyUsbDeviceConnectionListenerList) {
                    for (NotifyUsbDeviceConnectionListener listener : mNotifyUsbDeviceConnectionListenerList) {
                        listener.onOpened(device);
                    }
                }
            }
        }
    };

    /**
     * @see UsbDeviceManager#setPprDataListener(IPprDataListener)
     */
    @Override
    public void setPprDataListener(IPprDataListener listener) {
        ((UsbDeviceController) mDeviceController).setPprDataListener(listener);
    }

    /**
     * @see UsbDeviceManager#removePprDataListener(IPprDataListener)
     */
    @Override
    public void removePprDataListener(IPprDataListener listener) {
        ((UsbDeviceController) mDeviceController).removePprDataListener(listener);
    }

    @Override
    public void setSpadDataListener(SignpadDataListener listener) {
        ((UsbDeviceController) mDeviceController).setSpadDataListener(listener);
    }

    @Override
    public void removeSpadDataListener(SignpadDataListener listener) {
        ((UsbDeviceController) mDeviceController).removeSpadDataListener(listener);
    }

    /**
     * @see UsbDeviceController#getProductId()
     */
    @Override
    public int getProductId() {
        return ((UsbDeviceController) mDeviceController).getProductId();
    }

    /**
     * 接続対象デバイスが変更されたかを判定する【マルチデバイス対応】
     */
    private boolean isChangedTargetDevice(int venderId) {
        if (!mMultiDevice) {
            // マルチデバイス対応が不要なデバイス
            return false;
        }
        // check current device
        if (containsLastDevice(venderId)) {
            // 前回接続していたデバイスが本体に接続されているままなら初期化は不要
            return false;
        }
        // 前回接続していたデバイスが本体に接続されていない場合
        int newDevice = getCurrentDeviceProductID(venderId);
        if (mLastMultiDeviceProductID != newDevice) {
            mLastMultiDeviceProductID = newDevice;
            return true;
        }
        return false;
    }

    /**
     * @brief 接続対象デバイスが本体に接続されているかを判定する【マルチデバイス対応】
     */
    private boolean containsLastDevice(int venderId) {
        List<Integer> currentDeviceList = createProductIDList(venderId);
        if (currentDeviceList.isEmpty()) {
            return false;
        }
        return currentDeviceList.contains(mLastMultiDeviceProductID);
    }

    /**
     * @brief 現在接続されている USB ポートが最も若いデバイスを取得する【マルチデバイス対応】
     */
    private int getCurrentDeviceProductID(int venderId) {
        List<Integer> currentDeviceList = createProductIDList(venderId);
        if (currentDeviceList.isEmpty()) {
            return 0; // 接続なし
        }
        // 優先度順に構成されるため
        // リストの0番目を使う
        return currentDeviceList.get(0);
    }

    /**
     * @brief 現在接続されているDeviceのリストを作成する【マルチデバイス対応】
     */
    private List<Integer> createProductIDList(int vendorId) {
        // 優先度の高い順に ProductID を探索・追加
        List<Integer> productIDList = new ArrayList<Integer>();

        // 全デバイスのリスト
        List<File> deviceDirList = new ArrayList<File>(
                Arrays.asList(new File(PATH_DEVICES).listFiles()));

        deviceDirList.remove(DEVICES_DIR_USB1);
        deviceDirList.remove(DEVICES_DIR_USB2);
        deviceDirList.remove(DEVICES_DIR_USB3);
        deviceDirList.add(0, DEVICES_DIR_USB2);
        deviceDirList.add(1, DEVICES_DIR_USB3);

        // バスパワー対応ポート
        {
            int pid_i = checkDevice(vendorId, DEVICES_DIR_USB1);
            if (pid_i >= 0) {
                productIDList.add(mProductIds[pid_i]);
            }
        }

        // バスパワー非対応ポート
        // 各 USB ポートに直接接続されたデバイスを優先して探索
        // ハブに接続されたデバイスを探索
        for (File deviceDir : deviceDirList) {
            int pid_i = checkDevice(vendorId, deviceDir);
            if (pid_i >= 0) {
                if (mBusPower[pid_i]) {
                    CalcUtil.removeIntByList(productIDList, mProductIds[pid_i]);
                } else {
                    productIDList.add(mProductIds[pid_i]);
                }
            }
        }

        return productIDList;
    }

    /**
     * @brief 探索対象デバイスであるかを確認する【マルチデバイス対応】
     * @retval = -1 探索対象デバイスでない
     * @retval >= 0 探索対象デバイスの Product ID
     */
    private int checkDevice(int vendorId, File deviceDir) {
        if (!deviceDir.isDirectory()) {
            return -1;
        }

        File[] files = deviceDir.listFiles();
        if (files == null) {
            mLoggingManager.e(TAG, "   USB Device File is not a directory");
            return -1;
        }
        File idProductFile = null;
        File idVendorFile = null;

        for (int j = 0; j < files.length; j++) {
            if (files[j].getName().equals("idProduct")) {
                idProductFile = files[j];
            } else if (files[j].getName().equals("idVendor")) {
                idVendorFile = files[j];
            }
        }

        if (idProductFile == null || idVendorFile == null) {
            return -1;
        }

        String p = null;
        String v = null;
        try {
            BufferedReader idProductBR = new BufferedReader(new InputStreamReader(
                    new FileInputStream(idProductFile)));
            p = idProductBR.readLine();
            idProductBR.close();

            BufferedReader idVendorBR = new BufferedReader(new InputStreamReader(
                    new FileInputStream(idVendorFile)));
            v = idVendorBR.readLine();
            idVendorBR.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return -1;
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }

        int pid = 0;
        int vid = 0;
        try {
            pid = Integer.parseInt(p, 16);
            vid = Integer.parseInt(v, 16);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return -1;
        }

        if (vendorId != vid) {
            return -1;
        }

        for (int i = 0; i < mProductIds.length; i++) {
            if (mProductIds[i] == pid) {
                return i;
            }
        }

        return -1;
    }
}
