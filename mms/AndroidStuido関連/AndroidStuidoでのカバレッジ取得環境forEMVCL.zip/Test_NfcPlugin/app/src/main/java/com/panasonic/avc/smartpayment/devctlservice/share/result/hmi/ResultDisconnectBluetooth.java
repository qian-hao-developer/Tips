
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * DisconnectBluetoothの実行結果データ
 */
public class ResultDisconnectBluetooth extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultDisconnectBluetooth(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultDisconnectBluetooth() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultDisconnectBluetooth> CREATOR = new Parcelable.Creator<ResultDisconnectBluetooth>() {
        public ResultDisconnectBluetooth createFromParcel(Parcel in) {
            return new ResultDisconnectBluetooth(in);
        }

        public ResultDisconnectBluetooth[] newArray(int size) {
            return new ResultDisconnectBluetooth[size];
        }
    };
}
