
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * イメージ転送印字要求
 */
public class RequestPrintImage extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x0018;

    /** @brief コマンド詳細(バーストモード) */
    private static final int COMMAND_DETAIL_BRUST = 0xA000;

    /** @brief コマンド詳細(バーストモードなし) */
    private static final int COMMAND_DETAIL_BRUST_END = 0xE000;

    /** @brief コマンド長 */
    private static final int LENGTH = 0x0004;

    /** @brief 画像データ */
    private byte[] mData;

    /** @brief 情報付与有無 */
    private boolean mIsInfo;

    /** @brief 画像の横幅 */
    private int mX;

    /** @brief 画像の縦幅 */
    private int mY;

    /** @brief 表示開始位置 */
    private int mPosX;

    /** @brief 印字幅 */
    private int mWidth;

    /**
     * @brief コンストラクタ
     * @param brust バーストモードかどうか
     * @param posx 表示開始位置
     * @param x 画像の横幅
     * @param y 画像の縦幅
     * @param data 画像データ
     * @param isInfo 情報付与有無
     */
    public RequestPrintImage(boolean brust, int posx, int x, int y, byte[] data, boolean isInfo,
            int width) {
        mCommandId = COMMAND_ID;
        mCommandDetail = brust ? COMMAND_DETAIL_BRUST : COMMAND_DETAIL_BRUST_END;
        mX = x;
        mY = y;
        mPosX = posx;
        mData = data;
        mIsInfo = isInfo;
        mWidth = width;
    }

    /**
     * @brief 画像データを取得する
     * @return data 画像データ
     */
    public byte[] getData() {
        return mData;
    }

    /**
     * @brief 画像データを設定する
     * @param data 画像データ
     */
    public void setData(byte[] data) {
        mData = data;
    }

    /**
     * @brief 情報付与の有無を取得する
     * @return 情報付与の有無
     */
    public boolean isInfo() {
        return mIsInfo;
    }

    /**
     * @brief 情報付与の有無を設定する
     * @param isInfo 情報付与の有無
     */
    public void setIsInfo(boolean isInfo) {
        mIsInfo = isInfo;
    }

    /**
     * @brief 画像の横幅を取得する
     * @return 画像の横幅
     */
    public int getX() {
        return mX;
    }

    /**
     * @brief 画像の横幅を設定する
     * @param x 画像の横幅
     */
    public void setX(int x) {
        mX = x;
    }

    /**
     * @brief 画像の縦幅を設定する
     * @return 画像の縦幅
     */
    public int getY() {
        return mY;
    }

    /**
     * @brief 画像の縦幅を取得する
     * @param y 画像の縦幅
     */
    public void setY(int y) {
        mY = y;
    }

    /**
     * @brief 表示位置を取得する
     * @return posX 表示位置
     */
    public int getPosX() {
        return mPosX;
    }

    /**
     * @brief 表示位置を設定する
     * @param 表示位置
     */
    public void setPosX(int posX) {
        mPosX = posX;
    }

    /**
     * @brief 印字幅を取得する
     * @return 印字幅
     */
    public int getWidth() {
        return mWidth;
    }

    /**
     * @brief 印字幅を設定する
     * @param width 印字幅
     */
    public void setWidth(int width) {
        mWidth = width;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        if (mIsInfo) {
            byte[] parameter = new byte[LENGTH + mData.length];

            parameter[0] = (byte) mPosX;
            parameter[1] = (byte) (mX / 8);
            parameter[2] = (byte) mY;
            parameter[3] = (byte) 0x00;

            System.arraycopy(mData, 0, parameter, 4, mData.length);

            return toCommand(parameter);
        } else {
            return toCommand(mData);
        }

    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mData == null) {
            return false;
        }

        if (mWidth < 1 || mWidth > 2) {
            return false;
        }

        if (mWidth == 1) {
            if (mPosX <= 0 || mPosX > 48) {
                return false;
            }

            if (mX <= 0 || mX > 384) {
                return false;
            }
        } else {
            if (mPosX <= 0 || mPosX > 54) {
                return false;
            }

            if (mX <= 0 || mX > 432) {
                return false;
            }
        }

        if (mData == null || mData.length <= 0) {
            return false;
        }

        return true;
    }

}
