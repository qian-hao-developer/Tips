
package com.panasonic.avc.smartpayment.devctlservice.cfg;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.ConcurrentHashMap;

import android.content.ContentResolver;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.contesnts.ManagementData;
import com.panasonic.avc.smartpayment.devctlservice.contesnts.ManagementDatabase;
import com.panasonic.avc.smartpayment.devctlservice.share.ICfgServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultBuzzerOn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultGetPrinter;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultInitCfg;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultSetBrightness;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultSetBuzzer;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultSetLowPower;

/**
 * CFG処理部
 */
public class Configuration {

    /** @brief ログ出力用タグ */
    private static final String TAG = Configuration.class.getSimpleName();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, ICfgServiceListener> mICfgServiceListenerList = new ConcurrentHashMap<String, ICfgServiceListener>();

    /** @brief シングルトンインスタンス */
    private static Configuration sInstance = new Configuration();

    /** @brief データベース用インスタンス */
    private ManagementDatabase mManagementDatabase = ManagementDatabase.getInstance();

    private Context mContext;

    /** @brief ブザーバッファ */
    private BufferedWriter mBufferedWriter = null;

    /** @brief ブザーONバッファ */
    private BufferedWriter mBuzzerOnBufferedWriter = null;

    private static final int NULL = 0;

    private static final int TRUE = 1;

    private static final int FALSE = 2;

    private static final int LOW_POWER_STAND_BY = 1;

    private static final int LOW_POWER_SCREEN_SAVER = 2;

    private static final int LOW_POWER_MAX_TIME = 5;

    private static final int BRIGHTNESS_MAX = 10;

    private static final int BUZZER_VOL_MAX = 4;

    public static final String SCREEN_OFF_TIMEOUT = "screen_off_timeout";

    private static final int FALLBACK_SCREEN_TIMEOUT_VALUE = 30000;

    private final String UNIFIED_PATH = "/firmware2";

    private final String UNIFIED_FILE = "unified";

    private static long[] sLowPowerTimeoutArray = {
            60000, // 1min
            180000, // 3min
            300000, // 5min
            600000, // 10min
            900000, // 15min
    };

    // 設定できるintの値は0〜255の256段階。mCurrentBrightnessは1〜10の10段階なので変換する
    // ただし、0を入れてしまうと画面が真っ黒で操作できなくなるので最低値を1にする
    private static final int sRealBrightnessArray[] = {
            34, // レベル 1
            59, // レベル 2
            83, // レベル 3
            108, // レベル 4
            132, // レベル 5
            157, // レベル 6
            181, // レベル 7
            206, // レベル 8
            230, // レベル 9
            255, // レベル 10
    };

    /**
     * @brief コンストラクタ
     */
    private Configuration() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static Configuration getInstance() {
        return sInstance;
    }

    /**
     * @brief CFGを初期化します
     * @return JSON形式[device,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval upos UPOS処理結果[整数型]
     */
    public ResultInitCfg initCfg() {
        ResultInitCfg result = new ResultInitCfg();

        try {
            mBufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
                    new File("/sys/devices/platform/l0dbyb_buzzer/set_volume"))));
            mBuzzerOnBufferedWriter = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(new File(
                            "/sys/devices/platform/l0dbyb_buzzer/en_buzzer"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();

            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * 本体の省電力設定を行う
     * 
     * @param time 省電力モードに移行する時間を指定
     * @return 実行結果
     */
    public ResultSetLowPower setLowPower(int time) {

        ResultSetLowPower result = new ResultSetLowPower();
        boolean resTime = false;

        if (time < NULL || time > LOW_POWER_MAX_TIME) {
            // 値がおかしいためエラー
            result.setTime(NULL);
        } else if (time == NULL) {
            resTime = true;
            result.setTime(getLowPowerSleepTime());
        } else {
            if (setLowPowerSleepTime(time - 1)) {
                result.setTime(time);
                resTime = true;
            } else {
                result.setTime(NULL);
            }
        }

        if (resTime) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        } else {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
        }

        return result;
    }

    /**
     * 本体ディスプレイの輝度設定
     * 
     * @param brightness 輝度
     * @return 実行結果
     */
    public ResultSetBrightness setBrightness(int brightness) {
        ResultSetBrightness result = new ResultSetBrightness();

        if (brightness < NULL || brightness > BRIGHTNESS_MAX) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            result.setBrightness(NULL);
            return result;
        } else if (brightness == NULL) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            result.setBrightness(getCurrentBrightnessLevel());
        } else {
            if (setCurrentBrightnessLevel(brightness)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
                result.setBrightness(brightness);
            } else {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
                result.setBrightness(NULL);
            }
        }

        return result;
    }

    /**
     * ブザーの音量を設定する
     * 
     * @param vol 音量
     * @return 実行結果
     */
    public ResultSetBuzzer setBuzzer(int vol) {
        ResultSetBuzzer result = new ResultSetBuzzer();

        if (mBufferedWriter == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return result;
        }

        if (vol < NULL || vol > BUZZER_VOL_MAX) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        } else {
            int volume = mManagementDatabase.getSettingsVolume();

            if (vol != NULL) {
                // user: 1 origin / device: 0 origin
                volume = vol - 1;
            } else {
                vol = volume + 1;
            }

            try {
                mBufferedWriter.write(Integer.toString(volume));
                mBufferedWriter.flush();
            } catch (IOException e) {
                e.printStackTrace();

                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
                return result;
            }
            mManagementDatabase.updateSettingsVolume(volume);
        }

        result.setVolume(vol);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

        return result;
    }

    /**
     * プリンタの設定情報取得
     * 
     * @return 実行結果
     */
    public ResultGetPrinter getPrinter() {
        ResultGetPrinter result = new ResultGetPrinter();
        ManagementData data = mManagementDatabase.query();

        if (data == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        } else {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            result.setBold(data.getFont());
            result.setCutType(data.getSlip());
            result.setDensity(data.getDensity());
        }

        return result;
    }

    /**
     * ブザーの鳴動
     * 
     * @param time 時間
     * @return 実行結果
     */
    public ResultBuzzerOn buzzerOn(int time) {
        ResultBuzzerOn result = new ResultBuzzerOn();
        if (mBuzzerOnBufferedWriter == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return result;
        }

        if ((time < 1) || (time > 10000)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        try {
            mBuzzerOnBufferedWriter.write(Integer.toString(time));
            mBuzzerOnBufferedWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();

            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, Configuration.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * 本体の利用可否情報取得
     * 
     * @return 実行結果
     */
    public ResultCheckHealth checkHealth(boolean isPaperLess, boolean health,
            boolean hasUpdateInfo, boolean isWired) {
        ResultCheckHealth result = new ResultCheckHealth();
        result.setPaperLess(isPaperLess);
        result.setHealth(health);
        result.setNewest(hasUpdateInfo);
        result.setWired(isWired);

        if (!isWired) {
            WifiManager manager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = manager.getConnectionInfo();

            ConnectivityManager connectivityManager = (ConnectivityManager) mContext
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

            if ((networkInfo != null) && (info != null)) {
                if (networkInfo.isConnected()) {
                    int rssi = info.getRssi();
                    int level = WifiManager.calculateSignalLevel(rssi, 6);
                    if (level == 0) {
                        result.setWirelessLevel(6);
                    } else {
                        result.setWirelessLevel(level);
                    }
                }
            } else {
                result.setWirelessLevel(6);
            }

        }

        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);

        return result;
    }

    /**
     * @brief 製品品番、シリアル番号、ハード構成情報、APL Version、PF Versionを取得します
     * @return JSON形式[device,verinfo,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval verinfo デバイス情報[model,sno,hdinfo,aplver,pfver]
     * @retval model 製品品番[文字列型]
     * @retval sno シリアル番号[文字列型]
     * @retval hdinfo ハード構成情報[文字列型]
     * @retval aplver アプリケーションVersion[文字列型]
     * @retval pfver プラットフォーム[文字列型]
     * @retval upos UPOS処理結果[整数型]
     */
    public ResultGetVersionInfo getVersionInfo() {
        ResultGetVersionInfo result = new ResultGetVersionInfo();
        result.setHdInfo(null);
        result.setAplVer(null);
        result.setPfVer(getUnifiedNumber());
        return result;
    }

    /**
     * @brief CFGプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerCfgServiceListener(String tag, ICfgServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mICfgServiceListenerList) {
            mICfgServiceListenerList.put(tag, listener);
        }
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * @brief CFGプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterCfgServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mICfgServiceListenerList) {
            mICfgServiceListenerList.remove(tag);
        }
    }

    private int getLowPowerSleepTime() {
        if (mContext == null) {
            return NULL;
        }
        long currentTimeout = Settings.System.getLong(mContext.getContentResolver(),
                SCREEN_OFF_TIMEOUT, FALLBACK_SCREEN_TIMEOUT_VALUE);

        for (int i = 0; i < sLowPowerTimeoutArray.length; i++) {
            if (sLowPowerTimeoutArray[i] == currentTimeout) {
                return i + 1;
            }
        }
        return NULL;
    }

    private boolean setLowPowerSleepTime(int index) {
        if (mContext == null) {
            return false;
        }

        Settings.System.putLong(mContext.getContentResolver(), SCREEN_OFF_TIMEOUT,
                sLowPowerTimeoutArray[index]);
        return true;
    }

    /**
     * @brief 現在の輝度を取得してintで返す
     * @return int level
     */
    private int getCurrentBrightnessLevel() {
        int realBrightness = Settings.System.getInt(mContext.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, 132);
        int i;
        for (i = 0; i < sRealBrightnessArray.length - 1; i++) {
            if (realBrightness <= sRealBrightnessArray[i]) {
                break;
            }
        }
        return i + 1;
    }

    private boolean setCurrentBrightnessLevel(int level) {

        if (level <= 0 || mContext == null) {
            return false;
        }

        ContentResolver resolver =
                mContext.getApplicationContext().getContentResolver();
        String name = Settings.System.SCREEN_BRIGHTNESS;
        Settings.System.putInt(resolver, name, sRealBrightnessArray[level - 1]);
        return true;
    }

    private String getUnifiedNumber() {
        String ret = "";
        File dir = new File(UNIFIED_PATH);
        File[] list = dir.listFiles();
        for (int i = 0; i < list.length; i++) {
            if (UNIFIED_FILE.equals(list[i].getName())) {
                try {
                    FileInputStream stream = new FileInputStream(list[i]);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(stream,
                            "UTF-8"));
                    String s = null;
                    s = reader.readLine();
                    if (s != null) {
                        ret = s;
                    }
                    break;
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }

}
