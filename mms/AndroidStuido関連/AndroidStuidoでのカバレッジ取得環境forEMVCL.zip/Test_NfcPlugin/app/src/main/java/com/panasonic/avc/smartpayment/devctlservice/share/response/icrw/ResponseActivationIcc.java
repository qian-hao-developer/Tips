
package com.panasonic.avc.smartpayment.devctlservice.share.response.icrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * ActivationEventデータ
 */
public class ResponseActivationIcc extends ResponseData implements Parcelable {

    /** @brief 活性化処理結果 */
    private int mResult;

    /** @brief 活性化処理結果タグ */
    private static final String RESULT = "result";

    /** @brief 活性化エラーの詳細 */
    private int mError;

    /** @brief 活性化エラーの詳細タグ */
    private static final String ERROR = "error";

    /** @brief ICカードの応答内容 */
    private String mAtr;

    /** @brief ICカードの応答内容タグ */
    private static final String ATR = "atr";

    /** @brief マスターコマンド **/
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド **/
    private static final byte SUB_COMMAND = 0x03;

    /** @brief コマンドの長さ(最短の場合) **/
    private static final int LENGTH_AND_OVER = 9;

    /** @brief 成功時の返り値定数 **/
    private static final int RESULT_SUCCESS = 0;

    /** @brief 失敗時の返り値定数 **/
    private static final int RESULT_FAIL = 1;

    /** @brief タイムアウト時の返り値定数 **/
    public static final int RESULT_TIMEOUT = 2;

    /** @brief 正常 **/
    private static final int ERROR_NONE = 0x00;

    /** @brief ICカード検知エラー **/
    private static final int ERROR_IC_CARD = 0x71;

    /** @brief パラメータエラー **/
    private static final byte ERROR_PARAM = (byte) 0x81;

    /** @brief 活性化エラー(非活性化済み) **/
    private static final byte ERROR_DEACTIVATED = (byte) 0x91;

    /** @brief ATRデータエラー(非活性化済み) **/
    private static final byte ERROR_ATR_DEACTIVATED = (byte) 0x93;

    /** @brief BN値が端末内部で保持している値と同じ **/
    private static final byte ERROR_SAVED_SAME_VALUE = (byte) 0xff;

    /** @brief ICカード未装着 **/
    private static final int ERROR_IC_CARD_NOT_FOUND = 1;

    /** @brief ATR応答なし **/
    public static final int ERROR_ATR_NOT_RESPONDING = 2;

    /** @brief ATR内容不適格 **/
    private static final int ERROR_ATR_INVALID_VALUE = 3;

    /** @brief ICカード通信エラー発生 **/
    private static final int ERROR_IC_CARD_COMMUNICATION_ERROR = 4;

    /** @brief ICカードから受信したデータの内容あるいは長さが不適格(非活性化状態) **/
    private static final int ERROR_IC_CARD_LENGTH_ERROR_DEACTIVATION = 5;

    /** @brief ICカードから受信したデータの内容あるいは長さが不適格(活性化状態) **/
    public static final int ERROR_IC_CARD_LENGTH_ERROR_ACTIVATION = 6;

    /**
     * @brief コンストラクタ
     * @param result 活性化処理結果
     * @param error 活性化エラーの詳細
     * @param atr ICカードの応答内容
     */
    public ResponseActivationIcc(int result, int error, String atr) {
        mResult = result;
        mError = error;
        mAtr = atr;
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseActivationIcc(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseActivationIcc() {

    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponseActivationIcc> CREATOR = new Parcelable.Creator<ResponseActivationIcc>() {

        /**
         * @see Parcelable.Creator#createFromParcel(Parcel)
         */
        public ResponseActivationIcc createFromParcel(Parcel in) {
            return new ResponseActivationIcc(in);
        }

        /**
         * @see Parcelable.Creator#newArray(int)
         */
        public ResponseActivationIcc[] newArray(int size) {
            return new ResponseActivationIcc[size];
        }
    };

    /**
     * @see Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mResult);
        dest.writeInt(mError);
        dest.writeString(mAtr);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mResult = in.readInt();
        mError = in.readInt();
        mAtr = in.readString();
    }

    /**
     * @brief 活性化処理結果を取得する
     * @return 活性化処理結果
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @brief 活性化処理結果を設定する
     * @param 活性化処理結果
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * @brief 活性化エラーの詳細情報を取得する
     * @return 活性化エラーの詳細情報
     */
    public int getError() {
        return mError;
    }

    /**
     * @brief 活性化エラーの詳細情報を設定する
     * @param 活性化エラーの詳細情報
     */
    public void setError(int error) {
        mError = error;
    }

    /**
     * @brief ICカードの応答内容を取得する
     * @return ICカードの応答内容
     */
    public String getAtr() {
        return mAtr;
    }

    /**
     * @brief ICカードの応答内容を設定する
     * @param ICカードの応答内容
     */
    public void setAtr(String atr) {
        mAtr = atr;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len < LENGTH_AND_OVER) {
            return false;
        }

        int status = buffer[PinpadDefine.INDEX_PARAMETER + 1];

        int error = buffer[PinpadDefine.INDEX_PARAMETER + 5];

        switch (error) {
            case ERROR_NONE:
                mResult = RESULT_SUCCESS;
                break;
            case ERROR_IC_CARD:
                mResult = RESULT_FAIL;
                mError = ERROR_IC_CARD_NOT_FOUND;
                mAtr = null;
                return true;
            case ERROR_PARAM:
                mResult = RESULT_FAIL;
                mError = ERROR_IC_CARD_COMMUNICATION_ERROR;
                mAtr = null;
                return true;
            case ERROR_DEACTIVATED:
                mResult = RESULT_FAIL;
                mError = ERROR_ATR_NOT_RESPONDING;
                mAtr = null;
                return true;
            case ERROR_ATR_DEACTIVATED:
                mResult = RESULT_FAIL;
                mError = ERROR_ATR_INVALID_VALUE;
                mAtr = null;
                return true;
            case ERROR_SAVED_SAME_VALUE:
                mResult = RESULT_FAIL;
                mAtr = null;
                return true;
            default:
                mResult = RESULT_TIMEOUT;
                mAtr = null;
                return true;
        }

        int sensor = buffer[PinpadDefine.INDEX_PARAMETER + 6];

        int number = buffer[PinpadDefine.INDEX_PARAMETER + 7];

        byte[] atr = new byte[buffer.length - (PinpadDefine.INDEX_PARAMETER + 9)
                - PinpadDefine.CRC_NOT_CALC_SIZE];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 9, atr, 0, buffer.length
                - (PinpadDefine.INDEX_PARAMETER + 9) - PinpadDefine.CRC_NOT_CALC_SIZE);

        mAtr = CalcUtil.toHexString(atr);

        return true;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(RESULT, getResult());
            json.put(ERROR, getError());

            if (getAtr() == null) {
                json.put(ATR, JSONObject.NULL);
            } else {
                json.put(ATR, getAtr());
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
