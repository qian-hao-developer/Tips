
package com.panasonic.avc.smartpayment.devctlservice.emcrw.device.request;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data.RequestEmcrwData;

public class RequestACK extends RequestEmcrwData {

    private final int LENGTH = 1;

    /**
     * @brief コンストラクタ
     */
    public RequestACK() {
        mReturnLength = 1;
    }

    /**
     * @brief パラメータ部を合成しコマンドに変換する
     * @param parameter パラメータ部
     * @return コマンド
     */
    @Override
    protected byte[] toCommand(byte[] parameter) {

        byte[] data = new byte[parameter.length];
        for (int i = 0; i < data.length; i++) {
            data[i] = parameter[i];
        }
        // return packetGenerator(data);
        return data;
    }

    /*
     * @see RequestEmcrwData#toCommand()
     */
    @Override
    public byte[] toCommand() {
        byte[] parameter = new byte[LENGTH];
        parameter[0] = (byte) 0x06; // ACK

        return toCommand(parameter);
    }

}
