package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.RW_SETTING_CHANGE_REQUEST.TIMERSETTING1;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.RW_SETTING_CHANGE_REQUEST.TIMERSETTING2;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.RW_SETTING_CHANGE_REQUEST.TIMERSETTING3;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.RW_SETTING_CHANGE_REQUEST.TIMERSETTING4;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.RW_SETTING_CHANGE_REQUEST.TIMERSETTING5;

/**
 * R/W設定変更Requestクラス.
 * 
 */
public class RWSettingChangeRequest extends BaseRequest {

    /** @brief ログ用タグ */
    private static final String TAG = RWSettingChangeRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x52;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x04;

    /** @brief 音量設定値 . */
    private byte mVolume;
    /** @brief タイマ1設定値 . */
    private byte[] mTimerSetting1;
    /** @brief タイマ2設定値 . */
    private byte[] mTimerSetting2;
    /** @brief タイマ3設定値 . */
    private byte[] mTimerSetting3;
    /** @brief タイマ4設定値 . */
    private byte[] mTimerSetting4;
    /** @brief タイマ5設定値 . */
    private byte[] mTimerSetting5;
    /** @brief LCD表示データ . */
    private byte mLcdMessageData;
    /** @brief 表示言語 . */
    private byte mMessageLanguage;
    /** @brief 動作モード . */
    private byte mOperationMode;

    /**
     * 音量設定値を設定する.
     * 
     * @param volume 音量設定値
     */
    public void setVolume(byte volume) {
        mVolume = volume;
    }

    /**
     * タイマ1設定値を設定する.
     * 
     * @param timerSetting1 タイマ1設定値
     */
    public void setTimerSetting1(byte[] timerSetting1) {
        mTimerSetting1 = timerSetting1;
    }

    /**
     * タイマ2設定値を設定する.
     * 
     * @param timerSetting2 タイマ2設定値
     */
    public void setTimerSetting2(byte[] timerSetting2) {
        mTimerSetting2 = timerSetting2;
    }

    /**
     * タイマ3設定値を設定する.
     * 
     * @param timerSetting3 タイマ3設定値
     */
    public void setTimerSetting3(byte[] timerSetting3) {
        mTimerSetting3 = timerSetting3;
    }

    /**
     * タイマ4設定値を設定する.
     * 
     * @param timerSetting4 タイマ4設定値
     */
    public void setTimerSetting4(byte[] timerSetting4) {
        mTimerSetting4 = timerSetting4;
    }

    /**
     * タイマ5設定値を設定する.
     * 
     * @param timerSetting5 タイマ5設定値
     */
    public void setTimerSetting5(byte[] timerSetting5) {
        mTimerSetting5 = timerSetting5;
    }

    /**
     * LCD表示データを設定する.
     * 
     * @param lcdMessageData LCD表示データ
     */
    public void setLcdMessageData(byte lcdMessageData) {
        mLcdMessageData = lcdMessageData;
    }

    /**
     * 表示言語を設定する.
     * 
     * @param messageLanguage 表示言語
     */
    public void setMessageLanguage(byte messageLanguage) {
        mMessageLanguage = messageLanguage;
    }

    /**
     * 動作モードを設定する.
     * 
     * @param operationMode 動作モード
     */
    public void setOperationMode(byte operationMode) {
        mOperationMode = operationMode;
    }

    /** Constructor */
    public RWSettingChangeRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // 音量設定値:0～2
        if (!ByteUtil.checkTargetValueByte(mVolume, (byte) 0x00, (byte) 0x01,
                (byte) 0x02)) {
            Logger.e(TAG, "isValidValue VOLUME mismatch =" + mVolume);
            return false;
        }

        // タイマ1設定値:必須チェック
        if (mTimerSetting1 == null) {
            Logger.e(TAG, "isValidValue mTimerSetting1 is null ");
            return false;
        }

        // サイズチェック
        if(mTimerSetting1.length != TIMERSETTING1.getDataLength()){
            Logger.e(TAG, "mTimerSetting1 length mismatch ="
                    + mTimerSetting1.length);
            return false;
        }

        // タイマ2設定値:必須チェック
        if (mTimerSetting2 == null) {
            Logger.e(TAG, "isValidValue mTimerSetting2 is null ");
            return false;
        }

        // サイズチェック
        if(mTimerSetting2.length != TIMERSETTING2.getDataLength()){
            Logger.e(TAG, "mTimerSetting2 length mismatch ="
                    + mTimerSetting2.length);
            return false;
        }

        // タイマ3設定値:必須チェック
        if (mTimerSetting3 == null) {
            Logger.e(TAG, "isValidValue mTimerSetting3 is null ");
            return false;
        }

        // サイズチェック
        if(mTimerSetting3.length != TIMERSETTING3.getDataLength()){
            Logger.e(TAG, "mTimerSetting3 length mismatch ="
                    + mTimerSetting3.length);
            return false;
        }

        // タイマ4設定値:必須チェック
        if (mTimerSetting4 == null) {
            Logger.e(TAG, "isValidValue mTimerSetting4 is null ");
            return false;
        }

        // サイズチェック
        if(mTimerSetting4.length != TIMERSETTING4.getDataLength()){
            Logger.e(TAG, "mTimerSetting4 length mismatch ="
                    + mTimerSetting4.length);
            return false;
        }

        // タイマ5設定値:必須チェックのみ
        if (mTimerSetting5 == null) {
            Logger.e(TAG, "isValidValue mTimerSetting5 is null ");
            return false;
        }

        // サイズチェック
        if(mTimerSetting5.length != TIMERSETTING5.getDataLength()){
            Logger.e(TAG, "mTimerSetting5 length mismatch ="
                    + mTimerSetting5.length);
            return false;
        }

        // LCD表示データ:チェック不要（byte単体でフラグ使用のため）
        // 表示言語:0～1（日本語、英語）
        if (!ByteUtil.checkTargetValueByte(mMessageLanguage, (byte) 0x00,
                (byte) 0x01)) {
            Logger.e(TAG, "isValidValue mMessageLanguage mismatch ="
                    + mMessageLanguage);
            return false;
        }

        // 動作モード:0～1
        if (!ByteUtil.checkTargetValueByte(mOperationMode, (byte) 0x00,
                (byte) 0x01)) {
            Logger.e(TAG, "isValidValue mOperationMode mismatch =" + mOperationMode);
            return false;
        }

        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return toCommand(ByteUtil.mergeByteArray(new byte[] { mVolume },
                mTimerSetting1, mTimerSetting2, mTimerSetting3, mTimerSetting4,
                mTimerSetting5, new byte[] { mLcdMessageData },
                new byte[] { mMessageLanguage }, new byte[] { mOperationMode }));
    }
}
