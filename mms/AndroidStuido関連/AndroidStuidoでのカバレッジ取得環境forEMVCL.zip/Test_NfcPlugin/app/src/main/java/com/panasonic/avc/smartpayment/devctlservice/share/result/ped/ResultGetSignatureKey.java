
package com.panasonic.avc.smartpayment.devctlservice.share.result.ped;

import java.util.Arrays;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetSignatureKey extends ResultData {

    /** @brief タンパ領域 ID5/ID6の最大の長さ */
    private static final int KEY_LENGTH_MAX = 2048;

    private byte[] mKey = new byte[KEY_LENGTH_MAX];

    public byte[] getKey() {
        return mKey;
    }

    public void setKey(byte[] key) {
        if (key == null) {
            return;
        }
        if (key.length > KEY_LENGTH_MAX) {
            return;
        }
        Arrays.fill(mKey, (byte) 0);

        for (int i = 0; i < key.length; i++) {
            mKey[i] = key[i];
        }
    }
}
