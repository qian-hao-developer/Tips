package com.panasonic.avc.smartpayment.devctlservice.nfc.request;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_SIZE_WITHOUT_PARAMETER;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.ID_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * ダウンロード終了BaseRequestクラス.
 * 
 */
abstract public class BaseDownloadEndRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = BaseDownloadEndRequest.class
            .getSimpleName();

    /** ID */
    protected byte mId = (byte) 0x02;
    /** @brief MC */
    protected byte mMainCommand = (byte) 0x01;
    /** @brief SC */
    protected byte mSubCommand = (byte) 0x82;
    /** @brief データ部Length */
    private int mDataLength = 0;

    /**
     * set McSc
     * @param mc MC
     * @param sc SC
     */
    protected void setMCSC(byte mc, byte sc) {
        mMainCommand = mc;
        mSubCommand = sc;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isValidValue() {
        return true;
    }


    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        // データ部なし
        return toCommand(null);
    }

    protected byte[] toCommand(byte[] parameter) {
        // コマンドの全体長取得
        int len = 0;
        mDataLength = len;

        // 配列を確保
        byte[] data = new byte[DATA_SIZE_WITHOUT_PARAMETER + mDataLength];
        // 値を入力
        data[ID_INDEX] = mId;
        data[MAINCOMMAND_INDEX] = mMainCommand;
        data[SUBCOMMAND_INDEX] = mSubCommand;
        data[DATALENGTHHIGH_INDEX] = (byte) (mDataLength & 0x00ff);
        data[DATALENGTHLOW_INDEX] = (byte) ((mDataLength >> 8) & 0x00ff);
        return data;
    }
}
