
package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;

/**
 * CheckHealth処理結果データ
 */
public class ResultCheckHealth extends
        com.panasonic.avc.smartpayment.devctlservice.share.result.ResultCheckHealth {

    private static final String CONDITION = "condition";

    private static final String PAPER = "paper";

    private static final String HEALTH = "health";

    private static final String NEWEST = "newest";

    private static final String NETWORK = "network";

    private static final String WIRELESS = "wireless";

    private boolean mIsPaperLess;

    private boolean mIsHealth;

    private boolean mHasNewest;

    private boolean mIsWired;

    private int mWirelessLevel;

    public ResultCheckHealth() {
    }

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth(Parcel in) {
        super(in);
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCheckHealth> CREATOR = new Parcelable.Creator<ResultCheckHealth>() {
        public ResultCheckHealth createFromParcel(Parcel in) {
            return new ResultCheckHealth(in);
        }

        public ResultCheckHealth[] newArray(int size) {
            return new ResultCheckHealth[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mIsPaperLess ? 1 : 0);
        dest.writeInt(mIsHealth ? 1 : 0);
        dest.writeInt(mHasNewest ? 1 : 0);
        dest.writeInt(mIsWired ? 1 : 0);
        dest.writeInt(mWirelessLevel);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mIsPaperLess = in.readInt() == 1 ? true : false;
        mIsHealth = in.readInt() == 1 ? true : false;
        mHasNewest = in.readInt() == 1 ? true : false;
        mIsWired = in.readInt() == 1 ? true : false;
        mWirelessLevel = in.readInt();
    }

    public boolean isPaperLess() {
        return mIsPaperLess;
    }

    public void setPaperLess(boolean paperLess) {
        mIsPaperLess = paperLess;
    }

    public boolean isHealth() {
        return mIsHealth;
    }

    public void setHealth(boolean health) {
        mIsHealth = health;
    }

    public boolean hasNewest() {
        return mHasNewest;
    }

    public void setNewest(boolean hasNewest) {
        mHasNewest = hasNewest;
    }

    public int isWired() {
        return mIsWired ? 1 : 2;
    }

    public void setWired(boolean wired) {
        mIsWired = wired;
    }

    public int getWirelessLevel() {
        return mWirelessLevel;
    }

    public void setWirelessLevel(int wirelessLevel) {
        mWirelessLevel = wirelessLevel;
    }

    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonCondition = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonCondition.put(PAPER, !isPaperLess());
            jsonCondition.put(HEALTH, !isHealth());
            jsonCondition.put(NEWEST, !hasNewest());
            jsonCondition.put(NETWORK, isWired());

            if (isWired() != 1) {
                jsonCondition.put(WIRELESS, getWirelessLevel());
            } else {
                jsonCondition.put(WIRELESS, JSONObject.NULL);
            }

            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(CONDITION, JSONObject.NULL);
            } else {
                json.put(CONDITION, jsonCondition);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
