
package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultBuzzerOn処理結果データ
 */
public class ResultBuzzerOn extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultBuzzerOn(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultBuzzerOn() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultBuzzerOn> CREATOR = new Parcelable.Creator<ResultBuzzerOn>() {
        public ResultBuzzerOn createFromParcel(Parcel in) {
            return new ResultBuzzerOn(in);
        }

        public ResultBuzzerOn[] newArray(int size) {
            return new ResultBuzzerOn[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

}
