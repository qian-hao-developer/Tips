
package com.panasonic.avc.smartpayment.devctlservice.system.util;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.panasonic.avc.smartpayment.devctlservice.R;

public class CreateAlartViewNoButton {

    private WindowManager mWindowManager = null;
    private View mBackGroundView = null;
    private View mDialogView = null;

    public void showView(Context context, int title_id, int message_id) {

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_SYSTEM_ERROR,
                WindowManager.LayoutParams.FLAG_LOCAL_FOCUS_MODE,
                PixelFormat.TRANSLUCENT);

        mWindowManager = (WindowManager) context.getSystemService(context.WINDOW_SERVICE);
        mBackGroundView = layoutInflater.inflate(
                com.panasonic.avc.smartpayment.devctlservice.R.layout.alert_background, null);
        mDialogView = layoutInflater
                .inflate(
                        com.panasonic.avc.smartpayment.devctlservice.R.layout.create_alert_dialog_no_button,
                        null);

        ((TextView) mDialogView.findViewById(R.id.tv_dialog_title)).setText(title_id);
        ((TextView) mDialogView.findViewById(R.id.tv_dialog_message)).setText(message_id);
        mWindowManager.addView(mBackGroundView, params);
        mWindowManager.addView(mDialogView, params);
    }

    public void dismissView() {
        if (mWindowManager != null && mDialogView != null && mBackGroundView != null) {
            mWindowManager.removeView(mDialogView);
            mWindowManager.removeView(mBackGroundView);
        }
    }

}
