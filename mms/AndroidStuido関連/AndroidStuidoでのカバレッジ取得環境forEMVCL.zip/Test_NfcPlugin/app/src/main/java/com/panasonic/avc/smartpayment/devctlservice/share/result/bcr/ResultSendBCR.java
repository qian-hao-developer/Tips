
package com.panasonic.avc.smartpayment.devctlservice.share.result.bcr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * SendBCRの実行結果データ
 */
public class ResultSendBCR extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultSendBCR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendBCR() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendBCR> CREATOR = new Parcelable.Creator<ResultSendBCR>() {
        public ResultSendBCR createFromParcel(Parcel in) {
            return new ResultSendBCR(in);
        }

        public ResultSendBCR[] newArray(int size) {
            return new ResultSendBCR[size];
        }
    };
}
