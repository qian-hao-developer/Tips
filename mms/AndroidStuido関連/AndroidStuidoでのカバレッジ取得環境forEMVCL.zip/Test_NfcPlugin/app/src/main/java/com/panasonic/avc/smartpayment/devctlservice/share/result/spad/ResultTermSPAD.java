
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultTermSPAD extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultTermSPAD(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermSPAD() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermSPAD> CREATOR = new Parcelable.Creator<ResultTermSPAD>() {

        @Override
        public ResultTermSPAD createFromParcel(Parcel in) {
            return new ResultTermSPAD(in);
        }

        @Override
        public ResultTermSPAD[] newArray(int size) {
            return new ResultTermSPAD[size];
        }
    };
}
