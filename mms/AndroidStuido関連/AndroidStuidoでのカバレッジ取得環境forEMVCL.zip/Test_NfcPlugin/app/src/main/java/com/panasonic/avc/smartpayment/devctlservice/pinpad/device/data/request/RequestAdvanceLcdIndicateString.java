
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 拡張LCD表示コマンド(文字列表示)
 */
public class RequestAdvanceLcdIndicateString extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x03;

    /** @brief コマンドの長さ */
    private static final int MIN_LENGTH = 0x4;

    /** @brief 表示データ */
    private byte[] mIndicateData;

    /** @brief 表示種別 */
    private static final byte LCD_INDICATE_MODE = 0x00;

    /** @brief 画面クリアコマンドサイズ */
    private static final byte ESC_SIZE = 2;

    /** @brief ESCヘッダー */
    private static final byte ESC_COMMAND_HEADER = 0x1b;

    /** @brief ESC画面消去 */
    private static final byte ESC_COMMAND_DELETE = 0x44;

    /**
     * @brief コンストラクタ
     */
    public RequestAdvanceLcdIndicateString(byte[] indicateData) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mIndicateData = indicateData;
    }

    /**
     * @brief 表示データを取得する
     * @return 表示データ(nullもしくは128バイトのデータ)
     */
    public byte[] getIndicateData() {
        return mIndicateData;
    }

    /**
     * @brief 表示データを設定する
     * @param indicateData 表示データ
     */
    public void setIndicateData(byte[] indicateData) {
        mIndicateData = indicateData;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[MIN_LENGTH + mIndicateData.length + ESC_SIZE];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = LCD_INDICATE_MODE;
        parameter[3] = 1;
        parameter[4] = ESC_COMMAND_HEADER;
        parameter[5] = ESC_COMMAND_DELETE;
        System.arraycopy(mIndicateData, 0, parameter, 6, mIndicateData.length);

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mIndicateData == null || mIndicateData.length > 256) {
            return false;
        }

        return true;
    }

}
