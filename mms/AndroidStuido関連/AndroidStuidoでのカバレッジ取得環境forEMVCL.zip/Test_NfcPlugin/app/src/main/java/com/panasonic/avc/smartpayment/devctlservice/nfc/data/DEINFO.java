package com.panasonic.avc.smartpayment.devctlservice.nfc.data;

/**
 * Data Exchange情報格納クラス<br>
 */
public class DEINFO {
    /** 継続フラグ. */
    public byte ContinueFlag;
    /** 処理結果. */
    public byte[] Result;
    /** Data Exchangeデータ. */
    public byte[] DataExchangeData;
    /** DEINFOが設定されているか. */
    public boolean isSet = false;
}
