
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 拡張キー入力制御コマンド
 */
public class RequestAdvanceKeyInput extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x04;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 5;

    /** @brief キーマスク設定 */
    private int mKeyMask;

    /** @brief F1キー **/
    private static final int VALID_KEY_F1 = 0;

    /** @brief F2キー **/
    private static final int VALID_KEY_F2 = 1;

    /** @brief F3キー **/
    private static final int VALID_KEY_F3 = 2;

    /** @brief 確定キー **/
    private static final int VALID_KEY_ENTER = 3;

    /** @brief 訂正キー **/
    private static final int VALID_KEY_CLEAR = 4;

    /** @brief 取り消しキー **/
    private static final int VALID_KEY_CANCEL = 5;

    /** @brief 確定キー **/
    private static final int VALID_BIT_KEY_ENTER = 0;

    /** @brief 取り消しキー **/
    private static final int VALID_BIT_KEY_CANCEL = 1;

    /** @brief 訂正キー **/
    private static final int VALID_BIT_KEY_CLEAR = 2;

    /** @brief F1キー **/
    private static final int VALID_BIT_KEY_F1 = 3;

    /** @brief F2キー **/
    private static final int VALID_BIT_KEY_F2 = 4;

    /** @brief F3キー **/
    private static final int VALID_BIT_KEY_F3 = 5;

    /**
     * @brief ブザー設定
     */
    public enum Buzzer {
        ON((byte) 0x01),
        OFF((byte) 0x00);

        private final byte mValue;

        private Buzzer(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }
    }

    /** @brief ブザー有効無効 */
    private Buzzer mBuzzer;

    /**
     * @brief コンストラクタ
     * @param buzzer ブザー設定
     */
    public RequestAdvanceKeyInput(Buzzer buzzer, int mask) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mBuzzer = buzzer;
        mKeyMask = mask;
    }

    /**
     * @brief ブザー設定を取得する
     * @return ブザー設定
     */
    public Buzzer getBuzzer() {
        return mBuzzer;
    }

    /**
     * @brief ブザーの有無の設定する
     * @param buzzer ブザー設定
     */
    public void setBuzzer(Buzzer buzzer) {
        mBuzzer = buzzer;
    }

    /**
     * @brief キーマスクを取得します
     * @return キーマスク
     */
    public int getKeyMask() {
        return mKeyMask;
    }

    /**
     * @brief キーマスクを設定します
     * @param keyMask キーマスク
     */
    public void setKeyMask(int keyMask) {
        mKeyMask = keyMask;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        // プラグインのAPI仕様からPINPADのインターフェースに変換
        int key = 0;
        key |= ((mKeyMask >> VALID_KEY_F1) & 0x01) > 0 ? 1 << VALID_BIT_KEY_F1 : 0;
        key |= ((mKeyMask >> VALID_KEY_F2) & 0x01) > 0 ? 1 << VALID_BIT_KEY_F2 : 0;
        key |= ((mKeyMask >> VALID_KEY_F3) & 0x01) > 0 ? 1 << VALID_BIT_KEY_F3 : 0;
        key |= ((mKeyMask >> VALID_KEY_ENTER) & 0x01) > 0 ? 1 << VALID_BIT_KEY_ENTER : 0;
        key |= ((mKeyMask >> VALID_KEY_CLEAR) & 0x01) > 0 ? 1 << VALID_BIT_KEY_CLEAR : 0;
        key |= ((mKeyMask >> VALID_KEY_CANCEL) & 0x01) > 0 ? 1 << VALID_BIT_KEY_CANCEL : 0;

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = mBuzzer.getValue();
        parameter[3] = (byte) (key & 0xff);
        parameter[4] = (byte) (key >> 8 & 0xff);

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mKeyMask < 1 || mKeyMask > 63) {
            return false;
        }

        return true;
    }

}
