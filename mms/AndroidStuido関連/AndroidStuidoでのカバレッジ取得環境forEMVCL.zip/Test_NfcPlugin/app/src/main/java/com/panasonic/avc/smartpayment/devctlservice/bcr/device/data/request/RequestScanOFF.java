
package com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.RequestBarcodeReaderData;

/**
 * バーコードの読み取りを終了します
 */
public class RequestScanOFF extends RequestBarcodeReaderData {

    /** @brief コマンド種別 - オートトリガを無効 */
    private static final String COMMAND_ID_PLUS_F = "+F";

    /** @brief コマンド種別 - スキャナの読み取り動作を無効 */
    private static final String COMMAND_ID_EAU = "EAU";

    /**
     * @brief コンストラクタ
     * @param productId プロダクトID
     */
    public RequestScanOFF(int productId) {
        addCommand(COMMAND_ID_PLUS_F);
        if (productId != BarcodeReaderDefine.PID_C_40_C_41) {
            // 一次元バーコードでは定義されないコマンド
            addCommand(COMMAND_ID_EAU);
        }
    }

}
