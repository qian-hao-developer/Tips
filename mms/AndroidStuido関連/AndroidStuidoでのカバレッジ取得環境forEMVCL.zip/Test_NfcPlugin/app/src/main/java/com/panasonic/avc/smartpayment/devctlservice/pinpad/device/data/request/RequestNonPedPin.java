
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 非PED対応暗証番号入力要求クラス
 */
public class RequestNonPedPin extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x04;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x00;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 82;

    /** @brief 暗証番号入力フォーマット */
    public enum NonPedPinFormat {
        ISO9564Format0((byte) 0x00),
        ISO9564Format1((byte) 0x01),
        ISO9564Format2((byte) 0x02),
        ISO9564Format3((byte) 0x03),
        ECI2Format((byte) 0x10),
        VISA3Format((byte) 0x11),
        ISO9564Format0WithJDebit((byte) 0x20),
        INFOXFormat((byte) 0x21),
        INFOXFormatWithJDebit((byte) 0x22),
        OfflinePinBlock((byte) 0x30);

        private final byte mNum;

        private NonPedPinFormat(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力拡張フォーマット */
    public enum NonPedPinFormatAdvance {
        Padding0((byte) 0x00),
        PKCS7((byte) 0x01),
        ANSIX923((byte) 0x02),
        ISO10126((byte) 0x03),
        PanddingRand((byte) 0x04);

        private final byte mNum;

        private NonPedPinFormatAdvance(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 入力制御 */
    public enum NonPedPinSoundAndTenKeyTimer {
        NONE((byte) 0x00),
        JP_NON_TIMEOUT((byte) 0x80),
        JP_TIMEOUT((byte) 0xA0),
        US_NON_TIMEOUT((byte) 0xC0),
        US_TIMEOUT((byte) 0xE0);

        private final byte mNum;

        private NonPedPinSoundAndTenKeyTimer(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 画面制御 */
    public enum NonPedPinDisplayControl {
        NONE((byte) 0x00),
        CANCEL((byte) 0x40),
        UNDER_SCORE((byte) 0x10),
        CANCEL_AND_UNDER_SCORE((byte) 0x50);

        private final byte mNum;

        private NonPedPinDisplayControl(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 表示制御 */
    public enum NonPedPinScreen {
        NONE((byte) 0x00),
        AMOUNT((byte) 0x81),
        BY_PASS((byte) 0x11),
        DCC((byte) 0x03),
        AMOUNT_AND_BY_PASS((byte) 0x91),
        AMOUNT_AND_DCC((byte) 0x83),
        BY_PASS_AND_DCC((byte) 0x13),
        AMOUNT_AND_BY_PASS_AND_DCC((byte) 0x93);

        private final byte mNum;

        private NonPedPinScreen(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief アプリ名称ID */
    public enum NonPedPinAppName {
        NONE((byte) 0x00),
        AMOUNT_JP((byte) 0x01),
        CREDIT_JP((byte) 0x02),
        DEBIT((byte) 0x03),
        AMOUNT_US((byte) 0x04),
        ID((byte) 0x05),
        CREDIT_US((byte) 0x06),
        GINREN((byte) 0x07),
        WAON((byte) 0x08);

        private final byte mNum;

        private NonPedPinAppName(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 金額表示文字種別 */
    public enum NonPedPinMoneyChar {
        NORMAL((byte) 0x00),
        DOT6SIZE((byte) 0x01);

        private final byte mNum;

        private NonPedPinMoneyChar(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(前段) */
    public enum NonPedPinDisplayFirst {
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03),
        DISP4((byte) 0x04),
        DISP5((byte) 0x05),
        DISP6((byte) 0x06),
        DISP7((byte) 0x07),
        DISP8((byte) 0x08),
        DISP9((byte) 0x09),
        DISP10((byte) 0x0a),
        DISP11((byte) 0x0b),
        DISP12((byte) 0x0c),
        DISP13((byte) 0x0d),
        DISP14((byte) 0x0e),
        DISP15((byte) 0x0f),
        DISP16((byte) 0x10),
        DISP17((byte) 0x11),
        DISP18((byte) 0x12),
        DISP19((byte) 0x13),
        DISP20((byte) 0x14),
        DISP21((byte) 0x15),
        DISP22((byte) 0x16),
        DISP23((byte) 0x17),
        DISP24((byte) 0x18),
        DISP25((byte) 0x19),
        DISP26((byte) 0x1a),
        DISP27((byte) 0x1b);

        private final byte mNum;

        private NonPedPinDisplayFirst(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(中段) */
    public enum NonPedPinDisplaySecond {
        DISP0((byte) 0x00),
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03),
        DISP4((byte) 0x04),
        DISP5((byte) 0x05),
        DISP6((byte) 0x06);

        private final byte mNum;

        private NonPedPinDisplaySecond(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(後段)正常完了時 */
    public enum NonPedPinDisplayThirdComplete {
        DISP0((byte) 0x00),
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03);

        private final byte mNum;

        private NonPedPinDisplayThirdComplete(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(後段)スキップ時 */
    public enum NonPedPinDisplayThirdSkip {
        DISP0((byte) 0x00),
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03);

        private final byte mNum;

        private NonPedPinDisplayThirdSkip(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(後段)取消時 */
    public enum NonPedPinDisplayThirdCancel {
        DISP0((byte) 0x00),
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03);

        private final byte mNum;

        private NonPedPinDisplayThirdCancel(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(後段)タイムアウト時 */
    public enum NonPedPinDisplayThirdTimeout {
        DISP0((byte) 0x00),
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03);

        private final byte mNum;

        private NonPedPinDisplayThirdTimeout(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 暗証番号入力画面(後段)処理中断時 */
    public enum NonPedPinDisplayThirdWorkInterruption {
        DISP0((byte) 0x00),
        DISP1((byte) 0x01),
        DISP2((byte) 0x02),
        DISP3((byte) 0x03);

        private final byte mNum;

        private NonPedPinDisplayThirdWorkInterruption(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 取引中止確認画面 */
    public enum NonPedPinDisplayCancel {
        NONE((byte) 0x00),
        ENABLE((byte) 0x01);

        private final byte mNum;

        private NonPedPinDisplayCancel(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief PIN不知メッセージ画面 */
    public enum NonPedPinDisplayUnknown {
        NONE((byte) 0x00),
        ENABLE((byte) 0x01);

        private final byte mNum;

        private NonPedPinDisplayUnknown(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief スキップ確認画面 */
    public enum NonPedPinDisplaySkip {
        NONE((byte) 0x00),
        ENABLE((byte) 0x01);

        private final byte mNum;

        private NonPedPinDisplaySkip(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 業務名称ID */
    public enum NonPedPinWorkName {
        NONE((byte) 0x00),
        SALE((byte) 0x01),
        CANCEL((byte) 0x02),
        RETURN((byte) 0x03),
        RETURN_CANCEL((byte) 0x04),
        SHOURI((byte) 0x05),
        AUTHORIZATION((byte) 0x06),
        CARD_CHECK((byte) 0x07),
        BALANCE((byte) 0x08);

        private final byte mNum;

        private NonPedPinWorkName(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 支払い方法ID */
    public enum NonPedPinPayType {
        NONE((byte) 0x00),
        JP_NON_TIMEOUT((byte) 0x01),
        LUMP((byte) 0x02),
        INSTALLMENT((byte) 0x03),
        BONUS((byte) 0x04),
        BONUS_CONBINATION((byte) 0x05),
        REVOLVING((byte) 0x06);

        private final byte mNum;

        private NonPedPinPayType(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief 通貨コード */
    private String mCurrency;

    /** @brief 金額 */
    private String mAmount;

    /** @brief 入力PINの最小桁数 */
    private int mMin;

    /** @brief 入力PINの最大桁 */
    private int mMax;

    private NonPedPinFormat mPinFormat;

    private NonPedPinFormatAdvance mPinFormatAdvance;

    private String mPanInfo;

    private NonPedPinSoundAndTenKeyTimer mSoundAndTimer;

    private NonPedPinDisplayControl mDisplayControl;

    private NonPedPinScreen mScreen;

    private NonPedPinAppName mAppName;

    private NonPedPinMoneyChar mMoneyChar;

    private NonPedPinDisplayFirst mDisplayFirst;

    private NonPedPinDisplaySecond mDisplaySecond;

    private NonPedPinDisplayThirdComplete mDisplayThirdComplete;

    private NonPedPinDisplayThirdSkip mDisplayThirdSkip;

    private NonPedPinDisplayThirdCancel mDisplayThirdCancel;

    private NonPedPinDisplayThirdTimeout mDisplayThirdTimount;

    private NonPedPinDisplayThirdWorkInterruption mDisplayThirdWork;

    private NonPedPinDisplayCancel mDisplayCancel;

    private NonPedPinDisplayUnknown mDisplayUnknown;

    private NonPedPinDisplaySkip mDisplaySkip;

    private NonPedPinWorkName mDisplayWorkName;

    private NonPedPinPayType mPayType;

    /**
     * @brief コンストラクタ
     */
    public RequestNonPedPin(String currency, String amount, int min, int max, String panInfo,
            NonPedPinFormat format, NonPedPinFormatAdvance formatAdvance,
            NonPedPinSoundAndTenKeyTimer soundAndTimer, NonPedPinDisplayControl displayControl,
            NonPedPinScreen screen, NonPedPinAppName appName, NonPedPinMoneyChar moneyChar,
            NonPedPinDisplayFirst displayFirst, NonPedPinDisplaySecond displaySecond,
            NonPedPinDisplayThirdComplete displayThirdComplete,
            NonPedPinDisplayThirdSkip displayThirdSkip,
            NonPedPinDisplayThirdCancel displayThirdCancel,
            NonPedPinDisplayThirdTimeout displayThirdTimount,
            NonPedPinDisplayThirdWorkInterruption displayThirdWork,
            NonPedPinDisplayCancel displayCancel,
            NonPedPinDisplayUnknown displayUnknown, NonPedPinDisplaySkip displaySkip,
            NonPedPinWorkName displayWorkName, NonPedPinPayType payType) {
        mCurrency = currency;
        mAmount = amount;
        mMin = min;
        mMax = max;
        mPanInfo = panInfo;
        mPinFormat = format;
        mPinFormatAdvance = formatAdvance;
        mSoundAndTimer = soundAndTimer;
        mDisplayControl = displayControl;
        mScreen = screen;
        mAppName = appName;
        mMoneyChar = moneyChar;
        mDisplayFirst = displayFirst;
        mDisplaySecond = displaySecond;
        mDisplayThirdComplete = displayThirdComplete;
        mDisplayThirdSkip = displayThirdSkip;
        mDisplayThirdCancel = displayThirdCancel;
        mDisplayThirdTimount = displayThirdTimount;
        mDisplayThirdWork = displayThirdWork;
        mDisplayCancel = displayCancel;
        mDisplayUnknown = displayUnknown;
        mDisplaySkip = displaySkip;
        mDisplayWorkName = displayWorkName;
        mPayType = payType;
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @brief 通貨コードを取得します
     * @return mCurrency 通貨コード
     */
    public String getCurrency() {
        return mCurrency;
    }

    /**
     * @brief 通貨コードを設定します
     * @param[in] mCurrency 通貨コード
     */
    public void setCurrency(String mCurrency) {
        this.mCurrency = mCurrency;
    }

    /**
     * @brief 金額を取得します
     * @return mAmount 金額
     */
    public String getAmount() {
        return mAmount;
    }

    /**
     * @brief 金額を設定します
     * @param[in] mAmount 金額
     */
    public void setAmount(String mAmount) {
        this.mAmount = mAmount;
    }

    /**
     * @brief 入力PINの最小桁数を取得します
     * @return mMin 入力PINの最小桁数
     */
    public int getMin() {
        return mMin;
    }

    /**
     * @brief 入力PINの最小桁数を設定します
     * @param[in] mMin 入力PINの最小桁数
     */
    public void setMin(int mMin) {
        this.mMin = mMin;
    }

    /**
     * @brief 入力PINの最大桁を取得します
     * @return mMax 入力PINの最大桁
     */
    public int getMax() {
        return mMax;
    }

    /**
     * @brief 入力PINの最大桁を設定します
     * @param[in] mMax 入力PINの最大桁
     */
    public void setMax(int mMax) {
        this.mMax = mMax;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        byte[] paramater = new byte[LENGTH];

        byte[] paninfo = CalcUtil.toByte(mPanInfo);
        if (paninfo == null) {
            return null;
        }

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);
        paramater[2] = (byte) 0x60;
        paramater[3] = (byte) 0x08;
        paramater[4] = (byte) 0x00;
        paramater[5] = (byte) 0x00;
        paramater[6] = (byte) 0x03;
        paramater[7] = mPinFormat.getNum();
        paramater[8] = mPinFormatAdvance.getNum();
        paramater[9] = (byte) (0x1300 & 0x00ff);
        paramater[10] = (byte) ((0x1300 >> 8) & 0x00ff);
        paramater[11] = (byte) 0x00;
        paramater[12] = (byte) 0x00;
        paramater[13] = (byte) 0x70;
        paramater[14] = (byte) (0x18 & 0x00ff);
        paramater[15] = (byte) ((0x18 >> 8) & 0x00ff);
        paramater[16] = (byte) 0x01;
        paramater[17] = (byte) (0x1302 & 0x00ff);
        paramater[18] = (byte) ((0x1302 >> 8) & 0x00ff);
        paramater[19] = (byte) 0x00;
        paramater[20] = (byte) 0x00;
        paramater[21] = (byte) 0x41;
        paramater[22] = (byte) 0x01;
        paramater[23] = (byte) 0x10;
        paramater[24] = paninfo[0];
        paramater[25] = paninfo[1];
        paramater[26] = paninfo[2];
        paramater[27] = paninfo[3];
        paramater[28] = paninfo[4];
        paramater[29] = paninfo[5];
        paramater[30] = paninfo[6];
        paramater[31] = paninfo[7];
        paramater[32] = paninfo[8];
        paramater[33] = paninfo[9];
        paramater[34] = paninfo[10];
        paramater[35] = paninfo[11];
        paramater[36] = paninfo[12];
        paramater[37] = paninfo[13];
        paramater[38] = paninfo[14];
        paramater[39] = paninfo[15];
        paramater[40] = (byte) ((mMin & 0x0f) << 4 | mMax & 0x0f);
        paramater[41] = mSoundAndTimer.getNum();
        paramater[42] = mDisplayControl.getNum();
        paramater[43] = mScreen.getNum();
        paramater[44] = mAppName.getNum();
        paramater[45] = mMoneyChar.getNum();
        paramater[46] = (byte) mCurrency.getBytes()[2];
        paramater[47] = (byte) mCurrency.getBytes()[1];
        paramater[48] = (byte) mCurrency.getBytes()[0];
        paramater[49] = (byte) 0x00;// TODO 金額データ
        paramater[50] = (byte) 0x00;// TODO 金額データ
        paramater[51] = (byte) 0x00;// TODO 金額データ
        paramater[52] = (byte) 0x00;// TODO 金額データ
        paramater[53] = (byte) 0x00;// TODO 金額データ
        paramater[54] = (byte) 0x00;// TODO 金額データ
        paramater[55] = (byte) 0x00;// TODO 金額データ
        paramater[56] = (byte) 0x00;// TODO 金額データ
        paramater[57] = (byte) 0x00;// TODO 金額データ
        paramater[58] = (byte) 0x00;// TODO 金額データ
        paramater[59] = (byte) 0x00;// TODO 金額データ
        paramater[60] = (byte) 0x00;// TODO 金額データ
        paramater[61] = (byte) 0x00;// TODO 金額データ
        paramater[62] = (byte) 0x00;// TODO 金額データ
        paramater[63] = (byte) 0x00;// TODO 金額データ
        paramater[64] = (byte) 0x00;// TODO 金額データ
        paramater[65] = (byte) 0x00;// TODO 金額データ
        paramater[66] = (byte) 0x00;// TODO 金額データ
        paramater[67] = (byte) 0x00;// TODO 金額データ
        paramater[68] = (byte) 0x00;// TODO 金額データ
        paramater[69] = (byte) 0x00;// TODO 金額データ
        paramater[70] = mDisplayFirst.getNum();
        paramater[71] = mDisplaySecond.getNum();
        paramater[72] = mDisplayThirdComplete.getNum();
        paramater[73] = mDisplayThirdSkip.getNum();
        paramater[74] = mDisplayThirdCancel.getNum();
        paramater[75] = mDisplayThirdTimount.getNum();
        paramater[76] = mDisplayThirdWork.getNum();
        paramater[77] = mDisplayCancel.getNum();
        paramater[78] = mDisplayUnknown.getNum();
        paramater[79] = mDisplaySkip.getNum();
        paramater[80] = mDisplayWorkName.getNum();
        paramater[81] = mPayType.getNum();

        return toCommand(paramater);
    }
}
