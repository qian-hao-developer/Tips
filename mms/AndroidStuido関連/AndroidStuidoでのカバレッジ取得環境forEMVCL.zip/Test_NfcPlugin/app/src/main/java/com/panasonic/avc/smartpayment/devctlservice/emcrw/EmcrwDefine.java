
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

public class EmcrwDefine {

    /** @brief NonContactICCard JT-R550CR PID */
    public static final int PID_JT_R500CR = 0x3c30;

    /** @brief NonContactICCard JT-R550CR-41 PID */
    public static final int PID_JT_R500CR_41 = 0x0f54;

    /** @brief NonContactICCard VID */
    public static final int VID = 0x04da;

    /** @brief NonContactICCard PID リスト */
    public static final int[] PID_LIST = new int[] {
        PID_JT_R500CR, // JT-R550CR
        PID_JT_R500CR_41, // JT-R550CR-41
    };

    /** @brief NonContactICCard USB バスパワー対応リスト */
    public static final boolean[] USB_BUS_POWER_LIST = new boolean[] {
        false, // JT-R550CR
        true, // JT-R550CR-41
    };

    // FeliCaコマンドアプリ APID
    public static final byte FELICA_APID = (byte) 0x40;

    /* モデルタイプ定義 */
    public final static int MODEL_TYPE_M = 1; /* モバイル型 */
    public final static int MODEL_TYPE_R = 2; /* 据置型　 */
    public final static int MODEL_TYPE_D = 3; /* 一体型　 */

    /* リンクレベル定義 */
    public final static int LINK_LEVEL_CCT = 1;
    public final static int LINK_LEVEL_PINPAD = 2;

    /** @brief コマンドのSTX値 */
    public static final byte STX_CODE = 0x02;

    /** @brief コマンドのETX値 */
    public static final byte ETX_CODE = 0x03;

    /** @brief CRCサイズ */
    public static final int CRC_SIZE = 2;

    /** @brief STXサイズ */
    public static final int STX_SIZE = 1;

    /** @brief ヘッダーサイズ */
    public static final int HEADER_SIZE = 5;

    /** @brief ETXサイズ */
    public static final int ETX_SIZE = 1;

    /** @brief パラメータを除いた固定のデータサイズ */
    public static final int DATA_SIZE_WITHOUT_PARAMETER = STX_SIZE + HEADER_SIZE + ETX_SIZE
            + CRC_SIZE;

    /** @brief CRCを計算しない領域のサイズ */
    public static final int CRC_NOT_CALC_SIZE = STX_SIZE + CRC_SIZE;
}
