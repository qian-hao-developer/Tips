
package com.panasonic.avc.smartpayment.devctlservice.share.result.msr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * TermMSRの実行結果データ
 */
public class ResultTermMSR extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermMSR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermMSR() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermMSR> CREATOR = new Parcelable.Creator<ResultTermMSR>() {
        public ResultTermMSR createFromParcel(Parcel in) {
            return new ResultTermMSR(in);
        }

        public ResultTermMSR[] newArray(int size) {
            return new ResultTermMSR[size];
        }
    };
}
