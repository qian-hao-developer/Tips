
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * RequestBuzzerONの実行結果データ
 */
public class ResultRequestBuzzerON extends AnalyzeResultData {

    /** @brief マスターコマンド **/
    private static final byte MASTER_COMMAND = 0x20;

    /** @brief サブコマンド **/
    private static final byte SUB_COMMAND = 0x04;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x02;

    /**
     * @brief コンストラクタ
     */
    public ResultRequestBuzzerON() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief コンストラクタ
     */
    public ResultRequestBuzzerON(Parcel in) {
        super(in);
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultRequestBuzzerON> CREATOR = new Parcelable.Creator<ResultRequestBuzzerON>() {
        public ResultRequestBuzzerON createFromParcel(Parcel in) {
            return new ResultRequestBuzzerON(in);
        }

        public ResultRequestBuzzerON[] newArray(int size) {
            return new ResultRequestBuzzerON[size];
        }
    };

    /**
     * @see AnalyzeResultData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int result = buffer[PinpadDefine.INDEX_PARAMETER];

        if (result != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.HMI, result, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        return true;
    }
}
