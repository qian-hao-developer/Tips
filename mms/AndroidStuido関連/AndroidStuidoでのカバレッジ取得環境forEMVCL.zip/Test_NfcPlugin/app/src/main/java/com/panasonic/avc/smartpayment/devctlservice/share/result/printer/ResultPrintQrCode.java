
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

public class ResultPrintQrCode extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintQrCode(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintQrCode() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintQrCode> CREATOR = new Parcelable.Creator<ResultPrintQrCode>() {
        public ResultPrintQrCode createFromParcel(Parcel in) {
            return new ResultPrintQrCode(in);
        }

        public ResultPrintQrCode[] newArray(int size) {
            return new ResultPrintQrCode[size];
        }
    };
}
