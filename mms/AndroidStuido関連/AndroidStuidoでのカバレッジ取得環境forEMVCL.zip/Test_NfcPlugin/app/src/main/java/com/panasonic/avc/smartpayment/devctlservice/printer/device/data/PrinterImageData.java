
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data;

/**
 * 描画画像管理クラス
 */
public class PrinterImageData {

    /** @brief 画像の横幅 */
    private int mX;

    /** @brief 画像の縦幅 */
    private int mY;

    /** @brief 画像のデータ */
    private byte[] mImage;

    /** @brief 名前 */
    private String mName;

    /** @brief 通常印字 */
    public static final int SCALE_NORMAL = 1;

    /** @brief 縦倍 */
    private static final int SCALE_HEIGHT = 2;

    /** @brief 横倍 */
    private static final int SCALE_WIDTH = 3;

    /** @brief 縦横倍 */
    private static final int SCALE_HEIGHT_WIDTH = 4;

    /**
     * @brief コンストラクタ
     * @param x 画像の横幅
     * @param y 画像の縦幅
     * @param image 画像データ
     * @param name 名前
     */
    public PrinterImageData(int x, int y, byte[] image, String name) {
        mX = x * 8;
        mY = y;
        mImage = image;
        mName = name;
    }

    /**
     * @brief 画像の横幅を取得する
     * @return 画像の横幅
     */
    public int getX(int scale) {
        switch (scale) {
            case SCALE_HEIGHT_WIDTH:
            case SCALE_WIDTH:
                return mX * 2;
            case SCALE_HEIGHT:
            case SCALE_NORMAL:
            default:
                break;
        }

        return mX;
    }

    /**
     * @brief 画像の横幅を取得する
     * @return 画像の横幅
     */
    public int getX() {
        return getX(SCALE_NORMAL) / 8;
    }

    /**
     * @brief 画像の横幅を設定する
     * @param x 画像の横幅
     */
    public void setX(int x) {
        mX = x;
    }

    /**
     * @brief 画像の縦幅を取得する
     * @return 画像の縦幅
     */
    public int getY(int scale) {
        switch (scale) {
            case SCALE_HEIGHT_WIDTH:
            case SCALE_HEIGHT:
                return mY * 2;
            case SCALE_NORMAL:
            case SCALE_WIDTH:
            default:
                break;
        }
        return mY;
    }

    /**
     * @brief 画像の縦幅を取得する
     * @return 画像の縦幅
     */
    public int getY() {
        return getY(SCALE_NORMAL);
    }

    /**
     * @brief 画像の縦幅を設定する
     * @param y 画像の縦幅
     */
    public void setY(int y) {
        mY = y;
    }

    /**
     * @brief 画像データを取得する
     * @return 画像データ
     */
    public byte[] getImage(int scale) {
        if (mImage == null) {
            return null;
        }
        byte[] ret = null;

        switch (scale) {
            case SCALE_WIDTH:
                ret = createScaleWidth(mImage);
                break;
            case SCALE_HEIGHT:
                ret = createScaleHeight(mImage);
                break;
            case SCALE_HEIGHT_WIDTH:
                byte[] tmp = createScaleHeight(mImage);
                ret = createScaleWidth(tmp);
                break;
            case SCALE_NORMAL:
            default:
                ret = mImage;
                break;
        }
        return ret;
    }

    /**
     * @brief 画像データを取得する
     * @return 画像データ
     */
    public byte[] getImage() {
        return getImage(SCALE_NORMAL);
    }

    /**
     * @brief 画像データを設定する
     * @param image 画像データ
     */
    public void setImage(byte[] image) {
        mImage = image;
    }

    /**
     * @brief 名前を取得する
     * @return 名前
     */
    public String getName() {
        return mName;
    }

    /**
     * @brief 名前を設定する
     * @param name 名前
     */
    public void setName(String name) {
        mName = name;
    }

    /**
     * @brief データの上限下限チェック
     * @return 問題があるかどうか
     */
    public boolean isValidValue(int width, int scale) {
        if (mImage == null) {
            return false;
        }

        if (mName == null || mName.length() > 9) {
            return false;
        }

        if (width == 1) {
            if (mX <= 0 || mX > 384) {
                return false;
            }
        } else {
            if (mX <= 0 || mX > 432) {
                return false;
            }
        }

        if (mY <= 0 || mY > 200) {
            return false;
        }

        switch (scale) {
            case SCALE_WIDTH:
            case SCALE_HEIGHT:
            case SCALE_HEIGHT_WIDTH:
            case SCALE_NORMAL:
                break;
            default:
                return false;
        }

        return true;
    }

    /**
     * 横倍処理
     * 
     * @param bytes
     * @return 横倍結果
     */
    private byte[] createScaleWidth(byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        byte[] ret = new byte[bytes.length * 2];

        for (int i = 0, index = 0; i < bytes.length; i++, index += 2) {
            byte bit0 = (byte) ((bytes[i] & 0x01) >> 0);
            byte bit1 = (byte) ((bytes[i] & 0x02) >> 1);
            byte bit2 = (byte) ((bytes[i] & 0x04) >> 2);
            byte bit3 = (byte) ((bytes[i] & 0x08) >> 3);
            byte bit4 = (byte) ((bytes[i] & 0x10) >> 4);
            byte bit5 = (byte) ((bytes[i] & 0x20) >> 5);
            byte bit6 = (byte) ((bytes[i] & 0x40) >> 6);
            byte bit7 = (byte) ((bytes[i] & 0x80) >> 7);

            byte byte1 = (byte) (bit0 | (bit0 << 1) | (bit1 << 2) | (bit1 << 3) | (bit2 << 4)
                    | (bit2 << 5) | (bit3 << 6) | (bit3 << 7));
            byte byte2 = (byte) (bit4 | (bit4 << 1) | (bit5 << 2) | (bit5 << 3) | (bit6 << 4)
                    | (bit6 << 5) | (bit7 << 6) | (bit7 << 7));
            ret[index] = byte2;
            ret[index + 1] = byte1;
        }

        return ret;
    }

    /**
     * 縦倍処理
     * 
     * @param bytes
     * @return 縦倍結果
     */
    private byte[] createScaleHeight(byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        byte[] ret = new byte[bytes.length * 2];

        int line = mX / 8;
        int count = bytes.length / line;

        int index = 0;
        for (int i = 0; i < count; i++) {
            System.arraycopy(bytes, i * line, ret, index, line);
            index += line;
            System.arraycopy(bytes, i * line, ret, index, line);
            index += line;
        }

        return ret;
    }
}
