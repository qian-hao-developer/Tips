
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSendImage extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSendImage(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendImage() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendImage> CREATOR = new Parcelable.Creator<ResultSendImage>() {

        @Override
        public ResultSendImage createFromParcel(Parcel in) {
            return new ResultSendImage(in);
        }

        @Override
        public ResultSendImage[] newArray(int size) {
            return new ResultSendImage[size];
        }
    };
}
