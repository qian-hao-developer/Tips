
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

import java.util.LinkedHashMap;
import java.util.Map;

import android.annotation.SuppressLint;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * 非接触 IC カード R/W のアプリケーションデータマップクラス
 */
@SuppressWarnings("serial")
public class EmcrwApplicationDataMap extends LinkedHashMap<Byte, EmcrwApplicationData> {

    /**
     * コンストラクタ
     */
    public EmcrwApplicationDataMap() {
        super();
    }

    /**
     * コンストラクタ
     */
    public EmcrwApplicationDataMap(int capacity) {
        super(capacity);
    }

    /**
     * コンストラクタ
     */
    public EmcrwApplicationDataMap(int capacity, float loadFactor) {
        super(capacity, loadFactor);
    }

    /**
     * @param apData
     * @return
     */
    @SuppressLint("UseValueOf")
    public boolean add(EmcrwApplicationData apData) {
        try {
            Byte key = CalcUtil.toByteChar(apData.getID());
            if (containsKey(key)) {
                return false;
            } else {
                super.put(key, apData);
                return true;
            }
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * @deprecated use {@link EmcrwApplicationDataMap#add(EmcrwApplicationData)}
     */
    @Override
    public EmcrwApplicationData put(Byte key, EmcrwApplicationData value) {
        return super.put(key, value);
    }

    /**
     * @deprecated use {@link EmcrwApplicationDataMap#add(EmcrwApplicationData)}
     */
    @Override
    public void putAll(Map<? extends Byte, ? extends EmcrwApplicationData> map) {
        super.putAll(map);
    }

}
