
package com.panasonic.avc.smartpayment.devctlservice.pinpad;

import android.content.Context;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.SerialDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.UsbDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.DeviceType;

/**
 * デバイス管理クラス
 */
public class DeviceManager {

    /** @brief インスタンス */
    private static DeviceManager sInstance = new DeviceManager();

    /** @brief デバイスクラス */
    private ControlDeviceManager mDevice;

    /**
     * @brief コンストラクタ
     */
    private DeviceManager() {

    }

    /**
     * インスタンス取得
     * 
     * @return インスタンス
     */
    public static DeviceManager getInstance() {
        return sInstance;
    }

    /**
     * @brief 管理クラス生成
     * @param context コンテキスト’
     * @param type デバイスの種類
     * @return 管理クラス
     */
    public ControlDeviceManager createDeviceController(Context context, DeviceType type) {
        switch (type) {
            case USB:
                mDevice = new UsbDeviceManager(context);
                break;
            case SERIAL:
                mDevice = new SerialDeviceManager(context);
                break;
            default:
                return null;
        }
        return mDevice;
    }

    /**
     * @brief 管理クラスを取得する
     * @return 管理クラス
     */
    public ControlDeviceManager getDevice() {
        return mDevice;
    }
}
