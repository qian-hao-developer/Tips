
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import android.content.Context;

import com.panasonic.avc.smartpayment.devctlservice.pos.device.data.request.RequestSendPos;

/**
 * Serialデバイス管理クラス
 */
public class SerialDeviceManager extends ControlDeviceManager {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = SerialDeviceManager.class.getSimpleName();

    /**
     * @brief コンストラクタ
     * @param context コンテキスト
     */
    public SerialDeviceManager(Context context) {
        mContext = context;
        mDeviceController = new SerialDeviceController(mContext);
    }

    /**
     * @see ControlDeviceManager#init(int)
     */
    @Override
    public boolean init(int vendorId, int[] productIds, boolean[] busPower) {
        return false;
    }

    /**
     * @see ControlDeviceManager#init(int, int)
     */
    @Override
    public boolean init(int baudrate, int parity) {
        return false;
    }

    /**
     * @brief 初期化
     * @param deviceInterface 通信インタフェース シリアル:0 USB:1
     * @param baudrate 通信速度
     * @param parity パリティ種別 パリティチェックなし:0 奇数パリティ:1 偶数パリティ:2
     * @see ControlDeviceManager#init(int, int, int)
     */
    @Override
    public boolean init(int deviceInterface, int baudrate, int parity) {
        if (mStatus != ManagerStatus.NONE) {
            return false;
        }

        ((SerialDeviceController) mDeviceController).setManager(this);
        ((SerialDeviceController) mDeviceController).setInterface(deviceInterface);
        ((SerialDeviceController) mDeviceController).setBaudrate(baudrate);
        ((SerialDeviceController) mDeviceController).setParity(parity);

        init();

        if (mDeviceController.isActive()) {
            mStatus = ManagerStatus.ACTIVE;
            return true;
        } else {
            mStatus = ManagerStatus.NONE;
            return false;
        }
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込するデータ
     * @return 書き込みに成功したかどうか
     */
    public synchronized boolean write(RequestSendPos request) {
        ((SerialDeviceController) mDeviceController).setBlockSize(request.getBlockSize());
        return super.write(request);
    }

}
