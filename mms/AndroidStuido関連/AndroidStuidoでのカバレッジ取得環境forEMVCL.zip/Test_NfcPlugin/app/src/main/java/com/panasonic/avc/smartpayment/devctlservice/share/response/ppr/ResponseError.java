
package com.panasonic.avc.smartpayment.devctlservice.share.response.ppr;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * PassportReaderエラーイベントデータクラス
 */
public class ResponseError implements Parcelable {

    /** @brief ecode tag */
    private static final String ECODE = "ecode";

    /** @brief vcode tag */
    private static final String VCODE = "vcode";

    /** @brief extcode tag */
    private static final String EXTCODE = "extcode";

    /** @brief extinfo tag */
    private static final String EXTINFO = "extinfo";

    /** @brief エラーの種類 */
    private int mEcode;

    /** @brief デバイスベンダ識別コード */
    private int mVcode;

    /** @brief 拡張コード */
    private int mExtcode;

    /** @brief 拡張情報 */
    private String mExtinfo;

    /**
     * コンストラクタ
     */
    public ResponseError() {
        setEcode(0);
        setVcode(0);
        setExtcode(0);
        setExtinfo(null);
    }

    /**
     * コンストラクタ
     * 
     * @param[in] ecode エラーの種類
     * @param[in] vcode デバイスベンダ識別コード
     * @param[in] extcode 拡張コード
     * @param[in] extinfo 拡張情報
     */
    public ResponseError(int ecode, int vcode, int extcode, String extinfo) {
        setEcode(ecode);
        setVcode(vcode);
        setExtcode(extcode);
        setExtinfo(extinfo);
    }

    /**
     * @brief コンストラクタ
     * @param[in] source Parcelデータ
     */
    public ResponseError(Parcel source) {
        readFromParcel(source);
    }

    /**
     * @brief エラーの種類を取得します
     * @return mEcode エラーの種類
     */
    public int getEcode() {
        return mEcode;
    }

    /**
     * @brief エラーの種類を設定します
     * @param[in] mEcode エラーの種類
     */
    public void setEcode(int mEcode) {
        this.mEcode = mEcode;
    }

    /**
     * デバイスベンダ識別コードを取得します
     * 
     * @return mVcode デバイスベンダ識別コード
     */
    public int getVcode() {
        return mVcode;
    }

    /**
     * @brief デバイスベンダ識別コードを設定します
     * @param[in] mVcode デバイスベンダ識別コード
     */
    public void setVcode(int mVcode) {
        this.mVcode = mVcode;
    }

    /**
     * @brief 拡張コードを取得します
     * @return mExtcode
     */
    public int getExtcode() {
        return mExtcode;
    }

    /**
     * @brief 拡張コードを設定します
     * @param[in] mExtcode 拡張コード
     */
    public void setExtcode(int mExtcode) {
        this.mExtcode = mExtcode;
    }

    /**
     * @brief 拡張情報を取得します
     * @return mExtinfo 拡張情報
     */
    public String getExtinfo() {
        return mExtinfo;
    }

    /**
     * @brief 拡張情報を設定します
     * @param[in] mExtinfo 拡張情報
     */
    public void setExtinfo(String mExtinfo) {
        this.mExtinfo = mExtinfo;
    }

    /**
     * @brief JSON形式で各フィールドの値を出力します
     * @return 各フィールドの値をJSON形式に整形した文字列（失敗時null）
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(ECODE, mEcode);
            json.put(VCODE, mVcode);
            if (getExtcode() == 0) {
                json.put(EXTCODE, JSONObject.NULL);
            } else {
                json.put(EXTCODE, getExtcode());
            }
            if (getExtinfo() == null || getExtinfo().length() == 0) {
                json.put(EXTINFO, JSONObject.NULL);
            } else {
                json.put(EXTINFO, getExtinfo());
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();

    }

    /**
     * @brief Parcelable
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief Parcelable
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mEcode);
        dest.writeInt(mVcode);
        dest.writeInt(mExtcode);
        dest.writeString(mExtinfo);

    }

    /**
     * @brief Parcelable
     * @param[in] in Parcelデータ
     */
    public void readFromParcel(Parcel in) {
        mEcode = in.readInt();
        mVcode = in.readInt();
        mExtcode = in.readInt();
        mExtinfo = in.readString();
    }

    /**
     * @brief 復元用
     */
    public static final Parcelable.Creator<ResponseError> CREATOR = new Parcelable.Creator<ResponseError>() {

        @Override
        public ResponseError createFromParcel(Parcel source) {
            return new ResponseError(source);
        }

        @Override
        public ResponseError[] newArray(int size) {
            return new ResponseError[size];
        }
    };
}
