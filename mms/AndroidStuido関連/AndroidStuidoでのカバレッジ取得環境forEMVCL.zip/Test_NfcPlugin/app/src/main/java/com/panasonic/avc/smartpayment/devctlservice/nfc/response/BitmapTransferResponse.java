package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.BITMAP_TRANSFER_RESPONSE;

/**
 * ビットマップ転送Responseクラス.
 * 
 */
public class BitmapTransferResponse extends BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = BitmapTransferResponse.class.getSimpleName();

    /** @brief MC */
    private byte MAINCOMMAND = (byte) 0x40;
    /** @brief SC */
    private byte SUBCOMMAND = (byte) 0x06;

    /** @brief レスポンスデータ拡張ありなし */
    private boolean mIsNeedExpand = false;

    /** @brief R/W状態フラグ . */
    private byte mStatusFlg;
    /** @brief R/W状態番号 . */
    private byte mStatusNo;

    /** @brief ブロック通番 . */
    private byte[] mBlock_num = null;
    private static final int mBlock_num_len = 2;
    /** @brief 処理実行結果 . */
    private byte[] mDispose_result = {(byte)0xE9, (byte)0x99};
    private static final int mDispose_result_len = 2;
    /** @brief 接続会社コード . */
    private byte[] mCompany_code = null;
    private static final int mCompany_code_len = 11;
    /** @brief 接続会社名 . */
    private byte[] mCompany_name = null;
    private static final int mCompany_name_len = 10;
    /** @brief 会員番号 . */
    private byte[] mMember_num = null;
    private static final int mMember_num_len = 19;
    /** @brief 有効期限 . */
    private byte[] mExpiration_date = null;
    private static final int mExpiration_date_len = 4;
    /** @brief 使用KID . */
    private byte[] mUse_kid = null;
    private static final int mUse_kid_len = 3;
    /** @brief ブランド識別子 . */
    private byte mBrand_identifier;
    private static final int mBrand_identifier_len = 1;
    /** @brief Cardholder Name（カナ氏名） . */
    private byte[] mCardholder_name = null;
    private static final int mCardholder_name_len = 26;
    /** @brief Application PAN Sequence Number . */
    private byte mApp_pan_num;
    private static final int mApp_pan_num_len = 1;
    /** @brief 取引結果ビット . */
    private byte[] mTran_result_bit = null;
    private static final int mTran_result_bit_len = 5;
    /** @brief 詳細エラーコード . */
    private byte[] mDetailed_err_code = {(byte)0x33, (byte)0x12};
    private static final int mDetailed_err_code_len = 2;
    /** @brief OUTCOMELen情報 . */
    private byte[] mOutcomelen = null;
    private static final int mOutcomelen_len = 2;
    /** @brief OUTCOME情報 . */
    private byte[] mOutcome = null;
    private static final int mOutcome_len = 64;
    /** @brief TLVデータ . */
    private byte[] mTlv = null;
    private static final int mTlv_len = 515;
    /** @brief TLV拡張データ . */
    private byte[] mTlvExpand = null;
    private static final int mTlvExpand_len = 2600;
    /** @brief TLV拡張データ２ . */
    private byte[] mTlvExpand2 = null;
    private static final int mTlvExpand2_len = 3076;

    /** Constructor */
    public BitmapTransferResponse() {
    }

    /** Constructor */
    public BitmapTransferResponse(byte sc) {
        SUBCOMMAND = sc;
    }


    public void isNeedExpand(boolean tf) {
        mIsNeedExpand = tf;
    }
    /**
     * R/W状態フラグを返却する.
     * 
     * @return R/W状態フラグ
     */
    public byte getStatusFlg() {
        return mStatusFlg;
    }

    /**
     * R/W状態番号を返却する.
     * 
     * @return R/W状態番号
     */
    public byte getStatusNo() {
        return mStatusNo;
    }

    /**
     * ブロック通番を返却する.
     * 
     * @return ブロック通番
     */
    public byte[] getBlock_num() {
        return mBlock_num;
    }

    /**
     * 処理実行結果を返却する.
     * 
     * @return 処理実行結果
     */
    public byte[] getDispose_result() {
        return mDispose_result;
    }

    /**
     * 接続会社コードを返却する.
     * 
     * @return 接続会社コード
     */
    public byte[] getCompany_code() {
        return mCompany_code;
    }

    /**
     * 接続会社名を返却する.
     * 
     * @return 接続会社名
     */
    public byte[] getCompany_name() {
        return mCompany_name;
    }

    /**
     * 会員番号を返却する.
     * 
     * @return 会員番号
     */
    public byte[] getMember_num() {
        return mMember_num;
    }

    /**
     * 有効期限を返却する.
     * 
     * @return 有効期限
     */
    public byte[] getExpiration_date() {
        return mExpiration_date;
    }

    /**
     * 使用KIDを返却する.
     * 
     * @return 使用KID
     */
    public byte[] getUse_kid() {
        return mUse_kid;
    }

    /**
     * ブランド識別子を返却する.
     * 
     * @return ブランド識別子
     */
    public byte getBrand_identifier() {
        return mBrand_identifier;
    }

    /**
     * Cardholder Name（カナ氏名）返却する.
     * 
     * @return Cardholder Name（カナ氏名）
     */
    public byte[] getCardholder_name() {
        return mCardholder_name;
    }

    /**
     * Application PAN Sequence Numberを返却する.
     * 
     * @return Application PAN Sequence Number
     */
    public byte getApp_pan_num() {
        return mApp_pan_num;
    }

    /**
     * 取引結果ビットを返却する.
     * 
     * @return 取引結果ビット
     */
    public byte[] getTran_result_bit() {
        return mTran_result_bit;
    }

    /**
     * 詳細エラーコードを返却する.
     * 
     * @return 詳細エラーコード
     */
    public byte[] getDetailed_err_code() {
        return mDetailed_err_code;
    }

    /**
     * OUTCOME情報を返却する.
     * 
     * @return OUTCOME情報
     */
    public byte[] getOutcome() {
        return mOutcome;
    }

    /**
     * TLVデータを返却する.
     * 
     * @return TLVデータ
     */
    public byte[] getTlv() {
        return mTlv;
    }

    /**
     * TLV拡張データを返却する.
     * 
     * @return TLV拡張データ
     */
    public byte[] getTlvExpand() {
        return mTlvExpand;
    }

    /**
     * TLV拡張データ２を返却する.
     *
     * @return TLV拡張データ２
     */
    public byte[] getTlvExpand2() {
        return mTlvExpand2;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {  //PT_IMPOSSIBLE_BRANCH
            return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return (cutDeviceResult(bytes) != null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MAINCOMMAND) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND mismatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND) {
            Logger.e(TAG, "checkResponseData SUBCOMMAND mismatch = "
                    + bytes[SUBCOMMAND_INDEX]);
            return false;
        }

        // データ長は可変の為指定長チェックは行わない（実データ長との比較は親クラスで実施済み）
        // R/W状態フラグ、R/W状態番号、ビットマップデータは格納前チェックは不要

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ格納を行う
        BITMAP_TRANSFER_RESPONSE[] dataConstArray = BITMAP_TRANSFER_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (BITMAP_TRANSFER_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* R/W状態フラグ */
            case STATUSFLG:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mStatusFlg = checkByteArray[0];
                break;
            /* R/W状態番号 */
            case STATUSNO:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mStatusNo = checkByteArray[0];
                break;
            /* ビットマップデータ */
            case BITMAPDATA:
                int bitmapDataLength = getDataLength()
                        - BITMAP_TRANSFER_RESPONSE.STATUSFLG.getDataLength()
                        - BITMAP_TRANSFER_RESPONSE.STATUSNO.getDataLength();
                if (bitmapDataLength > 0) {
                    checkByteArray = new byte[bitmapDataLength];
                    System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                            checkByteArray.length);
                    try {
                        perseBitmap(checkByteArray);
                    } catch (ArrayIndexOutOfBoundsException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                break;
            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return bytes;
    }

    private void perseBitmap(byte[] bitmapByteArray) {
        // index 6から8byteずつint化
        // 対応するbitが立っているかを算出
        // 該当箇所に保存
        byte[] fieldBite = new byte[32];
        int index = 6;
        System.arraycopy(bitmapByteArray, index, fieldBite, 0,
                            fieldBite.length);
        index += fieldBite.length;

        if ((fieldBite[8] & 0x20) != 0) {
            mBlock_num = new byte[mBlock_num_len];
            System.arraycopy(bitmapByteArray, index, mBlock_num, 0, mBlock_num_len);
            index += mBlock_num_len;
        }
        if ((fieldBite[24] & 0x10) != 0) {
            mDispose_result = new byte[mDispose_result_len];
            System.arraycopy(bitmapByteArray, index, mDispose_result, 0, mDispose_result_len);
            index += mDispose_result_len;
        }
        if ((fieldBite[29] & 0x40) != 0) {
            mCompany_code = new byte[mCompany_code_len];
            System.arraycopy(bitmapByteArray, index, mCompany_code, 0, mCompany_code_len);
            index += mCompany_code_len;
        }
        if ((fieldBite[29] & 0x20) != 0) {
            mCompany_name = new byte[mCompany_name_len];
            System.arraycopy(bitmapByteArray, index, mCompany_name, 0, mCompany_name_len);
            index += mCompany_name_len;
        }
        if ((fieldBite[30] & 0x80) != 0) {
            mMember_num = new byte[mMember_num_len];
            System.arraycopy(bitmapByteArray, index, mMember_num, 0, mMember_num_len);
            index += mMember_num_len;
        }
        if ((fieldBite[30] & 0x40) != 0) {
            mExpiration_date = new byte[mExpiration_date_len];
            System.arraycopy(bitmapByteArray, index, mExpiration_date, 0, mExpiration_date_len);
            index += mExpiration_date_len;
        }
        if ((fieldBite[30] & 0x20) != 0) {
            mUse_kid = new byte[mUse_kid_len];
            System.arraycopy(bitmapByteArray, index, mUse_kid, 0, mUse_kid_len);
            index += mUse_kid_len;
        }
        if ((fieldBite[30] & 0x10) != 0) {
            mBrand_identifier = bitmapByteArray[index];
            index += mBrand_identifier_len;
        }
        if ((fieldBite[30] & 0x08) != 0) {
            mCardholder_name = new byte[mCardholder_name_len];
            System.arraycopy(bitmapByteArray, index, mCardholder_name, 0, mCardholder_name_len);
            index += mCardholder_name_len;
        }
        if ((fieldBite[30] & 0x04) != 0) {
            mApp_pan_num = bitmapByteArray[index];
            index += mApp_pan_num_len;
        }
        if ((fieldBite[30] & 0x02) != 0) {
            mTran_result_bit = new byte[mTran_result_bit_len];
            System.arraycopy(bitmapByteArray, index, mTran_result_bit, 0, mTran_result_bit_len);
            index += mTran_result_bit_len;
        }
        if ((fieldBite[30] & 0x01) != 0) {
            mDetailed_err_code = new byte[mDetailed_err_code_len];
            System.arraycopy(bitmapByteArray, index, mDetailed_err_code, 0, mDetailed_err_code_len);
            index += mDetailed_err_code_len;
        }
        if ((fieldBite[31] & 0x80) != 0) {
            mOutcomelen = new byte[mOutcomelen_len];
            System.arraycopy(bitmapByteArray, index, mOutcomelen, 0, mOutcomelen_len);
            index += mOutcomelen_len;
            mOutcome = new byte[mOutcome_len];
            System.arraycopy(bitmapByteArray, index, mOutcome, 0, mOutcome_len);
            index += mOutcome_len;
        }
        if ((fieldBite[31] & 0x40) != 0) {
            mTlv = new byte[mTlv_len];
            System.arraycopy(bitmapByteArray, index, mTlv, 0, mTlv_len);
            index += mTlv_len;
        }
        if (mIsNeedExpand) {
            mTlvExpand = new byte[mTlvExpand_len];
            System.arraycopy(bitmapByteArray, index, mTlvExpand, 0, mTlvExpand_len);
            index += mTlvExpand_len;

            mTlvExpand2 = new byte[mTlvExpand2_len];
            System.arraycopy(bitmapByteArray, index, mTlvExpand2, 0, mTlvExpand2_len);
            index += mTlvExpand2_len;
        }
    }
}
