
package com.panasonic.avc.smartpayment.devctlservice.share.result.cfg;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultSetBrightness処理結果データ
 */
public class ResultSetBrightness extends ResultData {

    /** @brief LCDタグ */
    private static final String LCD = "lcd";

    /** @brief 輝度設定タグ */
    private static final String BRIGHTNESS = "brightness";

    private int mBrightness;

    /**
     * @brief コンストラクタ
     */
    public ResultSetBrightness(Parcel in) {
        super(in);
        mBrightness = in.readInt();
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetBrightness() {

    }

    public int getBrightness() {
        return mBrightness;
    }

    public void setBrightness(int brightness) {
        mBrightness = brightness;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetBrightness> CREATOR = new Parcelable.Creator<ResultSetBrightness>() {
        public ResultSetBrightness createFromParcel(Parcel in) {
            return new ResultSetBrightness(in);
        }

        public ResultSetBrightness[] newArray(int size) {
            return new ResultSetBrightness[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mBrightness);
    }

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonLcd = new JSONObject();
        try {
            json.put(DEVICE, getDevice());

            if (getBrightness() == 0) {
                jsonLcd.put(BRIGHTNESS, JSONObject.NULL);
            } else {
                jsonLcd.put(BRIGHTNESS, getBrightness());
            }

            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(LCD, JSONObject.NULL);
            } else {
                json.put(LCD, jsonLcd);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
