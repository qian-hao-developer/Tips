package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

import android.os.AsyncTask;

/**
 * 非同期処理用AbstractThreadクラス.<br>
 */
public abstract class AsyncTransaction<Params, Progress, Result>{

    /**
     * 非同期処理実装用メソッド（SubThread）
     *
     * @param params mainThreadから引き渡されたデータ配列
     * @return 処理結果
     */
    protected abstract Result doInBackground(Params... params);

    /**
     * 非同期処理実行後処理（MainThread）
     *
     * @param result 非同期処理実施結果
     */
    protected abstract void onPostExecute(Result result);

    /**
     * 非同期処理を実行する.<br>
     *
     * @param params 非同期処理に引き渡すデータ
     * @return 処理結果
     */
    @SafeVarargs
    public final Integer execute(Params... params) {
        (new InnerAsyncTask()).execute(params);
        return 0;
    }

    private class InnerAsyncTask extends AsyncTask<Params, Progress, Result> {

        @Override
        @SafeVarargs
        protected final Result doInBackground(Params... params) {
            return AsyncTransaction.this.doInBackground(params);
        }

        @Override
        protected void onPostExecute(Result result) {
            super.onPostExecute(result);
            AsyncTransaction.this.onPostExecute(result);
        }
    }
}
