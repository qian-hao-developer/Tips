package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DOWNLOAD_DATA_REQUEST.SENDRECORDNO;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_SIZE_WITHOUT_PARAMETER;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.ID_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * ダウンロードデータBaseRequestクラス.
 * 
 */
abstract public class BaseDownloadDataRequest {

    /** @brief ログ用タグ */
    private static final String TAG = BaseDownloadDataRequest.class
            .getSimpleName();

    /** ID */
    protected byte mId = (byte) 0x02;
    /** @brief MC */
    protected byte mMainCommand = (byte) 0x01;
    /** @brief SC */
    protected byte mSubCommand = (byte) 0x81;
    /** @brief データ部Length */
    private int mDataLength;

    /** @brief 送信レコード番号 . */
    private byte[] mSendRecordNo;
    /** @brief レコードデータ . */
    private byte[] mRecordData;

    /**
     * set McSc
     * @param mc MC
     * @param sc SC
     */
    protected void setMCSC(byte mc, byte sc) {
        mMainCommand = mc;
        mSubCommand = sc;
    }

    /**
     * 送信レコード番号を設定する.
     * 
     * @param sendRecordNo 送信レコード番号
     */
    public void setSendRecordNo(byte[] sendRecordNo) {
        mSendRecordNo = sendRecordNo;
    }

    /**
     * レコードデータを設定する.
     * 
     * @param recordData レコードデータ
     */
    public void setRecordData(byte[] recordData) {
        mRecordData = recordData;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isValidValue() {
        // 送信レコード番号:必須チェック
        if (mSendRecordNo == null) {
            Logger.e(TAG, "isValidValue mSendRecordNo is null ");
            return false;
        }

        // サイズチェック
        if (mSendRecordNo.length != SENDRECORDNO.getDataLength()) {
            Logger.e(TAG, "isValidValue mSendRecordNo length mismatch = "
                    + mSendRecordNo.length);
            return false;
        }

        // レコードデータ:必須チェック
        if (mRecordData == null) {
            Logger.e(TAG, "isValidValue mRecordData is null ");
            return false;
        }

        // サイズチェック（可変サイズで1～8190）
        if (mRecordData.length < 1 || mRecordData.length > 8190) {
            Logger.e(TAG, "isValidValue mRecordData length mismatch = "
                    + mRecordData.length);
            return false;
        }

        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        return toCommand(ByteUtil.mergeByteArray(mSendRecordNo,
                mRecordData));
    }

    protected byte[] toCommand(byte[] parameter) {
        // コマンドの全体長取得
        int len = 0;
        if (parameter != null) {
            len = parameter.length;
        }
        mDataLength = len;

        // 配列を確保
        byte[] data = new byte[DATA_SIZE_WITHOUT_PARAMETER + mDataLength];
        // 値を入力
        data[ID_INDEX] = mId;
        data[MAINCOMMAND_INDEX] = mMainCommand;
        data[SUBCOMMAND_INDEX] = mSubCommand;
        data[DATALENGTHHIGH_INDEX] = (byte) (mDataLength & 0x00ff);
        data[DATALENGTHLOW_INDEX] = (byte) ((mDataLength >> 8) & 0x00ff);
        if (mDataLength != 0) {
            System.arraycopy(parameter, 0, data, 5, parameter.length);
        }
        return data;
    }
}
