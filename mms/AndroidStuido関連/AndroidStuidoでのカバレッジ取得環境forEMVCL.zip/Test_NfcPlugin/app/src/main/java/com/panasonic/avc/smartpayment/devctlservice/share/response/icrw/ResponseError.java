
package com.panasonic.avc.smartpayment.devctlservice.share.response.icrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * ErrorEventデータ
 */
public class ResponseError implements Parcelable {

    /** @brief エラーの種類 */
    private int mEcode;

    /** @brief エラーの種類タグ */
    private static final String ECODE = "ecode";

    /** @brief デバイスベンダ識別コード */
    private int mVcode;

    /** @brief デバイスベンダ識別コードタグ */
    private static final String VCODE = "vcode";

    /** @brief 拡張コード */
    private int mExtcode;

    /** @brief 拡張コードタグ */
    private static final String EXTCODE = "extcode";

    /** @brief 拡張情報 */
    private String mExtinfo;

    /** @brief 拡張情報タグ */
    private static final String EXTINFO = "extinfo";

    /**
     * @brief コンストラクタ
     */
    public ResponseError(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    public ResponseError(int ecode, int vcode, int extcode, String extinfo) {
        mEcode = ecode;
        mVcode = vcode;
        mExtcode = extcode;
        mExtinfo = extinfo;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseError() {

    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponseError> CREATOR = new Parcelable.Creator<ResponseError>() {

        /**
         * @see Parcelable.Creator#createFromParcel(Parcel)
         */
        public ResponseError createFromParcel(Parcel in) {
            return new ResponseError(in);
        }

        /**
         * @see Parcelable.Creator#newArray(int)
         */
        public ResponseError[] newArray(int size) {
            return new ResponseError[size];
        }
    };

    /**
     * @see Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mEcode);
        dest.writeInt(mVcode);
        dest.writeInt(mExtcode);
        dest.writeString(mExtinfo);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mEcode = in.readInt();
        mVcode = in.readInt();
        mExtcode = in.readInt();
        mExtinfo = in.readString();
    }

    /**
     * @brief
     * @return エラーの種類
     */
    public int getEcode() {
        return mEcode;
    }

    /**
     * @brief エラーの種類を設定する
     * @param エラーの種類
     */
    public void setEcode(int ecode) {
        mEcode = ecode;
    }

    /**
     * @brief デバイスベンダ識別コードを取得する
     * @return デバイスベンダ識別コード
     */
    public int getVcode() {
        return mVcode;
    }

    /**
     * @brief デバイスベンダ識別コードを設定する
     * @param デバイスベンダ識別コード
     */
    public void setVcode(int vcode) {
        mVcode = vcode;
    }

    /**
     * @brief 拡張コードを取得する
     * @return 拡張コード
     */
    public int getExtcode() {
        return mExtcode;
    }

    /**
     * @brief 拡張コードを設定する
     * @param 拡張コード
     */
    public void setExtcode(int extcode) {
        mExtcode = extcode;
    }

    /**
     * @brief 拡張情報を取得する
     * @return 拡張情報
     */
    public String getExtinfo() {
        return mExtinfo;
    }

    /**
     * @brief 拡張情報を設定する
     * @param 拡張情報
     */
    public void setExtinfo(String extinfo) {
        mExtinfo = extinfo;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(ECODE, getEcode());
            json.put(VCODE, getVcode());
            if (getExtcode() == 0) {
                json.put(EXTCODE, JSONObject.NULL);
            } else {
                json.put(EXTCODE, getExtcode());
            }
            if (getExtinfo() == null || getExtinfo().length() == 0) {
                json.put(EXTINFO, JSONObject.NULL);
            } else {
                json.put(EXTINFO, getExtinfo());
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
