
package com.panasonic.avc.smartpayment.devctlservice.system.util;

import java.io.File;

import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;

public class Util {

    /**
     * ローカルファームバージョン取得
     * 
     * @param key 種類
     * @return バージョン
     */
    public static String getFirmVersion(int key) {
        String path = "";
        String header = "";

        switch (key) {
            case PdsClientManager.KEY_FMV_PAYMENT1:
                path = "/firmware2/printer";
                header = "PRN_FW_";
                break;
            case PdsClientManager.KEY_FMV_PAYMENT2:
                path = "/firmware2/msr";
                header = "MSR_FW_";
                break;
            case PdsClientManager.KEY_FMV_PINPAD:
                path = "/firmware2/pinpad";
                header = "PINPAD_FW_";
                break;
            case PdsClientManager.KEY_FMV_RW:
                path = "/firmware2/rw/firmware";
                // rwはrw/firmwareのファイルの中を参照するため、このメソッドは使わない
                break;
            default:
                return "";
        }

        File dir = new File(path);
        File[] files = dir.listFiles();
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            if (file.getName().startsWith(header)) {
                return file.getName().substring(0, file.getName().length() - 4);
            }
        }

        return "";
    }
}
