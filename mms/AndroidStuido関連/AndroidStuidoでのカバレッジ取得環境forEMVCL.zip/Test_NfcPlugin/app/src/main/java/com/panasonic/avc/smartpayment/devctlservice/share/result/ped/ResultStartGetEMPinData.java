
package com.panasonic.avc.smartpayment.devctlservice.share.result.ped;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * StartGetEMPINDataの実行結果データクラス
 */
public class ResultStartGetEMPinData extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultStartGetEMPinData(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultStartGetEMPinData() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultStartGetEMPinData> CREATOR = new Parcelable.Creator<ResultStartGetEMPinData>() {
        public ResultStartGetEMPinData createFromParcel(Parcel in) {
            return new ResultStartGetEMPinData(in);
        }

        public ResultStartGetEMPinData[] newArray(int size) {
            return new ResultStartGetEMPinData[size];
        }
    };
}
