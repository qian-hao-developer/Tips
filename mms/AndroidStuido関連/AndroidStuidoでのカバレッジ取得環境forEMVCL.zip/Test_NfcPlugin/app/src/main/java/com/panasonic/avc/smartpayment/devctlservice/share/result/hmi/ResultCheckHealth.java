
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * CheckHealth処理結果データ
 */
public class ResultCheckHealth extends ResultData {

    /** @brief HMI状態タグ */
    private static final String CONDITION = "condition";

    /** @brief 電池電圧情報 */
    private int mBattery;

    /** @brief 電池電圧情報タグ */
    private static final String BATTERY = "battery";

    /** @brief 給電状態情報 */
    private boolean mPower;

    /** @brief 給電状態情報タグ */
    private static final String POWER = "power";

    public static final int BATTERY_NORMAL = 1;

    public static final int BATTERY_HIGH = 2;

    public static final int BATTERY_LOW = 3;

    public static final int BATTERY_EMPTY = 4;

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth(Parcel in) {
        super(in);
    }

    /**
     * コンストラクタ
     */
    public ResultCheckHealth() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCheckHealth> CREATOR = new Parcelable.Creator<ResultCheckHealth>() {
        public ResultCheckHealth createFromParcel(Parcel in) {
            return new ResultCheckHealth(in);
        }

        public ResultCheckHealth[] newArray(int size) {
            return new ResultCheckHealth[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mBattery);
        dest.writeInt(mPower ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mBattery = in.readInt();
        mPower = in.readInt() == 1 ? true : false;
    }

    public int getBattery() {
        return mBattery;
    }

    public void setBattery(int battery) {
        mBattery = battery;
    }

    public boolean isPower() {
        return mPower;
    }

    public void setPower(boolean power) {
        mPower = power;
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonCondition = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonCondition.put(BATTERY, getBattery());
            jsonCondition.put(POWER, isPower());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(CONDITION, JSONObject.NULL);
            } else {
                json.put(CONDITION, jsonCondition);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
