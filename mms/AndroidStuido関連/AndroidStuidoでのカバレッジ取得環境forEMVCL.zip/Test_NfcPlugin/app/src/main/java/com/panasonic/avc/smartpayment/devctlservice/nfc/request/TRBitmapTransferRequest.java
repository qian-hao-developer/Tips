package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * トレーニング用ビットマップ転送Requestクラス.
 * 
 */
public class TRBitmapTransferRequest extends BitmapTransferRequest {

    /** @brief ログ用タグ */
    private static final String TAG = TRBitmapTransferRequest.class
            .getSimpleName();

    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x07;

    /** Constructor */
    public TRBitmapTransferRequest() {
        super(SUBCOMMAND);
    }
}
