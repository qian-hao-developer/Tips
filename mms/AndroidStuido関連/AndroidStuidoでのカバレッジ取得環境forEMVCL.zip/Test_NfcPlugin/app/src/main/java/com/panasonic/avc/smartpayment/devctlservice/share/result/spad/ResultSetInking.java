
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetInking extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetInking(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetInking() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetInking> CREATOR = new Parcelable.Creator<ResultSetInking>() {

        @Override
        public ResultSetInking createFromParcel(Parcel in) {
            return new ResultSetInking(in);
        }

        @Override
        public ResultSetInking[] newArray(int size) {
            return new ResultSetInking[size];
        }
    };
}
