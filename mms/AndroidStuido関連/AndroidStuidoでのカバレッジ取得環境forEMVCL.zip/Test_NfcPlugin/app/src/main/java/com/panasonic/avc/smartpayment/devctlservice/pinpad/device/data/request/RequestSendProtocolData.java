
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 拡張T=0/1プロトコルデータ送受信要求クラス
 */
public class RequestSendProtocolData extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x07;

    /** @brief APDUデータの暗号化状態を指定 */
    private boolean mEncrypt;

    /** @brief apduのデータ数(1以上32以下) */
    private int mNum;

    /** @brief 暗号化した結果 */
    private String mApdu;

    /** @brief データを識別するための番号 */
    private int mSendAPDUId;

    /**
     * @briefコンストラクタ
     * @param[in] encrypt APDUデータの暗号化状態を指定
     * @param[in] num apduのデータ数
     * @param[in] apdu 暗号化した結果
     * @param[in] id データを識別するための番号
     */
    public RequestSendProtocolData(boolean encrypt, int num, String apdu, int id) {
        mEncrypt = encrypt;
        mNum = num;
        mApdu = apdu;
        mSendAPDUId = id;

        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @brief APDUデータの暗号化状態を指定を取得します
     * @retun APDUデータの暗号化状態を指定
     */
    public boolean isEncrypt() {
        return mEncrypt;
    }

    /**
     * @brief APDUデータの暗号化状態を指定を設定します
     * @param[in] APDUデータの暗号化状態を指定
     */
    public void setEncrypt(boolean encrypt) {
        mEncrypt = encrypt;
    }

    /**
     * @brief apduのデータ数を取得します
     * @retun apduのデータ数
     */
    public int getNum() {
        return mNum;
    }

    /**
     * @brief apduのデータ数を設定します
     * @param[in] apduのデータ数
     */
    public void setNum(int num) {
        mNum = num;
    }

    /**
     * @brief 暗号化した結果を取得します
     * @retun 暗号化した結果
     */
    public String getApdu() {
        return mApdu;
    }

    /**
     * @brief 暗号化した結果を設定します
     * @param[in] 暗号化した結果
     */
    public void setApdu(String apdu) {
        mApdu = apdu;
    }

    /**
     * @brief データを識別するための番号を取得します
     * @retun データを識別するための番号
     */
    public int getSendAPDUId() {
        return mSendAPDUId;
    }

    /**
     * @brief データを識別するための番号を設定します
     * @param[in] データを識別するための番号
     */
    public void setSendAPDUId(int id) {
        mSendAPDUId = id;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] apdu = CalcUtil.toByte(mApdu);
        if (apdu == null) {
            return null;
        }

        byte[] paramater = new byte[apdu.length + 7];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);
        paramater[2] = (byte) 0x00;
        paramater[3] = mEncrypt ? (byte) 0x01 : (byte) 0x00;
        paramater[4] = mEncrypt ? (byte) 0x01 : (byte) 0x00;
        paramater[5] = (byte) (mSendAPDUId & 0xff);
        paramater[6] = (byte) (mNum & 0xff);
        System.arraycopy(apdu, 0, paramater, 7, apdu.length);

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mApdu == null || mApdu.equals("")) {
            return false;
        }

        if (!(1 <= mSendAPDUId && mSendAPDUId <= 255)) {
            return false;
        }

        if (!(1 <= mNum && mNum <= 32)) {
            return false;
        }
        return true;
    }
}
