package com.panasonic.avc.smartpayment.devctlservice.nfc.data;

/**
 * 決済デバイスの設定情報格納クラス<br>
 */
public class SETTINGINFO {
    /** 決済デバイスの状態. */
    public byte StatusFlag;
    /** 設定決済デバイス音量. */
    public byte VolumeOfSound;
    /** タイマ１設定値 */
    public byte[] Timer1;
    /** タイマ２設定値 */
    public byte[] Timer2;
    /** タイマ３設定値 */
    public byte[] Timer3;
    /** タイマ４設定値 */
    public byte[] Timer4;
    /** タイマ５設定値 */
    public byte[] Timer5;
    /** LCD表示データ */
    public byte LCDSettings;
    /** 表示言語 */
    public byte Language;
    /** 製品番号 */
    public byte[] Model;
    /** シリアル番号 */
    public byte[] SNo;
    /** ハード構成情報 */
    public byte[] HWInfo;
    /** アプリケーションバージョン */
    public byte[] AplVer;
    /** アプリケーションID */
    public byte[] AplId;
    /** RW状態番号 */
    public byte StatusNumber;
}
