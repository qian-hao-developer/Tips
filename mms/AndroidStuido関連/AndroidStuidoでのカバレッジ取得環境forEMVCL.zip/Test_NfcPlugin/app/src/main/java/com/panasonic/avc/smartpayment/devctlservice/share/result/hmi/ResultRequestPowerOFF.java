
package com.panasonic.avc.smartpayment.devctlservice.share.result.hmi;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * RequestPowerOFFの実行結果データ
 */
public class ResultRequestPowerOFF extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultRequestPowerOFF(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultRequestPowerOFF() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultRequestPowerOFF> CREATOR = new Parcelable.Creator<ResultRequestPowerOFF>() {
        public ResultRequestPowerOFF createFromParcel(Parcel in) {
            return new ResultRequestPowerOFF(in);
        }

        public ResultRequestPowerOFF[] newArray(int size) {
            return new ResultRequestPowerOFF[size];
        }
    };
}
