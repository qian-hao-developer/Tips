package com.panasonic.avc.smartpayment.devctlservice.nfc.data;

/**
 * 取引に必要なデータ格納クラス<br>
 */
public class TRANSACTIONDATA {
    /** TransactionType. */
    public byte TransactionType;
    /** 動作モード. */
    public int FunctionMode;
    /** TransactionDateとTransactionTime. */
    public byte[] CommunicationTime;
    /** ブロック通番. */
    public int BlockNumber;
    /** 取引金額. */
    public byte[] AmountAuthorised;
    /** その他金額. */
    public byte[] AmountOther;
    /** 業務指定ビット. */
    public byte MerchantSpecificData;
    /** TLVデータ. */
    public byte[] TLVData;
}
