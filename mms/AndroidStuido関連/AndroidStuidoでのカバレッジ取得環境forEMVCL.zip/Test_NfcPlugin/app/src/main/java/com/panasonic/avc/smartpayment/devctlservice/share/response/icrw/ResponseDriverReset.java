
package com.panasonic.avc.smartpayment.devctlservice.share.response.icrw;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * DriverReset処理結果データ
 */
public class ResponseDriverReset extends ResponseData {

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x0002;

    /** @brief リセット結果 **/
    private int mRes = -1;

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            return false;
        }

        setRes(buffer[PinpadDefine.INDEX_PARAMETER]);

        return true;
    }

    public int getRes() {
        return mRes;
    }

    public void setRes(int mRes) {
        this.mRes = mRes;
    }

}
