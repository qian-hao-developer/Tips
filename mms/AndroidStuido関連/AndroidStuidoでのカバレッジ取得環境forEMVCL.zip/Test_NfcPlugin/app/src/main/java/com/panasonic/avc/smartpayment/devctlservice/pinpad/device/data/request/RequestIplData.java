
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * IPLデータコマンド
 */
public class RequestIplData extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x03;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x01;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 7;

    private int mNumber;

    private byte[] mData;

    /**
     * @brief コンストラクタ
     */
    public RequestIplData(int num, byte[] data) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mNumber = num;
        mData = data;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH + mData.length - 1];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = (byte) (mNumber & 0xff);
        parameter[3] = (byte) ((mNumber >> 8) & 0xff);
        parameter[4] = (byte) (mData.length & 0xff);
        parameter[5] = (byte) ((mData.length >> 8) & 0xff);

        System.arraycopy(mData, 0, parameter, 6, mData.length);

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mNumber < 0) {
            return false;
        }

        if (mData == null || mData.length <= 0) {
            return false;
        }

        return true;
    }
}
