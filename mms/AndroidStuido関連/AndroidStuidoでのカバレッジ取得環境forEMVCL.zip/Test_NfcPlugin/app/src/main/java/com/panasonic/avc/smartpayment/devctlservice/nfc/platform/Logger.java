package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

import android.os.SystemProperties;
import android.util.Log;

/**
 * @brief Log for depend on Android platform 
 */
public class Logger {
    /** @brief ログレベル */
    private static final int NONE = 0;
    private static final int ERROR = 1;
    private static final int DEBUG = 2;

    /**
     * @see Log#d(String, String)
     */
    public static void d(String tag, String text) {
        switch (getLogLevel()) {
            case DEBUG:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @see Log#e(String, String)
     */
    public static void e(String tag, String text) {
        switch (getLogLevel()) {
            case DEBUG:
                Log.e(tag, text);
                break;
            case ERROR:
                Log.e(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @brief ログレベルを取得する
     * @return int ログレベル
     */
    private static int getLogLevel() {
        return SystemProperties.getInt("persist.sys.emv.loglevel", DEBUG);
    }
}

