
package com.panasonic.avc.smartpayment.devctlservice.pinpad.duk;

import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceApduCodeDukptKeyUpdate;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAdvanceDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.share.IDukServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultInitDuk;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultMakeTransactionKey;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * DUKPT処理部
 */
public class DeriveUniqueKeyPerTransaction {

    /** @brief ログ出力用タグ */
    private static final String TAG = DeriveUniqueKeyPerTransaction.class.getSimpleName();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IDukServiceListener> mIDukServiceListenerList = new ConcurrentHashMap<String, IDukServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 5000;

    /** @brief シングルトンインスタンス */
    private static DeriveUniqueKeyPerTransaction sInstance = new DeriveUniqueKeyPerTransaction();

    /** @brief コンテキスト */
    private Context mContext;

    /**
     * @brief コンストラクタ
     */
    private DeriveUniqueKeyPerTransaction() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static DeriveUniqueKeyPerTransaction getInstance() {
        return sInstance;
    }

    /**
     * @brief DUKPTを初期化します
     * @return JSON形式[device,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval upos UPOS処理結果[整数型]
     */
    public ResultInitDuk initDuk() {
        ResultInitDuk result = new ResultInitDuk();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief トランザクションキーの生成要求します
     * @param[in] req 更新するトランザクションキーの指定
     * @return JSON形式[device,ksn,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval ksn 生成したトランザクションキー情報[文字列型]
     * @retval upos UPOS処理結果[整数型]
     */
    public ResultMakeTransactionKey makeTransactionKey(int req) {
        final RequestAdvanceApduCodeDukptKeyUpdate request = new RequestAdvanceApduCodeDukptKeyUpdate();
        ResultMakeTransactionKey result = new ResultMakeTransactionKey();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowMakeTransactionKeyError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, DeriveUniqueKeyPerTransaction.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief DUKPT利用可否情報を取得します
     * @return JSON形式[device,devsts,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval devstsデバイスの利用可否情報[論理型]
     * @retval upos UPOS処理結果[整数型]
     */
    public ResultCheckHealth checkHealth() {
        final RequestDeviceInformation request = new RequestDeviceInformation();
        ResultCheckHealth result = new ResultCheckHealth();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            // PINPAD が接続されていない場合は
            // MSR の MakeTransactionKey が使用できるので
            // 常に「利用可能(devsts=true)」を返却する
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            result.setDevSts(true);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief DUKPTの製品品番、シリアル番号、ハード構成情報、APL Version、PF Versionを取得します
     * @return JSON形式[device,verinfo,upos]
     * @retval device 周辺装置処理結果[整数型]
     * @retval verinfo デバイス情報[model,sno,hdinfo,aplver,pfver]
     * @retval model DUKPT デバイスの製品品番[文字列型]
     * @retval sno DUKPT デバイスのシリアル番号[文字列型]
     * @retval hdinfo DUKPT デバイスのハード光星情報[文字列型]
     * @retval aplver DUKPT デバイスのアプリケーションVersion[文字列型]
     * @retval pfver DUKPT デバイスのプラットフォーム[文字列型]
     * @retval upos UPOS処理結果[整数型]
     */
    public ResultGetVersionInfo getVersionInfo() {
        // 機器情報要求
        RequestDeviceInformation requestDeviceInfo = new RequestDeviceInformation();
        ResponseDeviceInformation responseDeviceInfo = new ResponseDeviceInformation();

        // 拡張製品情報取得
        RequestAdvanceDeviceInformation requestAdvanceDevInfo = new RequestAdvanceDeviceInformation();
        ResponseAdvanceDeviceInformation responseAdvanceDevInfo = new ResponseAdvanceDeviceInformation();

        ResultGetVersionInfo result = new ResultGetVersionInfo();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {

            // PINPAD が接続されていない場合は
            // MSR の MakeTransactionKey が使用できるので
            // 「ポート異常(upos=104)」は返却せず
            // デバイス情報「情報無しの場合(=null)」を返却する

            result.setModel(null);
            result.setSno(null);
            result.setHdInfo(null);
            result.setAplVer(null);
            result.setPfVer(null);

            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return result;
        }

        // 機器情報要求コマンド
        if (!requestDeviceInfo.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] bufferDevInfo;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestDeviceInfo, TIME_OUT);
            bufferDevInfo = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(bufferDevInfo)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseDeviceInfo.inputPinpadResult(bufferDevInfo)) {
            result.setDevice(responseDeviceInfo.getDevice());
            result.setUpos(responseDeviceInfo.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        // 拡張製品情報取得コマンド
        if (!requestAdvanceDevInfo.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] bufferAdvance;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestAdvanceDevInfo, TIME_OUT);
            bufferAdvance = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(bufferAdvance)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseAdvanceDevInfo.inputPinpadResult(bufferAdvance)) {
            result.setDevice(responseAdvanceDevInfo.getDevice());
            result.setUpos(responseAdvanceDevInfo.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setModel(responseAdvanceDevInfo.getProduct());
        result.setSno(responseAdvanceDevInfo.getSerial());
        result.setHdInfo(null);
        result.setAplVer(responseDeviceInfo.getIfd());
        result.setPfVer(responseDeviceInfo.getFirmwareVersion());

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief DUKPTプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerDukptServiceListener(String tag, IDukServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIDukServiceListenerList) {
            mIDukServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief DUKPTプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterDukptServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIDukServiceListenerList) {
            mIDukServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param device deviceの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int device) {
        if (device != PluginDefine.RESULT_DEVICE_SCCESS) {
            return true;
        }

        return false;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param device deviceの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowMakeTransactionKeyError(int device) {
        if (device == 1 || device == 2 || device == 3) {
            return true;
        }

        return false;
    }
}
