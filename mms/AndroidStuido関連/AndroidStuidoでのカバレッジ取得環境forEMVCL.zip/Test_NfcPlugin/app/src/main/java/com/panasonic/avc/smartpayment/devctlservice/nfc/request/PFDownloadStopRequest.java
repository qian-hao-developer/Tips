package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * PFダウンロード中止Requestクラス.
 * 
 */
public class PFDownloadStopRequest extends BaseDownloadStopRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = PFDownloadStopRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC3;

    /** Constructor */
    public PFDownloadStopRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
