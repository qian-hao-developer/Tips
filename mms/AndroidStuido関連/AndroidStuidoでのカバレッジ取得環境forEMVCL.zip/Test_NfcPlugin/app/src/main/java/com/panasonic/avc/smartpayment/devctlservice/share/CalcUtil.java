
package com.panasonic.avc.smartpayment.devctlservice.share;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 変換用便利関数
 */
public class CalcUtil {

    /**
     * @brief ２バイトのバイト列をint型に変更する
     * @param low 下位1バイト
     * @param high 上位1バイト
     * @return 結合したint
     */
    public static int toInt(byte low, byte high) {
        return ((high & 0xff) << 8) | low & 0xff;
    }

    /**
     * @brief 0x01の場合にtrueを返す
     * @param b 1バイトデータ
     * @return
     */
    public static boolean toBoolean(byte b) {
        return (b == 0x01);
    }

    /**
     * @brief バイト列を反転する
     * @param src 入力バイト列
     * @return 反転結果
     */
    public static byte[] reverseByte(byte[] src) {
        if (src == null) {
            return null;
        }

        byte[] dest = new byte[src.length];

        for (int i = 0; i < src.length; i++) {
            dest[i] = src[src.length - 1 - i];
        }
        return dest;
    }

    /**
     * @brief CRC生成(CRC-CCITT Kermit)
     * @param bytes バイト列
     * @return CRC
     */
    public static int createCRC(byte[] bytes) {
        long crc;
        long q;
        byte c;
        crc = 0;
        for (int i = 0; i < bytes.length; i++) {
            c = bytes[i];
            q = (crc ^ c) & 0x0f;
            crc = (crc >> 4) ^ (q * 0x1081);
            q = (crc ^ (c >> 4)) & 0xf;
            crc = (crc >> 4) ^ (q * 0x1081);
        }

        return (int) (((crc & 0xff) << 8) + ((crc >> 8) & 0xff));
    }

    /**
     * @brief バイト列を16進数文字列に変換する
     * @param data バイト列
     * @return 16進数文字列
     */
    public static String toHexString(byte[] data) {
        if (data == null) {
            return null;
        }

        StringBuffer buffer = new StringBuffer();
        for (byte b : data) {
            String str = Integer.toHexString(0xff & b);
            if (str.length() == 1) {
                buffer.append("0");
            }
            buffer.append(str);
        }
        return buffer.toString();
    }

    /**
     * @brief バイト列をASCII文字列に変換する
     * @param data バイト列
     * @return ASCII文字列
     */
    public static String toAscii(byte[] data) {
        if (data == null) {
            return null;
        }

        try {
            String str = new String(data, "US-ASCII");
            return str.trim();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * @brief 16進数文字列をバイト列に変換する
     * @param hex 16進数文字列
     * @return バイト列(変換に失敗した場合はnullを返す)
     */
    public static byte[] toByte(String hex) {
        if (hex == null) {
            return null;
        }

        byte[] bytes = new byte[hex.length() / 2];

        for (int index = 0; index < bytes.length; index++) {
            bytes[index] = (byte) Integer.parseInt(hex.substring(index * 2, (index + 1) * 2), 16);
        }
        return bytes;
    }

    /**
     * @brief 16進数文字をバイトに変換する
     * @param hex 16進数文字
     * @return バイト列(変換に失敗した場合はnullを返す)
     */
    public static byte toByteChar(String hex) {
        return (byte) Integer.parseInt(hex.substring(0, 2), 16);
    }

    /**
     * 整数値を16進数文字列(エンディアンに応じた)変更する
     * 
     * @param little エンディアン
     * @param value 値
     * @return 文字列
     */
    public static String toString(boolean little, int value) {
        String ret = null;
        if (little) {
            ret = String.format("%02x", (value & 0xff));
            ret += String.format("%02x", ((value >> 8) & 0xff));
        } else {
            ret = String.format("%02x", ((value >> 8) & 0xff));
            ret += String.format("%02x", (value & 0xff));
        }
        return ret;
    }

    /*
     * @brief int型の長さを2byteの配列に変換する(2byteで表現できる範囲まで)
     * @param length 変換したいlength
     * @param isLittle little endianかどうか
     * @return バイト列(変換に失敗した場合はnullを返す)
     */
    public static byte[] toByteLength(int length, boolean isLittle) {
        if (length < 0 || length > 65535) {
            return null;
        }
        ByteBuffer buffer = ByteBuffer.allocate((Short.SIZE / Byte.SIZE));
        byte[] ret = buffer.putShort((short) length).array();
        if (isLittle) {
            byte tmp = ret[0];
            ret[0] = ret[1];
            ret[1] = tmp;
        }
        return ret;
    }

    /**
     * @brief int型の長さを4byteの配列に変換する
     * @param length
     * @param isLittle LittleEndianで取得したい場合true
     * @return 4バイトのbyte配列を返す
     */
    public static byte[] toByteLength4(int length, boolean isLittle) {
        ByteBuffer buffer = ByteBuffer.allocate((Integer.SIZE / Byte.SIZE));
        buffer.putInt(length);
        if (isLittle) {
            buffer.order(ByteOrder.LITTLE_ENDIAN);
        }
        return buffer.array();
    }

    public static String byte2hex(byte data) {
        StringBuffer sb = new StringBuffer();
        String s = Integer.toHexString(0xff & data);
        if (s.length() == 1) {
            sb.append("0");
        }
        sb.append(s);
        return sb.toString();
    }

    public static String byte2hex(byte[] data) {
        StringBuffer sb = new StringBuffer();
        for (byte b : data) {
            String s = Integer.toHexString(0xff & b);
            if (s.length() == 1) {
                sb.append("0");
            }
            sb.append(s);
        }
        return sb.toString();
    }

    /**
     * @brief 特定のUSBデバイスの製品情報を取得する
     * @param vendorId ベンダID
     * @param productId プロダクトID
     * @param searchFileName 検索対象ファイル名(sys/bus/usb/devicesで作成されるファイル名)
     * @return 製品情報
     */
    public static String searchUsbDeviceInformation(int vendorId, int productId,
            String searchFileName) {
        String sdPath = "/sys/bus/usb/devices";
        File dir = new File(sdPath);
        File[] list = dir.listFiles();

        for (int i = 0; i < list.length; i++) {
            if (list[i].isDirectory()) {
                File[] f = list[i].listFiles();

                int product = 0;
                int productName = 0;
                int vendor = 0;
                int check = 0;

                for (int j = 0; j < f.length; j++) {
                    if (f[j].getName().equals("idProduct")) {
                        product = j;
                        check |= 1;
                    } else if (f[j].getName().equals("idVendor")) {
                        vendor = j;
                        check |= 2;
                    } else if (f[j].getName().equals(searchFileName)) {
                        productName = j;
                        check |= 4;
                    }
                }

                if (check == 7) {
                    try {
                        BufferedReader productBr = new BufferedReader(new InputStreamReader(
                                new FileInputStream(f[product])));
                        String p = productBr.readLine();
                        productBr.close();

                        BufferedReader vendorBr = new BufferedReader(new InputStreamReader(
                                new FileInputStream(f[vendor])));
                        String v = vendorBr.readLine();
                        vendorBr.close();

                        if (p == null || v == null) {
                            continue;
                        }

                        int pid = Integer.parseInt(p, 16);
                        int vid = Integer.parseInt(v, 16);

                        if (vendorId == vid && productId == pid) {
                            BufferedReader productNameBr = new BufferedReader(
                                    new InputStreamReader(
                                            new FileInputStream(f[productName])));
                            String ret = productNameBr.readLine();
                            productNameBr.close();
                            return ret;
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @brief byte 配列を List 型に変換する
     * @param bytes byte 配列
     * @return List 型の byte 列
     */
    public static List<Byte> toList(byte[] bytes) {
        List<Byte> list = new ArrayList<Byte>();
        for (int i = 0; i < bytes.length; i++) {
            list.add(bytes[i]);
        }
        return list;
    }

    /**
     * @brief List 型の byte 列を配列に変換する
     * @param byteList List 型の byte 列
     * @return byte 配列
     */
    public static byte[] toArray(List<Byte> byteList) {
        byte[] array = new byte[byteList.size()];
        Iterator<Byte> iterator = byteList.iterator();
        for (int i = 0; i < array.length; i++) {
            array[i] = iterator.next();
        }
        return array;
    }

    /**
     * @brief byte 配列をカットする
     * @param bytes byte 配列
     * @param length カット後の長さ
     * @return カット後の byte 配列
     */
    public static byte[] cutArray(byte[] bytes, int length) {
        byte[] array = new byte[length];
        System.arraycopy(bytes, 0, array, 0, length);
        return array;
    }

    /**
     * @brief List<byte[]> 型を二次元配列に変換する
     * @param byteArrayList byte 列
     * @return 二次元配列
     */
    public static byte[][] toMatrix(List<byte[]> byteArrayList) {
        byte[][] matrix = new byte[byteArrayList.size()][0];
        for (int i = 0; i < byteArrayList.size(); i++) {
            matrix[i] = byteArrayList.get(i);
        }
        return matrix;
    }

    /**
     * List<Integer> から値が value の要素を削除する
     * 
     * @param list 整数配列
     * @param value 削除する値
     */
    public static void removeIntByList(List<Integer> list, int value) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == value) {
                list.remove(i);
                i--;
            }
        }
    }

}
