
package com.panasonic.avc.smartpayment.devctlservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TamperMonitorServiceReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }

        if (intent.getAction().equals(TamperBroadcastAction.ACTION_TAMPER_ALARM)) {
            context.startService(new Intent(context, TamperMonitorService.class));
        }
    }

}
