
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetArea extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetArea(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetArea() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetArea> CREATOR = new Parcelable.Creator<ResultGetArea>() {

        @Override
        public ResultGetArea createFromParcel(Parcel in) {
            return new ResultGetArea(in);
        }

        @Override
        public ResultGetArea[] newArray(int size) {
            return new ResultGetArea[size];
        }
    };
}
