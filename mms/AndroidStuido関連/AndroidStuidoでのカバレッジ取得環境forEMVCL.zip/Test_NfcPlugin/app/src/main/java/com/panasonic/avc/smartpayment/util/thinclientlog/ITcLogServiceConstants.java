package com.panasonic.avc.smartpayment.util.thinclientlog;

/**
* ITcLogService(AIDL)のメソッドの引数として使用する定数<br>
* @version 1.1<br><br>
* 変更履歴<br>
* version 0.1: 新規作成<br>
* version 0.2: LogType に DEVICE_TROUBLE 追加<br>
* version 0.3: DeviceType に MSR、プリンタ追加<br>
* version 0.3: MonitoringEventTypeを追加<br>
* version 0.4: クラス名 MonitoringEventType を、MonitoringItem に変更<br>
* version 0.4: MonitoringEventType に定数 BATTERY_VOLTAGE 追加<br>
* version 0.4: DEVICE_TROUBLE_PORTENT の定数値変更（誤記修正）<br>
* version 0.4: クラス LogTypeSend 追加。表示用ログタイプと送信用ログタイプを分離。定数の値変更<br>
* version 0.8:　LogTypeSendクラスのシンクラ端末機能ログを意味する定数TCを削除。端末状態表示ログを意味する定数TERMINAL_STATUSの値変更。<br>
* version 0.8:　「予兆ログ」にタンパを追加し、名称を「監視ログ」に変更した。これに伴い、LogTypeSendクラスのデバイス異常の予兆ログを意味する定数DEVICE_TROUBLE_PORTENTをMONITORINGに変更。また、値を変更。<br>
* version 0.8: MonitoringItemクラスのタンパ予兆カウントを意味する定数TAMPERを、タンパを意味する定数に変更し、タンパ予兆用の定数TAMPER_PORTEN_COUNTを追加。MonitoringItemのメンバの値を、LogTypeと重複しないよう変更（運用ログの表示／印字データ抽出時に、監視ログが抽出されないようにするため）。<br>
* version 0.9: LogTypeクラスの定数名GENERALLをGENERALに変更（誤記修正）<br>
* version 1.1:　定数TERMINAL_STATUSのdeprecatedタグ削除（vivi専用メソッド）<br>
* version 1.1:　DeviceTypeクラスに定数DUK、HMI（いずれもvivi専用）追加<br>
*/

public class ITcLogServiceConstants{
	private ITcLogServiceConstants(){}
    /**
     * ログタイプ
     */
    public static class LogType{
    	private LogType(){}
        /**
         * 一般のログ（電源ON/OFFなど）
         */
        public static final int GENERAL = 1;

        /**
         * タンパログ
         */
        public static final int SECURITY = 2;

        /**
         * デバイス異常のログ<br>
        */
        public static final int DEVICE_TROUBLE = 4;
    }

    /**
     * 送信用ログタイプ
     */
    public static class LogTypeSend{
    	private LogTypeSend(){}
        /**
         * 運用ログ<br>
         * 一般のログ、タンパログ、デバイス異常のログが含まれる。PDSが収集するログ分類とは異なる場合があるので、注意すること。<br>
        */
        public static final int OPERATION = 1;

        /**
         * 端末状態表示ログ<br>
         * viviでのみ使用可。<br>
         * aceにてこれが指定されると、戻り値またはコールバックにてnullが通知される。         
         */
        public static final int TERMINAL_STATUS = 2;

        /**
         * 監視ログ<br>
        */
        public static final int MONITORING = 16;
    }

    /**
     * デバイスタイプ
     */
    public static class DeviceType{
    	private DeviceType(){}
        /**
         * 本体
         */
        public static final int MAIN = 1;

        /**
         * 非接触ICリーダライタ
         */
        public static final int RW = 2;

        /**
         * IC-PINPAD
         */
        public static final int PED = 4;

        /**
         * MSR
         */
        public static final int MS = 8;

        /**
         * プリンタ
         */
        public static final int PRT = 16;

        /**
         * DUKPT（vivi専用）
         */
        public static final int DUK = 32;

        /**
         * HMI（vivi専用）
         */
        public static final int HMI = 64;
    }
    
    /**
     * 監視項目
     */
    public static class MonitoringItem{
        //メンバ定数は、LogTypeのメンバ定数と重複しない値とすること（意味が同じものを除く）。
        //将来、項目が増える可能性があり、また、複数のデータを同時に要求されることはないため、各ビットに各メンバを割り当てる方法は採らない。
    	private MonitoringItem(){}
        /**
         * タンパ
         */
        public static final int TAMPER = 2;//LogType.SECURITYと同一

        /**
         * タンパ予兆カウント
         */
        public static final int TAMPER_PORTEN_COUNT = 32;//0x20

        /**
         * 電池電圧
         */
        public static final int BATTERY_VOLTAGE = 48;//0x30
    }
}
