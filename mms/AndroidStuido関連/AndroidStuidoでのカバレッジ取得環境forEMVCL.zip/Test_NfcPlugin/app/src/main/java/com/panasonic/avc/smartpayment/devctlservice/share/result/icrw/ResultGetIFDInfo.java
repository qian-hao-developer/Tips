
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.AnalyzeResultData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * GetIFDInfo処理結果データ
 */
public class ResultGetIFDInfo extends AnalyzeResultData {
    /** @brief IFDシリアル番号取得結果 */
    private String mIfdSerial;

    /** @brief IFDシリアル番号取得処理結果タグ */
    protected static final String IFD_SERIAL = "ifdserial";

    /** @brief マスターコマンド **/
    private static final byte MASTER_COMMAND = 0x30;

    /** @brief サブコマンド **/
    private static final byte SUB_COMMAND = 0x01;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x1A;

    /**
     * @brief コンストラクタ
     */
    public ResultGetIFDInfo(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetIFDInfo() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetIFDInfo> CREATOR = new Parcelable.Creator<ResultGetIFDInfo>() {
        public ResultGetIFDInfo createFromParcel(Parcel in) {
            return new ResultGetIFDInfo(in);
        }

        public ResultGetIFDInfo[] newArray(int size) {
            return new ResultGetIFDInfo[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(mIfdSerial);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mIfdSerial = in.readString();
    }

    /**
     * @brief IFDシリアル番号を取得します
     * @retun IFDシリアル番号
     */
    public String getIfdSerial() {
        return mIfdSerial;
    }

    /**
     * @brief IFDシリアル番号を設定します
     * @param[in] ifdSerial IFDシリアル番号
     */
    public void setIfdSerial(String ifdSerial) {
        mIfdSerial = ifdSerial;
    }

    /**
     * @see AnalyzeResultData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int result = buffer[PinpadDefine.INDEX_PARAMETER];
        if (result != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.RW, result, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        byte[] serial = new byte[8];

        System.arraycopy(bytes, PinpadDefine.INDEX_PARAMETER + 18, serial, 1, serial.length - 1);
        serial[0] = 0x30;
        mIfdSerial = new String(serial);

        return true;
    }

    /**
     * @see AnalyzeResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(IFD_SERIAL, JSONObject.NULL);
            } else {
                json.put(IFD_SERIAL, getIfdSerial());
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
