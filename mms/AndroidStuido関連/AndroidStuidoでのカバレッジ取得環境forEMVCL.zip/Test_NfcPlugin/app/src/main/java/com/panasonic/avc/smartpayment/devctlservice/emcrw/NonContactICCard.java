
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import android.content.Context;
import android.content.res.AssetManager;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.cfg.Configuration;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data.RequestEmcrwData;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data.ResponseEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data.ResponseSendFelicaCmd;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.request.RequestACK;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.request.RequestEOT;
import com.panasonic.avc.smartpayment.devctlservice.msr.MagneticStripeCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.IEmcrwServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultAplVersion;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCarrierOff;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCarrierOn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultInitEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultPolling;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultRegistEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSendFeliCaAplOff;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSendFeliCaCmd;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetHmi;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetSound;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetVolume;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultTermEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;
import com.panasonic.avc.smartpayment.devctlservice.tamper.TamperDetectionInfoController;
import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;

/**
 * 非接触ICカードリーダー処理部
 */
public class NonContactICCard {

    /** @brief ログ出力用タグ */
    private static final String TAG = Configuration.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static NonContactICCard sInstance = new NonContactICCard();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IEmcrwServiceListener> mIEmcrwServiceListenerList = new ConcurrentHashMap<String, IEmcrwServiceListener>();

    /** @brief コンテキスト */
    private Context mContext;

    /** @brief プラグインの状態 */
    private boolean mActive;

    /** @brief 非公開プラグインの状態 */
    private boolean mActiveEx;

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief 非接触ICカードリーダライタの使用状態(未認証) */
    public static final int RW_STATE_NOT_AUTH = 0;

    /** @brief 非接触ICカードリーダライタの使用状態(未使用状態) */
    public static final int RW_STATE_USE_NONE = 1;

    /** @brief 非接触ICカードリーダライタの使用状態(Emcrw Java API使用中) */
    public static final int RW_STATE_USE_EMCRW = 2;

    /** @brief 非接触ICカードリーダライタの使用状態(NFC Plug-In API使用中) */
    public static final int RW_STATE_USE_NFC = 3;

    /** @brief 文字セット最小の値 */
    private static final int CHARSET_SJIS = 1;

    /** @brief 文字セット最大の値 */
    private static final int CHARSET_UTF8 = 2;

    /** @brief 文字セット */
    private int mCharset = CHARSET_SJIS;

    /** @brief Charset - Shift-JIS */
    Charset Shift_JIS = Charset.forName("Shift-JIS");

    /** @brief Charset - UTF-8 */
    Charset UTF_8 = Charset.forName("UTF-8");

    /** @brief リンクレベル */
    private int mLinkLevel = EmcrwDefine.LINK_LEVEL_CCT;
    // private int mLinkLevel = EmcrwDefine.LINK_LEVEL_PINPAD;

    /** @brief モデルタイプ */
    private int mModelType = EmcrwDefine.MODEL_TYPE_R;

    /** @brief 時間計測ログ表示 */
    private boolean EnableTimeLog = false;

    /** @brief デバッグログ表示 */
    private boolean EnableDebugLog = true;

    private final int WRITE_TIME_OUT = 500;
    private final int READ_TIME_OUT = 5000;

    /** @brief 音量 */
    private int mVolume;

    /** @brief 非接触ICカードリーダライタの使用状態 */
    private int mRwState = RW_STATE_NOT_AUTH;

    /** @brief タンパ状態 */
    private boolean mIsTamper = true;

    /** @brief 利用可能状態 */
    private boolean mStatus = false;

    /** @brief リーダライタ登録状態 */
    private boolean mIsRegisted = false;

    /** @brief 認証状態 */
    private boolean mIsAuthenticated = false;

    /** @brief バージョンインフォ */
    private boolean mIsCreated = false;

    /** @brief バージョンインフォ */
    /** @brief 非接触ICカードリーダライタの製品品番 */
    private String mModel;

    /** @brief 非接触ICカードリーダライタのシリアル番号 */
    private String mSno;

    /** @brief 非接触ICカードリーダライタのアプリケーション番号 */
    private String mAplver;

    /** @brief 非接触ICカードリーダライタのプラットフォームバージョン */
    private String mPfver;

    /** @brief 非接触ICカードリーダライタのアプリケーションバージョン */
    private EmcrwApplicationDataMap mAPDataList = null;

    /** @brief エリアBの表示文字列 */
    private String mHmiTextB = null;

    /** @brief エリアDの表示文字列 */
    private String mHmiTextD = null;

    /** @brief 初期化に成功したか */
    private boolean mIsSucceededLastInit;

    /* key */

    // 元セッションキー
    private byte[] mBaseSessionKey = new byte[16];

    // 相互認証用セッションキー保存
    private byte[] mSessionKey2 = new byte[16];
    // セッションキーを保存する
    private byte[] mSessionKey = new byte[16];

    // 相互認証用元セッションキー
    private byte[] mBaseSessionKey2 = new byte[16];

    // 乱数A
    private byte[] mRandA = new byte[8];
    // 乱数B
    private byte[] mRandB = new byte[8];

    // マスターキー
    private byte[] mMasterKey = new byte[16];

    // マスターキー選択番号
    private byte[] mMasterKeyNumbers = new byte[2];

    // 相互認証用マスターキー
    private byte[] mMasterKey2 = new byte[16];
    // 相互認証用マスターキー選択番号
    private byte[] mMasterKeyNumbers2 = new byte[2];

    // 元マスターキー長
    private static final int SEED_LENGTH = 16;
    // 鍵長
    private static final int KEY_LENGTH = 16;

    // 元マスターキー
    private static final byte[][] MASTER_KEY_SEEDS =
            MagneticStripeCard.getInstance().getEmcrwMasterKeySeeds();

    private static final int PAYLOAD_LENGTH = 16;

    // デフォルトRW登録番号（固定バイト列につき変更不可）
    private byte[] mDefaultRWRegNum = new byte[] {
            (byte) 0xE3, (byte) 0x43, (byte) 0x7C, (byte) 0xBD,
            (byte) 0xEE, (byte) 0xE3, (byte) 0xBC, (byte) 0xC7,
    };

    private byte[] mRWRegNum = new byte[] {
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
    };

    private static final int PAYLOAD_LENGTH_RW = 31;

    private static final int POSITION_AREA_A = 1;
    private static final int POSITION_AREA_C = 2;
    private static final int POSITION_AREA_E = 3;

    /** @brief 非同期用スレッド(InitICRW) */
    private Thread mPrepareEmcrwThread;

    /**
     * デバイスの準備完了待ち用Latch
     */
    private CountDownLatch mPrepareLatch;

    /**
     * @brief コンストラクタ
     */
    private NonContactICCard() {
    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static NonContactICCard getInstance() {
        return sInstance;
    }

    public static String bin2hex(byte[] data) {
        StringBuffer sb = new StringBuffer();
        for (byte b : data) {
            String s = Integer.toHexString(0xff & b);
            if (s.length() == 1) {
                sb.append("0");
            }
            sb.append(s);
            // sb.append(",");
            // sb.append(" ");
        }
        return sb.toString();
    }

    public static byte[] hex2bin(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int index = 0; index < bytes.length; index++) {
            bytes[index] = (byte) Integer.parseInt(hex.substring(index * 2, (index + 1) * 2), 16);
        }
        return bytes;
    }

    public static boolean isValidhex2bin(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        try {
            for (int index = 0; index < bytes.length; index++) {
                bytes[index] = (byte) Integer.parseInt(hex.substring(index * 2, (index + 1) * 2),
                        16);
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    private void dumpBuffer(byte[] data) {
        if (data == null) {
            return;
        }
        String str = bin2hex(data);
        mLoggingManager.d(TAG, str);
    }

    public boolean isPrepared() {
        if (!mIsCreated) {
            mPrepareLatch = new CountDownLatch(1);
            try {
                boolean prepared = mPrepareLatch.await(60, TimeUnit.SECONDS);
                if (prepared) {
                    return true;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mPrepareLatch = null;
        } else {
            return true;
        }
        return false;
    }

    /**
     * @brief 非接触ICカードリーダライタ接続時に必要な準備を行う
     * @return 実行結果
     */
    public void createEmcrw() {

        mVolume = -1;
        mIsTamper = true;
        mStatus = false;
        mIsRegisted = false;
        mIsAuthenticated = false;

        mModel = null;
        mSno = null;
        mAplver = null;
        mPfver = null;

        mAPDataList = null;

        generateMasterKey(); // マスターキーの生成
        generateMasterKey2(); // 相互認証用マスターキーの生成
        generateRandA(); // 乱数Aの生成
        generateBaseSessionKey(); // 元セッションキーの生成
        generateBaseSessionKey2(); // 相互認証用元セッションキーの生成

        if (DevCtlServiceDefine.SERIAL) {
            getRWStatus();
            mIsCreated = true;
        } else {
            mPrepareEmcrwThread = new Thread() {
                public void run() {
                    create();
                    setRwState(RW_STATE_USE_NONE);
                }
            };
            mPrepareEmcrwThread.start();
        }

    }

    /**
     * @brief 非接触ICカードリーダライタ切断時に必要な準備を行う
     * @return 実行結果
     */
    public void destroyEmcrw() {
        setRwState(RW_STATE_NOT_AUTH);
        mIsCreated = false;
        mModel = null;
        mSno = null;
        mAplver = null;
        mPfver = null;
    }

    /**
     * @brief 非接触ICカードリーダライタを登録します
     * @return 実行結果
     */
    public ResultRegistEmcrw registEmcrw(String number) {
        ResultRegistEmcrw result = new ResultRegistEmcrw();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (number != null && number.length() != 16) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
        result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);

        /* デフォルト相互認証解除 */
        if (sendUnregister()) {

            if (number != null) {
                mRWRegNum = CalcUtil.toByte(number);
            }
            /* デフォルト相互認証 リーダーライター番号登録 */
            if (sendDefaultAuthentication()) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            }
        }
        return result;
    }

    /**
     * @brief EMCRWを初期化します
     * @param[in] stime 非接触ICカードリーダライタを整字するための時刻情報
     * @param[in] charset 非接触ICカードリーダライタで使用する文字セット
     * @param[in] paid アプリケーションID
     * @return 実行結果
     */
    public ResultInitEmcrw initEmcrw(String stime, int charset, byte apid) {
        ResultInitEmcrw result = new ResultInitEmcrw();

        if (mModelType == EmcrwDefine.MODEL_TYPE_R) {
            result.setModelType(ResultInitEmcrw.MODE_TYPE_R);
        } else if (mModelType == EmcrwDefine.MODEL_TYPE_M) {
            result.setModelType(ResultInitEmcrw.MODE_TYPE_M);
        }

        if (getRwState() == RW_STATE_USE_NFC) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_CONFLICT_ERROR);
            return result;
        }

        if (!isEnableDevice() || !isPrepared() || !mIsCreated) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            mIsSucceededLastInit = false;
            return result;
        }

        if (stime == null || !(stime.length() == 0 || stime.length() == 14)
                || !((charset == CHARSET_UTF8) || (charset == CHARSET_SJIS))) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            mIsSucceededLastInit = false;
            return result;
        }

        if (stime.length() != 0) {
            try {
                Long.parseLong(stime);
            } catch (NumberFormatException e) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                mIsSucceededLastInit = false;
                return result;
            }
        }

        if (!mIsAuthenticated) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            mIsSucceededLastInit = false;
            return result;
        }
        setRwState(RW_STATE_USE_EMCRW);

        mActive = true;

        /* 4桁表示だとRWが記憶できないので記憶しておく必要がある。init時にクリアする */
        mHmiTextB = null;
        mHmiTextD = null;

        if (charset == CHARSET_UTF8) {
            mCharset = CHARSET_UTF8;
        } else if (charset == CHARSET_SJIS) {
            mCharset = CHARSET_SJIS;
        }

        // アプリ切り替え
        ResponseEmcrw response = sendChangeAp(apid);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            mIsSucceededLastInit = false;
            return result;
        }

        if (response.getBuffer() != null && response.isSuccess()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        } else {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        }

        boolean isSucceededInit = isResultSuccess(result);
        if (mIsSucceededLastInit && isSucceededInit) {
            // 前回と今回の初期化処理結果が共に成功であれば E_BUSY を返却する
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            mIsSucceededLastInit = isSucceededInit;
            return result;
        }

        mIsSucceededLastInit = true;
        return result;
    }

    /**
     * @brief FeliCaカードにコマンドを送信します
     * @param[in] timeout 受信タイムアウト時間(1～1970, 10ms単位)
     * @param[in] count 実効回数(1～65535)
     * @param[in] cardCommandPacketLength カードコマンドパケット長
     * @param[in] cardCommandPacket カードコマンドパケット
     * @return 実行結果
     */
    public ResultSendFeliCaCmd sendFeliCaCmd(int timeout, int count, int cardCommandPacketLength,
            String cardCommandPacket) {
        ResultSendFeliCaCmd result = new ResultSendFeliCaCmd();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setCardResponsePacket("");
        result.setCardResponsePacketLength(0);

        if (!isEnableDevice()) {
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (timeout != 0) {
            if (timeout < 0 || timeout > 1970 || count < 1 || count > 65535) {
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }
        }

        // cardCommandPacketLengthが0の場合はレングス1のデータとして扱う
        if (cardCommandPacketLength == 0) {
            cardCommandPacketLength = 1;
            cardCommandPacket = "";
        } else {
            if (cardCommandPacketLength < 0 || cardCommandPacketLength > 227
                    || cardCommandPacket == null) {
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }
        }

        // packet length check
        byte[] packet = hex2bin(cardCommandPacket);

        if (packet.length != (cardCommandPacketLength - 1)) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        // 透過コマンド送信
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        // set packet
        request.setEncrpt(true);
        request.setCommand((byte) 0x30, (byte) 0x00);
        request.setReturnLength(256);

        // set data
        int data_len = 1 + 2 + 2 + 1 + cardCommandPacketLength;
        int padding_len = request.getPaddingLength(data_len); // パディングサイズ
        int total_len = data_len + padding_len; // パケットサイズ + パディングサイズ

        byte[] data = new byte[total_len];
        data[0] = (byte) 0x70; // コマンドコード 70H 透過コマンド

        byte[] timeout_byte = CalcUtil.toByteLength(timeout, false);
        data[1] = timeout_byte[0];
        data[2] = timeout_byte[1];

        // タイムアウトが0のときはカウントに0x00 0x01以外を指定すると構文異常になるので0x00 0x01に置き換える
        if (timeout == 0) {
            byte[] count_byte = CalcUtil.toByteLength(1, false);
            data[3] = count_byte[0];
            data[4] = count_byte[1];
        } else {
            byte[] count_byte = CalcUtil.toByteLength(count, false);
            data[3] = count_byte[0];
            data[4] = count_byte[1];
        }

        data[5] = (byte) cardCommandPacketLength;

        int index = 6;
        for (int i = 0; i < packet.length; i++, index++) {
            data[index] = packet[i];
        }

        // padding
        byte[] padding = new byte[padding_len];
        for (int i = 0; i < padding.length; i++, index++) {
            data[index] = padding[i];
        }
        // set data
        byte[] setdata = encrypt(data, mSessionKey2);
        request.setData(setdata);

        // mLoggingManager.d(TAG, "send    FelicaCmd before encrypt");
        // dumpBuffer(data);

        // mLoggingManager.d(TAG, "send    FelicaCmd");
        // dumpBuffer(request.toPacket());

        // if (EnableTimeLog) {
        // long start = System.currentTimeMillis();
        // }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        request.setTimeout(timeout * 10);
        request.setCount(count);
        ResponseEmcrw res = sendEmcrw(request);

        // if (EnableTimeLog) {
        // long end = System.currentTimeMillis();
        // mLoggingManager.e(TAG, (end % 1000000) + " LinkPF  : time = " + (end
        // - start));
        // }
        // mLoggingManager.d(TAG, "receive  FelicaCmd");
        // dumpBuffer(ret);

        if (res == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (res.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {

            ResponseSendFelicaCmd response = new ResponseSendFelicaCmd();

            if (response.inputSendFelicaCmdResult(res.getData())) {
                result.setCardResponsePacketLength(response.getCardResponsePacketLength());
                result.setCardResponsePacket(response.getCardResponsePacket());
            } else {
                result.setCardResponsePacketLength(1);
                result.setCardResponsePacket("");
            }
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }

        return result;
    }

    /**
     * @brief キャリアをONにするコマンドを送信します
     * @return 実行結果
     */
    public ResultCarrierOn carrierOn() {
        ResultCarrierOn result = new ResultCarrierOn();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        request.setCommand((byte) 0x30, (byte) 0x0);
        request.setReturnLength(12);
        request.setData(generateSetCarrierOnPacketPayload());

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }
        return result;
    }

    /**
     * @brief キャリアをOFFにするコマンドを送信します
     * @return 実行結果
     */
    public ResultCarrierOff carrierOff() {
        ResultCarrierOff result = new ResultCarrierOff();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        request.setCommand((byte) 0x30, (byte) 0x0);
        request.setReturnLength(12);
        request.setData(generateSetCarrierOffPacketPayload());

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }

        return result;
    }

    /**
     * @brief 非接触ICカードリーダライタのHMIを制御します
     * @param[in] antennaMode LED の点灯/点滅/消灯を 1~9 で指定(整数型)します。
     * @param[in] antennaOntime LED の点灯時間を 1~600(100ms 単位)で指定(整数型)します。
     * @param[in] antennaBlinkOn LED の点灯時間を 1~100(100ms 単位)で指定(整数型)します。
     * @param[in] antennaBlinkOff LED の消灯時間を 1~100(100ms 単位)で指定(整数型)します。
     * @param[in] soundNumber 音源データの登録番号を 1~40 で指定(整数型)します。
     * @param[in] soundLoop 再生回数を 1~255 で指定(整数型)します。
     * @param[in] lcdImage_A 表示エリアAのイメージ登録番号を 1~10(4 行表示の RW の場合)または 1~800(5 行表示の RW
     *            の場合)で指定(整数型)します。
     * @param[in] lcdText_B 表示エリアBに表示する文字列を指定します。
     * @param[in] lcdImage_C 表示エリアCのイメージ登録番号を 1~10(4 行表示の RW の場合)または1~800(5 行表示の RW の場合)で指定(整数型)します。
     * @param[in] lcdText_D 表示エリアDに表示する文字列を指定します。
     * @param[in] lcdImage_E 表示エリアEのイメージ登録番号を 1~10(4 行表示の RW の場合)または1~800(5 行表示の RW の場合)で指定(整数型)します。
     * @param[in] lcdImage_B 表示エリア B のイメージ登録番号を 1~800 で指定(整数型)します。
     * @param[in] lcdText_C 表示エリア C に表示する文字列を指定します。
     * @param[in] lcdImage_D 表示エリア D のイメージ登録番号を 1~800 で指定(整数型)します。
     * @param[in] lcdText_F 表示エリア F に表示する文字列を指定します。
     * @param[in] lcdImage_F 表示エリア F のイメージ登録番号を 1~800 で指定(整数型)します。
     * @return 実行結果
     */
    public ResultSetHmi setHmi(int antennaMode, int antennaOntime, int antennaBlinkOn,
            int antennaBlinkOff,
            int soundNumber, int soundLoop, int lcdImage_A, String lcdText_B, int lcdImage_C,
            String lcdText_D, int lcdImage_E, int lcdImage_B, String lcdText_C, int lcdImage_D,
            String lcdText_F, int lcdImage_F) {

        ResultSetHmi result = new ResultSetHmi();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        request.setCommand((byte) 0x30, (byte) 0x00);
        request.setReturnLength(12);

        byte[] antenna = {
                (byte) 0xFF, (byte) 0x11, (byte) 0x12, (byte) 0x21, (byte) 0x22, (byte) 0x31,
                (byte) 0x32, (byte) 0x41, (byte) 0x42, (byte) 0x00,
        };

        // パラメータチェック
        if (!isHmiValidParam(lcdImage_A, lcdText_B, lcdImage_C, lcdText_D, lcdImage_E, lcdImage_B,
                lcdText_C, lcdImage_D, lcdText_F, lcdImage_F)) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        ByteBuffer buf = ByteBuffer.allocate(64);
        buf.clear();

        buf.put((byte) 0x9e); // コマンドコード9eh(外部UI制御4)

        // LED MODE
        if (antennaMode >= 0 && antennaMode <= 9) {
            buf.put((byte) antenna[antennaMode]);
        } else {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        // LED OnTime
        if (antennaOntime < 0 || antennaOntime > 600) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }
        if (antennaOntime == 0) {
            buf.put(request.calcLength2((byte) 0xff));// LED制御時間
        } else {
            buf.put(request.calcLength2(antennaOntime));// LED制御時間
        }

        // LED antennaBlinkOn
        if (antennaBlinkOn <= 0 || antennaBlinkOn > 100) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }
        buf.put((byte) antennaBlinkOn); // LED点滅間隔(点灯)

        // LED antennaBlinkOff
        if (antennaBlinkOff <= 0 || antennaBlinkOff > 100) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }
        buf.put((byte) antennaBlinkOff); // LED点滅間隔(消灯)

        // soundNumber
        int soundNumberMax = 0;
        if (mModelType == EmcrwDefine.MODEL_TYPE_R) {
            // 据置型は1-32
            soundNumberMax = 32;
        } else if (mModelType == EmcrwDefine.MODEL_TYPE_M) {
            // モバイル型は1-40
            soundNumberMax = 40;
        }

        if (soundNumber == 0) {
            buf.put((byte) 0xff); // 音源停止
        } else if (soundNumber == 99) {
            buf.put((byte) 0xfe); // 音源制御なし
        } else {
            if (soundNumber < 0 || soundNumber > soundNumberMax) {
                result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
                return result;
            }
            buf.put((byte) (soundNumber - 1)); // 音源
        }

        // soundLoop
        if (soundLoop < 0 || soundLoop > 255) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (soundLoop == 0) {
            buf.put((byte) 0x00); // 再生し続ける
        } else {
            buf.put((byte) soundLoop); // 再生回数
        }

        if (lcdImage_A == 0) {
            buf.put((byte) 0xff); // エリアA表示イメージ（表示なし）
            buf.put((byte) 0xff); // エリアA表示イメージ（表示なし）
        } else {
            byte[] byte_number = CalcUtil.toByteLength((lcdImage_A - 1), false); // エリアA表示イメージ
            buf.put(byte_number);
        }
        byte[] strAreaB = new byte[] {
                (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20,
        };

        // LCD消去時は記憶している文字列を消去する
        if (antennaMode == 9 && soundNumber == 0 && lcdImage_A == 0 && lcdImage_C == 0
                && lcdImage_E == 0 && lcdText_B.length() == 0 && lcdText_D.length() == 0) {
            mHmiTextB = null;
            mHmiTextD = null;
        }

        /* 4桁表示版ではRWが文字列を記憶しないので付与する */
        if (lcdText_B.length() == 0 && mHmiTextB != null) {
            lcdText_B = mHmiTextB;
        } else {
            mHmiTextB = lcdText_B;
        }

        if (lcdText_B.length() == 0) {
            // 空白を表示
            buf.put(strAreaB);
        } else {
            if (lcdText_B.length() != strAreaB.length) {
                byte[] str = getString(lcdText_B);
                int mergin = strAreaB.length - lcdText_B.length();
                for (int i = mergin, j = 0; i < strAreaB.length; i++, j++) {
                    strAreaB[i] = str[j];
                }
                buf.put(strAreaB);
            } else {
                buf.put(getString(lcdText_B));
            }
        }

        if (lcdImage_C == 0) {
            buf.put((byte) 0xff); // エリアC表示イメージ（表示なし）
            buf.put((byte) 0xff); // エリアC表示イメージ（表示なし）
        } else {
            byte[] byte_number = CalcUtil.toByteLength((lcdImage_C - 1), false); // エリアC表示イメージ
            byte_number[0] = (byte) ((byte) 0x10 + byte_number[0]);
            buf.put(byte_number);
        }
        byte[] strAreaD = new byte[] {
                (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20,
                (byte) 0x20, (byte) 0x20, (byte) 0x20, (byte) 0x20,
        };

        /* 4桁表示版ではRWが文字列を記憶しないので付与する */
        if (lcdText_D.length() == 0 && mHmiTextD != null) {
            lcdText_D = mHmiTextD;
        } else {
            mHmiTextD = lcdText_D;
        }

        if (lcdText_D.length() == 0) {
            // 空白を表示
            buf.put(strAreaD);
        } else {
            if (lcdText_D.length() != strAreaD.length) {
                byte[] str = getString(lcdText_D);
                int mergin = strAreaD.length - lcdText_D.length();
                for (int i = mergin, j = 0; i < strAreaD.length; i++, j++) {
                    strAreaD[i] = str[j];
                }
                buf.put(strAreaD);
            } else {
                buf.put(getString(lcdText_D));
            }
        }

        if (lcdImage_E == 0) {
            buf.put((byte) 0xff); // エリアE表示イメージ（表示なし）
            buf.put((byte) 0xff); // エリアE表示イメージ（表示なし）
        } else {
            byte[] byte_number = CalcUtil.toByteLength((lcdImage_E - 1), false); // エリアE表示イメージ
            byte_number[0] = (byte) ((byte) 0x20 + byte_number[0]);
            buf.put(byte_number);
        }

        byte[] padding = new byte[10];
        Arrays.fill(padding, (byte) 0x00);
        buf.put(padding);
        buf.rewind();

        byte[] packet = new byte[64];
        buf.get(packet);

        request.setData(encrypt(packet, mSessionKey2));

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }

        return result;
    }

    /**
     * @brief 非接触ICカードリーダライタの音量を設定し、設定後の最新状態を取得します
     * @param[in] volume 非接触 IC カードリーダライタの音量
     * @return 実行結果
     */
    public ResultSetVolume setVolume(int volume) {
        if (volume == 0) {
            ResultSetVolume result = new ResultSetVolume();
            if (!mActive) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
                return result;
            }
            // フェリカスルーアプリが起動中のときは通信エラーになるので記憶しているデータを返す
            if (mActive && mVolume > 0) {
                result.setEndCode(0);
                result.setEndSubCode(0);
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
                result.setVolume(mVolume);
                return result;
            }
            return getVolume();
        } else {
            return setVolumeLocal(volume);
        }
    }

    /**
     * @brief 非接触ICカードリーダライタの音量を設定し、設定後の最新状態を取得します(Launcher専用)
     * @param[in] volume 非接触 IC カードリーダライタの音量
     * @return 実行結果
     */
    public ResultSetVolume setVolumeInternal(int volume) {
        boolean status = mActive;
        ResultSetVolume ret = null;

        if (status != true) {
            mActive = true;
        }
        if (volume == 0) {
            ret = getVolume();
        } else {
            ret = setVolumeLocal(volume);
        }
        if (status == false) {
            mActive = false;
        }
        return ret;
    }

    private ResultSetVolume getVolume() {
        ResultSetVolume result = new ResultSetVolume();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }
        // フェリカスルーアプリが起動中のときは通信エラーになるので記憶しているデータを返す
        if (mActive && mVolume > 0) {
            result.setEndCode(0);
            result.setEndSubCode(0);
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            result.setVolume(mVolume);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        byte mc = (byte) 0x00;
        byte sc = (byte) 0x00;
        request.setCommand(mc, sc);
        request.setReturnLength(41);
        request.setData(generateRwInformationPacketPayload());

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            result.setVolume(mVolume);
        } else {
            if (response.getMC() == mc) {
                if (response.getData().length == 32) {
                    byte[] buffer0 = response.getData();
                    byte[] buffer = decrypt(buffer0, mSessionKey2);

                    int value = buffer[2];
                    mVolume = getVolumeValue(value);
                    result.setVolume(mVolume);
                }
            }
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }

        return result;
    }

    private int getVolumeValue(int volume) {
        int value = volume;
        if (value == 0) {
            // なし
            value = 1; // 消音
        } else if (value == 1) {
            // 小
            value = 2;
        } else if (value == 2) {
            // 大
            value = 6; // 消音
        }
        return value;
    }

    private ResultSetVolume setVolumeLocal(int volume) {
        ResultSetVolume result = new ResultSetVolume();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (volume < 1 || volume > 6) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        request.setCommand((byte) 0x22, (byte) 0x0);
        request.setReturnLength(9);

        byte[] data = new byte[16];

        int old_volume = mVolume;
        int result_volume = mVolume;
        if (volume == 0) {
            // 　設定変更しない
            data[0] = (byte) 0x80;
        } else if (volume == 1) {
            // 消音
            data[0] = (byte) 0x00;
            result_volume = 1;
        } else if (volume == 2 || volume == 3 || volume == 4) {
            // 小
            data[0] = (byte) 0x01;
            result_volume = 2;
        } else if (volume == 5 || volume == 6) {
            // 大
            data[0] = (byte) 0x02;
            result_volume = 6;
        } else {
            data[0] = (byte) 0x80;
        }

        data[1] = (byte) 0x07; // コントラスト 初期値 0x07
        data[2] = (byte) 0x01; // バックライト 初期値 0x01

        for (int i = 0; i < 13; i++) {
            data[3 + i] = 0x00;
        }

        request.setData(encrypt(data, mSessionKey2));

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            mVolume = old_volume;
            result.setVolume(mVolume);
            return result;
        }

        result.setEndCode(response.getEndCode());
        result.setEndSubCode(response.getEndSubCode());

        if (response.getBuffer() != null && response.isSuccess()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            mVolume = result_volume;
            result.setVolume(mVolume);
        } else {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            mVolume = old_volume;
            result.setVolume(mVolume);
        }

        return result;
    }

    /**
     * @brief イメージデータを送信します
     * @param[in] area 表示エリアを指定します[整数型]
     * @param[in] number 登録番号を指定します[整数型]
     * @param[in] data イメージデータを16進数文字列に変換して指定します[文字列型]
     * @return 実行結果
     */
    public ResultSetImage setImage(int area, int number, String data) {
        ResultSetImage result = new ResultSetImage();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (area < 1 || area > 3 || data == null) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] img = hex2bin(data);

        if (!isSetImageValidParam(area, number, data)) {
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        request.setCommand((byte) 0x30, (byte) 0x0);
        request.setReturnLength(12);

        int packet_length = 5 + 1 + 2 + img.length;
        int padding_len = 16 - (packet_length % 16);
        int total_length = packet_length + padding_len;

        ByteBuffer buf = ByteBuffer.allocate(total_length);
        buf.clear();

        buf.put((byte) 0x98); // コマンドコード98h(イメージデータ登録)

        byte[] byte_number = CalcUtil.toByteLength((number - 1), false);
        switch (area) {
            case 1:
                // エリアA
                break;
            case 2:
                // エリアC
                byte_number[0] = (byte) ((byte) 0x10 + byte_number[0]);
                break;
            case 3:
                // エリアE
                byte_number[0] = (byte) ((byte) 0x20 + byte_number[0]);
                break;
            default:
                break;

        }
        buf.put(byte_number);

        buf.put(img); // イメージデータ

        byte[] padding = new byte[padding_len];
        Arrays.fill(padding, (byte) 0x00);
        buf.put(padding);
        buf.rewind();

        byte[] packet = new byte[total_length];
        buf.get(packet);

        // mLoggingManager.d(TAG, "check packet");
        // dumpBuffer(packet);
        request.setData(encrypt(packet, mSessionKey2));

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }

        return result;
    }

    /**
     * @brief 音源データを送信します
     * @param[in] number 登録番号を指定します[整数型]
     * @param[in] checksum 音源データのチェックサム値を16進数文字列に変換して指定します[文字列型]
     * @param[in] dataLength データ長を1~65,490で指定します[整数型]
     * @param[in] data 音源データを16進数文字列に変換して指定します[文字列型]
     * @return 実行結果
     */
    public ResultSetSound setSound(int number, String checksum, int dataLength, String data) {
        ResultSetSound result = new ResultSetSound();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!isSetSoundValidParam(number, checksum, dataLength, data)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        request.setCommand((byte) 0x30, (byte) 0x0);
        request.setReturnLength(128);

        byte[] sound = hex2bin(data);

        int sound_length = sound.length;

        int data_max = 7000;
        int packet_length = 0;
        int padding_length = 0;
        int total_length = 0;
        int send_size = 0;

        int total_block_num = sound_length / data_max;
        total_block_num++;
        int now_block = 1;
        int index = 0;

        while (sound_length != 0) {

            if (sound_length > data_max) {
                // 7000byte 送信する
                send_size = data_max;
                packet_length = 1 + 1 + 2 + 1 + 1 + 2 + 2 + data_max;
                padding_length = 16 - (packet_length % 16);
                total_length = packet_length + padding_length;
            } else {
                send_size = sound_length;
                packet_length = 1 + 1 + 2 + 1 + 1 + 2 + 2 + send_size;
                padding_length = 16 - (packet_length % 16);
                total_length = packet_length + padding_length;
            }
            // mLoggingManager.d(TAG, " packet_length  = " + packet_length);
            // mLoggingManager.d(TAG, " padding_length = " + padding_length);
            // mLoggingManager.d(TAG, " total_length   = " + total_length);

            ByteBuffer buf = ByteBuffer.allocate(total_length);
            buf.clear();

            buf.put((byte) 0xEA); // コマンドコードEAh(音源登録)
            buf.put((byte) (number - 1)); // 音源番号

            // チェックサム
            if (now_block == 1) {
                byte[] check_sum = hex2bin(checksum);
                buf.put(check_sum[0]);
                buf.put(check_sum[1]);
            } else {
                buf.put((byte) 0x00);
                buf.put((byte) 0x00);
            }
            buf.put((byte) total_block_num); // 全ブロック数
            buf.put((byte) now_block); // 本ブロック数
            buf.put(request.calcLength2(dataLength)); // 音源データサイズ
            buf.put(request.calcLength2(send_size)); // 分割音源データサイズ

            // 音源データ
            for (int i = 0; i < send_size; i++) {
                buf.put(sound[index++]);
            }

            byte[] padding = new byte[padding_length];
            Arrays.fill(padding, (byte) 0x00);
            buf.put(padding);
            buf.rewind();

            byte[] packet = new byte[total_length];
            buf.get(packet);

            // mLoggingManager.d(TAG, "check packet");
            // dumpBuffer(packet);
            request.setData(encrypt(packet, mSessionKey2));

            request.setTimeout(10000);
            ResponseEmcrw response = sendEmcrw(request);

            if (response == null) {
                result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                break;
            }

            if (response.getBuffer() == null) {
                result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
                result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                break;
            } else {
                result.setEndCode(response.getEndCode());
                result.setEndSubCode(response.getEndSubCode());
                if (response.isSuccess()) {
                    result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                    result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
                } else {
                    result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
                    result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                    break;
                }
            }

            now_block++;
            sound_length -= send_size;
        }

        return result;
    }

    /**
     * @brief キャリアをOFFし、非接触ICカードリーダライタのFeliCaアプリを終了するコマンドを送信します
     * @return 実行結果
     */
    public ResultSendFeliCaAplOff sendFeliCaAplOff() {
        ResultSendFeliCaAplOff result = new ResultSendFeliCaAplOff();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        request.setCommand((byte) 0x30, (byte) 0x0);
        request.setReturnLength(12);
        request.setData(generateFelicaAplOffPacketPayload());

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {
            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        }

        return result;
    }

    /**
     * @brief 非接触ICカードリーダライタ利用可否情報を取得します
     * @return 実行結果
     */
    public ResultCheckHealth checkHealth() {
        ResultCheckHealth result = new ResultCheckHealth();

        if (!isEnableDevice() || !mIsCreated) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }
        result.setSts(mStatus);
        result.setTamper(mIsTamper);

        TamperDetectionInfoController.DEVICE device = TamperDetectionInfoController.DEVICE.EMCRW;
        if (TamperDetectionInfoController.hasTamper(device)) {
            result.setTamper(false);
        } else {
            if (!result.isTamper()) {
                TamperDetectionInfoController.saveTamper(device);
            }
        }
        if (!result.isTamper()) {
            SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief 指定のシステムコードを持つ FeliCa カード、または、全ての FeliCa カードをポーリングし、応答を受信します
     * @param[in] systemCode サーチするシステムコード
     * @param[in] timeslot 同時に検出する枚数
     * @param[in] timeout 受信タイムアウト時間(1～1970, 10ms単位)
     * @return 実行結果
     */
    public ResultPolling polling(String systemCode, int timeslot, int timeout) {
        ResultPolling result = new ResultPolling();

        if (!isEnableDevice()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (systemCode == null || systemCode.length() != 4 || timeout < 1 || timeout > 65535) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        request.setCommand((byte) 0x30, (byte) 0x0);
        request.setReturnLength(300);
        request.setData(generateSetCarrierOnPacketPayload());

        // set data
        int data_len = 1 + 2 + 2 + 1;
        int padding_len = request.getPaddingLength(data_len); // パディングサイズ
        int total_len = data_len + padding_len; // パケットサイズ + パディングサイズ

        byte[] data = new byte[total_len];
        data[0] = (byte) 0x60; // コマンドコード 60H カード検出コマンド

        byte[] timeout_byte = CalcUtil.toByteLength(timeout, false);
        data[1] = timeout_byte[0];
        data[2] = timeout_byte[1];

        byte[] system_code_byte = CalcUtil.toByte(systemCode);
        data[3] = system_code_byte[0];
        data[4] = system_code_byte[1];

        byte slot = (byte) 0x00;
        if (timeslot == 1) {
            slot = (byte) 0x00;
        } else if (timeslot == 2) {
            slot = (byte) 0x01;
        } else if (timeslot == 4) {
            slot = (byte) 0x03;
        } else if (timeslot == 8) {
            slot = (byte) 0x07;
        } else if (timeslot == 16) {
            slot = (byte) 0x0f;
        } else {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }
        data[5] = slot;

        int index = 6;
        // padding
        byte[] padding = new byte[padding_len];
        for (int i = 0; i < padding.length; i++, index++) {
            data[index] = padding[i];
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        // mLoggingManager.d(TAG, "dump");
        // dumpBuffer(data);

        // set data
        byte[] setdata = encrypt(data, mSessionKey2);
        request.setData(setdata);

        // timeoutは10ms単位で指定されるので10倍に設定する
        request.setTimeout(timeout * 10);
        ResponseEmcrw response = sendEmcrw(request);

        if (response == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
        } else if (response.getBuffer() == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_FAILURE);
            result.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
        } else {

            result.setEndCode(response.getEndCode());
            result.setEndSubCode(response.getEndSubCode());
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

            if (response.isSuccess() && response.getData().length >= 20) {
                byte[] res = response.getData();
                int num = res[3];
                byte[] id = new byte[8 * num];
                byte[] pm = new byte[8 * num];
                int pos = 4;
                int start = 0;
                for (int i = 0; i < num; i++) {
                    System.arraycopy(res, pos, id, start, 8);
                    System.arraycopy(res, pos + 8, pm, start, 8);
                    pos += 16;
                    start += 8;
                }
                result.setNum(num);
                result.setIdm(CalcUtil.byte2hex(id));
                result.setPmm(CalcUtil.byte2hex(pm));
            } else {
                result.setNum(0);
                result.setIdm("");
                result.setPmm("");
            }
        }

        return result;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {

        ResultGetPackageInfo result = new ResultGetPackageInfo();

        result.setName(jsName, pluginName, "Emcrw");
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);

        return result;
    }

    /**
     * @brief 非接触ICカードリーダライタの製品品番、シリアル番号、ハード構成情報、APL Version、PF Versionを取得します
     * @return 実行結果
     */
    public ResultGetVersionInfo getVersionInfo() {

        ResultGetVersionInfo result = new ResultGetVersionInfo();

        if (!isEnableDevice() || !mIsCreated) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!mActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        result.setModel(mModel);
        result.setSno(mSno);
        result.setHdinfo(null);
        result.setAplver(mAplver);
        result.setPfver(mPfver);

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);

        return result;
    }

    /**
     * @brief EMCRWを終了します
     * @return 実行結果
     */
    public ResultTermEmcrw termEmcrw() {
        mActive = false;
        ResultTermEmcrw result = new ResultTermEmcrw();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        mIsSucceededLastInit = false;
        if (getRwState() == RW_STATE_USE_EMCRW) {
            // RW切替を実行して他コンポーネントが使用できる状態へ遷移(復帰値は評価しない)
            sendChangeRw();
            setRwState(RW_STATE_USE_NONE);
        }
        return result;
    }

    /**
     * @brief 非接触ICカードリーダーのアプリ情報を返す(Launcher用)
     */
    public ResultAplVersion getAplDataList() {
        ResultAplVersion ret = new ResultAplVersion();

        ArrayList<String> mAPLVersionList = null;
        mAPLVersionList = new ArrayList<String>();

        if (mAPDataList != null && !mAPDataList.isEmpty()) {

            for (EmcrwApplicationData data : mAPDataList.values()) {
                mAPLVersionList.add(data.getVersion());
            }
        }
        ret.setAplVersion(mAPLVersionList);
        return ret;
    }

    /** private api */

    private void create() {

        // リーダライタの準備ができるまで待つ
        try {
            int sleep_time = 1000;
            mLoggingManager.d(TAG, "prepare sleep " + sleep_time);
            Thread.sleep(sleep_time);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // 運用相互認証
        if (sendOperationAuthentication()) {

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            getRWInitialData();
            // 情報を取得してからフラグを立てる
            mIsAuthenticated = true;

        } else {

            // 運用相互認証に失敗した場合は自動登録する
            int retry = 3;
            boolean auth = false;

            while (retry > 0) {
                ResultRegistEmcrw result = registEmcrw(null);
                if (result.getDevice() == 0 && result.getUpos() == 0) {
                    // 運用相互認証
                    if (sendOperationAuthentication()) {
                        auth = true;
                        break;
                    }
                }
                retry--;
            }

            if (auth) {
                getRWInitialData();
                // 情報を取得してからフラグを立てる
                mIsAuthenticated = true;
            }
        }

        if (mIsAuthenticated) {
            if (mPrepareLatch != null) {
                mPrepareLatch.countDown();
            }
        }

        mIsCreated = true;
    }

    // RWの初期情報を取得する
    private void getRWInitialData() {

        boolean isSuccess = false;
        int max = 10;

        // RW状態取得
        for (int i = 0; i < max; i++) {
            mLoggingManager.d(TAG, "getRWInitialData try = " + i);
            isSuccess = getRWStatus();
            if (isSuccess) {
                break;
            }
            wait(1000);
        }

        // RW状態取得できなかった場合リセットする
        if (isSuccess == false) {
            mLoggingManager.d(TAG, "ERROR getRWStatus fail so send reset");
            sendReset();
            return;
        }

        // RW製造番号取得
        if (!getRWInfo()) {
            return;
        }
        // IPL PFのバージョン取得
        if (!getPfInfo()) {
            return;
        }
        // PF 詳細情報(アプリケーションバージョン取得)
        if (!getPfDetailInfo()) {
            return;
        }
    }

    private String getTerminalSerialNumber() {
        String terminalNumber = null;
        PdsClientManager mPdsClientManager = new PdsClientManager();
        terminalNumber = mPdsClientManager
                .getTerminalStatus(PdsClientManager.KEY_PRODUCT_ID);
        return terminalNumber;
    }

    public boolean getPfDetailInfo() {
        boolean ret = false;
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        byte mc = (byte) 0x25;
        byte sc = (byte) 0x04;
        request.setCommand(mc, sc);
        request.setReturnLength(713);// MAX SIZE = 1 + 5 + 704 + 3

        ResponseEmcrw response = sendEmcrw(request);
        if (response != null) {

            if (response.getMC() == mc) {
                byte[] buffer0 = response.getData();
                byte[] buffer = decrypt(buffer0, mSessionKey2);

                mLoggingManager.d(TAG, "Detail");
                dumpBuffer(buffer);

                byte[] info = new byte[22];
                int index = 0;

                mAPDataList = new EmcrwApplicationDataMap();

                for (int i = 0; (i + info.length) < response.getLength();) {

                    System.arraycopy(buffer, index, info, 0, info.length);

                    // アプリケーションのIDを取得する
                    byte[] id = new byte[1];
                    System.arraycopy(info, 1, id, 0, id.length);
                    String id_str = CalcUtil.byte2hex(id);

                    // アプリケーションのバージョンを取得する
                    byte[] version = new byte[16];
                    System.arraycopy(info, 6, version, 0, version.length);
                    String ver = CalcUtil.toAscii(version);

                    // システムアプリ以外のバージョンを記憶
                    if (info[1] != 0) {
                        EmcrwApplicationData data = new EmcrwApplicationData();
                        data.setID(id_str);
                        data.setVersion(ver);
                        mAPDataList.add(data);
                    }
                    // フェリカスルーアプリのIDを記憶
                    if (info[1] == EmcrwDefine.FELICA_APID) {
                        mAplver = ver;
                        ret = true;
                    }
                    index += info.length;
                    i += info.length;
                }

            }
        }
        // debug
        // setTestData();

        if (mAPDataList != null && !mAPDataList.isEmpty()) {
            for (EmcrwApplicationData data : mAPDataList.values()) {
                mLoggingManager.d(TAG, "APL :" + data.getID() + ", " + data.getVersion() + ", "
                        + data.getFileName());
            }
        }

        return ret;
    }

    // アプリバージョン最大値テスト
    private void setTestData() {
        /* デバッグ用 */
        if (mAPDataList != null && mAPDataList.size() < 31) {
            int size = 31 - mAPDataList.size();
            for (int i = 0; i <= size; i++) {
                EmcrwApplicationData data = new EmcrwApplicationData();
                byte num = (byte) (50 + i);
                String id = CalcUtil.byte2hex(num);
                data.setID(id);
                String ver = "DummyVersion==" + i;
                data.setVersion(ver);
                mAPDataList.add(data);
            }
        }
    }

    private boolean getPfInfo() {
        boolean ret = false;
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        byte mc = (byte) 0x25;
        byte sc = (byte) 0x00;
        request.setCommand(mc, sc);
        request.setReturnLength(63);

        ResponseEmcrw response = sendEmcrw(request);
        if (response != null) {

            if (response.getMC() == mc) {
                byte[] buffer0 = response.getData();

                byte[] buffer = decrypt(buffer0, mSessionKey2);

                byte[] ipl = new byte[16];
                System.arraycopy(buffer, 0, ipl, 0, ipl.length);
                String ipl_str = CalcUtil.toAscii(ipl);

                byte[] pf = new byte[16];
                System.arraycopy(buffer, 16, pf, 0, pf.length);
                String pf_str = CalcUtil.toAscii(pf);

                byte[] pfmodel = new byte[2];
                System.arraycopy(buffer, 32, pfmodel, 0, pfmodel.length);
                String pfmodel_str = CalcUtil.toAscii(pfmodel);

                mPfver = pf_str;

                mLoggingManager.d(TAG, "IPL Version = " + ipl_str);
                mLoggingManager.d(TAG, "PF  Version = " + pf_str);
                mLoggingManager.d(TAG, "PF  MODEL   = " + pfmodel_str);
                ret = true;
            }
        }
        return ret;
    }

    private boolean getRWInfo() {
        boolean ret = false;
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        byte mc = (byte) 0x28;
        byte sc = (byte) 0x80;
        request.setCommand(mc, sc);
        request.setReturnLength(53);

        ResponseEmcrw response = sendEmcrw(request);
        if (response != null) {
            if (response.getMC() == mc) {
                byte[] buffer = response.getData();
                if (buffer != null && buffer.length > 22) {

                    byte[] product = new byte[12];
                    System.arraycopy(buffer, 0, product, 0, product.length);
                    mModel = CalcUtil.toAscii(product);

                    byte[] serial = new byte[10];
                    System.arraycopy(buffer, 12, serial, 0, serial.length);
                    mSno = CalcUtil.toAscii(serial);
                    ret = true;
                }
            }
        }
        return ret;
    }

    private boolean getRWStatus() {

        if (!isEnableDevice()) {
            return false;
        }

        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);
        byte mc = (byte) 0x00;
        byte sc = (byte) 0x00;
        request.setCommand(mc, sc);
        request.setReturnLength(41);
        request.setData(generateRwInformationPacketPayload());

        ResponseEmcrw response = sendEmcrw(request);

        if (response == null || response.getBuffer() == null) {
            return false;
        } else {
            if (response.getMC() == mc) {
                if (response.getData().length == 32) {
                    byte[] buffer0 = response.getData();
                    byte[] buffer = decrypt(buffer0, mSessionKey2);
                    byte status = buffer[0];
                    byte tamper = (byte) (status & (byte) 0x02);
                    byte regist = (byte) (status & (byte) 0x04);

                    if (tamper == (byte) 0x02) {
                        mIsTamper = false;
                    }
                    if (regist == (byte) 0x04) {
                        mIsRegisted = true;
                    }

                    byte volume = buffer[2];
                    mVolume = getVolumeValue(volume);
                    mLoggingManager.d(TAG, "EMCRW Volume = " + mVolume);

                    return true;
                }
            }
        }
        return false;
    }

    /**
     * JIS X 0201、JIS X 0208 で定義されない文字を黒豆腐にする
     */
    protected String replaceBlackTofu(String text) {
        CharsetEncoder sjisEncoder = Shift_JIS.newEncoder();

        for (int i = 0; i < text.length(); i = text.offsetByCodePoints(i, 1)) {

            int codePoint = text.codePointAt(i);
            if (Character.isSupplementaryCodePoint(codePoint)) {
                // サロゲートペア(複数のcharで1文字を表現)
                // JIS第3水準、JIS第4水準で構成されるため変換
                text = text.replace(new String(Character.toChars(codePoint)), "■");
                continue;
            }

            char c = text.charAt(i);

            if (!sjisEncoder.canEncode(c)) {
                // Shift_JIS に定義のない文字
                text = text.replace(c, '■');
                continue;
            }

            byte[] wordbyte = Character.toString(c).getBytes(Shift_JIS);

            if (wordbyte.length == 1) {
                // 1byte文字
                // JIS X 0201
                continue;
            }

            // 2byte文字
            // JIS X 0208
            int code = CalcUtil.toInt(wordbyte[1], wordbyte[0]);

            if (code > 0xEAA4) {
                // 第 1 水準, 第 2 水準漢字の領域外
                text = text.replace(c, '■');
            }

            if ((code & 0xFF00) == 0x8700) {
                // JIS X 0208 に定義されない非漢字
                // ①〜⑳、Ⅰ〜Ⅹ など
                text = text.replace(c, '■');
            }

        }

        return text;
    }

    private byte[] getString(String text) {

        byte[] str;

        // Shift-JIS に無い文字や第3,第4水準漢字を黒豆腐変換
        text = replaceBlackTofu(text);

        if (mCharset == CHARSET_UTF8) {
            if (!text.equals(new String(text.getBytes(Shift_JIS), Shift_JIS))) {
                str = new String(text.getBytes(UTF_8), Shift_JIS).getBytes();
            } else {
                str = text.getBytes(Shift_JIS);
            }
        } else {
            str = text.getBytes(Shift_JIS);
        }
        return str;
    }

    private boolean sendUnregister() {
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        mLoggingManager.d(TAG, "sendUnregister");
        // set packet
        request.setCommand((byte) 0x06, (byte) 0x01);
        request.setReturnLength(9);

        ResponseEmcrw response = sendEmcrw(request);

        if (response != null) {
            return true;
        } else {
            return true;
        }
    }

    private boolean sendReset() {
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        mLoggingManager.d(TAG, "sendReset");
        // set packet
        request.setCommand((byte) 0x20, (byte) 0x00);
        request.setReturnLength(9);

        ResponseEmcrw response = sendEmcrw(request);
        if (response != null) {
            return true;
        } else {
            return false;
        }
    }

    private boolean sendDefaultAuthentication() {

        mLoggingManager.d(TAG, "DefaultAuthentication");

        // デフォルト相互認証
        RequestEmcrwData requestDefaultAuthentication = new RequestEmcrwData(mLinkLevel);

        byte[] sessionKey = encrypt(mBaseSessionKey, mMasterKey); // セッションキーをマスターキーで暗号化
        byte[] defaultRWRegNum = generateDefaultMutalCertificatePayload(); // デフォルト相互認証用コマンドペイロードの生成

        // craete data
        ByteBuffer buf = ByteBuffer.allocate(34);
        buf.clear();
        buf.put(mMasterKeyNumbers);
        buf.put(sessionKey);
        buf.put(defaultRWRegNum);

        buf.rewind();
        byte[] data = new byte[34];
        buf.get(data);

        // set packet
        requestDefaultAuthentication.setCommand((byte) 0x04, (byte) 0x0);
        requestDefaultAuthentication.setData(data);
        requestDefaultAuthentication.setReturnLength(25);

        mLoggingManager.d(TAG, "send default authentication");
        ResponseEmcrw res = sendEmcrw(requestDefaultAuthentication);

        if (res == null) {
            return false;
        }

        byte[] defaultRegisterReturnPacket = res.getData();

        createSessionKey(defaultRegisterReturnPacket, mBaseSessionKey, mSessionKey);

        // RW番号登録
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        // craete data
        ByteBuffer buf2 = ByteBuffer.allocate(16);
        buf2.clear();
        buf2.put(generateRegisterRWPayload());
        buf2.rewind();
        byte[] data2 = new byte[16];
        buf2.get(data2);

        // set packet
        request.setCommand((byte) 0x06, (byte) 0x00);
        request.setData(data2);
        request.setReturnLength(9);

        mLoggingManager.d(TAG, "send RW regist");
        ResponseEmcrw res2 = sendEmcrw(request);

        if (res2 == null) {
            return false;
        }

        return true;
    }

    private boolean sendOperationAuthentication() {
        // 相互認証
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        byte[] sessionKey = encrypt(mBaseSessionKey2, mMasterKey2); // セッションキーをマスターキーで暗号化
        byte[] rwRegNum = generateMutalCertificatePayload(); // 相互認証コマンドペイロードの生成

        // craete data
        ByteBuffer buf = ByteBuffer.allocate(34);
        buf.clear();
        buf.put(mMasterKeyNumbers2);
        buf.put(sessionKey);
        buf.put(rwRegNum);
        buf.rewind();
        byte[] data = new byte[34];
        buf.get(data);

        mLoggingManager.d(TAG, "send    operation auth before encrypt");
        dumpBuffer(data);

        // set packet
        request.setCommand((byte) 0x04, (byte) 0x01);
        request.setData(data);
        request.setReturnLength(25);

        mLoggingManager.d(TAG, "send    operation auth");

        ResponseEmcrw res = sendEmcrw(request);
        if (res != null) {
            if (res.getMC() == (byte) 0x04 && res.getSC() == (byte) 0x01) {
                if (res.getData() != null) {
                    byte[] buffer = res.getData();
                    createSessionKey(buffer, mBaseSessionKey, mSessionKey);
                    createSessionKey(buffer, mBaseSessionKey2, mSessionKey2);
                    return true;
                }
            }
        }
        return false;
    }

    // RW登録コマンド送信用
    private byte[] generateRegisterRWPayload() {
        ByteBuffer buf = ByteBuffer.allocate(PAYLOAD_LENGTH);
        buf.clear();
        buf.put(mRandA);
        buf.put(mRWRegNum);
        buf.rewind();
        byte[] payload = new byte[PAYLOAD_LENGTH];
        buf.get(payload);

        mLoggingManager.d(TAG, "RW登録コマンドペイロード（暗号化前）");
        // mLoggingManager.d(TAG, dumpBytes(payload));

        return encrypt(payload, mSessionKey);
    }

    // 相互認証コマンドペイロードの生成
    private byte[] generateMutalCertificatePayload() {
        ByteBuffer buf = ByteBuffer.allocate(PAYLOAD_LENGTH);
        buf.clear();
        buf.put(mRandA); // 乱数A
        buf.put(mRWRegNum); // デフォルトRW登録番号

        buf.rewind();
        byte[] payload = new byte[PAYLOAD_LENGTH];
        buf.get(payload); // ペイロードをbyte配列で取得

        // mLoggingManager.d(TAG, "RW登録番号");
        // mLoggingManager.d(TAG, dumpBytes(mRWRegNum));
        // mLoggingManager.d(TAG, "相互認証コマンドペイロード");
        // mLoggingManager.d(TAG, dumpBytes(payload));

        return encrypt(payload, mBaseSessionKey2); // 相互認証用元セッションキーで暗号化して返す
    }

    private ResponseEmcrw sendChangeAp(byte aplID) {
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        // set packet
        request.setCommand((byte) 0x24, (byte) 0x02);
        request.setReturnLength(9);

        request.setData(generateChangeMode2ApPacketPayload(aplID));

        mLoggingManager.d(TAG, " send ChangeAp");

        ResponseEmcrw res = sendEmcrw(request);

        return res;
    }

    private ResponseEmcrw sendChangeRw() {
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        // set packet
        request.setCommand((byte) 0x24, (byte) 0x80);
        request.setReturnLength(9);

        mLoggingManager.d(TAG, " send ChangeRw");

        ResponseEmcrw res = sendEmcrw(request);

        return res;
    }

    private byte[] generateChangeMode2ApPacketPayload(byte id) {
        ByteBuffer buf = ByteBuffer.allocate(16);
        buf.clear();
        buf.put(id);

        byte[] reserved = new byte[] {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00,
        };
        buf.put(reserved);

        byte[] packet = new byte[16];
        buf.rewind();
        buf.get(packet);

        return encrypt(packet, mSessionKey2);
    }

    private byte[] readApData(String target) {
        AssetManager manager = mContext.getResources().getAssets();
        InputStream is;

        try {
            is = manager.open(target);
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            while (true) {
                int len = is.read(buffer);
                if (len < 0) {
                    break;
                }
                bout.write(buffer, 0, len);
            }
            return bout.toByteArray();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // キャリアONにするためのパケットの暗号化ペイロード部分を生成する
    private byte[] generateSetCarrierOnPacketPayload() {
        ByteBuffer buf = ByteBuffer.allocate(16);
        buf.clear();

        buf.put((byte) 0xE4); // コマンドコードE4h(キャリアON)
        byte[] padding = new byte[15];
        Arrays.fill(padding, (byte) 0x00);
        buf.put(padding);
        buf.rewind();

        byte[] packet = new byte[16];
        buf.get(packet);

        // mLoggingManager.d(TAG, "キャリアONパケットペイロード（暗号化前）");
        // mLoggingManager.d(TAG, dumpBytes(packet));

        // return packet;
        return encrypt(packet, mSessionKey2);
    }

    // キャリアONにするためのパケットの暗号化ペイロード部分を生成する
    private byte[] generateSetCarrierOffPacketPayload() {
        ByteBuffer buf = ByteBuffer.allocate(16);
        buf.clear();

        buf.put((byte) 0xE2); // コマンドコードE4h(キャリアON)
        byte[] padding = new byte[15];
        Arrays.fill(padding, (byte) 0x00);
        buf.put(padding);
        buf.rewind();

        byte[] packet = new byte[16];
        buf.get(packet);

        // mLoggingManager.d(TAG, "キャリアOFFパケットペイロード（暗号化前）");

        // return packet;
        return encrypt(packet, mSessionKey2);
    }

    // FeliCaアプリオフにするためのパケットの暗号化ペイロード部分を生成する
    private byte[] generateFelicaAplOffPacketPayload() {
        ByteBuffer buf = ByteBuffer.allocate(16);
        buf.clear();

        buf.put((byte) 0xEC); // コマンドコードE4h(キャリアON)
        byte[] padding = new byte[15];
        Arrays.fill(padding, (byte) 0x00);
        buf.put(padding);
        buf.rewind();

        byte[] packet = new byte[16];
        buf.get(packet);

        // mLoggingManager.d(TAG, "キャリアOFFパケットペイロード（暗号化前）");

        // return packet;
        return encrypt(packet, mSessionKey2);
    }

    private byte[] generateRwInformationPacketPayload() {
        RequestEmcrwData request = new RequestEmcrwData(mLinkLevel);

        ByteBuffer buf = ByteBuffer.allocate(16);
        SimpleDateFormat dateStr = new SimpleDateFormat("yyMMddHHmmss");
        String tmpDate = dateStr.format(new Date());
        mLoggingManager.d(TAG, tmpDate);
        long date = Long.parseLong(tmpDate);
        byte[] dateBytesBCD = request.long2bcd(date);
        buf.put(dateBytesBCD);

        byte[] reserved = new byte[] {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
        };
        buf.put(reserved);

        byte[] ret = new byte[16];
        buf.rewind();
        buf.get(ret);

        return encrypt(ret, mSessionKey2);
    }

    private void wait(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private String tagTime = "";
    private long start = 0;
    private long end = 0;

    private void startTime(String tag) {
        if (EnableTimeLog) {
            tagTime = tag;
            start = System.currentTimeMillis();
            // mLoggingManager.d(TAG, (start % 1000000) + " START(" + tagTime +
            // ")");
            mLoggingManager.d(TAG, " START(" + tagTime + ")");
        }
    }

    private void endTime() {
        if (EnableTimeLog) {
            end = System.currentTimeMillis();
            // mLoggingManager.d(TAG, (end % 1000000) + " END  (" + tagTime +
            // "): time = " +
            // (end - start));
            mLoggingManager.d(TAG, " END  (" + tagTime + "): time = " + (end - start));
        }
    }

    /**
     * @brief リーダライタと通信を行う
     * @param[in] request コマンド
     * @return 実行結果
     * @retval ResponseEmcrw : 通信失敗:null, データ不正:mBufferがnull, 成功:
     */

    synchronized ResponseEmcrw sendEmcrw(RequestEmcrwData request) {
        ResponseEmcrw response = new ResponseEmcrw(mLinkLevel);
        byte[] buffer = null;

        if (request == null) {
            return null;
        }

        if (EnableDebugLog) {
            mLoggingManager.d(TAG, "sendEmcrw");
            dumpBuffer(request.toPacket());
        }
        if (mLinkLevel == EmcrwDefine.LINK_LEVEL_CCT) {
            buffer = sendCCT(request);

        } else if (mLinkLevel == EmcrwDefine.LINK_LEVEL_PINPAD) {
            buffer = sendPINPAD(request, 5000);
        }

        if (EnableDebugLog) {
            mLoggingManager.d(TAG, "recvEmcrw");
            dumpBuffer(buffer);
        }

        if (buffer == null || buffer.length == 0 || buffer[0] == 0x00) {
            // 通信に失敗した場合はSTSをfalseにする
            mStatus = false;
            return null;
        }
        // 通信に成功した場合はSTSをtrueにする
        mStatus = true;

        if (response.inputResponse(buffer)) {
            response.dumpBuffer();
        } else {
            return response;
        }

        return response;
    }

    private byte[] sendCCT(RequestEmcrwData request) {

        int mergin = 6000;

        startTime("W [D]");
        mControlDeviceManager.write(request, WRITE_TIME_OUT);
        endTime();

        byte[] returnPacket = new byte[request.getReturnLength()];
        startTime("R [D]");

        // mLoggingManager.d(TAG, " timeout = " + request.getTimeout() +
        // " ,  count = " + request.getCount());

        if (request.getCount() <= 1) {

            // countが1回のときは 6000msマージンを待つ
            if (request.getTimeout() < (65535 - mergin)) {
                returnPacket = mControlDeviceManager.read(returnPacket, request.getTimeout()
                        + mergin);
            } else {
                returnPacket = mControlDeviceManager.read(returnPacket, request.getTimeout());
                if (returnPacket != null && returnPacket.length != 0 && returnPacket[0] == 0x00) {
                    returnPacket = mControlDeviceManager.read(returnPacket, mergin);
                }
            }
        } else {

            // countが1回より多いときは 6000msマージンを待つ
            for (int i = 0; i < request.getCount(); i++) {
                returnPacket = mControlDeviceManager.read(returnPacket, request.getTimeout());
                if (returnPacket != null && returnPacket.length != 0 && returnPacket[0] != 0x00) {
                    break;
                }
            }
            if (returnPacket != null && returnPacket.length != 0 && returnPacket[0] == 0x00) {
                returnPacket = mControlDeviceManager.read(returnPacket, mergin);
            }

        }

        endTime();

        return returnPacket;
    }

    private byte[] sendPINPAD(RequestEmcrwData request, int sleep_time) {

        // startTime("1");
        // wait(sleep_time);
        // endTime();

        // RequestSETUP up = new RequestSETUP();
        // byte[] r = mControlDeviceManager.write(up, 2000);
        // wait(sleep_time);

        // mControlDeviceManager.setStart(true);

        startTime("W [D]");
        boolean retb = mControlDeviceManager.write(request, 2000);
        endTime();

        // wait(sleep_time);
        wait(1);

        // ACK待ち
        byte[] ackPacket = new byte[1];
        startTime("R [A]");
        byte[] ret = mControlDeviceManager.read(ackPacket, 5000);
        endTime();
        // mLoggingManager.d(TAG, "ACK" + ret[0]);

        // wait(sleep_time);
        wait(1);

        byte[] eotPacket = new byte[] {
                0x04
        };

        RequestEOT requestEOT = new RequestEOT();

        startTime("W [E]");
        retb = mControlDeviceManager.write(requestEOT, 500);
        endTime();

        // wait(sleep_time);
        wait(1);

        // for (int j = 0; j < 0; j++) {
        // byte[] bb = new byte[j];
        // bb = mControlDeviceManager.read(bb, 5000);
        // for (int i = 0; i < j; i++)
        // mLoggingManager.d(TAG, "b[" + i + "]=" + bb[i]);
        // }

        mLoggingManager.e(TAG, "return size = " + request.getReturnLength());
        byte[] returnPacket = new byte[request.getReturnLength()];
        // mLoggingManager.e(TAG, "  return length = " +
        // request.getResutnLength());
        startTime("R [D]");
        returnPacket = mControlDeviceManager.read(returnPacket, 5000);
        endTime();

        if (returnPacket.length == 0) {
            wait(100);
            startTime("55");
            returnPacket = mControlDeviceManager.read(returnPacket, 5000);
            endTime();
        }

        // mLoggingManager.d(TAG, "returnpacket");

        // ackを返却する
        RequestACK requestACK = new RequestACK();
        startTime("W [A]");
        retb = mControlDeviceManager.write(requestACK, 500);
        endTime();

        // EOTの受信
        byte[] receiveEOTPacket = new byte[1];
        startTime("R [E]");
        ret = mControlDeviceManager.read(receiveEOTPacket, 500);
        endTime();

        // mLoggingManager.d(TAG, "ReceiveEOT " + ret[0]);

        return returnPacket;
    }

    public Context getContext() {
        return mContext;
    }

    public void setContext(Context mContext) {
        this.mContext = mContext;
    }

    /**
     * @brief NonContactIcCardプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerNonContactIcCardServiceListener(String tag, IEmcrwServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIEmcrwServiceListenerList) {
            mIEmcrwServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief ContactIcCardプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterNonContactIcCardServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIEmcrwServiceListenerList) {
            mIEmcrwServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    // authentication
    // 元マスターキー１を生成する
    private ByteBuffer generateFirstSeed() {
        ByteBuffer buf = ByteBuffer.allocate(SEED_LENGTH);
        buf.clear();
        int firstSeed = (int) (Math.random() * 100) % 10;
        byte[] seed = MASTER_KEY_SEEDS[firstSeed];
        buf.put(seed);
        byte[] nullbyte = {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
        };
        buf.put(nullbyte);
        buf.rewind();

        mMasterKeyNumbers[0] = (byte) firstSeed;

        return buf;
    }

    // 元マスターキー２を生成する
    private ByteBuffer generateSecondSeed() {
        ByteBuffer buf = ByteBuffer.allocate(SEED_LENGTH);
        buf.clear();
        int secondSeed = (int) (Math.random() * 100) % 10;
        byte[] seed = MASTER_KEY_SEEDS[secondSeed];
        byte[] nullbyte = {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
        };
        buf.put(nullbyte);
        buf.put(seed);
        buf.rewind();

        mMasterKeyNumbers[1] = (byte) secondSeed;

        return buf;
    }

    // 元マスターキーからマスターキーを生成する
    private void generateMasterKey() {
        ByteBuffer firstSeedBuffer = ByteBuffer.allocate(SEED_LENGTH);
        ByteBuffer secondSeedBuffer = ByteBuffer.allocate(SEED_LENGTH);

        byte[] firstSeed = new byte[SEED_LENGTH];
        byte[] secondSeed = new byte[SEED_LENGTH];
        byte[] masterKey = new byte[KEY_LENGTH];

        firstSeedBuffer.clear();
        secondSeedBuffer.clear();

        firstSeedBuffer.put(generateFirstSeed());
        secondSeedBuffer.put(generateSecondSeed());

        firstSeedBuffer.rewind();
        secondSeedBuffer.rewind();
        firstSeedBuffer.get(firstSeed);
        secondSeedBuffer.get(secondSeed);

        for (int i = 0; i < SEED_LENGTH; i++) {
            masterKey[i] = (byte) (firstSeed[i] ^ secondSeed[i]);
        }

        // マスターキー保存
        mMasterKey = masterKey;

        return;
    }

    // 相互認証用マスターキーを生成する
    private void generateMasterKey2() {
        ByteBuffer firstSeedBuffer = ByteBuffer.allocate(SEED_LENGTH);
        ByteBuffer secondSeedBuffer = ByteBuffer.allocate(SEED_LENGTH);

        byte[] firstSeed = new byte[SEED_LENGTH];
        byte[] secondSeed = new byte[SEED_LENGTH];
        byte[] masterKey = new byte[KEY_LENGTH];

        firstSeedBuffer.clear();
        secondSeedBuffer.clear();

        firstSeedBuffer.put(generateFirstSeed2());
        secondSeedBuffer.put(generateSecondSeed2());

        firstSeedBuffer.rewind();
        secondSeedBuffer.rewind();
        firstSeedBuffer.get(firstSeed);
        secondSeedBuffer.get(secondSeed);

        for (int i = 0; i < SEED_LENGTH; i++) {
            masterKey[i] = (byte) (firstSeed[i] ^ secondSeed[i]);
        }

        // マスターキー保存
        mMasterKey2 = masterKey;

        return;
    }

    // 相互認証用元マスターキー１を生成する
    private ByteBuffer generateFirstSeed2() {
        ByteBuffer buf = ByteBuffer.allocate(SEED_LENGTH);
        buf.clear();
        // int firstSeed = (int) (Math.random() * 100) % 10;
        int firstSeed = 7;
        byte[] seed = MASTER_KEY_SEEDS[firstSeed];
        buf.put(seed);
        byte[] nullbyte = {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
        };
        buf.put(nullbyte);
        buf.rewind();

        mMasterKeyNumbers2[0] = (byte) firstSeed;

        return buf;
    }

    // 相互認証用元マスターキー２を生成する
    private ByteBuffer generateSecondSeed2() {
        ByteBuffer buf = ByteBuffer.allocate(SEED_LENGTH);
        buf.clear();
        // int secondSeed = (int) (Math.random() * 100) % 10;
        int secondSeed = 9;
        byte[] seed = MASTER_KEY_SEEDS[secondSeed];
        byte[] nullbyte = {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
        };
        buf.put(nullbyte);
        buf.put(seed);
        buf.rewind();

        mMasterKeyNumbers2[1] = (byte) secondSeed;

        return buf;
    }

    // 元セッションキーを生成する
    private void generateBaseSessionKey() {

        byte[] sessionKey = new byte[16];
        SecureRandom random = null;
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
            random.nextBytes(sessionKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        mBaseSessionKey = sessionKey;

        return;
    }

    // 元セッションキーを生成する
    private void generateBaseSessionKey2() {

        byte[] sessionKey = new byte[16];
        SecureRandom random = null;
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
            random.nextBytes(sessionKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        mBaseSessionKey2 = sessionKey;

        return;
    }

    public byte[] testEncrypt(byte[] input) {
        return encrypt(input, mSessionKey2);
    }

    public byte[] testDecrypt(byte[] input) {
        return decrypt(input, mSessionKey2);
    }

    // sessionkey
    private byte[] encrypt(byte[] data, byte[] seed) {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKey key = new SecretKeySpec(seed, "AES");

            byte[] ivSeed = new byte[] {
                    (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                    (byte) 0x00, (byte) 0x00,
                    (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                    (byte) 0x00, (byte) 0x00,
            };
            IvParameterSpec iv = new IvParameterSpec(ivSeed);

            cipher.init(Cipher.ENCRYPT_MODE, key, iv);

            // mLoggingManager.d(TAG, "AES 初期ベクトル");
            // mLoggingManager.d(TAG, dumpBytes(cipher.getIV()));

            return cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    // dataをseedをキーにAESで復号化する
    private byte[] decrypt(byte[] target, byte[] seed) {
        if (DevCtlServiceDefine.SERIAL) {
            // エミュレータツールからの応答は暗号化しない
            return target;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKey key = new SecretKeySpec(seed, "AES");
            byte[] ivSeed = new byte[] {
                    (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                    (byte) 0x00, (byte) 0x00,
                    (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                    (byte) 0x00, (byte) 0x00,
            };
            IvParameterSpec iv = new IvParameterSpec(ivSeed);

            cipher.init(Cipher.DECRYPT_MODE, key, iv);

            // mLoggingManager.d(TAG, "AES 初期ベクトル");
            // mLoggingManager.d(TAG, dumpBytes(cipher.getIV()));

            return cipher.doFinal(target);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // 乱数Aを生成する
    private void generateRandA() {

        byte[] randA = new byte[8];
        SecureRandom random = null;
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
            random.nextBytes(randA);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        mRandA = randA;

        return;
    }

    // デフォルト相互認証コマンド用ペイロードの生成
    private byte[] generateDefaultMutalCertificatePayload() {
        ByteBuffer buf = ByteBuffer.allocate(PAYLOAD_LENGTH);
        buf.clear();
        buf.put(mRandA); // 乱数A
        buf.put(mDefaultRWRegNum); // デフォルトRW登録番号

        buf.rewind();
        byte[] payload = new byte[PAYLOAD_LENGTH];
        buf.get(payload); // ペイロードをbyte配列で取得

        return encrypt(payload, mBaseSessionKey); // 元セッションキーで暗号化して返す
    }

    // RW側から受け取ったレスポンスから乱数Bを取り出し、元セッションキーとのXORを取りセッションキーを生成する
    private void createSessionKey(byte[] response, byte[] baseSessionKey, byte[] sessionKey) {

        // デフォルト相互認証でJT-R550CRから受け取ったパケットからデフォルトRW登録番号+乱数Bのペイロードを取り出す
        ByteBuffer buf = ByteBuffer.allocate(PAYLOAD_LENGTH_RW);
        buf.clear();
        buf.put(response);
        buf.rewind();
        byte[] encryptedPayload = new byte[16];
        buf.position(0);
        buf.get(encryptedPayload);

        // ペイロードをdecryptしてデフォルトRW登録番号と乱数Bを取り出す
        byte[] decryptedPayload = decrypt(encryptedPayload, baseSessionKey);

        // 乱数Bを取り出す
        ByteBuffer bufRandB = ByteBuffer.allocate(16);
        bufRandB.clear();
        bufRandB.put(decryptedPayload);
        bufRandB.rewind();
        bufRandB.position(8);
        byte[] randB = new byte[8];
        bufRandB.get(randB);
        mRandB = randB;

        ByteBuffer bufXORRandB = ByteBuffer.allocate(16);
        bufXORRandB.clear();
        bufXORRandB.position(8);
        bufXORRandB.put(mRandB);
        bufXORRandB.rewind();
        byte[] xorRandB = new byte[16];
        bufXORRandB.get(xorRandB);

        // 元セッションキーと乱数BのXOR
        for (int i = 0; i < KEY_LENGTH; i++) {
            sessionKey[i] = (byte) (baseSessionKey[i] ^ xorRandB[i]);
        }

        return;
    }

    /** 共通メソッド */
    public boolean isEnableDevice() {
        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            return false;
        }
        return true;
    }

    public void setCreated(boolean created) {
        mIsCreated = created;
    }

    public boolean isCreated() {
        return mIsCreated;
    }

    public boolean isActive() {
        return mActive;
    }

    public void setActive(boolean active) {
        mActive = active;
    }

    public boolean isActiveEx() {
        return mActiveEx;
    }

    public void setActiveEx(boolean activeEx) {
        mActiveEx = activeEx;
    }

    /** 判定メソッド **/
    public boolean isHmiValidParam(int lcdImage_A, String lcdText_B, int lcdImage_C,
            String lcdText_D, int lcdImage_E, int lcdImage_B, String lcdText_C, int lcdImage_D,
            String lcdText_F, int lcdImage_F) {

        // イメージ登録番号の最小値、最大値
        int lcdImageMin = 0;
        int lcdImageMaxA = 200;
        int lcdImageMaxC = 400;
        int lcdImageMaxE = 200;
        // テキスト登録番号の最小値、最大値
        int lcdTextMin = 0;
        int lcdTextMax = 20;

        // 4桁、5桁共通
        if (lcdImage_A < lcdImageMin || lcdImage_A > lcdImageMaxA) {
            return false;
        }

        if (lcdText_B == null || lcdText_B.length() < lcdTextMin || lcdText_B.length() > lcdTextMax) {
            return false;
        }

        if (lcdImage_C < lcdImageMin || lcdImage_C > lcdImageMaxC) {
            return false;
        }

        if (lcdText_D == null || lcdText_D.length() < lcdTextMin || lcdText_D.length() > lcdTextMax) {
            return false;
        }

        if (lcdImage_E < lcdImageMin || lcdImage_E > lcdImageMaxE) {
            return false;
        }

        // 4桁表示の場合
        if (lcdImage_B != 0) {
            return false;
        }

        if (lcdText_C == null || lcdText_C.length() != 0) {
            return false;
        }

        if (lcdImage_D != 0) {
            return false;
        }

        if (lcdText_F == null || lcdText_F.length() != 0) {
            return false;
        }

        if (lcdImage_F != 0) {
            return false;
        }

        return true;
    }

    public boolean isSetSoundValidParam(int number, String checksum, int dataLength, String data) {
        int numberMax = 32;

        if (number < 1 || number > numberMax) {
            return false;
        }
        if (dataLength < 1 || dataLength > 65490) {
            return false;
        }
        if (checksum == null || (checksum.length() != 4)) {
            return false;
        }
        if (data == null || data.length() == 0 || ((dataLength * 2) != data.length())) {
            return false;
        }
        return true;
    }

    public boolean isSetImageValidParam(int area, int number, String data) {
        int areaA_Max_Number = 200;
        int areaC_Max_Number = 400;
        int areaE_Max_Number = 200;
        int areaA_Size = 440;
        int areaC_Size = 800;
        int areaE_Size = 360;

        if (number < 1) {
            return false;
        }

        if (area == 1) {
            if (data.length() != areaA_Size || number > areaA_Max_Number) {
                return false;
            }
        } else if (area == 2) {
            if (data.length() != areaC_Size || number > areaC_Max_Number) {
                return false;
            }
        } else if (area == 3) {
            if (data.length() != areaE_Size || number > areaE_Max_Number) {
                return false;
            }
        }
        return true;
    }

    /**
     * 処理結果が成功であるか
     * 
     * @return {@code (device == 0 && upos == 0)}
     */
    public static boolean isResultSuccess(ResultData result) {
        return (result.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS && result.getUpos() == PluginDefine.RESULT_UPOS_SCCESS);
    }

    /**
     * APのアップデートを実行する
     * 
     * @param appData アプリのバイナリ
     * @return
     */
    public boolean execUpdateAP(byte[] appData) {
        mLoggingManager.v(TAG, "execUpdateAP");
        boolean ret = false;
        int size = appData.length;
        // アプリダウンロード開始
        ret = startDownloadAP(size);
        if (ret == false) {
            mLoggingManager.v(TAG, "failed startDownloadAP");
            return false;
        }

        wait(1000);

        // アプリデータのダウンロード
        ret = downloadAPData(appData);
        if (ret == false) {
            mLoggingManager.v(TAG, "failed downloadAPData");
            return false;
        }

        wait(2000);

        // アプリダウンロード完了通知
        ret = finishDownloadAP();
        if (ret == false) {
            mLoggingManager.v(TAG, "failed finishDownloadAP");
        }
        return ret;
    }

    /**
     * APダウンロード開始コマンド
     * 
     * @return
     */
    private boolean startDownloadAP(int appSize) {
        EmcrwCommand cmd = EmcrwCommand.START_DOWNLOAD_AP;
        byte[] sendData = new byte[8];
        // 格納する
        // intからbyte配列に変換 これはビッグエンディアン
        byte[] size = new byte[4];
        size = CalcUtil.toByteLength4(appSize, false);

        // 配列をコピー
        // 引数は以下の順番
        // コピー元,コピー元開始位置,コピー先、コピー先開始位置、長さ
        System.arraycopy(size, 0, sendData, 2, 4);

        ResponseEmcrw res = execCommand(cmd, sendData);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return false;
    }

    /**
     * APPデータの最大送信バイト数
     */
    private static final int AP_DATA_MAX_SEND_LENGTH = 8190;

    /**
     * APダウンロードデータコマンド
     * 
     * @return
     */
    private boolean downloadAPData(byte[] appData) {
        return downloadDataCommand(appData, AP_DATA_MAX_SEND_LENGTH, EmcrwCommand.DOWNLOAD_AP_DATA);
    }

    /**
     * AP、PFダウンロードデータコマンドの共通処理
     * 
     * @param data ダウンロードするデータ
     * @param maxLength 分割送信する時の最大サイズ
     * @param cmd
     * @return
     */
    private boolean downloadDataCommand(byte[] data, int maxLength, EmcrwCommand cmd) {
        // APプログラムデータダウンロード時の最大byte数が8190のため、それ以上は
        // 分割が必要
        // カウンタ
        int count = 0;
        // 予定回数
        int loop = data.length / maxLength;
        // 最終dataバイト数
        int rest = data.length % maxLength;
        int hoge = rest > 0 ? 1 : 0;
        mLoggingManager.v(TAG, "分割数" + (loop + hoge));

        // バッファ
        byte[] loopbuf = new byte[maxLength];
        // データが最大サイズより小さいときに使用するバッファ
        byte[] restbuf = new byte[rest];

        ByteBuffer buf = ByteBuffer.wrap(data);
        buf.rewind();

        for (int i = 0; i < loop; i++) {
            buf.get(loopbuf);
            if (downloadDataCommandInner(loopbuf, count, cmd)) {
                count++;
                wait(500);
            } else {
                return false;
            }
        }
        // 残りのパケットの送信
        if (count == loop) {
            if (rest == 0) {
                // 残りのデータが無い場合はそのまま成功を返して終了
                return true;
            }
            buf.get(restbuf);
            return downloadDataCommandInner(restbuf, loop, cmd);
        }
        return false;
    }

    // APダウンロードデータ
    private boolean downloadDataCommandInner(byte[] downloadData, int loop, EmcrwCommand cmd) {
        mLoggingManager.v(TAG, "downloadDataCommandInner");
        // パラメータチェック
        if (!(cmd == EmcrwCommand.DOWNLOAD_AP_DATA || cmd == EmcrwCommand.DOWNLOAD_PF_DATA)) {
            // 対象コマンド以外なら失敗を返す
            mLoggingManager.v(TAG, "unsupported command : " + cmd);
            return false;
        }
        boolean ret = false;
        // 先頭２バイトはレコード番号（ここではloopを入れる）
        int detaLength = 2 + downloadData.length;
        mLoggingManager.v(TAG, "loop回数：" + loop);
        mLoggingManager.v(TAG, "LEN: " + detaLength);
        mLoggingManager.v(TAG, "送信レコード番号");
        // dumpBuffer(CalcUtil.toByteLength(loop, false));

        ByteBuffer buf = ByteBuffer.allocate(detaLength);
        buf.clear();

        buf.put(CalcUtil.toByteLength(loop, false)); // 送信レコード番号
        buf.put(downloadData); // レコードデータ
        buf.rewind();

        // 送信データの入れ物
        byte[] data = new byte[detaLength];

        buf.get(data);// データの読み込み

        ResponseEmcrw res = execCommand(cmd, data);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return ret;
    }

    /**
     * APダウンロード終了
     * 
     * @return
     */
    public boolean finishDownloadAP() {
        boolean ret = false;
        EmcrwCommand cmd = EmcrwCommand.FINISH_DOWNLOAD_AP;
        byte[] data = new byte[0];
        ResponseEmcrw res = execCommand(cmd, data);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                if (res.getData() != null) {
                    int wait_time = CalcUtil.toInt(res.getData()[1], res.getData()[0]);
                    wait(wait_time * 1000);
                }
                return true;
            }
        }
        return ret;
    }

    /**
     * @deprecated
     * @return
     */
    private boolean cancelDownloadApp() {
        boolean ret = false;
        EmcrwCommand cmd = EmcrwCommand.CANCEL_DOWNLOAD_AP;
        byte[] data = new byte[0];
        ResponseEmcrw res = execCommand(cmd, data);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return ret;
    }

    public boolean execUpdatePF(byte[] pfData) {
        mLoggingManager.v(TAG, "execUpdatePF");
        boolean ret = false;
        int size = pfData.length;
        // アプリダウンロード開始
        ret = startDownloadPF(size);
        if (ret == false) {
            mLoggingManager.v(TAG, "failed startDownloadPF");
            return false;
        }

        wait(2000);

        // アプリデータのダウンロード
        ret = downloadPFData(pfData);
        if (ret == false) {
            mLoggingManager.v(TAG, "failed downloadPFData");
            return false;
        }

        wait(2000);

        // アプリダウンロード完了通知
        ret = finishDownloadPF();
        if (ret == false) {
            mLoggingManager.v(TAG, "failed finishDownloadPF");
        }
        return ret;
    }

    /**
     * PFダウンロード開始通知
     * 
     * @return
     */
    public boolean startDownloadPF(int size) {
        EmcrwCommand cmd = EmcrwCommand.START_DOWNLOAD_PF;
        byte[] sendData = new byte[8];
        byte[] sizeByte = CalcUtil.toByteLength4(size, false);
        System.arraycopy(sizeByte, 0, sendData, 0, 4);

        ResponseEmcrw res = execCommand(cmd, sendData);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return false;
    }

    /**
     * PFデータ最大サイズ
     */
    private static final int PF_DATA_MAX_LENGTH = 8190;

    /**
     * PFデータのダウンロード
     * 
     * @return
     */
    public boolean downloadPFData(byte[] pfData) {
        return downloadDataCommand(pfData, PF_DATA_MAX_LENGTH, EmcrwCommand.DOWNLOAD_PF_DATA);

    }

    /**
     * PFダウンロード終了通知
     * 
     * @return
     */
    public boolean finishDownloadPF() {
        EmcrwCommand cmd = EmcrwCommand.FINISH_DOWNLOAD_PF;
        byte[] data = new byte[0];
        ResponseEmcrw res = execCommand(cmd, data);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return false;
    }

    /**
     * PFダウンロードキャンセル通知
     * 
     * @deprecated
     * @return
     */
    public boolean cancelDownloadPf() {
        EmcrwCommand cmd = EmcrwCommand.CANCEL_DOWNLOAD_PF;
        byte[] data = new byte[0];
        ResponseEmcrw res = execCommand(cmd, data);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return false;
    }

    /**
     * APのアンインストール
     * 
     * @param apId アプリID（0x01〜0xFD）これ以外はエラー
     * @return
     */
    public boolean uninstallAP(byte apId) {
        // 通常/強制 2 種のアンインストールコマンドのうち、
        // 強制アンインストールコマンドを使用する
        EmcrwCommand cmd = EmcrwCommand.UNINSTALL_AP_FORCE;
        return uninstallAP(cmd, apId);
    }

    /**
     * アプリアンインストールの共通処理
     * 
     * @param cmd
     * @param apId
     * @return
     */
    private boolean uninstallAP(EmcrwCommand cmd, byte apId) {
        // 0x01 ~ 0xFD以外のIDは無効
        if ((((int) apId & 0xff) < 0x01) ||
                ((int) (apId & 0xFF)) > 0xFD) {
            return false;
        }
        byte[] sendData = new byte[16];
        sendData[0] = apId;
        ResponseEmcrw res = execCommand(cmd, sendData);
        if (res != null) {
            if (cmd.mc == res.getMC()) {
                // TODO:エラーチェック
                return true;
            }
        }
        return false;
    }

    private ResponseEmcrw execCommand(EmcrwCommand cmd, byte[] data) {
        return execCommand(cmd, data, cmd.responseLength);
    }

    /**
     * 任意のコマンドを送信し、レスポンスを受信する
     * 
     * @param cmd 送信コマンド種別
     * @param data 送信するbyte列
     * @param responseSize レスポンスデータのヘッダ部＋データ部のサイズ
     * @return
     */
    private ResponseEmcrw execCommand(EmcrwCommand cmd, byte[] data, int responseSize) {
        ResponseEmcrw ret = null;
        RequestEmcrwData request = new RequestEmcrwData();

        request.setCommand(cmd.mc, cmd.sc);
        request.setReturnLength(responseSize + 4);// ＋４バイト(stx etx
                                                  // crc)返信パケットに付随する４バイトのデータ長を足す
        request.setTimeout(cmd.requestTimeoutMillis + (1 * 1000));// USB通信でのロスを考えてタイムアウトをさらに１秒追加する
        if (cmd.needEncrypt) {
            // 暗号化するデータは１６の倍数のデータ長である必要がある
            // １６の倍数でなければ、１６の倍数になるように後ろに0x00を付与してデータ長を調整する
            int length = data.length;
            int paddingLength = 0;
            if ((length % 16) > 0) {
                paddingLength = 16 - (length % 16);
                byte[] tmp = data;
                data = new byte[paddingLength + length];
                System.arraycopy(tmp, 0, data, 0, length);
            }
            data = encrypt(data, mSessionKey2);
        }
        request.setData(data);
        ret = sendEmcrw(request);
        return ret;
    }

    /**
     * リセットコマンドを送信(アップデートで使用)
     * 
     * @return
     */
    public boolean reset() {
        return sendReset();
    }

    /**
     * 非接触ICカードリーダライタのプラットフォームバージョンを取得
     * 
     * @return 非接触ICカードリーダライタのプラットフォームバージョン
     */
    public EmcrwPlatformData getPFData() {

        if (!isEnableDevice() || !isPrepared() || !mIsCreated) {
            return null;
        }
        if (mPfver == null) {
            return null;
        }
        EmcrwPlatformData ret = new EmcrwPlatformData();
        ret.setVersion(mPfver);
        return ret;
    }

    /**
     * 非接触ICカードリーダライタのアプリケーションバージョンを取得
     * 
     * @return 非接触ICカードリーダライタのアプリケーションバージョン
     */
    public EmcrwApplicationDataMap getAPDataMap() {
        return mAPDataList;
    }

    /**
     * @return 非接触ICカードリーダライタの製品品番
     */
    public String getModel() {
        return mModel;
    }

    /**
     * @return 非接触ICカードリーダライタのシリアル番号
     */
    public String getSno() {
        return mSno;
    }

    /**
     * 非接触ICカードリーダライタ接続時に必要な準備の終了を待つ
     */
    public void createEmcrwJoin() {
        if (mPrepareEmcrwThread != null) {
            try {
                mPrepareEmcrwThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 非接触ICカードリーダライタの使用状態を設定
     * Emcrw Java API と NFC Plug-In API の競合状態を管理する
     */
    public void setRwState(int rwState) {
        mLoggingManager.v(TAG, "setRwState " + mRwState + " -> " + rwState);
        mRwState = rwState;
    }

    /**
     * 非接触ICカードリーダライタの使用状態を取得
     * Emcrw Java API と NFC Plug-In API の競合状態を管理する
     */
    public int getRwState() {
        return mRwState;
    }

    /**
     * 仕様書6.1コマンド/レスポンス概要より
     */
    public enum EmcrwCommand {

        /**
         * APダウンロード開始
         */
        START_DOWNLOAD_AP((byte) 0x01, (byte) 0x80, false, 5, 5 * 1000),

        /**
         * APダウンロードデータ
         */
        DOWNLOAD_AP_DATA((byte) 0x01, (byte) 0x81, false, 5 + (2 + 6), 5 * 1000),

        /**
         * APダウンロード終了
         */
        FINISH_DOWNLOAD_AP((byte) 0x01, (byte) 0x82, false, 5 + (2 + 6), 60 * 1000),

        /**
         * APダウンロードキャンセル
         */
        CANCEL_DOWNLOAD_AP((byte) 0x01, (byte) 0x83, false, 5, 5 * 1000),
        /*
         * 中略
         */
        /* ここからPF保守用コマンド */
        /**
         * IPL、PFのバージョン取得
         */
        GET_IPL_PF_VERSION((byte) 0x25, (byte) 0x00, true, 5 + (16 + 16 + 2 + 14), 5 * 1000),
        /**
         * APのバージョン取得
         */
        GET_AP_VERSION((byte) 0x25, (byte) 0x01, true, 5 + 80, 5 * 1000),
        /**
         * PFの詳細状態取得
         */
        GET_DETAIL_STATE_PF((byte) 0x25, (byte) 0x04, true, 5 + ((22 * 32) + 16), 10 * 1000),

        /**
         * PFダウンロード開始
         */
        START_DOWNLOAD_PF((byte) 0x25, (byte) 0xC0, false, 5, 5 * 1000),

        /**
         * PFダウンロードデータ
         */
        DOWNLOAD_PF_DATA((byte) 0x25, (byte) 0xC1, false, 5 + (2 + 6), 5 * 1000),

        /**
         * PFダウンロード終了
         */
        FINISH_DOWNLOAD_PF((byte) 0x25, (byte) 0xC2, false, 5 + (2 + 6), 60 * 1000),
        /**
         * PFダウンロード中止
         */
        CANCEL_DOWNLOAD_PF((byte) 0x25, (byte) 0xC3, false, 5, 5 * 1000),
        /**
         * APの通常アンインストール
         */
        UNINSTALL_AP_NORMAL((byte) 0x25, (byte) 0x30, true, 5, 5 * 1000),
        /**
         * APの強制アンインストール
         */
        UNINSTALL_AP_FORCE((byte) 0x25, (byte) 0x31, true, 5, 5 * 1000);
        /**
         * @param mc メインコマンドバイト
         * @param sc サブコマンドバイト
         * @param needEncrypt 暗号化の要否
         * @param responseLength レスポンスパケットの最大サイズ
         * @param requestTimeoutMillis タイムアウトミリ秒
         */
        EmcrwCommand(byte mc, byte sc, boolean needEncrypt, int responseLength,
                int requestTimeoutMillis) {
            this.mc = mc;
            this.sc = sc;
            this.needEncrypt = needEncrypt;
            this.responseLength = responseLength;
            this.requestTimeoutMillis = requestTimeoutMillis;
        }

        /**
         * メインコマンド
         */
        public final byte mc;

        /**
         * サブコマンド
         */
        public final byte sc;

        /**
         * データの暗号化要否
         */
        public final boolean needEncrypt;

        /**
         * レスポンスパケットの最大サイズ
         */
        public final int responseLength;

        /**
         * リクエストタイムアウト時間
         */
        public final int requestTimeoutMillis;
    }

    public byte[] getSessionKey() {
        return mSessionKey2;
    }

}
