
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.PrinterDefine;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.ResponsePrinterData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * カット応答
 */
public class ResponseCut extends ResponsePrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x000B;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x8000;

    /** @brief コマンド長 */
    private static final int LENGTH = 16;

    /**
     * @brief コンストラクタ
     */
    public ResponseCut() {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
    }

    /**
     * @see ResponsePrinterData#inputPrinterResult(byte[])
     */
    @Override
    public boolean inputPrinterResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null || buffer.length != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            mLackDataSize = true;
            return false;
        }

        mCommandDetail = CalcUtil.toInt(buffer[PrinterDefine.INDEX_DETAIL_1],
                buffer[PrinterDefine.INDEX_DETAIL_2]);

        if (!isValidValue()) {
            mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.PRT, mCommandDetail, -1,
                    CalcUtil.toInt(buffer[PrinterDefine.INDEX_ID_1],
                            buffer[PrinterDefine.INDEX_ID_2]), null);
            setDevice(mCommandDetail);
            setUpos(PluginDefine.RESULT_DEVICE_SCCESS);
            return false;
        }

        byte status0 = buffer[PrinterDefine.INDEX_PARAMETER];
        byte status1 = buffer[PrinterDefine.INDEX_PARAMETER + 1];
        byte status2 = buffer[PrinterDefine.INDEX_PARAMETER + 2];
        byte status3 = buffer[PrinterDefine.INDEX_PARAMETER + 3];
        mStatus = status3 << 24 | status2 << 16 | status1 << 8 | status0;

        if (!checkStatus()) {
            return false;
        }

        return true;
    }

    /**
     * @see ResponsePrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mCommandDetail != COMMAND_DETAIL) {
            return false;
        }

        return true;
    }

}
