package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * RW情報要求Requestクラス.
 * 
 */
public class RWInformationRequest extends BaseRequest {

    /** @brief ログ用タグ */
    private static final String TAG = RWInformationRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x00;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x00;

    /** @brief 通信日時 . */
    private Calendar mCommDateTime;

    /**
     * 通信日時を設定する.
     * 
     * @param commDateTime 通信日時
     */
    public void setCommDateTime(Calendar commDateTime) {
        mCommDateTime = commDateTime;
    }

    /** Constructor */
    public RWInformationRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // 必須チェック
        if (mCommDateTime == null) {
            Logger.e(TAG, "isValidValue mCommDateTime is null ");
            return false;
        }

        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        // DateFormatはスレッドセーフではないためメソッド内で生成する
        DateFormat dateFormat = new SimpleDateFormat(
                CommandDataConstants.DATE_FORMAT_YYMMDDHHMMSS);
        String dateStr = dateFormat.format(mCommDateTime.getTime());
        byte[] setBytes = ByteUtil.convertBCDData(dateStr);
        return toCommand(setBytes);
    }
}
