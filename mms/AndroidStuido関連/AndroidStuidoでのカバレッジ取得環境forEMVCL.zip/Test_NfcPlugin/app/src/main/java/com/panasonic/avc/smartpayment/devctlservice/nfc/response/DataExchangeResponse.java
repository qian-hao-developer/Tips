package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_EXCHANGE_RESPONSE;

import java.math.BigInteger;

/**
 * Data Exchange レスポンス
 */
public class DataExchangeResponse extends BaseResponse {

    /** @brief MC */
    private byte MAINCOMMAND = (byte) 0x80;
    /** @brief SC */
    private byte SUBCOMMAND = (byte) 0x43;

    /** @brief 送信カウンタ. */
    private byte[] mSendCounter = null;
    /** @brief 継続フラグ. */
    private byte mContinueFlag = 0x00;
    /** @brief 処理結果. */
    private byte[] mResult = null;
    /** @brief Data Exchangeデータ. */
    private byte[] mExchangeData = null;

    /** Constructor */
    public DataExchangeResponse() {
    }

    /**
     * 送信カウンタを返却する.
     *
     * @return 送信カウンタ
     */
    public byte[] getSendCounter() {
        return mSendCounter;
    }

    /**
     * 継続フラグを返却する.
     *
     * @return 継続フラグ
     */
    public byte getContinueFlag() {
        return mContinueFlag;
    }

    /**
     * 処理結果を返却する.
     *
     * @return 処理結果
     */
    public byte[] getResult() {
        return mResult;
    }

    /**
     * Data Exchangeデータを返却する.
     *
     * @return Data Exchangeデータ
     */
    public byte[] getExchangeData() {
        return mExchangeData;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {  //PT_IMPOSSIBLE_BRANCH
            return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return (cutDeviceResult(bytes) != null);  //PT_IMPOSSIBLE_BRANCH
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MAINCOMMAND) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND mismatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND) {
            Logger.e(TAG, "checkResponseData SUBCOMMAND mismatch = "
                    + bytes[SUBCOMMAND_INDEX]);
            return false;
        }

        DATA_EXCHANGE_RESPONSE[] dataConstArray = DATA_EXCHANGE_RESPONSE.values();
        int indexPosition = DATA_INDEX;

        byte[] checkByteArray;
        for (DATA_EXCHANGE_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* 送信カウンタ */
                case SENDCOUNTER:
                    // 格納前チェック不要
                    break;
            /* 継続フラグ */
                case CONTINUEFLAG:
                    // 格納前チェック不要
                    break;
            /* 処理結果 */
                case RESULT:
                    // 格納前チェック不要
                    break;
            /* Data Exchange データ */
                case EXCHANGEDATA:
                    /* データ部のサイズ */
                    int mDataLength = new BigInteger(new byte[]{(byte) 0x00,
                            bytes[DATALENGTHLOW_INDEX], bytes[DATALENGTHHIGH_INDEX]})
                            .intValue();

                    /* DataExchangeデータ(予備含め)のサイズ */
                    int exchangeDataLength = mDataLength
                            - DATA_EXCHANGE_RESPONSE.SENDCOUNTER.getDataLength()
                            - DATA_EXCHANGE_RESPONSE.CONTINUEFLAG.getDataLength()
                            - DATA_EXCHANGE_RESPONSE.RESULT.getDataLength()
                            - DATA_EXCHANGE_RESPONSE.RESERVE.getDataLength();

                    /* DataExchangeデータ(予備含め)のサイズが3未満かチェック */
                    if ( exchangeDataLength < 3 ) {
                        Logger.e(TAG, "checkResponseData " + "DataExchangeデータ(予備含め)"
                                + " mismatch =" + exchangeDataLength);
                        return false;
                    }

                    /* DataExchangeデータ(予備含め)のサイズの配列設定 */
                    checkByteArray = new byte[exchangeDataLength];
                    System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                            exchangeDataLength);
                    int checkData = 0;
                    int signalLength = 0;
                    int totalSignalLength = 0;
                    int chkSignalCnt = 0;
                    int signalCnt = new BigInteger(new byte[] { (byte) 0x00,
                        checkByteArray[0] }).intValue();
                    int signalInfoLength = new BigInteger(new byte[] { (byte) 0x00,
                            checkByteArray[1], checkByteArray[2] }).intValue();

                    /* シグナル情報(予備含め)の有無チェック */
                    if ((checkByteArray.length - 3) < signalInfoLength) {
                        Logger.e(TAG, "checkResponseData " + "シグナル情報(予備含め)"
                                + " mismatch =" + (checkByteArray.length - 3));
                        return false;
                    }

                    do{
                        if (signalCnt == 0 && signalInfoLength == 0) {
                            break;
                        }

                        for(int i=3; i < checkByteArray.length-1; i+=(signalLength+2)){
                            /* シグナルレングス取得 */
                            signalLength = new BigInteger(new byte[] { (byte) 0x00,
                                    checkByteArray[i], checkByteArray[i+1] }).intValue();

                            /* シグナル情報のサイズ取得(シグナルレングス + シグナルデータ) */
                            checkData = signalLength + 2;

                            /* シグナル情報レングス計算 */
                            totalSignalLength += checkData;

                            /* シグナル情報のサイズチェック */
                            if (checkData > 2560) {
                                Logger.e(TAG, "checkResponseData " + "シグナル情報"
                                        + " mismatch =" + checkData);
                                return false;
                            }

                            /* シグナル数計算 */
                            chkSignalCnt++;

                            /* シグナル情報レングスとシグナル情報の合計サイズの一致確認 */
                            if (signalInfoLength == totalSignalLength) {
                                break;
                            }
                        }
                    } while(false);

                    /* シグナル情報レングスチェック */
                    checkData = signalInfoLength;
                    if (checkData != totalSignalLength) {
                        Logger.e(TAG, "checkResponseData " + "シグナル情報レングス"
                                + " mismatch =" + checkData);
                        return false;
                    }

                    /* 予備チェック */
                    checkData = exchangeDataLength // DataExchangeデータ(予備含め)のサイズ
                            - 1 // シグナル数のサイズ
                            - 2 // シグナル情報レングスのサイズ
                            - totalSignalLength; // シグナル情報のサイズ
                    if (checkData > 15) {
                        Logger.e(TAG, "checkResponseData " + "予備"
                                + " mismatch =" + checkData);
                        return false;
                    }

                    /* シグナル数チェック */
                    checkData = new BigInteger(new byte[] { (byte) 0x00,
                            checkByteArray[0] }).intValue();
                    if(checkData != chkSignalCnt){
                        Logger.e(TAG, "checkResponseData " + "シグナル数"
                                + " mismatch =" + checkData);
                        return false;
                    }
                    break;
                default:
                    break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        // データ長は可変の為指定長チェックは行わない（実データ長との比較は親クラスで実施済み）
        // R/W状態フラグ、R/W状態番号、ビットマップデータは格納前チェックは不要

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ格納を行う
        DATA_EXCHANGE_RESPONSE[] dataConstArray = DATA_EXCHANGE_RESPONSE.values();
        int indexPosition = DATA_INDEX;

        // データ部順の配列を順次処理する
        for (DATA_EXCHANGE_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* 送信カウンタ */
                case SENDCOUNTER:
                    mSendCounter = new byte[dataConst.getDataLength()];
                    System.arraycopy(bytes, indexPosition, mSendCounter, 0,
                            dataConst.getDataLength());
                    break;
            /* 継続フラグ */
                case CONTINUEFLAG:
                    mContinueFlag = bytes[indexPosition];
                    break;
            /* 処理結果 */
                case RESULT:
                    mResult = new byte[dataConst.getDataLength()];
                    System.arraycopy(bytes, indexPosition, mResult, 0,
                            dataConst.getDataLength());
                    break;
            /* Data Exchange データ */
                case EXCHANGEDATA:
                    /* シグナル情報レングス */
                    byte[] signalByteArray = new byte[2];

                    System.arraycopy(bytes, indexPosition + 1, signalByteArray, 0, 2);

                    /* シグナル情報のサイズ取得  */
                    int signalInfoLength = new BigInteger(new byte[] { (byte) 0x00,
                            signalByteArray[0], signalByteArray[1] }).intValue();

                    /* Data Exchange データのサイズ取得  */
                    int exchangeDataLength = 1 + 2 + signalInfoLength;

                    /* Data Exchange データ取得  */
                    mExchangeData = new byte[exchangeDataLength];
                    System.arraycopy(bytes, indexPosition, mExchangeData, 0,
                            mExchangeData.length);
                    break;
                default:
                    break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return bytes;
    }
}
