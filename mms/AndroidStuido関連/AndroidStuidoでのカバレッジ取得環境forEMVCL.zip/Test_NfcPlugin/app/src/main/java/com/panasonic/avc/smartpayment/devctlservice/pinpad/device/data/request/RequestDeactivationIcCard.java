
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * カード非活性化要求クラス
 */
public class RequestDeactivationIcCard extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x04;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 0x0008;

    /**
     * @brief コンストラクタ
     */
    public RequestDeactivationIcCard() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] paramater = new byte[LENGTH];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);
        paramater[2] = 0;
        paramater[3] = 0;
        paramater[4] = 0;
        paramater[5] = 0;
        paramater[6] = 0;
        paramater[7] = 0;

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }

}
