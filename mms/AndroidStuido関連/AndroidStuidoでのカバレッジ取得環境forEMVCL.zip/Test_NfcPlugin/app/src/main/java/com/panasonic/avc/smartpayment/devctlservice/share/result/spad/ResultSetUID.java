
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetUID extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetUID(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetUID() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetUID> CREATOR = new Parcelable.Creator<ResultSetUID>() {

        @Override
        public ResultSetUID createFromParcel(Parcel in) {
            return new ResultSetUID(in);
        }

        @Override
        public ResultSetUID[] newArray(int size) {
            return new ResultSetUID[size];
        }
    };
}
