
package com.panasonic.avc.smartpayment.devctlservice.bcr;

/**
 * バーコードリーダ定義
 */
public class BarcodeReaderDefine {

    /** @brief 品番 (OPTICON M-10) */
    public static final String PRODUCT_NO_M_10 = "M-10";

    /** @brief 品番 (OPTICON C-40/41) */
    public static final String PRODUCT_NO_40_C_41 = "C-40/41";

    /** @brief BarcodeReader PID (OPTICON M-10) */
    public static final int PID_M_10 = 0xa002;

    /** @brief BarcodeReader PID (OPTICON C-40/41) */
    public static final int PID_C_40_C_41 = 0x0009;

    /** @brief BarcodeReader VID */
    public static final int VID = 0x065a;

    /** @brief BarcodeReader PID List */
    public static final int[] PID_LIST = new int[] {
            PID_M_10, PID_C_40_C_41,
    };

    /** @brief コマンドのSTX値 */
    public static final byte STX_CODE = 0x02;

    /** @brief コマンドのETX値 */
    public static final byte ETX_CODE = 0x03;

    /** @brief コマンドのEOT値 */
    public static final byte EOT_CODE = 0x04;

    /** @brief コマンドのACK値 */
    public static final byte ACK_CODE = 0x06;

    /** @brief コマンドのNAK値 */
    public static final byte NAK_CODE = 0x15;

    /** @brief コマンドのCR値 */
    public static final byte CR_CODE = 0x0d;

    /** @brief STXサイズ */
    public static final int STX_SIZE = 1;

    /** @brief ETXサイズ */
    public static final int ETX_SIZE = 1;

    /** @brief ACKサイズ */
    public static final int ACK_SIZE = 1;

    /** @brief NAKサイズ */
    public static final int NAK_SIZE = 1;

    /** @brief CRサイズ */
    public static final int CR_SIZE = 1;

    /** @brief ヘッダーサイズ */
    public static final int RESERVED_SIZE = 1;

    /** @brief コード別サフィックスサイズ */
    public static final int INDIVIDUAL_SUFFIX_SIZE = CR_SIZE;

    /** @brief コモンサフィックスサイズ */
    public static final int COMMON_SUFFIX_SIZE = 1;

    /** @brief サフィックスサイズ */
    public static final int SUFFIX_SIZE = INDIVIDUAL_SUFFIX_SIZE + COMMON_SUFFIX_SIZE;

    /** @brief デバイスタイプ - OPTICON M-10 */
    public static final int TYPE_M_10 = 1;

    /** @brief デバイスタイプ - OPTICON C-40/41 */
    public static final int TYPE_C_40_C_41 = 2;

    /** @brief デバイスモデル - 指定なし */
    public static final int MODEL_NOT_SPECIFIED = 0;

    /** @brief デバイスモデル - OPTICON M-10 C-40/41 */
    public static final int MODEL_M_10_C_40_C_41 = 1;

}
