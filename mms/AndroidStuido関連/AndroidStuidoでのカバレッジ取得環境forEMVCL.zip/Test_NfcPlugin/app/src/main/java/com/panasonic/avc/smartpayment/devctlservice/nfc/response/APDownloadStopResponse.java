package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * APダウンロード中止Responseクラス.
 * 
 */
public class APDownloadStopResponse extends BaseDownloadStopResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = APDownloadStopResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x83;

    /** Constructor */
    public APDownloadStopResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}

