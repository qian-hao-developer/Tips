package com.panasonic.avc.smartpayment.devctlservice.nfc;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Hex;
import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.DEINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.INSTALLEDFILEDATE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.RESULTINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.SETTINGINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.TRANSACTIONDATA;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.VERSIONINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.PlatformConfig;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.share.INfcServiceListener;

import android.content.Context;
import android.os.RemoteException;

/**
 *  Nfc Plug-In API公開クラス.
 */
public class NfcPlugin implements NFCCompleteEventHandler {
    private final static String TAG = NfcPlugin.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static NfcPlugin sInstance = new NfcPlugin();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, INfcServiceListener> mINfcServiceListenerList = new ConcurrentHashMap<String, INfcServiceListener>();

    /** Emcrw Java API(競合状態を管理するために使用) */
    private NonContactICCard mNonContactICCard = null;

    private static final int RETRY_TIMEOUT = 60;

    // Interface for Original API layer
    private final NFCInterfaceImpl mNFCInterfaceImpl = NFCInterfaceImpl.getInstance();

    // Depend on Platform setting
    private final PlatformConfig mPlatformConfig = mNFCInterfaceImpl.getPlatformConfig();

    //デバイス音量範囲
    private final int MAX_VOLUME = 2;
    private final int MIN_VOLUME = 0;

    //LCD表示メッセージ設定範囲
    private final int MAX_MESSAGE_STATUS = 255;
    private final int MIN_MESSAGE_STATUS = 0;

    //バージョン情報サイズ
    private final int ID_LEN = 2;
    private final int VER_LEN = 16;

    // 戻り値定義
    /**
     * JavaScriptIF戻り値設定enum
     */
    private enum CallJSReturn {
        /** 処理成功 */
        SUCCESS("00"),
        /** Open状態ではない */
        NOTOPEN("101"),
        /** イリーガルエラー */
        ILLEGAL_ERROR("106"),
        /** 競合エラー */
        CONFLICT_ERROR("109"),
        /** 通信エラー発生 */
        DEVICE_ERROR("111"),
        /** 非同期処理実行中のため、実行できない */
        NOW_ASYNC_RUNNING("113");

        /** 処理結果コード */
        private String resultCode;

        private CallJSReturn(final String resultCode) {
            this.resultCode = resultCode;
        }
    }

    /**
     * JavaScriptIFEventHandlerエラーenum
     */
    private enum EventJSError {
        /** 成功（返却値としては使用しないこと） */
        SUCCESS("00"),
        /** トランザクション成功（返却値としては使用しないこと） */
        SUCCESS_TRANSACTION("1"),
        /** トランザクション成功（返却値としては使用しないこと） */
        SUCCESS_DATA_EXCHANGE("2"),
        /** 決済デバイスの通信エラー（非同期処理のみ） */
        DEVICE_ERROR("111"),
        /** 決済デバイスのEMV処理エラー */
        EMV_ERROR("201"),
        /** 決済デバイスの非EMV処理エラー */
        NOT_EMV_ERROR("301"),
        /** 決済デバイスのシーケンスエラー */
        SEQUENCE_ERROR("302"),
        /** 決済デバイスの致命的エラー */
        DEVICE_FATAL_ERROR("303");

        /** errorコード */
        private final String errorCode;

        private EventJSError(final String errorCode) {
            this.errorCode = errorCode;
        }
    }

    /**  JSONキー名：実行結果. */
    private static final String JSON_KEYNAME_RUN_RESULT = "RunResult";
    /**  JSONキー名：処理結果. */
    private static final String JSON_KEYNAME_RESULT_CODE = "ResultCode";
    /**  JSONキー名：処理結果拡張コード. */
    private static final String JSON_KEYNAME_RESULT_CODE_EXTENDED = "ResultCodeExtended";
    /**  JSONキー名：transaction種別. */
    private static final String JSON_KEYNAME_TRANSACTION_TYPE = "TransactionType";
    /**  JSONキー名：動作モード. */
    private static final String JSON_KEYNAME_FUNCTION_MODE = "FunctionMode";
    /**  JSONキー名：Communication時間. */
    private static final String JSON_KEYNAME_COMMUNICATION_TIME = "CommunicationTime";
    /**  JSONキー名：ブロック通番. */
    private static final String JSON_KEYNAME_BLOCK_NUMBER = "BlockNumber";
    /**  JSONキー名：取引金額. */
    private static final String JSON_KEYNAME_AMOUNT_AUTHORISED = "AmountAuthorised";
    /**  JSONキー名：その他金額. */
    private static final String JSON_KEYNAME_AMOUNT_OTHER = "AmountOther";
    /**  JSONキー名：業務指定ビット. */
    private static final String JSON_KEYNAME_MERCHANT_SPECIFIC_DATA = "MerchantSpecificData";
    /**  JSONキー名：TLVデータ. */
    private static final String JSON_KEYNAME_TLV_DATA = "TLVData";
    /**  JSONキー名：取引処理結果. */
    private static final String JSON_KEYNAME_RESULT_INFO = "ResultInfo";
    /**  JSONキー名：設定情報. */
    private static final String JSON_KEYNAME_SETTINGS = "settings";
    /**  JSONキー名：音量設定値. */
    private static final String JSON_KEYNAME_VOLUME = "volume";
    /**  JSONキー名：LCD表示データ. */
    private static final String JSON_KEYNAME_MESSAGE_STATUS = "messageStatus";
    /**  JSONキー名：DataExchangeデータ. */
    private static final String JSON_KEYNAME_DEINFO = "deinfo";

    // 設定ファイル定義
    /**  ファイル種類（FileDll） */
    private static final int FILETYPE_DLL = 1;
    /**  ファイル種類（EMV設定ファイル） */
    private static final int FILETYPE_EMV = 2;
    /**  ファイル種類（設定削除） */
    private static final int FILETYPE_DELETE = 3;

    /**  トレーニングフラグ:非トレーニング. */
    private static final int TRAINING_FLG_FALSE = 0;
    /**  トレーニングフラグ:トレーニング. */
    private static final int TRAINING_FLG_TRUE = 1;

    /**
     *  ファイル種別
     */
    private enum SetFile {
        /** 選択出来なかった場合用. */
        NOT_TARGET(-1, -1),
        /** カーネル共通ファイル. */
        KERNELCOMMON(FILETYPE_EMV, 0x00),
        /** カーネルＣ１ファイル. */
        KERNELC1(FILETYPE_EMV, 0x01),
        /** カーネルＣ２ファイル. */
        KERNELC2(FILETYPE_EMV, 0x02),
        /** カーネルＣ３ファイル. */
        KERNELC3(FILETYPE_EMV, 0x03),
        /** カーネルＣ４ファイル. */
        KERNELC4(FILETYPE_EMV, 0x04),
        /** カーネルＣ５ファイル. */
        KERNELC5(FILETYPE_EMV, 0x05),
        /** カーネルＣ６ファイル. */
        KERNELC6(FILETYPE_EMV, 0x06),
        /** カーネルＣ７ファイル. */
        KERNELC7(FILETYPE_EMV, 0x07),
        /** ICカードテーブル. */
        IC_CARD(FILETYPE_DLL, 0x21),
        /** CA公開鍵ファイル. */
        CA_KEY(FILETYPE_DLL, 0x22),
        /** Merchantテーブル. */
        MERCHANT(FILETYPE_DLL, 0x23),
        /** 設定削除 */
        DELETE(FILETYPE_DELETE, 0xC0);
        private int fileType;
        private int fileNumber;

        private SetFile(int fileType, int fileNumber) {
            this.fileType = fileType;
            this.fileNumber = fileNumber;
        }

        private static SetFile getFileNumberEnum(int fileNumber) {
            for (SetFile checkEnum : SetFile.values()) {
                if (checkEnum.fileNumber == fileNumber) {
                    return checkEnum;
                }
            }

            // 見つからなかった場合
            return SetFile.NOT_TARGET;
        }
    }

    /** 取引処理成功時のイベントハンドラ名文字列 */
    private static final String EVENTNAME_TRANSACTIONCOMPLETE = "ontransactioncomplete";
    /** 取引処理失敗時のイベントハンドラ名文字列 */
    private static final String EVENTNAME_TRANSACTIONERROR = "ontransactionerror";

    /**
     * Plug-inクラスの必須コンストラクタ
     *
     * イベントハンドラ用にブラウザのWebViewを保持する。
     *
     * @param [in] view イベントハンドラ用WebView
     * @return 無し
     */
    public NfcPlugin() {
        String msg = "Custom constructor was called.";
        Logger.d(TAG, msg);
    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static NfcPlugin getInstance() {
        return sInstance;
    }

    public void setContext(ControlDeviceManager controlDeviceManager, NonContactICCard nonContactICCard) {
        mNonContactICCard = nonContactICCard;
        mPlatformConfig.setContext(controlDeviceManager, nonContactICCard);
    }

    /**
     * @brief NFCプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerNfcServiceListener(String tag, INfcServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mINfcServiceListenerList) {
            mINfcServiceListenerList.put(tag, listener);
        }  // PT_IMPOSSIBLE_BRANCH
    }

    /**
     * @brief NFCプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterNfcServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mINfcServiceListenerList) {
            mINfcServiceListenerList.remove(tag);
        }  // PT_IMPOSSIBLE_BRANCH
    }

    // Nfc Plug-in API
    /**
     *  取引の前処理.<br>
     * <br>
     * @return 実行結果文字列：<br>
     *         - 成功時： - SUCCESS("00")<br>
     *         - イリーガルエラー：ILLEGAL_ERROR("106")<br>
     *         - 競合エラー：CONFLICT_ERROR("109")<br>
     *         - 通信エラー発生：DEVICE_ERROR("111")
     */
    public String OpenDevice() {
        String METHOD_NAME = "OpenDevice";
        StartLog(METHOD_NAME);

        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;
        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        if (mNFCInterfaceImpl == null) {
            Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
            result = CallJSReturn.ILLEGAL_ERROR;
            EndLog(METHOD_NAME, result.name(), result.resultCode);
            return result.resultCode;
        }

        // RWが未接続および未認証な場合は未Openエラーを返す
        if (mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_NOT_AUTH) {
            Logger.d(TAG, METHOD_NAME + "() RW is not active.");
            result = CallJSReturn.NOTOPEN;
            EndLog(METHOD_NAME, result.name(), result.resultCode);
            return result.resultCode;
        }
        // Emcrw Java API がアクティブな場合は競合エラーを返す
        if (mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_EMCRW) {
            Logger.d(TAG, METHOD_NAME + "() Emcrw Java API is active.");
            result = CallJSReturn.CONFLICT_ERROR;
            EndLog(METHOD_NAME, result.name(), result.resultCode);
            return result.resultCode;
        }
        mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NFC);

        ret = mNFCInterfaceImpl.EMVCL_Open();
        // Ignore Open error.

        ret = mNFCInterfaceImpl.EMVCL_Claim(5000, resultCode, resultCodeExtended);

        if (ret != ApiReturnValues.Claim.SUCCESS.getStatus()) {
            Logger.d(TAG, METHOD_NAME + "() EMVCL_Claim ret = " + ret);
            // Open失敗時は未使用状態に戻す
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NONE);
            if (ret == ApiReturnValues.Claim.E_FAILURE.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                // 通信エラー
                result = CallJSReturn.DEVICE_ERROR;
            } else {
                // 通信エラー以外はILLEGAL_ERROR
                result = CallJSReturn.ILLEGAL_ERROR;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
        }

        EndLog(METHOD_NAME, result.name(), result.resultCode);
        return result.resultCode;
    }

    /**
     *  取引の終了処理.<br>
     * <br>
     * @return 実行結果文字列：<br>
     *         - 成功時：SUCCESS("00")<br>
     *         - Open状態ではない：NOTOPEN("101")<br>
     *         - イリーガルエラー：ILLEGAL_ERROR("106")<br>
     *         - 通信エラー発生：DEVICE_ERROR("111")<br>
     *         - 非同期処理実行中：NOW_ASYNC_RUNNING("113")
     */
    public String CloseDevice() {
        String METHOD_NAME = "CloseDevice";
        StartLog(METHOD_NAME);
        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;
        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];
        byte[] cardPresence = new byte[1];

        if (mNFCInterfaceImpl == null) {
            Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
            result = CallJSReturn.ILLEGAL_ERROR;
            EndLog(METHOD_NAME, result.name(), result.resultCode);
            return result.resultCode;
        }

        do {
            // RWが切断されていた場合(未認証状態が未使用状態の場合)は強制的にCloseして
            // EMVCL_Clear, EMVCL_Release を省略する
            if (mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_NOT_AUTH
                    || mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_NONE) {
                mNFCInterfaceImpl.EMVCL_ForceClose();
                break;
            }

            // EMVCL_Clear
            ret = mNFCInterfaceImpl.EMVCL_Clear(cardPresence, resultCode,
                    resultCodeExtended);

            if (ret != ApiReturnValues.Clear.SUCCESS.getStatus()) {
                Logger.d(TAG, METHOD_NAME + "() EMVCL_Clear ret=" + ret);
                if (ret == ApiReturnValues.Clear.E_CLOSED.getStatus()) {
                    // Open状態ではない
                    result = CallJSReturn.NOTOPEN;
                } else if (ret == ApiReturnValues.Clear.E_FAILURE.getStatus()) {
                    // 通信エラー発生
                    result = CallJSReturn.DEVICE_ERROR;
                } else if (ret == ApiReturnValues.Clear.E_BUSY.getStatus()) {
                    // 非同期処理実行中のため、実行できない
                    result = CallJSReturn.NOW_ASYNC_RUNNING;
                } else if (ret == ApiReturnValues.Clear.E_NOTCLAIMED.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                    break;
                } else {
                    // 上記以外はILLEGAL_ERROR
                    result = CallJSReturn.ILLEGAL_ERROR;  // PT_IMPOSSIBLE_INSTRUCTIONS
                }
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                return result.resultCode;
            }

            // EMVCL_Release
            resultCode = new int[1];
            resultCodeExtended = new int[1];
            ret = mNFCInterfaceImpl.EMVCL_Release(resultCode, resultCodeExtended);

            if (ret != ApiReturnValues.Release.SUCCESS.getStatus()) {
                Logger.d(TAG, METHOD_NAME + "() EMVCL_Release ret=" + ret);
                if (ret == ApiReturnValues.Release.E_CLOSED.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                    // Open状態ではない
                    result = CallJSReturn.NOTOPEN;  // PT_IMPOSSIBLE_INSTRUCTIONS
                } else if (ret == ApiReturnValues.Release.E_FAILURE.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                    // 通信エラー発生
                    result = CallJSReturn.DEVICE_ERROR;  // PT_IMPOSSIBLE_INSTRUCTIONS
                } else if (ret == ApiReturnValues.Release.E_BUSY.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                    // 非同期処理実行中のため、実行できない
                    result = CallJSReturn.NOW_ASYNC_RUNNING;  // PT_IMPOSSIBLE_INSTRUCTIONS
                } else {
                    // 上記以外はILLEGAL_ERROR
                    result = CallJSReturn.ILLEGAL_ERROR;
                }
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                return result.resultCode;
            }
        } while (false);

        // EMVCL_Close
        ret = mNFCInterfaceImpl.EMVCL_Close();

        if (ret != ApiReturnValues.Close.SUCCESS.getStatus()
                && ret != ApiReturnValues.Close.E_CLOSED.getStatus()) {
            // 成功以外はILLEGAL_ERROR(IF仕様上なしだが規定値以外が来た場合用)
            result = CallJSReturn.ILLEGAL_ERROR;
        }

        // Close成功時は未使用状態へ戻す
        if (mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_NFC) {
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NONE);
        }

        EndLog(METHOD_NAME, result.name(), result.resultCode);
        return result.resultCode;
    }

    /**
     *  取引データファイル設定.<br>
     * <br>
     * @param fileNumber
     *            設定するファイル番号（数値型）
     * @param fileData
     *            ファイルデータ（String型）
     * @return 実行結果 ※jsonデータ文字列
     */
    public String DoDeviceSettingData(int fileNumber, String fileData) {
        String METHOD_NAME = "DoDeviceSettingData";
        StartLog(METHOD_NAME, String.valueOf(fileNumber), fileData);
        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;

        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        do {
            if (mNFCInterfaceImpl == null) {
                Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // RWが未接続および未認証な場合は未Openエラーを返す
            if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
                Logger.d(TAG, METHOD_NAME + "() RW is not active.");
                result = CallJSReturn.NOTOPEN;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // ファイル番号に相当するファイルがあるかチェック
            SetFile targetFile = SetFile.getFileNumberEnum(fileNumber);

            if (targetFile.fileType == FILETYPE_DELETE) {

                SETTINGINFO settingInfo = new SETTINGINFO();
                VERSIONINFO versioninfo = new VERSIONINFO();
                INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();

                ret = mNFCInterfaceImpl.EMVCL_GetInfo((byte)0x00, settingInfo,
                        versioninfo, installedfiledate,
                        resultCode, resultCodeExtended);

                if (ret != ApiReturnValues.GetInfo.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() EMVCL_GetInfo ret = " + ret);
                    if (ret == ApiReturnValues.GetInfo.E_CLOSED.getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else if (ret == ApiReturnValues.GetInfo.E_FAILURE.getStatus()) {
                        // 通信エラー発生
                        result = CallJSReturn.DEVICE_ERROR;
                    } else if (ret == ApiReturnValues.GetInfo.E_BUSY.getStatus()) {
                        // 非同期処理実行中のため、実行できない
                        result = CallJSReturn.NOW_ASYNC_RUNNING;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                    break;
                }

                // 設定削除
                ret = mNFCInterfaceImpl.EMVCL_ClearSetting(resultCode, resultCodeExtended);
                if (ret != ApiReturnValues.ClearSetting.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() ClearSetting not success =" + ret
                            + ",resultCode = " + resultCode[0]
                            + ",resultCodeExtended = " + resultCodeExtended[0]);
                    if (ret == ApiReturnValues.ClearSetting.E_CLOSED.getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else if (ret == ApiReturnValues.ClearSetting.E_FAILURE.getStatus()) {
                        // 通信エラー発生
                        result = CallJSReturn.DEVICE_ERROR;
                    } else if (ret == ApiReturnValues.ClearSetting.E_BUSY.getStatus()) {
                        // 非同期処理実行中のため、実行できない
                        result = CallJSReturn.NOW_ASYNC_RUNNING;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                }

                ret = mNFCInterfaceImpl.EMVCL_DeviceSetting(settingInfo.VolumeOfSound,
                        100, settingInfo.LCDSettings,
                        resultCode, resultCodeExtended);

                if (ret != ApiReturnValues.DeviceSetting.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() EMVCL_DeviceSetting ret = " + result);
                    if (ret == ApiReturnValues.DeviceSetting.E_CLOSED.getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else if (ret == ApiReturnValues.DeviceSetting.E_FAILURE.getStatus()) {
                        // 通信エラー発生
                        result = CallJSReturn.DEVICE_ERROR;
                    } else if (ret == ApiReturnValues.DeviceSetting.E_BUSY.getStatus()) {
                        // 非同期処理実行中のため、実行できない
                        result = CallJSReturn.NOW_ASYNC_RUNNING;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                }
                break;
            }

            byte[] fileDataByte = ByteUtil.hex2bin(fileData);
            if (fileDataByte == null) {
                Logger.e(TAG, METHOD_NAME + "() fileData illegall");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            if (targetFile.fileType == FILETYPE_DLL && fileDataByte != null) {
                // FileDLL

                ret = mNFCInterfaceImpl.EMVCL_FileDLL((byte) fileNumber,
                        fileDataByte.length, fileDataByte,
                        resultCode, resultCodeExtended);

                if (ret != ApiReturnValues.FileDll.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() FileDLL not success =" + ret
                            + ",resultCode = " + resultCode[0]
                            + ",resultCodeExtended = " + resultCodeExtended[0]);
                    if (ret == ApiReturnValues.FileDll.E_CLOSED.getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else if (ret == ApiReturnValues.FileDll.E_FAILURE.getStatus()) {
                        // 通信エラー発生
                        result = CallJSReturn.DEVICE_ERROR;
                    } else if (ret == ApiReturnValues.FileDll.E_BUSY.getStatus()) {
                        // 非同期処理実行中のため、実行できない
                        result = CallJSReturn.NOW_ASYNC_RUNNING;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                }
            } else if (targetFile.fileType == FILETYPE_EMV && fileDataByte != null) {
                // EMVファイル
                ret = mNFCInterfaceImpl.EMVCL_SetEMV((byte) fileNumber,
                        fileDataByte.length, fileDataByte,
                        resultCode, resultCodeExtended);
                if (ret != ApiReturnValues.SetEMV.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() SetEMV not success =" + ret
                            + ",resultCode = " + resultCode[0]
                            + ",resultCodeExtended = " + resultCodeExtended[0]);
                    if (ret == ApiReturnValues.SetEMV.E_CLOSED.getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else if (ret == ApiReturnValues.SetEMV.E_FAILURE.getStatus()) {
                        // 通信エラー発生
                        result = CallJSReturn.DEVICE_ERROR;
                    } else if (ret == ApiReturnValues.SetEMV.E_BUSY.getStatus()) {
                        // 非同期処理実行中のため、実行できない
                        result = CallJSReturn.NOW_ASYNC_RUNNING;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                }
            } else {
                // 規定ファイル番号以外が設定された
                Logger.e(TAG, METHOD_NAME + "() fileNumber unmatch=" + fileNumber);
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
            }
        } while (false);

        JSONObject jsonObjectMain = createResultJson(result, resultCode, resultCodeExtended);

        EndLog(METHOD_NAME, result.name(), result.resultCode, ":ResultCode",
                String.valueOf(resultCode[0]), ":ResultCodeExtended",
                String.valueOf(resultCodeExtended[0]), ":jsonResult=",
                jsonObjectMain.toString());

        return jsonObjectMain.toString();
    }

    /**
     *  外貨取引データファイル設定.<br>
     * <br>
     * @param fileNumber
     *            設定するファイル番号（数値型）
     * @param fileData
     *            ファイルデータ（String型）
     * @param currencyAbbData
     *            決済する通貨名称（文字列型）
     * @return 実行結果 ※jsonデータ文字列
     */
    public String DoDCCSettingData(int fileNumber, String fileData,
                                   String currencyAbbData) {
        String METHOD_NAME = "DoDCCSettingData";
        StartLog(METHOD_NAME, String.valueOf(fileNumber), fileData, currencyAbbData);
        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;

        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        do {
            // 引数チェック
            byte[] fileDataByte = ByteUtil.hex2bin(fileData);
            if (fileDataByte == null) {
                Logger.e(TAG, METHOD_NAME + "() fileData illegall");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // ファイル番号に相当するファイルがあるかチェック
            SetFile targetFile = SetFile.getFileNumberEnum(fileNumber);

            if (targetFile.fileType != FILETYPE_EMV) {
                // EMV設定ファイルでないファイル番号が指定された
                Logger.d(TAG, METHOD_NAME + "() fileNumber unmatch fileEMV ="
                        + fileNumber);
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // 引数チェック
            byte[] currencyAbbDataByte = currencyAbbData.getBytes();
            if (currencyAbbDataByte == null) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                Logger.e(TAG, METHOD_NAME + "() currencyAbbData illegall");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            if (mNFCInterfaceImpl == null) {
                Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // RWが未接続および未認証な場合は未Openエラーを返す
            if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
                Logger.d(TAG, METHOD_NAME + "() RW is not active.");
                result = CallJSReturn.NOTOPEN;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // EMVCL_SetEMVTemp
            ret = mNFCInterfaceImpl.EMVCL_SetEMVTemp((byte) fileNumber,
                    fileDataByte.length, fileDataByte,
                    resultCode, resultCodeExtended);

            if (ret != ApiReturnValues.SetEMV.SUCCESS.getStatus()) {
                Logger.d(TAG, METHOD_NAME + "() SetEMVTemp not success =" + ret
                        + ",resultCode = " + resultCode[0]
                        + ",resultCodeExtended = " + resultCodeExtended[0]);
                if (ret == ApiReturnValues.SetEMV.E_CLOSED.getStatus()) {
                    // Open状態ではない
                    result = CallJSReturn.NOTOPEN;
                } else if (ret == ApiReturnValues.SetEMV.E_FAILURE.getStatus()) {
                    // 通信エラー発生
                    result = CallJSReturn.DEVICE_ERROR;
                } else if (ret == ApiReturnValues.SetEMV.E_BUSY.getStatus()) {
                    // 非同期処理実行中のため、実行できない
                    result = CallJSReturn.NOW_ASYNC_RUNNING;
                } else {
                    // 上記以外はILLEGAL_ERROR
                    result = CallJSReturn.ILLEGAL_ERROR;
                }
                break;
            }

            // EMVCL_SetCurrencyAbbreviation
            ret = mNFCInterfaceImpl.EMVCL_SetCurrencyAbbreviation(
                    currencyAbbDataByte, resultCode, resultCodeExtended);

            if (ret != ApiReturnValues.SetCurrencyAbbreviation.SUCCESS
                    .getStatus()) {
                Logger.d(TAG, METHOD_NAME
                        + "() SetCurrencyAbbreviation not success =" + ret
                        + ",resultCode = " + resultCode[0]
                        + ",resultCodeExtended = " + resultCodeExtended[0]);
                if (ret == ApiReturnValues.SetCurrencyAbbreviation.E_CLOSED
                        .getStatus()) {
                    // Open状態ではない
                    result = CallJSReturn.NOTOPEN;
                } else if (ret == ApiReturnValues.SetCurrencyAbbreviation.E_FAILURE
                        .getStatus()) {
                    // 通信エラー発生
                    result = CallJSReturn.DEVICE_ERROR;
                } else if (ret == ApiReturnValues.SetCurrencyAbbreviation.E_BUSY
                        .getStatus()) {
                    // 非同期処理実行中のため、実行できない
                    result = CallJSReturn.NOW_ASYNC_RUNNING;
                } else {
                    // 上記以外はILLEGAL_ERROR
                    result = CallJSReturn.ILLEGAL_ERROR;
                }
            }
        } while (false);

        JSONObject jsonObjectMain = createResultJson(result, resultCode, resultCodeExtended);

        EndLog(METHOD_NAME, result.name(), result.resultCode, ":ResultCode",
                String.valueOf(resultCode[0]), ":ResultCodeExtended",
                String.valueOf(resultCodeExtended[0]), ":jsonResult=",
                jsonObjectMain.toString());

        return jsonObjectMain.toString();
    }

    /**
     *  取引オペレーション実施.<br>
     * <br>
     * @param transactionData
     *            取引データ※jsonデータ文字列
     * @param isTraining
     *            トレーニングフラグ
     * @param rsaModulusData
     *            暗号化で使用するモジュラス（RSA-2048bit）（String型）
     * @param rsaExponentData
     *            暗号化で使用するエクスポーネントデータ（String型）
     * @return 実行結果文字列：<br>
     *         - 成功時：SUCCESS("00")<br>
     *         - Open状態ではない：NOTOPEN("101")<br>
     *         - イリーガルエラー：ILLEGAL_ERROR("106")<br>
     *         - 通信エラー発生：DEVICE_ERROR("111")<br>
     *         - 非同期処理実行中：NOW_ASYNC_RUNNING("113")
     */
    public String StartTransaction(String transactionData, int isTraining,
                                   String rsaModulusData, String rsaExponentData) {
        String METHOD_NAME = "StartTransaction";
        StartLog(METHOD_NAME, transactionData, String.valueOf(isTraining),
                rsaModulusData, rsaExponentData);
        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;
        boolean isTraingMode = false;

        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        do {
            // 引数チェック
            if (transactionData == null) {
                Logger.e(TAG, METHOD_NAME + "() transactionData null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            if (isTraining == TRAINING_FLG_FALSE) {
                isTraingMode = false;
            } else if (isTraining == TRAINING_FLG_TRUE) {
                isTraingMode = true;
            } else {
                Logger.e(TAG, METHOD_NAME + "() isTraining illegal");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            if (rsaModulusData == null || (rsaModulusData.length() % 2) == 1) {
                // 0byte文字は良いがNull禁止
                Logger.e(TAG, METHOD_NAME + "() rsaModulusData null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            if (rsaExponentData == null || (rsaExponentData.length() % 2) == 1) {
                // 0byte文字は良いがNull禁止
                Logger.e(TAG, METHOD_NAME + "() rsaExponentData null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            byte[] rsaModulusDataByte = null;
            byte[] rsaExponentDataByte = null;
            if (rsaModulusData.length() == 0 && rsaExponentData.length() != 0
                    || rsaModulusData.length() != 0 && rsaExponentData.length() == 0) {
                // どちらかしか設定されていない
                Logger.e(TAG, METHOD_NAME + "() Modulus or exponent is error");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            } else if (rsaModulusData.length() != 0 && rsaExponentData.length() != 0) {
                // どちらも設定されている
                rsaModulusDataByte = ByteUtil.hex2bin(rsaModulusData);
                if (rsaModulusDataByte == null) {
                    Logger.e(TAG, METHOD_NAME + "() rsaModulusDataByte illegall");
                    result = CallJSReturn.ILLEGAL_ERROR;
                    EndLog(METHOD_NAME, result.name(), result.resultCode);
                    break;
                }

                rsaExponentDataByte = ByteUtil.hex2bin(rsaExponentData);
                if (rsaExponentDataByte == null) {
                    Logger.e(TAG, METHOD_NAME + "() rsaExponentDataByte illegall");
                    result = CallJSReturn.ILLEGAL_ERROR;
                    EndLog(METHOD_NAME, result.name(), result.resultCode);
                    break;
                }
            }

            if (mNFCInterfaceImpl == null) {
                Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // RWが未接続および未認証な場合は未Openエラーを返す
            if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
                Logger.d(TAG, METHOD_NAME + "() RW is not active.");
                result = CallJSReturn.NOTOPEN;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // EMVCL_SetEncryptionKey(RSA２ファイルが両方とも0Byte文字列以外の場合)
            if (rsaModulusData.length() != 0) {
                ret = mNFCInterfaceImpl.EMVCL_SetEncryptionKey(
                        rsaModulusDataByte, rsaExponentDataByte,
                        resultCode, resultCodeExtended);

                if (ret != ApiReturnValues.SetEncryptionKey.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() SetEncryptionKey not success ="
                            + ret + ",resultCode = " + resultCode[0]
                            + ",resultCodeExtended = " + resultCodeExtended[0]);
                    if (ret == ApiReturnValues.SetEncryptionKey.E_CLOSED
                            .getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else if (ret == ApiReturnValues.SetEncryptionKey.E_FAILURE
                            .getStatus()) {
                        // 通信エラー発生
                        result = CallJSReturn.DEVICE_ERROR;
                    } else if (ret == ApiReturnValues.SetEncryptionKey.E_BUSY
                            .getStatus()) {
                        // 非同期処理実行中のため、実行できない
                        result = CallJSReturn.NOW_ASYNC_RUNNING;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                    break;
                }
            }

            // EMVCL_SetCompleteEvent
            TRANSACTIONDATA setTransactionData = null;
            setTransactionData = convertTransactionData(transactionData);
            if (setTransactionData != null) {
                // Event登録を行う
                ret = mNFCInterfaceImpl.EMVCL_SetCompleteEvent(this);

                if (ret != ApiReturnValues.SetCompleteEvent.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME
                            + "() SetCompleteEvent not success =" + ret);
                    if (ret == ApiReturnValues.SetCompleteEvent.E_CLOSED
                            .getStatus()) {
                        // Open状態ではない
                        result = CallJSReturn.NOTOPEN;
                    } else {
                        // 上記以外はILLEGAL_ERROR
                        result = CallJSReturn.ILLEGAL_ERROR;
                    }
                }
            } else {
                // データ変換できなかった場合なのでILLEGAL_ERROR（Logは変換処理内で出力）
                result = CallJSReturn.ILLEGAL_ERROR;
                break;
            }

            // EMVCL_Transaction/EMVCL_TRTransaction:トレーニングフラグから処理切り分け
            if (!isTraingMode) {
                ret = mNFCInterfaceImpl.EMVCL_Transaction(setTransactionData,
                        RETRY_TIMEOUT);
            } else {
                // EMVCL_TRTransaction
                ret = mNFCInterfaceImpl.EMVCL_TRTransaction(setTransactionData);
            }
            if (ret != ApiReturnValues.Transaction.SUCCESS.getStatus()) {
                Logger.d(TAG, METHOD_NAME + "() Transaction not success =" + ret
                        + ",resultCode = " + resultCode[0]
                        + ",resultCodeExtended = " + resultCodeExtended[0]);
                if (ret == ApiReturnValues.Transaction.E_CLOSED.getStatus()) {
                    // Open状態ではない
                    result = CallJSReturn.NOTOPEN;
                } else if (ret == ApiReturnValues.Transaction.E_BUSY
                        .getStatus()) {
                    // 非同期処理実行中のため、実行できない
                    result = CallJSReturn.NOW_ASYNC_RUNNING;
                } else {
                    // 上記以外はILLEGAL_ERROR(111も)
                    result = CallJSReturn.ILLEGAL_ERROR;
                }
            } else {
                resultCode[0] = 0;
                resultCodeExtended[0] = 0;
            }
        } while (false);

        JSONObject jsonObjectMain = createResultJson(result, resultCode, resultCodeExtended);

        EndLog(METHOD_NAME, result.name(), result.resultCode, ":ResultCode",
                String.valueOf(resultCode[0]), ":ResultCodeExtended",
                String.valueOf(resultCodeExtended[0]), ":jsonResult=",
                jsonObjectMain.toString());

        return jsonObjectMain.toString();
    }

    /**
     *  取引オペレーション実施.<br>
     * <br>
     * @param setJsonData
     *            JSONデータ文字列
     * @return 取引データ情報クラス
     */
    private TRANSACTIONDATA convertTransactionData(String setJsonData) {
        String METHOD_NAME = "convertTransactionData";
        TRANSACTIONDATA setData = null;
        try {
            JSONObject transactionJSON = new JSONObject(setJsonData);
            // JSON内データの取得
            String transactionType = transactionJSON
                    .getString(JSON_KEYNAME_TRANSACTION_TYPE);
            String functionMode = transactionJSON
                    .getString(JSON_KEYNAME_FUNCTION_MODE);
            String communicationTime = transactionJSON
                    .getString(JSON_KEYNAME_COMMUNICATION_TIME);
            String blockNumber = transactionJSON
                    .getString(JSON_KEYNAME_BLOCK_NUMBER);
            String amountAuthorised = transactionJSON
                    .getString(JSON_KEYNAME_AMOUNT_AUTHORISED);
            String amountOther = transactionJSON
                    .getString(JSON_KEYNAME_AMOUNT_OTHER);
            String merchantSpecificData = transactionJSON
                    .getString(JSON_KEYNAME_MERCHANT_SPECIFIC_DATA);
            String tlvData = transactionJSON.getString(JSON_KEYNAME_TLV_DATA);

            Logger.d(TAG, METHOD_NAME + "() JSONData "
                    + JSON_KEYNAME_TRANSACTION_TYPE + "=" + transactionType
                    + ":" + JSON_KEYNAME_FUNCTION_MODE + "=" + functionMode
                    + ":" + JSON_KEYNAME_COMMUNICATION_TIME + "="
                    + communicationTime + ":" + JSON_KEYNAME_BLOCK_NUMBER + "="
                    + blockNumber + ":" + JSON_KEYNAME_AMOUNT_AUTHORISED + "="
                    + amountAuthorised + ":" + JSON_KEYNAME_AMOUNT_OTHER + "="
                    + amountOther + ":" + JSON_KEYNAME_MERCHANT_SPECIFIC_DATA
                    + "=" + merchantSpecificData + ":" + JSON_KEYNAME_TLV_DATA
                    + "=" + tlvData);

            // transaction種別:長さチェック（値チェックは不要）
            if (transactionType == null || transactionType.length() != 2) {  // PT_IMPOSSIBLE_BRANCH
                Logger.d(TAG, METHOD_NAME + "() TransactionType is not set");
                return null;
            }

            // 動作モード
            if (!"0010".equals(functionMode) && !"0000".equals(functionMode)) {
                Logger.d(TAG, METHOD_NAME + "() functionMode is unmatch = "
                        + functionMode);
                return null;
            }

            if (!checkLongConvertString(communicationTime) || communicationTime.length() != 12) {
                Logger.d(TAG, METHOD_NAME
                        + "() communicationTime is not number data = "
                        + communicationTime);
                return null;
            }

            // ブロック通番
            if (!"8000".equals(blockNumber) && !"0000".equals(blockNumber)) {
                Logger.d(TAG, METHOD_NAME + "() blockNumber is unmatch = "
                        + blockNumber);
                return null;
            }

            // 取引金額.
            if (!checkLongConvertString(amountAuthorised) || amountAuthorised.length() != 12) {
                Logger.d(TAG, METHOD_NAME
                        + "() amountAuthorised is not number data = "
                        + amountAuthorised);
                return null;
            }

            // その他金額
            if (!checkLongConvertString(amountOther) || amountOther.length() != 12) {
                Logger.d(TAG, METHOD_NAME + "() amountOther is not number data = "
                        + amountOther);
                return null;
            }

            // 業務指定ビット
            if (merchantSpecificData == null
                    || merchantSpecificData.length() != 2) {  // PT_IMPOSSIBLE_BRANCH
                Logger.d(TAG, METHOD_NAME + "() merchantSpecificData is not set");
                return null;
            }

            // TLVデータ
            if (tlvData == null || (tlvData.length() % 2) == 1) {  // PT_IMPOSSIBLE_BRANCH
                Logger.d(TAG, METHOD_NAME + "() tlvData is not set");
                return null;
            }

            // transaction種別:16進数文字列をbyte配列変換
            byte[] setTransactionType = ByteUtil.hex2bin(transactionType);
            if (setTransactionType == null) {
                return null;
            }
            // 動作モード:16進数文字列をbyte配列変換
            int setFunctionMode = Integer.parseInt(functionMode, 16);
            // Communication時間:BCD形式byte[]データに変換
            byte[] setCommunicationTime = ByteUtil
                    .convertBCDData(communicationTime);
            // ブロック通番
            int setBlockNumber = Integer.parseInt(blockNumber, 16);
            // 取引金額:BCD形式byte[]データに変換
            byte[] setAmountAuthorised = ByteUtil
                    .convertBCDData(amountAuthorised);
            // その他金額:BCD形式byte[]データに変換
            byte[] setAmountOther = ByteUtil.convertBCDData(amountOther);
            // 業務指定ビット:
            byte[] setMerchantSpecificData = ByteUtil.hex2bin(merchantSpecificData);
            if (setMerchantSpecificData == null) {
                return null;
            }
            // TLVデータ:
            byte[] setTlvData = ByteUtil.hex2bin(tlvData);
            if (setTlvData == null) {
                setTlvData = new byte[0];
            }

            // 入力値チェック済データのセット
            setData = new TRANSACTIONDATA();
            setData.TransactionType = setTransactionType[0];
            setData.FunctionMode = setFunctionMode;
            setData.CommunicationTime = setCommunicationTime;
            setData.BlockNumber = setBlockNumber;
            setData.AmountAuthorised = setAmountAuthorised;
            setData.AmountOther = setAmountOther;
            setData.MerchantSpecificData = setMerchantSpecificData[0];
            setData.TLVData = setTlvData;
        } catch (JSONException je) {
            // JSON ParseError
            je.printStackTrace();
        }
        return setData;
    }

    /**
     *  取引中断処理.<br>
     * <br>
     * @return 実行結果文字列：<br>
     *         - 成功時：SUCCESS("00")<br>
     *         - Open状態ではない：NOTOPEN("101")<br>
     *         - イリーガルエラー：ILLEGAL_ERROR("106")<br>
     */
    public String CancelTransaction() {
        String METHOD_NAME = "CancelTransaction";
        StartLog(METHOD_NAME);
        CallJSReturn result = CallJSReturn.SUCCESS;

        if (mNFCInterfaceImpl == null) {
            Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
            result = CallJSReturn.ILLEGAL_ERROR;
            EndLog(METHOD_NAME, result.name(), result.resultCode);
            return result.resultCode;
        }

        // RWが未接続および未認証な場合は未Openエラーを返す
        if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
            Logger.d(TAG, METHOD_NAME + "() RW is not active.");
            result = CallJSReturn.NOTOPEN;
            EndLog(METHOD_NAME, result.name(), result.resultCode);
            return result.resultCode;
        }

        int ret = mNFCInterfaceImpl.EMVCL_Cancel();

        if (ret != ApiReturnValues.Cancel.SUCCESS.getStatus()) {
            Logger.d(TAG, METHOD_NAME + "Cancel not success =" + ret);
            if (ret == ApiReturnValues.Cancel.E_CLOSED.getStatus()) {
                // Open状態ではない
                result = CallJSReturn.NOTOPEN;
            } else {
                // 上記以外はILLEGAL_ERROR
                result = CallJSReturn.ILLEGAL_ERROR;
            }
        }

        EndLog(METHOD_NAME, result.name(), result.resultCode);
        return result.resultCode;
    }

    /**
     *  DataExchange処理.<br>
     * <br>
     * @param deinfo Data Exchangeのデータ構成
     * @return 実行結果文字列：<br>
     *         - 成功時：SUCCESS("00")<br>
     *         - イリーガルエラー：ILLEGAL_ERROR("106")<br>
     */
    public String SendDataExchange(String deinfo) {
        String METHOD_NAME = "SendDataExchange";
        StartLog(METHOD_NAME, deinfo);
        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;

        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        resultCode[0] = 0;
        resultCodeExtended[0] = 0;

        do {
            // 引数チェック
            if (deinfo == null) {
                Logger.e(TAG, METHOD_NAME + "() deinfo null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            if (mNFCInterfaceImpl == null) {
                Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
                result = CallJSReturn.ILLEGAL_ERROR;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            // RWが未接続および未認証な場合は未Openエラーを返す
            if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
                Logger.d(TAG, METHOD_NAME + "() RW is not active.");
                result = CallJSReturn.NOTOPEN;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            DEINFO setDeinfo = null;
            setDeinfo = convertDeinfo(deinfo);

            if (setDeinfo != null) {
                ret = mNFCInterfaceImpl.EMVCL_DataExchange(setDeinfo);

                if (ret != ApiReturnValues.DataExchange.SUCCESS.getStatus()) {
                    Logger.d(TAG, METHOD_NAME + "() DataExchange not success =" + ret);
                    result = CallJSReturn.ILLEGAL_ERROR;
                }
            } else {
                // データ変換できなかった場合なのでILLEGAL_ERROR（Logは変換処理内で出力）
                result = CallJSReturn.ILLEGAL_ERROR;
            }
        } while (false);

        JSONObject jsonObjectMain = createResultJson(result, resultCode, resultCodeExtended);

        EndLog(METHOD_NAME, result.name(), result.resultCode, ":ResultCode",
                String.valueOf(resultCode[0]), ":ResultCodeExtended",
                String.valueOf(resultCodeExtended[0]), ":jsonResult=",
                jsonObjectMain.toString());

        return jsonObjectMain.toString();
    }

    /**
     *  非接触EMVリーダ・ライタのステータス状態を取得.<br>
     * <br>
     * @param 無し
     * @return 実行結果
     */
    public String CheckHealth() {
        String METHOD_NAME = "CheckHealth";
        StartLog(METHOD_NAME);

        SETTINGINFO settingInfo = new SETTINGINFO();
        VERSIONINFO versioninfo = new VERSIONINFO();
        INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        // RWが未接続および未認証な場合は未Openエラーを返す
        if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
            Logger.d(TAG, METHOD_NAME + "() RW is not active.");
            EndLog(METHOD_NAME, CallJSReturn.NOTOPEN.name(), CallJSReturn.NOTOPEN.resultCode);
            return setHealth(101, settingInfo);
        }

        int result = mNFCInterfaceImpl.EMVCL_GetInfo((byte) 0x00, settingInfo,
                versioninfo, installedfiledate,
                resultCode, resultCodeExtended);

        if (result != ApiReturnValues.GetInfo.SUCCESS.getStatus()) {
            Logger.d(TAG, "CheckHealth() EMVCL_GetInfo ret = " + result);
            return setHealth(result, settingInfo);
        }

        EndLog(METHOD_NAME, "");
        return setHealth(result, settingInfo);
    }

    // /**
    // * ontransactioncomplete
    // * 取引処理完了結果を通知するイベントハンドラ
    // *
    // * - 業務処理完了結果を通知するイベントハンドラ。
    // * - 「StartTransaction」APIを実行後取引処理が完了した時に、
    // * - 完了結果イベントをJavaScriptへ通知する。通知が可能な実行完了結果は同時に一つまでとなる。
    // * - コール元の応答待ちタイムアウト時間の秒数を経過した場合のタイムアウト時にも呼ばれる。
    // * - 「StartTransaction」を実行後にこのAPIが実行される前に、新たに業務処理のメソッドを実行しないこと。
    // * - 尚CancelTransactionは除く
    // *
    // * @param [in] resultJsonString 実行結果 ※jsonデータ文字列
    // * @return 無し
    // * @note ontransactioncompleteイベントハンドラはJavaScript側で実装すること。
    // */
    private void ontransactioncomplete(String resultJsonString) {
        String METHOD_NAME = "EVENTNAME_ontransactioncomplete";
        StartLog(METHOD_NAME);

        synchronized (mINfcServiceListenerList) {
            for (Map.Entry<String, INfcServiceListener> listener : mINfcServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().ontransactioncomplete(resultJsonString);
                } catch (RemoteException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                    e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
                }
            }
        }  // PT_IMPOSSIBLE_BRANCH
        EndLog(METHOD_NAME, "");
    }

    // /**
    // * ontransactionerror
    // * 取引処理失敗のイベントハンドラ
    // *
    // * - 「StartTransaction」APIを実行後取引処理にてエラーが発生したときに
    // * - 発生イベントをJavaScriptへ通知する。NFC Plug-Inの生成後から消滅までの間に発生する。
    // *
    // * @param [in] errorcode エラーの種類
    // * @param [in] resultCodeExtends 処理結果拡張コード文字列
    // * @return 無し
    // * @note ontransactionerrorイベントハンドラはJavaScript側で実装すること。
    // */
    private void ontransactionerror(int errorcode, String resultCodeExtends) {
        String METHOD_NAME = "EVENTNAME_ontransactionerror";
        StartLog(METHOD_NAME, String.valueOf(errorcode), resultCodeExtends);

        synchronized (mINfcServiceListenerList) {
            for (Map.Entry<String, INfcServiceListener> listener : mINfcServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().ontransactionerror(errorcode, resultCodeExtends);
                } catch (RemoteException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                    e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
                }
            }
        }  // PT_IMPOSSIBLE_BRANCH
        EndLog(METHOD_NAME, "");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void WM_CompleteEvent() {
        String METHOD_NAME = "WM_CompleteEvent";
        StartLog(METHOD_NAME);
        EventJSError errorCode = EventJSError.SUCCESS;

        RESULTINFO resultInfo = new RESULTINFO();
        DEINFO deInfo = new DEINFO();
        int[] resultCode = new int[1];
        int[] resultCodeExtended = {111};
        resultCode[0] = Integer.parseInt(EventJSError.DEVICE_FATAL_ERROR.errorCode);

        do {
            if (mNFCInterfaceImpl == null) {
                Logger.d(TAG, METHOD_NAME + "() mNFCInterfaceImpl null");
                errorCode = EventJSError.DEVICE_FATAL_ERROR;
                break;
            }

            int ret = mNFCInterfaceImpl.EMVCL_GetTransactionResult(resultInfo,
                    deInfo, resultCode, resultCodeExtended);

            Logger.d(TAG, METHOD_NAME + "() GetTransactionResult ret = " + ret);
            if (ret == ApiReturnValues.GetTransactionResult.SUCCESS.getStatus()) {
                // resultCodeの確認を行う
                if (resultCode[0] != 0) {
                    errorCode = getResultCodeEnum(resultCode[0]);
                }
            } else {
                // 上記以外は致命的エラー
                errorCode = EventJSError.DEVICE_FATAL_ERROR;
            }
        } while (false);

        if (errorCode == EventJSError.SUCCESS) {
            // 取引処理成功
            String resultCodeExtendsString = String.format("%08X", resultCodeExtended[0]);
            String setJsonData = convertCompleJSONData(resultInfo, deInfo, resultCodeExtendsString);
            if (setJsonData != null) {  // PT_IMPOSSIBLE_BRANCH
                ontransactioncomplete(setJsonData);
            }
        } else {
            // 取引処理失敗
            int setResultCode = Integer.parseInt(errorCode.errorCode);
            String resultCodeExtendsString = String.format("%08X", resultCodeExtended[0]);
            ontransactionerror(setResultCode, resultCodeExtendsString);
        }
        // RWが切断されていた場合(未認証状態が未使用状態の場合)は強制的にCloseする
        if (mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_NOT_AUTH
                || mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_NONE) {
            if (mNFCInterfaceImpl != null) {
                mNFCInterfaceImpl.EMVCL_ForceClose();
            }
        }

        EndLog(METHOD_NAME, errorCode.name(), errorCode.errorCode);
    }

    /**
     *  取引結果情報格納データクラスから取引結果返却用JSON文字列に変換する.<br>
     * <br>
     * @param resultInfo
     *            取引結果情報格納データクラス
     * @param deInfo
     *            DataExchangeデータクラス
     * @param resultCodeExtendsString
     *            処理結果コード
     * @return 変換JSON文字列
     */
    private String convertCompleJSONData(RESULTINFO resultInfo, DEINFO deInfo, String resultCodeExtendsString) {
        String METHOD_NAME = "convertCompleJSONData";
        JSONObject jsonObjectMain = new JSONObject();
        JSONObject jsonObjectSub = new JSONObject();
        if (resultInfo.isSet) {
            try {
                jsonObjectMain.put(JSON_KEYNAME_RESULT_CODE_EXTENDED,
                        resultCodeExtendsString.toUpperCase());
                Logger.d(JSON_KEYNAME_RESULT_CODE_EXTENDED,
                        jsonObjectMain.getString(JSON_KEYNAME_RESULT_CODE_EXTENDED));
                if (resultInfo.TLVDataExtended2 != null) {
                    jsonObjectSub.put("TLVDataExtended2",
                            (new String(Hex.encodeHex(resultInfo.TLVDataExtended2))).toUpperCase());
                    String TLVDataExtended2Log = jsonObjectSub.getString("TLVDataExtended2");
                    Logger.d("TLVDataExtended2",
                            TLVDataExtended2Log.substring(0,4000));
                    Logger.d("TLVDataExtended2",
                            TLVDataExtended2Log.substring(4000, TLVDataExtended2Log.length()));
                }
                if (resultInfo.TLVDataExtended != null) {
                    jsonObjectSub.put("TLVDataExtended",
                            (new String(Hex.encodeHex(resultInfo.TLVDataExtended))).toUpperCase());
                    String TLVDataExtendedLog = jsonObjectSub.getString("TLVDataExtended");
                    Logger.d("TLVDataExtended",
                            TLVDataExtendedLog.substring(0,4000));
                    Logger.d("TLVDataExtended",
                            TLVDataExtendedLog.substring(4000, TLVDataExtendedLog.length()));
                }
                if (resultInfo.TLVData != null) {
                    jsonObjectSub.put("TLVData",
                            (new String(Hex.encodeHex(resultInfo.TLVData))).toUpperCase());
                    Logger.d("TLVData",
                            jsonObjectSub.getString("TLVData"));
                }
                if (resultInfo.OUTCOMEParameter != null) {
                    jsonObjectSub.put("OUTCOMEParameter",
                            (new String(Hex.encodeHex(resultInfo.OUTCOMEParameter))).toUpperCase());
                    Logger.d("OUTCOMEParameter",
                            jsonObjectSub.getString("OUTCOMEParameter"));
                }
                jsonObjectSub.put("CardBrandIdentifier",
                        (new String(Hex.encodeHex(new byte[] { resultInfo.CardBrandIdentifier }))).toUpperCase());
                Logger.d("CardBrandIdentifier",
                        jsonObjectSub.getString("CardBrandIdentifier"));
                if (resultInfo.MemberNumber != null) {
                    jsonObjectSub.put("MemberNumber",
                            (new String(Hex.encodeHex(resultInfo.MemberNumber))).toUpperCase());
                    Logger.d("MemberNumber",
                            jsonObjectSub.getString("MemberNumber"));
                }
                if (resultInfo.ExpirationDate != null) {
                    jsonObjectSub.put("ExpirationDate",
                            (new String(Hex.encodeHex(resultInfo.ExpirationDate))).toUpperCase());
                    Logger.d("ExpirationDate",
                            jsonObjectSub.getString("ExpirationDate"));
                }
                if (resultInfo.CardHolderName != null) {
                    jsonObjectSub.put("CardHolderName",
                            (new String(Hex.encodeHex(resultInfo.CardHolderName))).toUpperCase());
                    Logger.d("CardHolderName",
                            jsonObjectSub.getString("CardHolderName"));
                }
                jsonObjectSub.put("ApplicationPANSequenceNumber",
                        (new String(Hex.encodeHex(new byte[] { resultInfo.ApplicationPANSequenceNumber }))).toUpperCase());
                Logger.d("ApplicationPANSequenceNumber",
                        jsonObjectSub.getString("ApplicationPANSequenceNumber"));
                if (resultInfo.TransactionResultBit != null) {
                    jsonObjectSub.put("TransactionResultBit",
                            (new String(Hex.encodeHex(resultInfo.TransactionResultBit))).toUpperCase());
                    Logger.d("TransactionResultBit",
                            jsonObjectSub.getString("TransactionResultBit"));
                }
                jsonObjectMain.put(JSON_KEYNAME_RESULT_INFO,
                        jsonObjectSub);
                Logger.d(JSON_KEYNAME_RESULT_INFO,
                        jsonObjectMain.getString(JSON_KEYNAME_RESULT_INFO));
                jsonObjectMain.put(JSON_KEYNAME_RESULT_CODE,
                        EventJSError.SUCCESS_TRANSACTION.errorCode.toUpperCase());
                Logger.d(JSON_KEYNAME_RESULT_CODE,
                        jsonObjectMain.getString(JSON_KEYNAME_RESULT_CODE));
            } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
        } else if (deInfo.isSet) {
            try {
                jsonObjectMain.put(JSON_KEYNAME_RESULT_CODE_EXTENDED,
                        resultCodeExtendsString.toUpperCase());
                Logger.d(JSON_KEYNAME_RESULT_CODE_EXTENDED,
                        jsonObjectMain.getString(JSON_KEYNAME_RESULT_CODE_EXTENDED));
                jsonObjectSub.put("ContinueFlag",
                        (new String(Hex.encodeHex(new byte[] { deInfo.ContinueFlag }))).toUpperCase());
                Logger.d("ContinueFlag",
                        jsonObjectSub.getString("ContinueFlag"));
                if (deInfo.Result != null) {
                    jsonObjectSub.put("Result",
                            (new String(Hex.encodeHex(deInfo.Result))).toUpperCase());
                    Logger.d("Result",
                            jsonObjectSub.getString("Result"));
                }
                if (deInfo.DataExchangeData != null) {
                    jsonObjectSub.put("DataExchangeData",
                            (new String(Hex.encodeHex(deInfo.DataExchangeData))).toUpperCase());
                    Logger.d("DataExchangeData",
                            jsonObjectSub.getString("DataExchangeData"));
                }
                jsonObjectMain.put(JSON_KEYNAME_DEINFO,
                        jsonObjectSub);
                Logger.d(JSON_KEYNAME_DEINFO,
                        jsonObjectMain.getString(JSON_KEYNAME_DEINFO));
                jsonObjectMain.put(JSON_KEYNAME_RESULT_CODE,
                        EventJSError.SUCCESS_DATA_EXCHANGE.errorCode.toUpperCase());
                Logger.d(JSON_KEYNAME_RESULT_CODE,
                        jsonObjectMain.getString(JSON_KEYNAME_RESULT_CODE));
            } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
        }
        return jsonObjectMain.toString();
    }

    /**
     * GetPackageInfo パッケージ情報の取得.<br>
     * <br>
     * 自Plug-inのパッケージ情報を取得する。<br>
     *
     * @return パッケージ情報
     */
    public String GetPackageInfo(String jsName, String jsVer, String pluginName, String pluginVer) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("name", jsName + "," + pluginName + "," + "Nfc");
            jsonObject.put("ver", jsVer + "," + pluginVer + "," + DevCtlServiceDefine.VERSION);
        } catch (JSONException e) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
            return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonObject.toString();
    }

    /**
     *  センタからのオンライン承認結果（承認/拒否/エラー）を通知する.<br>
     * <br>
     * @param hostResult
     *            表示する結果
     * @param showTime
     *            表示する時間
     * @return 実行結果文字列：<br>
     *         - 成功時：SUCCESS("00")<br>
     *         - Open状態ではない：NOTOPEN("101")<br>
     *         - イリーガルエラー：ILLEGAL_ERROR("106")<br>
     *         - 通信エラー発生：DEVICE_ERROR("111")<br>
     *         - 非同期処理実行中：NOW_ASYNC_RUNNING("113")
     */
    public String SetResult(int hostResult, int showTime) {
        String METHOD_NAME = "SetResult";
        StartLog(METHOD_NAME, String.valueOf(hostResult), String.valueOf(showTime));

        CallJSReturn result = CallJSReturn.SUCCESS;
        int ret;
        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        do {
            // 引数チェック
            if (hostResult != 0x00
                    && hostResult != 0x01
                    && hostResult != 0x02) {
                Logger.d(TAG, METHOD_NAME + "()  hostResult mismatch = " + hostResult);
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                result = CallJSReturn.ILLEGAL_ERROR;
                break;
            }

            if (showTime < 0x00 || 0xff < showTime) {
                Logger.d(TAG, METHOD_NAME + "()  showTime mismatch = " + showTime);
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                result = CallJSReturn.ILLEGAL_ERROR;
                break;
            }

            // RWが未接続および未認証な場合は未Openエラーを返す
            if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
                Logger.d(TAG, METHOD_NAME + "() RW is not active.");
                result = CallJSReturn.NOTOPEN;
                EndLog(METHOD_NAME, result.name(), result.resultCode);
                break;
            }

            ret = mNFCInterfaceImpl.EMVCL_SetResult((byte)hostResult, (byte)showTime, resultCode, resultCodeExtended);
            if (ret != ApiReturnValues.SetResult.SUCCESS.getStatus()) {
                Logger.d(TAG, METHOD_NAME + "() EMVCL_SetResult ret = " + ret);

                if (ret == ApiReturnValues.SetResult.E_CLOSED.getStatus()) {
                    // Open状態ではない
                    result = CallJSReturn.NOTOPEN;
                } else if (ret == ApiReturnValues.SetResult.E_FAILURE.getStatus()) {
                    // 通信エラー発生
                    result = CallJSReturn.DEVICE_ERROR;
                } else if (ret == ApiReturnValues.SetResult.E_BUSY.getStatus()) {
                    // 非同期処理実行中のため、実行できない
                    result = CallJSReturn.NOW_ASYNC_RUNNING;
                } else {
                    // 上記以外はILLEGAL_ERROR
                    result = CallJSReturn.ILLEGAL_ERROR;
                }
            }
        } while (false);

        EndLog(METHOD_NAME, result.name(), result.resultCode);
        return result.resultCode;
    }

    /**
     * デバイスの音量を設定をする.
     *
     * @param [in] in_key        設定キー("volume", "messageStatus")
     * @param [in] in_value      音量/LCD表示メッセージ
     * @retval   0: 正常
     * @retval 106: パラメータエラー
     * @retval 111: 設定失敗
     */
    public int SetConfiguration(String in_key, String in_value) {
        Logger.d(TAG, "SetConfiguration was called. in_key = " + in_key
                + ", in_value = " + in_value);
        byte volume = 0;
        byte messageStatus = 0;
        String vol;
        String msgSts;
        int result = 106;
        String ret = GetConfiguration(JSON_KEYNAME_SETTINGS);

        try {
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            if (upos != 0) {
                return upos;
            }

            String conf = jsonObjectMain.getString("conf");
            JSONObject jsonObjectConf = new JSONObject(conf);
            JSONObject jsonObjectSet = jsonObjectConf.getJSONObject(JSON_KEYNAME_SETTINGS);

            vol = jsonObjectSet.getString(JSON_KEYNAME_VOLUME);
            msgSts = jsonObjectSet.getString(JSON_KEYNAME_MESSAGE_STATUS);

            if (in_key.equals(JSON_KEYNAME_VOLUME)) {
                volume = Byte.parseByte(in_value);
                if ((volume < MIN_VOLUME) || (volume > MAX_VOLUME)) {
                    Logger.e(TAG, "SetConfiguration(): volume = " + volume);
                    return result;
                }
                messageStatus = Byte.parseByte(msgSts);
            } else if (in_key.equals(JSON_KEYNAME_MESSAGE_STATUS)) {
                volume = Byte.parseByte(vol);
                int intValue = Integer.parseInt(in_value);
                if ((intValue < MIN_MESSAGE_STATUS) || (intValue > MAX_MESSAGE_STATUS)) {
                    Logger.e(TAG, "SetConfiguration(): messageStatus = " + in_value);
                    return result;
                }
                messageStatus = (byte) intValue;
            } else {
                return result;
            }
        } catch(JSONException e) {
            e.printStackTrace();
            return result;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            // in_valueは数字ではなかった
            return result;
        }

        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        result = mNFCInterfaceImpl.EMVCL_DeviceSetting(volume,
                100, messageStatus,
                resultCode, resultCodeExtended);

        if (result != ApiReturnValues.DeviceSetting.SUCCESS.getStatus()) {
            Logger.d(TAG, "SetConfiguration() EMVCL_DeviceSetting ret = " + result);
            return 111;
        }

        return 0;
    }

    /**
     * デバイスの情報を取得する.
     *
     * @param [in] in_key        設定キー
     * @retval     !null         in_keyに対応する設定値
     * @retval     null          取得失敗
     */
    public String GetConfiguration(String in_key) {
        Logger.d(TAG, "GetConfiguration was called. in_key = " + in_key);

        SETTINGINFO settingInfo = new SETTINGINFO();
        VERSIONINFO versioninfo = new VERSIONINFO();
        INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
        int[] resultCode = new int[1];
        int[] resultCodeExtended = new int[1];

        // RWが未接続および未認証な場合は未Openエラーを返す
        if (mNonContactICCard.getRwState() != NonContactICCard.RW_STATE_USE_NFC) {
            Logger.d(TAG, "GetConfiguration() RW is not active.");
            return createResultJson(101, null).toString();
        }

        if (in_key.equals("version")) {
            int result = mNFCInterfaceImpl.EMVCL_Release(resultCode, resultCodeExtended);

            if (result != ApiReturnValues.Release.SUCCESS.getStatus()) {
                if (result == ApiReturnValues.Release.E_CLOSED.getStatus()) {
                    return createResultJson(101, null).toString();
                } else if (result == ApiReturnValues.Release.E_FAILURE.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                    return createResultJson(111, null).toString();  // PT_IMPOSSIBLE_INSTRUCTIONS
                } else {
                    return createResultJson(106, null).toString();
                }
            }

            result = mNFCInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo,
                    installedfiledate, resultCode, resultCodeExtended);

            if (result != ApiReturnValues.GetInfo.SUCCESS.getStatus()) {
                Logger.d(TAG, "GetConfiguration() EMVCL_GetRWVerInfo ret = " + result);
                return createResultJson(111, null).toString();
            }

            result = mNFCInterfaceImpl.EMVCL_Claim(5000, resultCode, resultCodeExtended);

            if (result != ApiReturnValues.Claim.SUCCESS.getStatus()) {
                if (result == ApiReturnValues.Claim.E_FAILURE.getStatus()) {  // PT_IMPOSSIBLE_BRANCH
                    return createResultJson(111, null).toString();
                } else {
                    return createResultJson(106, null).toString();  // PT_IMPOSSIBLE_INSTRUCTIONS
                }
            }

            String deviceVersion = setVersion(settingInfo);
            return createResultJson(0, deviceVersion).toString();
        } else if (in_key.equals("dll") || in_key.equals("kernel") || in_key.equals("settings")) {
            int result = mNFCInterfaceImpl.EMVCL_GetInfo((byte)0x00, settingInfo,
                    versioninfo, installedfiledate,
                    resultCode, resultCodeExtended);

            if (result != ApiReturnValues.GetInfo.SUCCESS.getStatus()) {
                Logger.d(TAG, "GetConfiguration() EMVCL_GetInfo ret = " + result);
                return createResultJson(111, null).toString();
            }

            if (in_key.equals("dll") ){
                String dllData = setDll(installedfiledate);
                return createResultJson(0, dllData).toString();
            } else if (in_key.equals("kernel")) {
                String kernelData = setKernel(installedfiledate, versioninfo);
                return createResultJson(0, kernelData).toString();
            } else if (in_key.equals("settings")) {
                String settings = setSettings(settingInfo);
                return createResultJson(0, settings).toString();
            }
        }
        return createResultJson(106, null).toString();
    }

    // Nfc Plug-in API end

    /*
     * (non-Javadoc) ブラウザへ返す引数作成
     * 
     * @param func コールバック関数名
     * 
     * @param param コールバック関数に渡す引数配列
     */
    private String concatinateCallbackArg(String func, String[] param) {
        String arg = "javascript:";
        arg = arg.concat(func + "(");

        if (param != null) {
            int i;
            for (i = 0; i < param.length - 1; i++) {
                arg = arg.concat(param[i] + ",");
            }
            arg = arg.concat(param[i]);
        }
        arg = arg.concat(")");
        return arg;
    }

    /**
     * 引数のResultCodeに対応するResultCode用Enumを返却する.<br>
     * <br>
     *
     * @param checkResultCode
     *            指定ResultCode
     * @return 対応するResultCodeEnum
     */
    private EventJSError getResultCodeEnum(int checkResultCode) {
        EventJSError resultEnum = EventJSError.DEVICE_FATAL_ERROR;

        for (EventJSError checkEnum : EventJSError.values()) {
            if (Integer.parseInt(checkEnum.errorCode) == checkResultCode) {
                resultEnum = checkEnum;
                break;
            }
        }

        return resultEnum;
    }

    /**
     * 指定文字列がLong変換出来るかチェックする.<br>
     * <br>
     *
     * @param targetData
     *            変換対象文字列
     * @return Long変換できる場合はtrue
     */
    private static boolean checkLongConvertString(String targetData) {
        if (targetData == null) {
            return false;
        }
        try {
            Long.parseLong(targetData);
        } catch (NumberFormatException ne) {
            ne.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     *  開始ログ.<br>
     * <br>
     * @param methodName
     *            メソッド名文字列
     * @param paramArray
     *            ログ出力文字配列
     */
    private void StartLog(String methodName, String... paramArray) {
        if (paramArray == null || paramArray.length == 0) {
            Logger.d(TAG, methodName + "() Call");
        } else {
            StringBuilder stBuilder = new StringBuilder();
            for (int i = 0; i < paramArray.length; i++) {
                if (i == 0) {
                    stBuilder.append(paramArray[i]);
                } else {
                    stBuilder.append(", ").append(paramArray[i]);
                }
            }
            Logger.d(TAG, methodName + "(" + stBuilder.toString() + ") Call");
        }
    }

    /**
     *  終了ログ.<br>
     * <br>
     * @param methodName
     *            メソッド名文字列
     * @param returnName
     *            返却値
     * @param messageArray
     *            ログ出力文字配列
     */
    private void EndLog(String methodName, String returnName,
                        String... messageArray) {
        StringBuilder messageBuilder = new StringBuilder();
        messageBuilder.append(methodName).append("() End =[")
                .append(returnName).append("]:");
        for (String message : messageArray) {
            messageBuilder.append(message).append(" ");
        }
        Logger.d(TAG, messageBuilder.toString());
    }

    private JSONObject createResultJson(CallJSReturn result, int[] resultCode, int[] resultCodeExtended) {
        JSONObject jsonObjectMain = new JSONObject();
        try {
            jsonObjectMain.put(JSON_KEYNAME_RESULT_CODE_EXTENDED,
                    String.format("%08X", resultCodeExtended[0]));
            jsonObjectMain.put(JSON_KEYNAME_RESULT_CODE,
                    String.format("%02d", resultCode[0]));
            jsonObjectMain.put(JSON_KEYNAME_RUN_RESULT,
                    String.valueOf(result.resultCode));
        } catch (JSONException je) {
            je.printStackTrace();
        }
        return jsonObjectMain;
    }

    private JSONObject createResultJson(int result, String config) {
        JSONObject jsonObjectMain = new JSONObject();
        try {
            jsonObjectMain.put("upos", result);
            if (config == null || config.length() == 0) {
                jsonObjectMain.put("conf", JSONObject.NULL);
            } else {
                jsonObjectMain.put("conf", config);
            }
        } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonObjectMain;
    }

    private String setKernel(INSTALLEDFILEDATE installedfiledate, VERSIONINFO versioninfo){
        JSONObject jsonKernel = new JSONObject();
        JSONObject jsonKernelData = new JSONObject();
        JSONObject jsonAplVer = new JSONObject();
        JSONObject jsonEmvDate = new JSONObject();

        try {
            jsonAplVer.put("reader", ByteUtil.bin2hex(versioninfo.ReaderVersion));
            jsonAplVer.put("kernel1", ByteUtil.bin2hex(versioninfo.KernelC1Version));
            jsonAplVer.put("kernel2", ByteUtil.bin2hex(versioninfo.KernelC2Version));
            jsonAplVer.put("kernel3", ByteUtil.bin2hex(versioninfo.KernelC3Version));
            jsonAplVer.put("kernel4", ByteUtil.bin2hex(versioninfo.KernelC4Version));
            jsonAplVer.put("kernel5", ByteUtil.bin2hex(versioninfo.KernelC5Version));
            jsonAplVer.put("kernel6", ByteUtil.bin2hex(versioninfo.KernelC6Version));
            jsonAplVer.put("kernel7", ByteUtil.bin2hex(versioninfo.KernelC7Version));
            jsonAplVer.put("kernel8", ByteUtil.bin2hex(versioninfo.KernelC8Version));
            jsonAplVer.put("kernel9", ByteUtil.bin2hex(versioninfo.KernelC9Version));
            jsonAplVer.put("kernel10", ByteUtil.bin2hex(versioninfo.KernelC10Version));
            jsonAplVer.put("kernel11", ByteUtil.bin2hex(versioninfo.KernelC11Version));
            jsonAplVer.put("kernel12", ByteUtil.bin2hex(versioninfo.KernelC12Version));
            jsonAplVer.put("kernel13", ByteUtil.bin2hex(versioninfo.KernelC13Version));
            jsonAplVer.put("kernel14", ByteUtil.bin2hex(versioninfo.KernelC14Version));
            jsonAplVer.put("kernel15", ByteUtil.bin2hex(versioninfo.KernelC15Version));

            jsonEmvDate.put("common", ByteUtil.bin2hex(installedfiledate.CommonFile));
            jsonEmvDate.put("kernel1", ByteUtil.bin2hex(installedfiledate.KernelC1File));
            jsonEmvDate.put("kernel2", ByteUtil.bin2hex(installedfiledate.KernelC2File));
            jsonEmvDate.put("kernel3", ByteUtil.bin2hex(installedfiledate.KernelC3File));
            jsonEmvDate.put("kernel4", ByteUtil.bin2hex(installedfiledate.KernelC4File));
            jsonEmvDate.put("kernel5", ByteUtil.bin2hex(installedfiledate.KernelC5File));
            jsonEmvDate.put("kernel6", ByteUtil.bin2hex(installedfiledate.KernelC6File));
            jsonEmvDate.put("kernel7", ByteUtil.bin2hex(installedfiledate.KernelC7File));
            jsonEmvDate.put("kernel8", ByteUtil.bin2hex(installedfiledate.KernelC8File));
            jsonEmvDate.put("kernel9", ByteUtil.bin2hex(installedfiledate.KernelC9File));
            jsonEmvDate.put("kernel10", ByteUtil.bin2hex(installedfiledate.KernelC10File));
            jsonEmvDate.put("kernel11", ByteUtil.bin2hex(installedfiledate.KernelC11File));
            jsonEmvDate.put("kernel12", ByteUtil.bin2hex(installedfiledate.KernelC12File));
            jsonEmvDate.put("kernel13", ByteUtil.bin2hex(installedfiledate.KernelC13File));
            jsonEmvDate.put("kernel14", ByteUtil.bin2hex(installedfiledate.KernelC14File));
            jsonEmvDate.put("kernel15", ByteUtil.bin2hex(installedfiledate.KernelC15File));

            jsonKernelData.put("aplver", jsonAplVer);
            jsonKernelData.put("emvdate", jsonEmvDate);
            jsonKernel.put("kernel",jsonKernelData);
        } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonKernel.toString();
    }

    private String setDll(INSTALLEDFILEDATE installedfiledate){
        JSONObject jsonMain = new JSONObject();
        JSONObject jsonDll = new JSONObject();
        JSONObject jsonDllDate = new JSONObject();
        try {
            jsonDllDate.put("dll1", ByteUtil.bin2hex(installedfiledate.FileDLL1).substring(2, 10));
            jsonDllDate.put("dll2", ByteUtil.bin2hex(installedfiledate.FileDLL2).substring(2, 10));
            jsonDllDate.put("dll3", ByteUtil.bin2hex(installedfiledate.FileDLL3).substring(2, 10));
            jsonDllDate.put("dll4", ByteUtil.bin2hex(installedfiledate.FileDLL4).substring(2, 10));
            jsonDllDate.put("dll5", ByteUtil.bin2hex(installedfiledate.FileDLL5).substring(2, 10));
            jsonDllDate.put("dll6", ByteUtil.bin2hex(installedfiledate.FileDLL6).substring(2, 10));
            jsonDllDate.put("dll7", ByteUtil.bin2hex(installedfiledate.FileDLL7).substring(2, 10));
            jsonDllDate.put("dll8", ByteUtil.bin2hex(installedfiledate.FileDLL8).substring(2, 10));
            jsonDllDate.put("dll9", ByteUtil.bin2hex(installedfiledate.FileDLL9).substring(2, 10));
            jsonDllDate.put("dll10", ByteUtil.bin2hex(installedfiledate.FileDLL10).substring(2, 10));
            jsonDllDate.put("dll11", ByteUtil.bin2hex(installedfiledate.FileDLL11).substring(2, 10));
            jsonDllDate.put("dll12", ByteUtil.bin2hex(installedfiledate.FileDLL12).substring(2, 10));
            jsonDllDate.put("dll13", ByteUtil.bin2hex(installedfiledate.FileDLL13).substring(2, 10));
            jsonDllDate.put("dll14", ByteUtil.bin2hex(installedfiledate.FileDLL14).substring(2, 10));
            jsonDllDate.put("dll15", ByteUtil.bin2hex(installedfiledate.FileDLL15).substring(2, 10));

            jsonDll.put("dlldate", jsonDllDate);
            jsonMain.put("dll", jsonDll);

        } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonMain.toString();
    }

    private String setSettings(SETTINGINFO settinginfo){
        JSONObject jsonSettings = new JSONObject();
        JSONObject jsonSettingsData = new JSONObject();
        try {
            jsonSettingsData.put(JSON_KEYNAME_VOLUME, settinginfo.VolumeOfSound);
            jsonSettingsData.put(JSON_KEYNAME_MESSAGE_STATUS, settinginfo.LCDSettings);
            jsonSettings.put(JSON_KEYNAME_SETTINGS,jsonSettingsData);

        } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonSettings.toString();
    }

    private String setVersion(SETTINGINFO settinginfo){
        JSONObject jsonVer = new JSONObject();
        JSONObject jsonVerData = new JSONObject();
        try {
            jsonVerData.put("model", ByteUtil.toAscii(settinginfo.Model));
            jsonVerData.put("sno", ByteUtil.toAscii(settinginfo.SNo));
            jsonVerData.put("hdinfo", JSONObject.NULL);
            StringBuilder aplVerData = new StringBuilder();
            String aplId = ByteUtil.bin2hex(settinginfo.AplId);
            String aplVer = ByteUtil.toAscii(settinginfo.AplVer);

            Logger.d(TAG, "aplId" + aplId);
            Logger.d(TAG, "aplVer" + aplVer);
            int aplNum = (int)(aplId.length() / ID_LEN);
            int aplIdIndex;
            int aplVerIndex;
            for (int i = 0; i < aplNum; i++) {
                if (i > 0) {
                    aplVerData.append(",");
                }
                aplIdIndex = i * ID_LEN;
                aplVerIndex = i * VER_LEN;
                aplVerData.append(aplId.substring(aplIdIndex, aplIdIndex + ID_LEN))
                        .append(":")
                        .append(aplVer.substring(aplVerIndex, aplVerIndex + VER_LEN));
            }
            jsonVerData.put("aplver", aplVerData.toString().toUpperCase());
            jsonVerData.put("pfver", aplVer.substring(0, VER_LEN).toUpperCase());

            jsonVer.put("version", jsonVerData);
        } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonVer.toString();
    }

    private String setHealth(int upos, SETTINGINFO settinginfo){
        JSONObject jsonHealth = new JSONObject();
        JSONObject jsonCondition = new JSONObject();

        boolean isTamper = true;
        if(settinginfo.StatusFlag != 0){
            isTamper = false;
        }
        try {
            jsonHealth.put("upos", upos);
            jsonHealth.put("device", 0);
            jsonCondition.put("sts", true);
            jsonCondition.put("tamper", true);
            jsonHealth.put("condition", jsonCondition);

            if(upos == 0){
                jsonHealth.put("device", 0);
                jsonCondition.put("sts", true);
                jsonCondition.put("tamper", isTamper);
                jsonHealth.put("condition", jsonCondition);
            }
        } catch (JSONException je) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            je.printStackTrace();  // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return jsonHealth.toString();
    }

    /**
     *  DataExchange処理.<br>
     * <br>
     * @param setJsonData
     *            JSONデータ文字列
     * @return Data Exchange情報格納クラス
     */
    private DEINFO convertDeinfo(String setJsonData) {
        String METHOD_NAME = "convertDeinfo";
        DEINFO setData = null;
        try {
            JSONObject deinfoJSON = new JSONObject(setJsonData);
            // JSON内データの取得
            String ContinueFlag = deinfoJSON.getString("ContinueFlag");
            String Result = deinfoJSON.getString("Result");
            String DataExchangeData = deinfoJSON.getString("DataExchangeData");

            Logger.d(TAG, METHOD_NAME + "() JSONData "
                    + ":ContinueFlag=" + ContinueFlag
                    + ":Result=" + Result
                    + ":DataExchangeData=" + DataExchangeData);

            // 継続フラグ:16進数文字列をbyte配列変換
            byte[] setContinueFlag = ByteUtil.hex2bin(ContinueFlag);
            if (setContinueFlag == null) {
                Logger.d(TAG, METHOD_NAME + "() ContinueFlag is not set");
                return null;
            } else if (setContinueFlag.length != 1) {
                Logger.d(TAG, METHOD_NAME + "() ContinueFlag is invalid length. length=" + setContinueFlag.length);
                return null;
            }

            // 処理結果:16進数文字列をbyte配列変換
            byte[] setResult = ByteUtil.hex2bin(Result);
            if (setResult == null) {
                Logger.d(TAG, METHOD_NAME + "() Result is not set");
                return null;
            }

            // Data Exchangeデータ:16進数文字列をbyte配列変換
            byte[] setDataExchangeData = ByteUtil.hex2bin(DataExchangeData);
            if (setDataExchangeData == null) {
                Logger.d(TAG, METHOD_NAME + "() DataExchangeData is not set");
                return null;
            }

            // データのセット
            setData = new DEINFO();
            setData.ContinueFlag = setContinueFlag[0];
            setData.Result = setResult;
            setData.DataExchangeData = setDataExchangeData;

        } catch (JSONException je) {
            // JSON ParseError
            je.printStackTrace();
        }
        return setData;
    }
}
