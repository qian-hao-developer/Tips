package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * ビットマップ転送Requestクラス.
 * 
 */
public class BitmapTransferRequest extends BaseRequest {

    /** @brief ログ用タグ */
    private static final String TAG = BitmapTransferRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x40;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x06;

    /** @brief ビットマップデータ . */
    private byte[] mBitMapData;

    /**
     * ビットマップデータを設定する.
     * 
     * @param bitMapData ビットマップデータ
     */
    public void setBitMapData(byte[] bitMapData) {
        mBitMapData = bitMapData;
    }

    /** Constructor */
    public BitmapTransferRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /** Constructor */
    public BitmapTransferRequest(byte sc) {
        super(MAINCOMMAND, sc);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // ビットマップデータ必須チェック
        if (mBitMapData == null) {
            Logger.e(TAG, "isValidValue mBitMapData is null ");
            return false;
        }
        // サイズは可変の為チェック無し
        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return super.toCommand(mBitMapData);
    }
}
