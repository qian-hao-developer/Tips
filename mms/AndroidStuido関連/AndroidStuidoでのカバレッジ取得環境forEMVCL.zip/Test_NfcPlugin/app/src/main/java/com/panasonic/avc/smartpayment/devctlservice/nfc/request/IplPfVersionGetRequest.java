package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * IPL、PFのバージョン取得Requestクラス.
 * 
 */
public class IplPfVersionGetRequest extends BaseRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = IplPfVersionGetRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x00;

    /** Constructor */
    public IplPfVersionGetRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        // データ部なし
        return toCommand(null);
    }
}
