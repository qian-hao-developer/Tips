package com.panasonic.avc.smartpayment.pf.pds;

import android.os.RemoteException;
import android.os.SystemProperties;
import android.util.Log;
import android.content.Context;

public class PdsClientManager {
    public static final boolean DEBUG = SystemProperties.getBoolean("persist.sys.fwupdate.debug", false);
    private static String TAG = "PdsClient:Manager";

    public static final String SERVICE_NAME = "PdsClientService";
    private static IPdsClientService mIPdsClientService = null;
    private UpdaterCallback mCallback;

    /**
     * ファームウェアダウンロード状態を知らせるブロードキャスト名
     */
    public static final String ACTION_DOWNLOAD_STATUS   = "com.panasonic.avc.smartpayment.pf.pds.DOWNLOAD_STATUS";

    /**
     * ACTION_DOWNLOAD_STAUSの付加情報。ダウンロード進捗をint型で格納する。(0～100)
     */
    public static final String EXTRA_PROGRESS           = "progress";

    /**
     * ACTION_DOWNLOAD_STAUSの付加情報。ダウンロード状態をint型で格納する。
     * 対応するvalueはDOWNLOAD_STATUS_NONE,DOWNLOAD_STATUS_DOWNLOADING,DOWNLOAD_STATUS_COMPLETED,DOWNLOAD_STATUS_FAILED
     */
    public static final String EXTRA_STATUS             = "status";

    /**
     * ダウンロード状態:ダウンロードなし
     */
    public static final int DOWNLOAD_STATUS_NONE        = 0;

    /**
     * ダウンロード状態:ダウンロード中
     */
    public static final int DOWNLOAD_STATUS_DOWNLOADING = 1;

    /**
     * ダウンロード状態:ダウンロード完了
     */
    public static final int DOWNLOAD_STATUS_COMPLETED   = 2;

    /**
     * ダウンロード状態:ダウンロード失敗
     */
    public static final int DOWNLOAD_STATUS_FAILED      = 11;

    /**
     * 品番
     */
    public static final int KEY_PRODUCT_NO          = 0;

    /**
     * 製造番号
     */
    public static final int KEY_PRODUCT_ID          = 1;

    /**
     * 申込通番
     */
    public static final int KEY_CONTRACT_NO         = 2;

    /**
     * ユニークID
     */
    public static final int KEY_UNIQUE_ID           = 3;

    /**
     * PINPADの製造ID
     */
    public static final int KEY_PRODUCT_ID_PINPAD   = 4;

    /**
     * RWの製造ID
     */
    public static final int KEY_PRODUCT_ID_RW       = 5;

    /**
     * サインパッドの製造ID
     */
    public static final int KEY_PRODUCT_ID_SIGNPAD  = 6;

    /**
     * パスポートリーダの製造ID
     */
    public static final int KEY_PRODUCT_ID_PASSPORT = 7;

    /**
     * バーコードリーダの製造ID
     */
    public static final int KEY_PRODUCT_ID_BARCODE  = 8;

    /**
     * PINPADの品番
     */
    public static final int KEY_PRODUCT_NO_PINPAD   = 9;

    /**
     * RWの品番
     */
    public static final int KEY_PRODUCT_NO_RW       = 10;

    /**
     * サインパッドの品番
     */
    public static final int KEY_PRODUCT_NO_SIGNPAD  = 11;

    /**
     * パスポートリーダの品番
     */
    public static final int KEY_PRODUCT_NO_PASSPORT = 12;

    /**
     * バーコードリーダの品番
     */
    public static final int KEY_PRODUCT_NO_BARCODE  = 13;

    /** @hide */
    public static final int KEY_APPLY_CAMPAIGN_NAME = 14;

    /**
     * 統一バージョン
     */
    public static final int KEY_FMV_UNIFIED         = 15;

    /**
     * メインCPUバージョン
     */
    public static final int KEY_FMV_SP              = 16;

    /**
     * プリンタファームウェア・フォント統合バージョン
     */
    public static final int KEY_FMV_PAYMENT1        = 17;

    /**
     * MSRファームウェアバージョン
     */
    public static final int KEY_FMV_PAYMENT2        = 18;

    /**
     * ピンパッドのファームウェアバージョン
     */
    public static final int KEY_FMV_PINPAD          = 19;

    /**
     * RWのファームウェアバージョン
     */
    public static final int KEY_FMV_RW              = 20;

    /**
     * RW音源のバージョン
     */
    public static final int KEY_FMV_RW_SOUND        = 21;

    /**
     * サインパッドのファームウェアバージョン
     */
    public static final int KEY_FMV_SIGNPAD         = 22;

    /**
     * パスポートリーダのファームウェアバージョン
     */
    public static final int KEY_FMV_PASSPORT        = 23;

    /**
     * バーコードリーダのファームウェアバージョン
     */
    public static final int KEY_FMV_BARCODE         = 24;

    /** @hide */
    public static final int KEY_DEVICE_INTERVAL     = 25;

    /** @hide */
    public static final int KEY_MANUAL              = 26;

    /** @hide */
    public static final int KEY_DL_STATUS           = 27;

    /** @hide */
    public static final int KEY_WARNING_COUNT       = 28;

    /** @hide */
    public static final int KEY_MAX_COUNT           = 29;

    /**
     * 更新成功
     */
    public static final int RESULT_UPDATE_SUCCESS   = 0;

    /**
     * 更新なし
     */
    public static final int RESULT_UPDATE_NONE      = 1;

    public PdsClientManager() {
    }

    private static IPdsClientService getService() {
        if (mIPdsClientService != null) {
            if(DEBUG) {Log.d(TAG, "already connect to PdsClientService.");}
            return mIPdsClientService;
        }
        mIPdsClientService = IPdsClientService.Stub.asInterface(android.os.ServiceManager.getService(SERVICE_NAME));
        if(DEBUG) {Log.d(TAG, "connect to PdsClientService.");}
        return mIPdsClientService;
    }

    /**
     * 更新アプリのコールバックを登録
     * @param callback コールバック
     */
    public void registerUpdaterCallback(UpdaterCallback callback) {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#registerUpdaterCallback() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return;
        }
        try {
            mCallback = callback;
            mIPdsClientService.registerUpdaterCallback(mIUpdaterCallback);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return;
    }

    /**
     * 更新アプリのコールバックを解除
     */
    public void unregisterUpdaterCallback() {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#unregisterUpdaterCallback() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return;
        }
        try {
            mCallback = null;
            mIPdsClientService.unregisterUpdaterCallback();
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return;
    }

    /**
     * PDSに端末状態情報要求を送信する
     *
     * 本メソッドはUIスレッド以外でコールすること
     * @param true:手動送信, false:自動送信
     * @return 端末状態情報応答
     */
    public StatusInfoResponse getRemoteStatusInfo(boolean manual) {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#getRemoteStatusInfo() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return null;
        }
        try {
            return mIPdsClientService.getRemoteStatusInfo(manual);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return null;
    }

    /**
     * PDSに端末状態情報要求を送信せずに、既に受信済の端末状態情報応答を取得する
     * @retval 端末状態情報応答
     * @retval 未受信の場合はnullを返す
     */
    public StatusInfoResponse getLocalStatusInfo() {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#getLocalStatusInfo() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return null;
        }
        try {
            return mIPdsClientService.getLocalStatusInfo();
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return null;
    }

    /**
     * 定期端末状態情報要求送信タイマをリセットする
     * （リセット時に一度端末状態情報要求が送信される）
     */
    public void resetTimer() {
        if(DEBUG) {Log.d(TAG,"PdsClientManager#resetTimer() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return;
        }
        try {
            mIPdsClientService.resetTimer();
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return;
    }

    /**
     * 本体端末の更新を開始する
     *
     * 本メソッドはUIスレッド以外でコールすること
     * @retval 更新開始失敗の場合のみfalse
     * @retval 更新開始が成功となる場合は本メソッド内で端末再起動となる
     */
    public boolean startUpdate() {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#startUpdate() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return false;
        }
        try {
            return mIPdsClientService.startUpdate();
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return false;
    }

    /**
     * 本体端末の更新結果を取得する
     *
     * @retval 更新成功 RESULT_UPDATE_SUCCESS			
     * @retval 更新なし RESULT_UPDATE_NONE		
     * @retval 更新失敗 負数のエラーコード			
     */
    public int getUpdateResult() {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#getUpdateResult() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return RESULT_UPDATE_NONE;
        }
        try {
            return mIPdsClientService.getUpdateResult();
        } catch (RemoteException ex) {
            Log.e(TAG,"Service IPC failed", ex);
        }
        return RESULT_UPDATE_NONE;
    }

    /**
     * 端末状態情報を設定する
     *
     * @param key 端末状態設定項目
     * @param value 端末状態設定値
     * @retval 成功 true
     * @retval 失敗 false
     */
    public boolean setTerminalStatus(int key, String value) {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#setTerminalStatus() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return false;
        }
        try {
            return mIPdsClientService.setTerminalStatus(key, value);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return false;
    }

    /**
     * 端末状態情報を取得する
     *
     * @param key 端末状態設定項目
     * @retval 成功 keyに対応する端末情報
     * @retval 失敗 null
     */
    public String getTerminalStatus(int key) {
        if(DEBUG) {Log.d(TAG, "PdsClientManager#getTerminalStatus() called");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return null;
        }
        try {
            return mIPdsClientService.getTerminalStatus(key);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return null;
    }

    private IUpdaterCallback mIUpdaterCallback = new IUpdaterCallback.Stub() {
        @Override
        public boolean checkUpdate() {
            if(mCallback != null) {
                return mCallback.checkUpdate();
            }
            return false;
        }

        @Override
        public boolean startUpdate() {
            if(mCallback != null) {
                return mCallback.startUpdate();
            }
            return false;
        }

        @Override
        public boolean cancelUpdate() {
            if(mCallback != null) {
                return mCallback.cancelUpdate();
            }
            return false;
        }
    };
}
