
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * GetVersionInfo処理結果データ
 */
public class ResultGetVersionInfo extends ResultPrnData {

    /** @brief 接触ICカードリーダライタVersion情報タグ */
    private static final String VERINFO = "verinfo";

    /** @brief 接触ICカードリーダライタの製品品番 */
    private String mModel;

    /** @brief 接触ICカードリーダライタVersion情報タグ */
    private static final String MODEL = "model";

    /** @brief 接触ICカードリーダライタのシリアル番号 */
    private String mSno;

    /** @brief 接触ICカードリーダライタVersion情報タグ */
    private static final String SNO = "sno";

    /** @brief 接触ICカードリーダライタのハード構成情報 */
    private String mHdInfo;

    /** @brief 接触ICカードリーダライタVersion情報タグ */
    private static final String HDINFO = "hdinfo";

    /** @brief 接触ICカードリーダライタのアプリケーションVersion */
    private String mAplVer;

    /** @brief 接触ICカードリーダライタVersion情報タグ */
    private static final String APLVER = "aplver";

    /** @brief 接触ICカードリーダライタのプラットフォームVersion */
    private String mPfVer;

    /** @brief 接触ICカードリーダライタVersion情報タグ */
    private static final String PFVER = "pfver";

    /**
     * @brief コンストラクタ
     */
    public ResultGetVersionInfo(Parcel in) {
        super(in);
    }

    /**
     * コンストラクタ
     */
    public ResultGetVersionInfo() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetVersionInfo> CREATOR = new Parcelable.Creator<ResultGetVersionInfo>() {
        public ResultGetVersionInfo createFromParcel(Parcel in) {
            return new ResultGetVersionInfo(in);
        }

        public ResultGetVersionInfo[] newArray(int size) {
            return new ResultGetVersionInfo[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(mModel);
        dest.writeString(mSno);
        dest.writeString(mHdInfo);
        dest.writeString(mAplVer);
        dest.writeString(mPfVer);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mModel = in.readString();
        mSno = in.readString();
        mHdInfo = in.readString();
        mAplVer = in.readString();
        mPfVer = in.readString();
    }

    /**
     * @brief 接触ICカードリーダライタの製品品番を取得します
     * @return 接触ICカードリーダライタの製品品番
     */
    public String getModel() {
        return mModel;
    }

    /**
     * @brief 接触ICカードリーダライタの製品品番を設定します
     * @param[in] model 接触ICカードリーダライタの製品品番
     */
    public void setModel(String model) {
        mModel = model;
    }

    /**
     * @brief 接触ICカードリーダライタのシリアル番号を取得します
     * @return 接触ICカードリーダライタのシリアル番号
     */
    public String getSno() {
        return mSno;
    }

    /**
     * @brief 接触ICカードリーダライタのシリアル番号を設定します
     * @param[in] sno 接触ICカードリーダライタのシリアル番号
     */
    public void setSno(String sno) {
        mSno = sno;
    }

    /**
     * @brief 接触ICカードリーダライタのハード構成情報を取得します
     * @return 接触ICカードリーダライタのハード構成情報
     */
    public String getHdInfo() {
        return mHdInfo;
    }

    /**
     * @brief 接触ICカードリーダライタのハード構成情報を設定します
     * @param[in] hdInfo 接触ICカードリーダライタのハード構成情報
     */
    public void setHdInfo(String hdInfo) {
        mHdInfo = hdInfo;
    }

    /**
     * @brief 接触ICカードリーダライタのアプリケーションVersionを取得します
     * @return 接触ICカードリーダライタのアプリケーションVersion
     */
    public String getAplVer() {
        return mAplVer;
    }

    /**
     * @brief 接触ICカードリーダライタのアプリケーションVersionを設定します
     * @param[in] aplVer 接触ICカードリーダライタのアプリケーションVersion
     */
    public void setAplVer(String aplVer) {
        mAplVer = aplVer;
    }

    /**
     * @brief 接触ICカードリーダライタのプラットフォームVersionを取得します
     * @return 接触ICカードリーダライタのプラットフォームVersion
     */
    public String getPfVer() {
        return mPfVer;
    }

    /**
     * @brief 接触ICカードリーダライタのプラットフォームVersionを設定します
     * @param[in] pfVer 接触ICカードリーダライタのプラットフォームVersion
     */
    public void setPfVer(String pfVer) {
        mPfVer = pfVer;
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonVerInfo = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            if (getModel() != null) {
                jsonVerInfo.put(MODEL, getModel());
            } else {
                jsonVerInfo.put(MODEL, JSONObject.NULL);
            }

            if (getSno() != null) {
                jsonVerInfo.put(SNO, getSno());
            } else {
                jsonVerInfo.put(SNO, JSONObject.NULL);
            }

            if (getHdInfo() != null) {
                jsonVerInfo.put(HDINFO, getHdInfo());
            } else {
                jsonVerInfo.put(HDINFO, JSONObject.NULL);
            }

            if (getAplVer() != null) {
                jsonVerInfo.put(APLVER, getAplVer());
            } else {
                jsonVerInfo.put(APLVER, JSONObject.NULL);
            }

            if (getPfVer() != null) {
                jsonVerInfo.put(PFVER, getPfVer());
            } else {
                jsonVerInfo.put(PFVER, JSONObject.NULL);
            }

            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(VERINFO, JSONObject.NULL);
            } else {
                json.put(VERINFO, jsonVerInfo);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
