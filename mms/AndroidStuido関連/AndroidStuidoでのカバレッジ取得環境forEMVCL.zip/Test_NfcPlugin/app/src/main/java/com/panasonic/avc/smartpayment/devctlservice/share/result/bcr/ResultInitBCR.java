
package com.panasonic.avc.smartpayment.devctlservice.share.result.bcr;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitBCRの実行結果データ
 */
public class ResultInitBCR extends ResultData {
    /** @brief バーコードリーダ種別 */
    private int mType;

    /** @brief バーコードリーダ種別タグ */
    protected static final String TYPE = "type";

    /**
     * @brief コンストラクタ
     */
    public ResultInitBCR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitBCR() {

    }

    /**
     * @brief バーコードリーダ種別を取得します
     * @return バーコードリーダ種別
     * @retval =1 OPTICON M-10
     * @retval =2 OPTICON C-40/41
     */
    public int getType() {
        return mType;
    }

    /**
     * @brief バーコードリーダ種別を設定します
     * @param[in] type バーコードリーダ種別
     */
    public void setType(int type) {
        mType = type;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            json.put(TYPE, getType());
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitBCR> CREATOR = new Parcelable.Creator<ResultInitBCR>() {
        public ResultInitBCR createFromParcel(Parcel in) {
            return new ResultInitBCR(in);
        }

        public ResultInitBCR[] newArray(int size) {
            return new ResultInitBCR[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mType);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mType = in.readInt();
    }
}
