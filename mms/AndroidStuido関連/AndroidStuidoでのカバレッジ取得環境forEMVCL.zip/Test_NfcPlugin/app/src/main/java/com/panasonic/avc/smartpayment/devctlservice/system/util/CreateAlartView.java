
package com.panasonic.avc.smartpayment.devctlservice.system.util;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.panasonic.avc.smartpayment.devctlservice.R;

/**
 * アラートダイアログクラス(ボタン1つ)
 */
public class CreateAlartView {

    /** @brief WindowManager **/
    private WindowManager mWindowManager = null;

    /** @brief 背景View **/
    private View mBackGroundView = null;

    /** @brief ダイアログView **/
    private View mDialogView = null;

    /** @brief ボタンクリックリスナー **/
    private View.OnClickListener mButtonListener = null;

    /**
     * ダイアログ表示
     * 
     * @param context コンテキスト
     * @param title_id タイトルIDの
     * @param image_id 画像ID
     * @param message_id メッセージID
     * @param button_text_id テキストID
     * @param button_image_id ボタンイメージID
     */
    public void showView(Context context, int title_id, int image_id,
            int message_id, int button_text_id, int button_image_id) {

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
                WindowManager.LayoutParams.FLAG_LOCAL_FOCUS_MODE,
                PixelFormat.TRANSLUCENT);

        mWindowManager = (WindowManager) context.getSystemService(context.WINDOW_SERVICE);
        mBackGroundView = layoutInflater.inflate(
                com.panasonic.avc.smartpayment.devctlservice.R.layout.alert_background, null);
        mDialogView = layoutInflater.inflate(
                com.panasonic.avc.smartpayment.devctlservice.R.layout.create_alert_dialog,
                null);

        ((ImageView) mDialogView.findViewById(R.id.iv_dialog_image)).setImageResource(image_id);
        ((ImageView) mDialogView.findViewById(R.id.iv_dialog_button_image))
                .setImageResource(button_image_id);
        ((TextView) mDialogView.findViewById(R.id.tv_dialog_title)).setText(title_id);
        ((TextView) mDialogView.findViewById(R.id.tv_dialog_message)).setText(message_id);
        ((TextView) mDialogView.findViewById(R.id.tv_button_text)).setText(button_text_id);
        ((Button) mDialogView.findViewById(R.id.btn_dialog_bottom))
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mWindowManager.removeView(mDialogView);
                        mWindowManager.removeView(mBackGroundView);
                        if (mButtonListener != null) {
                            mButtonListener.onClick(view);
                        }
                    }
                });
        mWindowManager.addView(mBackGroundView, params);
        mWindowManager.addView(mDialogView, params);
    }

    /**
     * ダイアログの非表示
     */
    public void dismissView() {
        if (mWindowManager != null && mDialogView != null && mDialogView != null
                && mBackGroundView != null) {
            mWindowManager.removeView(mDialogView);
            mWindowManager.removeView(mBackGroundView);
        }
    }

    /**
     * リスナーの取得
     * 
     * @return リスナー
     */
    public View.OnClickListener getButtonListener() {
        return mButtonListener;
    }

    /**
     * リスナーの設定
     * 
     * @param mButtonListener リスナー
     */
    public void setButtonListener(View.OnClickListener mButtonListener) {
        this.mButtonListener = mButtonListener;
    }
}
