package com.panasonic.avc.smartpayment.pf.pds;

public interface UpdaterCallback {
    boolean checkUpdate();
    boolean startUpdate();
    boolean cancelUpdate();
}