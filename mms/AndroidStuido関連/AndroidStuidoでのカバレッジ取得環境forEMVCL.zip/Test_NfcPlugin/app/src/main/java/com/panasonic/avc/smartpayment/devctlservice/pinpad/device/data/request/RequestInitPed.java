
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;

public class RequestInitPed extends RequestData {

    private String mSTime;

    /**
     * @brief コンストラクタ
     * @param[in] stime 整時するための時刻情報
     */
    public RequestInitPed(String stime) {
        mSTime = stime;
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mSTime == null) {
            return false;
        }

        try {
            Long.parseLong(mSTime);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }
}
