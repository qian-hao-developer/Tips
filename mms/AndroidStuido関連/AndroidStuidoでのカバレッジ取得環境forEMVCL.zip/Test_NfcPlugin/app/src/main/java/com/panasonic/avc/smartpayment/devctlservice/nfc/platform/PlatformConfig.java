package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

import android.content.Context;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * @brief Log for depend on Android platform 
 */
public class PlatformConfig {

    private static final String TAG = "PlatformConfig";
    private static PlatformConfig sInstance = new PlatformConfig();

    private ControlDeviceManager mControlDeviceManager;
    private NonContactICCard mNonContactICCard;
    private byte[] mSessionKey = null;

    /**
     * @brief コンストラクタ
     */
    private PlatformConfig() {

    }

    public void setContext(ControlDeviceManager controlDeviceManager, NonContactICCard nonContactICCard) {
        mControlDeviceManager = controlDeviceManager;
        mNonContactICCard = nonContactICCard;
    }

    /**
     * @brief シングルトンインスタンス取得
     */
    public static PlatformConfig getInstance() {
        return sInstance;
    }

    public byte[] deviceSendReceive(byte[] data, int timeout) {
        byte[] ret = null;
        for (int i = 0; i < 5; i++) {
            mSessionKey = mNonContactICCard.getSessionKey();
            if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                wait(100);
            } else {
                if (0 >= internalWrite(data, timeout)) {
                    Logger.e(TAG, "internalDeviceSendReceive write failed");
                    return null;
                }
                ret = internalRead(timeout);
                break;
            }
        }
        return ret;
    }

    public void deviceReceive(int timeout) {
        for (int i = 0; i < 5; i++) {
            if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                wait(100);
            } else {
                // recieve data 読み捨て
                byte[] receiveDataBuff = new byte[10009];
                mControlDeviceManager.read(receiveDataBuff, timeout);
                break;
            }
        }
    }

    // sleep specified time
    private void wait(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void dump(String tag, String message, byte[] data, int length) {
        StringBuilder dumpdata = new StringBuilder();
        for (int i = 0; i < data.length && i < length; i++) {
            dumpdata.append(String.format("%02x", data[i]));
        }
        Logger.e(tag, message + dumpdata);
    }

    private int internalWrite(byte[] data, int timeout) {

        // illegal data size
        if (data.length < CommandDataConstants.DATA_SIZE_HEADER) {
            Logger.e(TAG, "internalWrite illegal data size");
            return -1;
        }
        dump(TAG, "[SEND] ", data, data.length);

        CommandDataConstants.printByte(data, TAG);
        // encrypt target data by index 5 - end. 
        byte[] encryptTarget = new byte[data.length - CommandDataConstants.DATA_SIZE_HEADER];
        byte[] encryptData;
        System.arraycopy(data, CommandDataConstants.DATA_SIZE_HEADER, encryptTarget, 0, encryptTarget.length);
        if (encryptTarget.length > 0 && checkCryptCommand(data)) {
            // cut by only Data portion
            encryptData = encryptCommand(encryptTarget);
            if (encryptData == null) {
                Logger.e(TAG, "internalWrite encrypt failed");
                return -1;
            }
        } else {
            encryptData = encryptTarget;
        }
        // send data to R550
        byte[] sendData = new byte[data.length + 4];

        // CRC target data by data + ETX
        byte[] crcTarget = new byte[data.length + 1];

        // set STX
        sendData[CommandDataConstants.STX_INDEX] = CommandDataConstants.STX;

        // copy from data header to sendData of index 1 - 5
        System.arraycopy(data, 0, sendData, 1, CommandDataConstants.DATA_SIZE_HEADER);
        // copy from data header to crcTarget of index 0 - 4
        System.arraycopy(data, 0, crcTarget, 0, CommandDataConstants.DATA_SIZE_HEADER);

        // copy from encryptData to sendData of index 6 - end
        System.arraycopy(encryptData, 0, sendData, CommandDataConstants.DATA_SIZE_PRIFIX, encryptData.length);
        // copy from encryptData to crcTarget of index 5 - end
        System.arraycopy(encryptData, 0, crcTarget, CommandDataConstants.DATA_SIZE_HEADER, encryptData.length);

        // set ETX
        sendData[sendData.length - CommandDataConstants.ETX_INDEX_REV] = CommandDataConstants.ETX;
        crcTarget[crcTarget.length - 1] = CommandDataConstants.ETX;

        // calcCRC
        int crc = CommandDataConstants.calcCRC(crcTarget);
        sendData[sendData.length - CommandDataConstants.CRC_LOW_INDEX_REV] = (byte) (crc >> 8 & 0xff);
        sendData[sendData.length - CommandDataConstants.CRC_HIGH_INDEX_REV] = (byte) (crc & 0xff);


        CommandDataConstants.printByte(sendData, TAG);
        if (!mControlDeviceManager.write(sendData, timeout)) {
            return -1;
        }
        return 1;
    }

    private byte[] internalRead(int timeout) {

        // recieve data
        byte[] receiveDataBuff = new byte[10009];
        byte[] receiveData = mControlDeviceManager.read(receiveDataBuff, timeout);
        if (receiveData == null || Arrays.equals(receiveDataBuff, receiveData)) {
            Logger.e(TAG, "internalRead read data noting");
            return null;
        }
        dump(TAG, "[ENC ] ", receiveData, receiveData.length);

        CommandDataConstants.printByte(receiveData, TAG);
        // CRC target data by receiveData - STX - CRC
        byte[] crcTarget = new byte[receiveData.length - 3];

        // extraction crc
        int crc = (receiveData[receiveData.length - CommandDataConstants.CRC_LOW_INDEX_REV] & 0xff) << 8
                | receiveData[receiveData.length - CommandDataConstants.CRC_HIGH_INDEX_REV] & 0xff;
        System.arraycopy(receiveData, 1, crcTarget, 0, crcTarget.length);

        // compare with crc to calcCRC
        if (crc != CommandDataConstants.calcCRC(crcTarget)) {
            Logger.e(TAG, "internalRead crc not match");
            return null;
        }

        // decrypt target receiveData - STX - HEADER - ETX - CRC
        byte[] decryptTarget
                = new byte[receiveData.length - CommandDataConstants.DATA_SIZE_PRIFIX - CommandDataConstants.DATA_SIZE_POSTFIX];
        byte[] decryptData;
        System.arraycopy(receiveData, CommandDataConstants.DATA_SIZE_PRIFIX, decryptTarget, 0, decryptTarget.length);
        if (decryptTarget.length > 0) {
            decryptData = decryptCommand(decryptTarget);
            if (decryptData == null) {
                Logger.e(TAG, "internalRead decrypt failed");
                return null;
            }
        } else {
            decryptData = decryptTarget;
        }
        // returnData by receiveData - STX - ETX - CRC
        byte[] returnData = new byte[receiveData.length - 4];
        // copy HEADER to returnData
        System.arraycopy(receiveData, 1, returnData, 0, CommandDataConstants.DATA_SIZE_HEADER);
        // copy decrypt Data to returnData
        System.arraycopy(decryptData, 0, returnData, CommandDataConstants.DATA_SIZE_HEADER, decryptData.length);
        CommandDataConstants.printByte(returnData, TAG);
        dump(TAG, "[RECV] ", returnData, returnData.length);
        return returnData;
    }


    /** encrypt command */
    private byte[] encryptCommand(byte[] data) {
        if (data.length == 0 || data.length % 16 != 0) {
            Logger.d(TAG, "encryptCommand not encrypt target");
            return data;
        }

        return cipherData(data, mSessionKey, true);
    }

    // encrypt data by AES
    private byte[] cipherData(byte[] target, byte[] encryptKey, boolean isEncrypt) {
        byte[] ret = null;
        try {
            // create cipher key and initialize vector object.
            SecretKeySpec key = new SecretKeySpec(encryptKey, "AES");
            IvParameterSpec iv = new IvParameterSpec(new byte[16]);

            // create Cipher object and initialize
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            cipher.init(isEncrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, key, iv);

            ret = cipher.doFinal(target);

        } catch (NoSuchAlgorithmException e) { // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace(); // PT_IMPOSSIBLE_INSTRUCTIONS
            ret = null; // PT_IMPOSSIBLE_INSTRUCTIONS
        } catch (InvalidAlgorithmParameterException e) { // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace(); // PT_IMPOSSIBLE_INSTRUCTIONS
            ret = null; // PT_IMPOSSIBLE_INSTRUCTIONS
        } catch (NoSuchPaddingException e) { // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace(); // PT_IMPOSSIBLE_INSTRUCTIONS
            ret = null; // PT_IMPOSSIBLE_INSTRUCTIONS
        } catch (BadPaddingException e) { // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace(); // PT_IMPOSSIBLE_INSTRUCTIONS
            ret = null; // PT_IMPOSSIBLE_INSTRUCTIONS
        } catch (InvalidKeyException e) {
            e.printStackTrace();
            ret = null;
        } catch (IllegalBlockSizeException e) { // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
            e.printStackTrace(); // PT_IMPOSSIBLE_INSTRUCTIONS
            ret = null; // PT_IMPOSSIBLE_INSTRUCTIONS
        }
        return ret;
    }

    /** decrypt command */
    private byte[] decryptCommand(byte[] data) {
        if (data.length == 0 || data.length % 16 != 0) {
            Logger.d(TAG, "decryptCommand not decrypt target");
            return data;
        }

        return cipherData(data, mSessionKey, false);
    }

    private boolean checkCryptCommand(byte[] data) {
        if (data == null) {
            return false;
        }

        if (data[CommandDataConstants.MAINCOMMAND_INDEX] == (byte)0x01
                && data[CommandDataConstants.SUBCOMMAND_INDEX] == (byte)0x81) {
            return false;
        } else if (data[CommandDataConstants.MAINCOMMAND_INDEX] == (byte)0x25
                && data[CommandDataConstants.SUBCOMMAND_INDEX] == (byte)0xC1) {
            return false;
        }
        return true;
    }

}
