
package com.panasonic.avc.smartpayment.devctlservice.pos;

/**
 * POS 設定値データクラス
 */
public class PosSettingsData {

    /** @brief 通信インタフェース */
    private int mInterface;

    /** @brief 通信速度 */
    private int mBaudrate;

    /** @brief パリティ種別 */
    private int mParity;

    /** @brief ブロックサイズ */
    private int mBlockSize;

    /**
     * @brief コンストラクタ
     * @param pos_interface 通信インタフェース
     * @param serial_baudrate 通信速度
     * @param serial_parity パリティ種別
     * @param block_size ブロックサイズ
     */
    public PosSettingsData(int pos_interface, int serial_baudrate, int serial_parity,
            int block_size) {
        mInterface = pos_interface;
        mBaudrate = serial_baudrate;
        mParity = serial_parity;
        mBlockSize = block_size;
    }

    /**
     * @brief 通信インタフェースを取得する
     * @return 通信インタフェース
     */
    public int getInterface() {
        return mInterface;
    }

    /**
     * @brief 通信速度を取得する
     * @return 通信速度
     */
    public int getBaudrate() {
        return mBaudrate;
    }

    /**
     * @brief パリティ種別を取得する
     * @return パリティ種別
     */
    public int getParity() {
        return mParity;
    }

    /**
     * @brief ブロックサイズを取得する
     * @return ブロックサイズ
     */
    public int getBlockSize() {
        return mBlockSize;
    }

}
