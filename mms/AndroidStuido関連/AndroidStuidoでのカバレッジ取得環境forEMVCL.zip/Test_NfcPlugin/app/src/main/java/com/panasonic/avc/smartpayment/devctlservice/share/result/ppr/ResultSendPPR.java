
package com.panasonic.avc.smartpayment.devctlservice.share.result.ppr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * SendPPRの結果
 */
public class ResultSendPPR extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSendPPR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendPPR() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendPPR> CREATOR = new Parcelable.Creator<ResultSendPPR>() {
        public ResultSendPPR createFromParcel(Parcel in) {
            return new ResultSendPPR(in);
        }

        public ResultSendPPR[] newArray(int size) {
            return new ResultSendPPR[size];
        }
    };
}
