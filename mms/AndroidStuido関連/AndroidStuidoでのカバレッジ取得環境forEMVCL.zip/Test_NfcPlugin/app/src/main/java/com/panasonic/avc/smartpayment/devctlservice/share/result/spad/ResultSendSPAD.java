
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSendSPAD extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSendSPAD(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendSPAD() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendSPAD> CREATOR = new Parcelable.Creator<ResultSendSPAD>() {

        @Override
        public ResultSendSPAD createFromParcel(Parcel in) {
            return new ResultSendSPAD(in);
        }

        @Override
        public ResultSendSPAD[] newArray(int size) {
            return new ResultSendSPAD[size];
        }
    };
}
