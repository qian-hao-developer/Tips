
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * ICカードドライバリセット要求クラス
 */
public class RequestDriverReset extends RequestData {
    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x06;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 0x0002;

    /**
     * @brief コンストラクタ
     */
    public RequestDriverReset() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] paramater = new byte[LENGTH];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }
}
