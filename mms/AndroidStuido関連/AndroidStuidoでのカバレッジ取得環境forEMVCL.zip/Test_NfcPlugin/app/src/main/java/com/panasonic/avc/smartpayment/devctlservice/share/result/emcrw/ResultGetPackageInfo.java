
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * getPackageInfoデータ
 */
public class ResultGetPackageInfo implements Parcelable {
    /** @brief パッケージ名 */
    private String mName;

    /** @brief パッケージ名タグ */
    protected static final String NAME = "name";

    /** @brief バージョン番号 */
    private String mVer;

    /** @brief バージョン番号タグ */
    protected static final String VER = "ver";

    /**
     * @brief コンストラクタ
     */
    public ResultGetPackageInfo(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetPackageInfo() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetPackageInfo> CREATOR = new Parcelable.Creator<ResultGetPackageInfo>() {
        public ResultGetPackageInfo createFromParcel(Parcel in) {
            return new ResultGetPackageInfo(in);
        }

        public ResultGetPackageInfo[] newArray(int size) {
            return new ResultGetPackageInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mName);
        dest.writeString(mVer);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mName = in.readString();
        mVer = in.readString();
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(NAME, getName());
            json.put(VER, getVer());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

    /**
     * @brief パッケージ名を取得する
     * @return パッケージ名
     */
    public String getName() {
        return mName;
    }

    /**
     * @brief パッケージ名を設定する
     * @param パッケージ名
     */
    public void setName(String javascript, String plugin, String service) {
        mName = javascript + "," + plugin + "," + service;
    }

    /**
     * @brief バージョン番号を取得する
     * @return バージョン番号
     */
    public String getVer() {
        return mVer;
    }

    /**
     * @brief バージョン番号を設定する
     * @param バージョン番号
     */
    public void setVer(String javascript, String plugin, String service) {
        mVer = javascript + "," + plugin + "," + service;
    }

}
