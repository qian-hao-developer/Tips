
package com.panasonic.avc.smartpayment.devctlservice;

/**
 * DevCtlService 用定数クラス
 */
public class DevCtlServiceDefine {

    /** @brief DeviceEmulateTool 使用フラグ */
    public static final boolean SERIAL = false;

    /** @brief バージョン番号 */
    public static final String VERSION = "1.18.003";

}
