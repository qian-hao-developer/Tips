package com.panasonic.avc.smartpayment.devctlservice.nfc.data;

/**
 * 取引結果情報格納クラス<br>
 */
public class RESULTINFO {
    /** 取引結果ビット. */
    public byte[] TransactionResultBit;
    /** 会員番号. */
    public byte[] MemberNumber;
    /** 有効期限. */
    public byte[] ExpirationDate;
    /** Cardholder Name（カナ氏名）. */
    public byte[] CardHolderName;
    /** Application PAN Sequence Number. */
    public byte ApplicationPANSequenceNumber;
    /** カードブランド. */
    public byte CardBrandIdentifier;
    /** OUTCOMEパラメータLen. */
    public byte[] OUTCOMEParameterlen;
    /** OUTCOMEパラメータ. */
    public byte[] OUTCOMEParameter;
    /** 取得TLVデータ. */
    public byte[] TLVData;
    /** 取得TLVデータ（レスポンス拡張領域）. */
    public byte[] TLVDataExtended;
    /** 取得TLVデータ２（レスポンス拡張領域）. */
    public byte[] TLVDataExtended2;
    /** RESULTINFOが設定されているか. */
    public boolean isSet = false;
}
