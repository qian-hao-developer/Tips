package com.panasonic.avc.smartpayment.devctlservice.nfc;

/**
 * コマンドデータ定数クラス
 */
public class CommandDataConstants {

    /**
     * Privateコンストラクタとしてインスタンス生成を抑止する.
     */
    private CommandDataConstants() {
        super();
    }

    /** @brief 日時フォーマット（yyMMddhhmmss） */
    public static final String DATE_FORMAT_YYMMDDHHMMSS = "yyMMddHHmmss";
    /** @brief 日付フォーマット（yyyyMMdd） */
    public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";

    /** @brief 日付フォーマット（yyyyMMdd）日付未設定版 */
    public static final String DATE_FORMAT_YYYYMMDD_NOTESET = "00000000";

    /** 文字コード（StandardCharsets.UTF_8をセットすべきだが1.7からの為Stringで設定）. */
    public static final String CHARSETS_UTF_8 = "utf-8";

    // データ長情報
    public static final int ID_INDEX = 0;
    public static final int MAINCOMMAND_INDEX = ID_INDEX + 1;
    public static final int SUBCOMMAND_INDEX = MAINCOMMAND_INDEX + 1;
    public static final int DATALENGTHHIGH_INDEX = SUBCOMMAND_INDEX + 1;
    public static final int DATALENGTHLOW_INDEX = DATALENGTHHIGH_INDEX + 1;
    public static final int DATA_SIZE_WITHOUT_PARAMETER = DATALENGTHLOW_INDEX + 1;
    public static final int DATA_INDEX = DATA_SIZE_WITHOUT_PARAMETER;

    /** FILE_DLLファイルデータ最大送信サイズ. */
    public static final int FILE_DLL_DATA_MAX = 8118;
    /** EMV設定ファイルHEADERレングス部長さ. */
    public static final int FILE_HEADER_LENGTH_COL_LENGTH = 2;
    /** EMV設定ファイルHEADER(コマンド)部長さ */
    public static final int FILE_HEADER_LENGTH_EMV = 58;
    /** FileDLLファイルHEADER(コマンド)部長さ */
    public static final int FILE_HEADER_LENGTH_FILE_DLL = 58;

    /** BITMAP転送Responseファイル処理結果Index. */
    public static final int RESPONSE_BITMAP_RESULT_INDEX = 40;
    /** BITMAP転送Responseファイル拡張処理結果Index（EMV、FileDllのみ）. */
    public static final int RESPONSE_BITMAP_RESULT_EXTENDED_INDEX = 42;
    /** 取引情報用BITMAP長さ（予備含まず）. */
    public static final int TRANSACTION_BITMAP_DATA_LENGTH = 837;
    /** 取引情報用BITMAP：項目レングス部長さ. */
    public static final int TRANSACTION_BITMAP_HEADER_COL_LENGTH = 2;

    /** AP-ID長さ. */
    public static final int APID_LENGTH = 1;
    /** EMV設定日付長さ. */
    public static final int EMVSETTINGDATE_LENGTH = 4;
    /** LCD表示データ長さ. */
    public static final int LCDMESSAGEDATA_LENGTH = 1;
    /** R/W状態フラグ長さ. */
    public static final int STATUSFLG_LENGTH = 1;
    /** R/W状態番号長さ. */
    public static final int STATUSNO_LENGTH = 1;
    /** RW登録番号長さ. */
    public static final int REGISTRATION_LENGTH = 16;
    /** アプリバージョン長さ. */
    public static final int APVER_LENGTH = 2;
    /** チェックサム長さ. */
    public static final int CHECKSUM_LENGTH = 4;
    /** タイマ設定値長さ. */
    public static final int TIMERSETTING_LENGTH = 3;
    /** ファイルDLL日付長さ. */
    public static final int FILEDLLDATE_LENGTH = 4;
    /** 音量設定値長さ. */
    public static final int VOLUME_LENGTH = 1;
    /** 受信レコード番号長さ. */
    public static final int RECEIVERECORDNO_LENGTH = 2;
    /** 送信レコード番号長さ. */
    public static final int SENDRECORDNO_LENGTH = 2;
    /** 表示言語長さ. */
    public static final int MESSAGELANGUAGE_LENGTH = 1;
    /** 送信カウンタ長さ. */
    public static final int SENDCOUNTER_LENGTH = 2;
    /** 継続フラグ長さ. */
    public static final int CONTINUEFLAG_LENGTH = 1;
    /** 処理結果長さ. */
    public static final int RESULT_LENGTH = 2;

    // 結果系定数
    /** 実行処理結果：衝突検出. */
    protected static final byte[] RESULT_ERROR_RESULT_COLLISION = new byte[]{(byte)0xEA, (byte)0x19};
    /** 実行処理結果：タイムアウト. */
    protected static final byte[] RESULT_ERROR_RESULT_TIMEOUT = new byte[]{(byte)0xE9, (byte)0x99};
    /** 実行処理結果：Internal Error. */
    protected static final byte[] RESULT_ERROR_INTERNAL_ERROR = new byte[]{(byte)0x0F, (byte)0xFF};

    /** 処理結果正常. */
    public static final int RESULT_CODE_SUCCESS = 0;
    /** 処理結果：決済デバイスの通信エラー（非同期処理のみ）. */
    public static final int RESULT_CODE_NETWORK_ERROR = 111;
    /** 処理結果：決済デバイスのEMV処理エラー. */
    public static final int RESULT_CODE_EMV_PROC_ERROR = 201;
    /** 処理結果：決済デバイスの非EMV処理エラー. */
    public static final int RESULT_CODE_NOT_EMV_PROC_ERROR = 301;
    /** 決済デバイスのシーケンスエラー. */
    public static final int RESULT_CODE_EMV_SEQUENCE_ERROR = 302;
    /** 決済デバイスの決済デバイスの致命的エラー. */
    public static final int RESULT_CODE_FATAL_ERROR = 303;

    /** 処理拡張コード：正常. */
    public static final byte[] RESULT_EXTENDED_SUCCESS = new byte[]{(byte)0x00, (byte)0x00};
    /** 処理拡張コードTransactionCode：通信エラー. */
    public static final byte[] RESULT_EXTENDED_TRANSACTION_CONNECT_ERROR = new byte[]{(byte)0xFF, (byte)0xFF};
    /** 処理拡張コードTransactionCode：パラメータ異常. */
    public static final byte[] RESULT_EXTENDED_TRANSACTION_PARAM_ERROR = new byte[]{(byte)0xFF, (byte)0xFC};
    /** 処理拡張コードDetailedCode：正常. */
    public static final byte[] RESULT_EXTENDED_DETAILED_SUCCESS = new byte[]{(byte)0x00, (byte)0x00};

    /** エラーコード：決済デバイスのシーケンスエラー. */
    protected static final byte[] ERROR_CODE_RESPONSE_SEQ = new byte[]{(byte)0xC0, (byte)0x00};
    /** エラーコード：決済デバイスの致命的エラー：イベント実行不可異常（タンパ発生）. */
    protected static final byte[] ERROR_CODE_RESPONSE_F_TAMPA = new byte[]{(byte)0xE0, (byte)0x01};
    /** エラーコード：決済デバイスの致命的エラー：FROM書込み異常. */
    protected static final byte[] ERROR_CODE_RESPONSE_F_WRITE = new byte[]{(byte)0xE3, (byte)0x00};
    /** エラーコード：決済デバイスの致命的エラー：FROM初期化エラー. */
    protected static final byte[] ERROR_CODE_RESPONSE_F_INIT = new byte[]{(byte)0xE3, (byte)0x01};
    /** エラーコード：決済デバイスの致命的エラー：カーネル起動失敗. */
    protected static final byte[] ERROR_CODE_RESPONSE_F_KERNEL = new byte[]{(byte)0xE4, (byte)0x00};

    /** エラーレスポンス-RW状態フラグ タンパー検出. */
    public static final byte ERRES_RW_STS_TAMPER_DETECTION = (byte) 0x02;
    /** ResultCodeEx:タンパー検出. */
    protected static final int RESULT_CODE_EX_TAMPER_DETECTION = 0xE0010000;

    // 各API別データ長enum
    /**
     * RW情報要求Request長
     */
    public enum RW_INFORMATION_REQUEST {
        /** 通信日時. */
        COMMDATETIME(6);

        private final int dataLength;

        RW_INFORMATION_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * RW情報要求Response長
     */
    public enum RW_INFORMATION_RESPONSE {
        /** RW状態フラグ. */
        STATUSFLG(STATUSFLG_LENGTH),
        /** RW状態番号. */
        STATUSNO(STATUSNO_LENGTH),
        /** 音量設定値. */
        VOLUME(VOLUME_LENGTH),
        /** コントラスト. */
        CONTRAST(1),
        /** バックライト. */
        BACKLIGHT(1),
        /** RW製品品番. */
        PRODUCTNO(12),
        /** RW製造番号. */
        SERIALNO(10);

        private final int dataLength;

        RW_INFORMATION_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * APダウンロード開始Request長
     */
    public enum DOWNLOAD_START_REQUEST {
        /** 予備. */
        RESERVE(2),
        /** データサイズ. */
        DATASIZE(4);

        private final int dataLength;

        DOWNLOAD_START_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * ダウンロードデータRequest長
     */
    public enum DOWNLOAD_DATA_REQUEST {
        /** 送信レコード番号. */
        SENDRECORDNO(SENDRECORDNO_LENGTH);

        private final int dataLength;

        DOWNLOAD_DATA_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * ダウンロードデータResponse長
     */
    public enum DOWNLOAD_DATA_RESPONSE {
        /** 受信レコード番号. */
        RECEIVERECORDNO(RECEIVERECORDNO_LENGTH);

        private final int dataLength;

        DOWNLOAD_DATA_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * APダウンロード終了Response長
     */
    public enum DOWNLOAD_END_RESPONSE {
        /** APダウンロード終了処理待ち時間. */
        DOWNLOADTIME(2);

        private final int dataLength;

        DOWNLOAD_END_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * RW登録業務Request長
     */
    public enum RW_ENTRY_WORK_REQUEST {
        /** RW登録番号. */
        REGISTRATION(REGISTRATION_LENGTH);

        private final int dataLength;

        RW_ENTRY_WORK_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * 機器情報要求Response長
     */
    public enum DEVICE_INFORMATION_RESPONSE {
        /** R/W状態フラグ. */
        STATUSFLG(STATUSFLG_LENGTH),
        /** R/W状態番号. */
        STATUSNO(STATUSNO_LENGTH),
        /** 音量設定値. */
        VOLUME(VOLUME_LENGTH),
        /** タイマ1設定値. */
        TIMERSETTING1(TIMERSETTING_LENGTH),
        /** タイマ2設定値. */
        TIMERSETTING2(TIMERSETTING_LENGTH),
        /** タイマ3設定値. */
        TIMERSETTING3(TIMERSETTING_LENGTH),
        /** タイマ4設定値. */
        TIMERSETTING4(TIMERSETTING_LENGTH),
        /** タイマ5設定値. */
        TIMERSETTING5(TIMERSETTING_LENGTH),
        /** LCD表示データ. */
        LCDMESSAGEDATA(LCDMESSAGEDATA_LENGTH),
        /** 表示言語. */
        MESSAGELANGUAGE(MESSAGELANGUAGE_LENGTH),
        /** Readerアプリバージョン. */
        READAPVER(APVER_LENGTH),
        /** カーネル C1アプリバージョン. */
        KERNELC1APVER(APVER_LENGTH),
        /** カーネル C2アプリバージョン. */
        KERNELC2APVER(APVER_LENGTH),
        /** カーネル C3アプリバージョン. */
        KERNELC3APVER(APVER_LENGTH),
        /** カーネル C4アプリバージョン. */
        KERNELC4APVER(APVER_LENGTH),
        /** カーネル C5アプリバージョン. */
        KERNELC5APVER(APVER_LENGTH),
        /** カーネル C6アプリバージョン. */
        KERNELC6APVER(APVER_LENGTH),
        /** カーネル C7アプリバージョン. */
        KERNELC7APVER(APVER_LENGTH),
        /** カーネル C8アプリバージョン. */
        KERNELC8APVER(APVER_LENGTH),
        /** カーネル C9アプリバージョン. */
        KERNELC9APVER(APVER_LENGTH),
        /** カーネル C10アプリバージョン. */
        KERNELC10APVER(APVER_LENGTH),
        /** カーネル C11アプリバージョン. */
        KERNELC11APVER(APVER_LENGTH),
        /** カーネル C12アプリバージョン. */
        KERNELC12APVER(APVER_LENGTH),
        /** カーネル C13アプリバージョン. */
        KERNELC13APVER(APVER_LENGTH),
        /** カーネル C14アプリバージョン. */
        KERNELC14APVER(APVER_LENGTH),
        /** カーネル C15アプリバージョン. */
        KERNELC15APVER(APVER_LENGTH),
        /** パラメータ設定日付. */
        PARAMSETDATE(4),
        /** EMV設定日付(カーネル共通). */
        EMVSETTINGDATEKERNELCOMMON(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C1). */
        EMVSETTINGDATEKERNELC1(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C2). */
        EMVSETTINGDATEKERNELC2(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C3). */
        EMVSETTINGDATEKERNELC3(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C4). */
        EMVSETTINGDATEKERNELC4(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C5). */
        EMVSETTINGDATEKERNELC5(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C6). */
        EMVSETTINGDATEKERNELC6(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C7). */
        EMVSETTINGDATEKERNELC7(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C8). */
        EMVSETTINGDATEKERNELC8(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C9). */
        EMVSETTINGDATEKERNELC9(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C10). */
        EMVSETTINGDATEKERNELC10(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C11). */
        EMVSETTINGDATEKERNELC11(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C12). */
        EMVSETTINGDATEKERNELC12(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C13). */
        EMVSETTINGDATEKERNELC13(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C14). */
        EMVSETTINGDATEKERNELC14(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(カーネル C15). */
        EMVSETTINGDATEKERNELC15(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(デフォルトカーネル ID追加変更). */
        EMVSETTINGDATEKERNELDEFAULT(EMVSETTINGDATE_LENGTH),
        /** EMV設定日付(Revocation List). */
        EMVSETTINGDATEREVOCATIONLIST(EMVSETTINGDATE_LENGTH),
        /** Entry Pointチェックサム. */
        CHECKSUMENTRYPOINT(CHECKSUM_LENGTH),
        /** カーネル C1チェックサム. */
        CHECKSUMKERNELC1(CHECKSUM_LENGTH),
        /** カーネル C2チェックサム. */
        CHECKSUMKERNELC2(CHECKSUM_LENGTH),
        /** カーネル C3チェックサム. */
        CHECKSUMKERNELC3(CHECKSUM_LENGTH),
        /** カーネル C4チェックサム. */
        CHECKSUMKERNELC4(CHECKSUM_LENGTH),
        /** カーネル C5チェックサム. */
        CHECKSUMKERNELC5(CHECKSUM_LENGTH),
        /** カーネル C6チェックサム. */
        CHECKSUMKERNELC6(CHECKSUM_LENGTH),
        /** カーネル C7チェックサム. */
        CHECKSUMKERNELC7(CHECKSUM_LENGTH),
        /** カーネル C8チェックサム. */
        CHECKSUMKERNELC8(CHECKSUM_LENGTH),
        /** カーネル C9チェックサム. */
        CHECKSUMKERNELC9(CHECKSUM_LENGTH),
        /** カーネル C10チェックサム. */
        CHECKSUMKERNELC10(CHECKSUM_LENGTH),
        /** カーネル C11チェックサム. */
        CHECKSUMKERNELC11(CHECKSUM_LENGTH),
        /** カーネル C12チェックサム. */
        CHECKSUMKERNELC12(CHECKSUM_LENGTH),
        /** カーネル C13チェックサム. */
        CHECKSUMKERNELC13(CHECKSUM_LENGTH),
        /** カーネル C14チェックサム. */
        CHECKSUMKERNELC14(CHECKSUM_LENGTH),
        /** カーネル C15チェックサム. */
        CHECKSUMKERNELC15(CHECKSUM_LENGTH),
        /** Entry Pointアプリバージョン. */
        ENTRYPOINTAPVER(APVER_LENGTH),
        /** ファイルDLL日付１. */
        FILEDLLDATE1(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付２. */
        FILEDLLDATE2(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付３. */
        FILEDLLDATE3(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付４. */
        FILEDLLDATE4(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付５. */
        FILEDLLDATE5(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付６. */
        FILEDLLDATE6(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付７. */
        FILEDLLDATE7(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付８. */
        FILEDLLDATE8(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付９. */
        FILEDLLDATE9(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付１０. */
        FILEDLLDATE10(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付１１. */
        FILEDLLDATE11(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付１２. */
        FILEDLLDATE12(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付１３. */
        FILEDLLDATE13(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付１４. */
        FILEDLLDATE14(FILEDLLDATE_LENGTH),
        /** ファイルDLL日付１５. */
        FILEDLLDATE15(FILEDLLDATE_LENGTH);

        private final int dataLength;

        DEVICE_INFORMATION_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * ビットマップ転送Response長
     */
    public enum BITMAP_TRANSFER_RESPONSE {
        /** R/W状態フラグ. */
        STATUSFLG(STATUSFLG_LENGTH),
        /** R/W状態番号. */
        STATUSNO(STATUSNO_LENGTH),
        /** ビットマップデータ. */
        BITMAPDATA(0);

        private final int dataLength;

        BITMAP_TRANSFER_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         *
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * Data Exchange Response長
     */
    public enum DATA_EXCHANGE_RESPONSE {
        /** 送信カウンタ. */
        SENDCOUNTER(SENDCOUNTER_LENGTH),
        /** 継続フラグ. */
        CONTINUEFLAG(CONTINUEFLAG_LENGTH),
        /** 処理結果. */
        RESULT(RESULT_LENGTH),
        /** 予備. */
        RESERVE(3),
        /** Data Exchange データ. */
        EXCHANGEDATA(0);

        private final int dataLength;

        DATA_EXCHANGE_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * 処理キャンセルResponse長
     */
    public enum PROCESSING_CANCEL_RESPONSE {
        /** R/W状態フラグ. */
        STATUSFLG(STATUSFLG_LENGTH),
        /** R/W状態番号. */
        STATUSNO(STATUSNO_LENGTH),
        /** カード有無. */
        CARDPRESENCE(1);

        private final int dataLength;

        PROCESSING_CANCEL_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * RW設定変更Request長
     */
    public enum RW_SETTING_CHANGE_REQUEST {
        /** 音量設定値. */
        VOLUME(VOLUME_LENGTH),
        /** タイマ1設定値. */
        TIMERSETTING1(TIMERSETTING_LENGTH),
        /** タイマ2設定値. */
        TIMERSETTING2(TIMERSETTING_LENGTH),
        /** タイマ3設定値. */
        TIMERSETTING3(TIMERSETTING_LENGTH),
        /** タイマ4設定値. */
        TIMERSETTING4(TIMERSETTING_LENGTH),
        /** タイマ5設定値. */
        TIMERSETTING5(TIMERSETTING_LENGTH),
        /** LCD表示データ. */
        LCDMESSAGEDATA(LCDMESSAGEDATA_LENGTH),
        /** 表示言語. */
        MESSAGELANGUAGE(MESSAGELANGUAGE_LENGTH),
        /** 動作モード. */
        OPERATIONMODE(1);

        private final int dataLength;

        RW_SETTING_CHANGE_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * IPL、PFのバージョン取得Response長
     */
    public enum IPL_PF_VERSION_GET_RESPONSE {
        /** IPLバージョン. */
        IPLVERSION(16),
        /** PFバージョン. */
        PFVERSION(16),
        /** PFモデル. */
        PFMODELNO(2);

        private final int dataLength;

        IPL_PF_VERSION_GET_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * APのバージョン取得Response長
     */
    public enum AP_VERSION_GET_RESPONSE {
        /** バージョン情報. */
        VERSIONINFO(80);

        private final int dataLength;

        AP_VERSION_GET_RESPONSE(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * 暗号鍵設定Request長
     */
    public enum ENCRYPTION_KEY_SETTING_REQUEST {
        /** モジュラス. */
        MODULUSDATA(256),
        /** エクスポーネント. */
        EXPONENTDATA(3);

        private final int dataLength;

        ENCRYPTION_KEY_SETTING_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

    /**
     * 決済通貨表示設定Request長
     */
    public enum CURRENCY_DISPLAY_SETTING_REQUEST {
        /** 決済通貨名称. */
        CURRENCYABBDATA(3);

        private final int dataLength;

        CURRENCY_DISPLAY_SETTING_REQUEST(int setDataLength) {
            dataLength = setDataLength;
        }

        /**
         * 指定項目のデータ長を返す.
         * 
         * @return 指定項目データ長
         */
        public int getDataLength() {
            return dataLength;
        }
    }

}
