
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.panasonic.avc.smartpayment.devctlservice.cfg.Configuration;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;

/**
 * IC カードリーダライタ FW 更新情報
 */
public class EmcrwUpdateInfo {

    /** FW 更新情報のディレクトリ */
    private String mDirPath;

    /** RW 統一バージョン */
    private String mRWUnityVersion;

    /** PF 情報 */
    private EmcrwPlatformData mUpdatePFData;

    /** AP 情報 */
    private EmcrwApplicationDataMap mUpdateAPDataMap;

    /** @brief ログ出力用タグ */
    private static final String TAG = Configuration.class.getSimpleName();

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    /**
     * コンストラクタ
     * 
     * @param dirPath FW 更新情報のディレクトリ
     * @param rwUnityVer 統一バージョン(更新情報)
     * @param updatePFData PF(更新情報)
     * @param updateAPDataMap AP(更新情報)
     * @see EmcrwUpdateInfoCreator#create()
     */
    public EmcrwUpdateInfo(String dirPath, String rwUnityVer,
            EmcrwPlatformData updatePFData, EmcrwApplicationDataMap updateAPDataMap) {
        mDirPath = dirPath;
        mRWUnityVersion = rwUnityVer;
        mUpdatePFData = updatePFData;
        mUpdateAPDataMap = updateAPDataMap;
    }

    /**
     * インストールされた PF のバージョン、各 AP のバージョンを更新情報と比較する
     * 
     * @param curtPFData インストールされている PF データ
     * @param curtAPDataMap インストールされている AP のデータマップ
     * @return 全て一致 or 不一致あり
     */
    public boolean equalsVersion(EmcrwPlatformData curtPFData, EmcrwApplicationDataMap curtAPDataMap) {

        if (curtPFData.isNeedUpdate(mUpdatePFData)) {
            // PF バージョンが古い
            return false;
        }

        if (!mUpdateAPDataMap.keySet().equals(curtAPDataMap.keySet())) {
            // アプリケーション数 or アプリケーション ID が不一致
            return false;
        }

        for (Byte apid : mUpdateAPDataMap.keySet()) {
            EmcrwApplicationData curtAPData = curtAPDataMap.get(apid);
            EmcrwApplicationData updateAPData = mUpdateAPDataMap.get(apid);
            if (curtAPData.isNeedUpdate(updateAPData)) {
                // AP バージョンが古い
                return false;
            }
        }

        // 全て一致または新しい
        return true;
    }

    /**
     * アンインストールするアプリの ID リストを取得する
     * 
     * @param curtAPIDSet インストールされている AP の ID セット
     * @return アンインストールするアプリの ID リスト
     */
    public List<Byte> getUninstallAPIDList(Set<Byte> curtAPIDSet) {
        // 更新情報に ID 記載がない AP がインストールされている場合はアンインストール
        // 集合「インストール済み AP ID」から集合「更新情報の AP ID」を減算する
        Set<Byte> tmp = new HashSet<Byte>(curtAPIDSet);
        tmp.removeAll(mUpdateAPDataMap.keySet());
        return new ArrayList<Byte>(tmp);
    }

    /**
     * アップデート(新規インストール含む)する AP のパスリストを取得する
     * 
     * @param curtAPDataMap インストールされている AP のデータマップ
     * @return アップデートする AP のパスリスト
     */
    public List<String> getUpdateAPPathList(EmcrwApplicationDataMap curtAPDataMap) {
        ArrayList<String> ret = new ArrayList<String>();

        for (Byte updateAPID : mUpdateAPDataMap.keySet()) {
            EmcrwApplicationData curtAPData = curtAPDataMap.get(updateAPID);
            EmcrwApplicationData updateAPData = mUpdateAPDataMap.get(updateAPID);
            if (curtAPData == null || curtAPData.isNeedUpdate(updateAPData)) {
                ret.add(new File(mDirPath, updateAPData.getFileName()).getPath());
                if (curtAPData != null) {
                    mLoggingManager.d(
                            TAG,
                            "AP now=" + curtAPData.getVersion() + " up="
                                    + updateAPData.getVersion());
                } else {
                    mLoggingManager.d(
                            TAG,
                            "AP is not installed" + " install="
                                    + updateAPData.getVersion());
                }
            }
        }

        return ret;
    }

    /**
     * アップデートする PF のパスを取得する
     * 
     * @param curtPFData インストールされている PF データ
     * @return アップデートする PF のパス (アップデート不要時は {@code null}
     */
    public String getUpdatePFPath(EmcrwPlatformData curtPFData) {
        if (curtPFData.isNeedUpdate(mUpdatePFData)) {
            mLoggingManager.d(TAG,
                    "PF now=" + curtPFData.getVersion() + " up=" + mUpdatePFData.getVersion());

            return new File(mDirPath, mUpdatePFData.getFileName()).getPath();
        }
        return null;
    }

    /**
     * 統一バージョン(更新情報)を取得する
     * 
     * @return 統一バージョン(更新情報)
     */
    public String getRWUnityVersion() {
        return mRWUnityVersion;
    }

    /**
     * FW 更新情報のディレクトリを取得する
     * 
     * @return FW 更新情報のディレクトリ
     */
    protected String getDirPath() {
        return mDirPath;
    }

    /**
     * PF(更新情報)を取得する
     * 
     * @return PF(更新情報)
     */
    protected EmcrwPlatformData getPFData() {
        return mUpdatePFData;
    }

    /**
     * AP(更新情報)を取得する
     * 
     * @return AP(更新情報)
     */
    protected EmcrwApplicationDataMap getAPDataMap() {
        return mUpdateAPDataMap;
    }
}
