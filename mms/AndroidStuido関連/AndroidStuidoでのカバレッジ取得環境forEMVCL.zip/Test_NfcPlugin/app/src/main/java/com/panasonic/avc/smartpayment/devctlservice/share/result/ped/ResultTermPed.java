
package com.panasonic.avc.smartpayment.devctlservice.share.result.ped;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * TermPEDの実行結果データ
 */
public class ResultTermPed extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermPed(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermPed() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermPed> CREATOR = new Parcelable.Creator<ResultTermPed>() {
        public ResultTermPed createFromParcel(Parcel in) {
            return new ResultTermPed(in);
        }

        public ResultTermPed[] newArray(int size) {
            return new ResultTermPed[size];
        }
    };
}
