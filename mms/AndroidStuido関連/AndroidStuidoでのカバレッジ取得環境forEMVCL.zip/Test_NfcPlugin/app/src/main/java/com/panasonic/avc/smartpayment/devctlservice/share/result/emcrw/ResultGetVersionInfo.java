
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * GetVersionInfo処理結果データ
 */
public class ResultGetVersionInfo extends ResultData {

    /** @brief 非接触ICカードリーダライタの製品品番 */
    private String mModel;

    /** @brief 非接触ICカードリーダライタのシリアル番号 */
    private String mSno;

    /** @brief 非接触ICカードリーダライタのハード構成情報 */
    private String mHdinfo;

    /** @brief 非接触ICカードリーダライタのアプリケーションVersion */
    private String mAplver;

    /** @brief 非接触ICカードリーダライタのプラットフォームVersion */
    private String mPfver;

    /**
     * @brief コンストラクタ
     */
    public ResultGetVersionInfo(Parcel in) {
        super(in);
    }

    /**
     * コンストラクタ
     */
    public ResultGetVersionInfo() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetVersionInfo> CREATOR = new Parcelable.Creator<ResultGetVersionInfo>() {
        public ResultGetVersionInfo createFromParcel(Parcel in) {
            return new ResultGetVersionInfo(in);
        }

        public ResultGetVersionInfo[] newArray(int size) {
            return new ResultGetVersionInfo[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(mModel);
        dest.writeString(mSno);
        dest.writeString(mHdinfo);
        dest.writeString(mAplver);
        dest.writeString(mPfver);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mModel = in.readString();
        mSno = in.readString();
        mHdinfo = in.readString();
        mAplver = in.readString();
        mPfver = in.readString();
    }

    /**
     * @brief 非接触ICカードリーダライタの製品品番を取得します
     * @return 非接触ICカードリーダライタの製品品番
     */
    public String getModel() {
        return mModel;
    }

    /**
     * @brief 非接触ICカードリーダライタの製品品番を設定します
     * @param[in] model 非接触ICカードリーダライタの製品品番
     */
    public void setModel(String model) {
        mModel = model;
    }

    /**
     * @brief 非接触ICカードリーダライタのシリアル番号を取得します
     * @return 非接触ICカードリーダライタのシリアル番号
     */
    public String getSno() {
        return mSno;
    }

    /**
     * @brief 非接触ICカードリーダライタのシリアル番号を設定します
     * @param[in] sno 非接触ICカードリーダライタのシリアル番号
     */
    public void setSno(String sno) {
        mSno = sno;
    }

    /**
     * @brief 非接触ICカードリーダライタのハード構成情報を取得します
     * @return 非接触ICカードリーダライタのハード構成情報
     */
    public String getHdinfo() {
        return mHdinfo;
    }

    /**
     * @brief 非接触ICカードリーダライタのハード構成情報を設定します
     * @param[in] hdInfo 非接触ICカードリーダライタのハード構成情報
     */
    public void setHdinfo(String hdinfo) {
        mHdinfo = hdinfo;
    }

    /**
     * @brief 非接触ICカードリーダライタのアプリケーションVersionを取得します
     * @return 非接触ICカードリーダライタのアプリケーションVersion
     */
    public String getAplver() {
        return mAplver;
    }

    /**
     * @brief 非接触ICカードリーダライタのアプリケーションVersionを設定します
     * @param[in] aplVer 非接触ICカードリーダライタのアプリケーションVersion
     */
    public void setAplver(String aplver) {
        mAplver = aplver;
    }

    /**
     * @brief 非接触ICカードリーダライタのプラットフォームVersionを取得します
     * @return 非接触ICカードリーダライタのプラットフォームVersion
     */
    public String getPfver() {
        return mPfver;
    }

    /**
     * @brief 非接触ICカードリーダライタのプラットフォームVersionを設定します
     * @param[in] pfVer 非接触ICカードリーダライタのプラットフォームVersion
     */
    public void setPfver(String pfver) {
        mPfver = pfver;
    }

}
