
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultSetBrightness extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultSetBrightness(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetBrightness() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetBrightness> CREATOR = new Parcelable.Creator<ResultSetBrightness>() {

        @Override
        public ResultSetBrightness createFromParcel(Parcel in) {
            return new ResultSetBrightness(in);
        }

        @Override
        public ResultSetBrightness[] newArray(int size) {
            return new ResultSetBrightness[size];
        }
    };
}
