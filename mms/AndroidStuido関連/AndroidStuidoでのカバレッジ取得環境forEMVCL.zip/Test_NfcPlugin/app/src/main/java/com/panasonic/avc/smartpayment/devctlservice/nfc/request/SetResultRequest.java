package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * 結果通知Requestクラス.
 */
public class SetResultRequest extends BaseRequest {

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x80;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x01;

    /** @brief 結果通知データ. */
    private byte[] mSetResultInfo;

    /**
     * 結果通知データを設定する.
     *
     * @param setResultInfo 結果通知データ
     */
    public void setSetResultInfo(byte[] setResultInfo) {
        mSetResultInfo = setResultInfo;
    }

    /** Constructor */
    public SetResultRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // 結果通知データ必須チェック
        if (mSetResultInfo == null) {
            return false;
        }
        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     *
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        return super.toCommand(mSetResultInfo);
    }
}
