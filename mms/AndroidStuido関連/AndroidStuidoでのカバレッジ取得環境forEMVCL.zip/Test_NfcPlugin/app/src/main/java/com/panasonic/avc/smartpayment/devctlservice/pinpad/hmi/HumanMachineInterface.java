
package com.panasonic.avc.smartpayment.devctlservice.pinpad.hmi;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAck;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceKeyInput;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceKeyInput.Buzzer;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceLcdIndicateRegisteredImage;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceLcdIndicateString;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceLcdSetting;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestBuzzerOn;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceSetting;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceSetting.Language;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestInterruption;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestLcdBackLight;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAck;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAdvanceLcdIndicateRegisteredImage;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAdvanceLcdIndicateString;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAdvanceLcdSetting;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseBuzzerOn;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseDeviceSetting;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseLcdBackLight;
import com.panasonic.avc.smartpayment.devctlservice.share.IHmiServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.hmi.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.hmi.ResponseFuncKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultCancelGetFuncKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultDisconnectBluetooth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultInitHMI;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultPutLCDImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultPutLCDString;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultRequestBuzzerON;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultRequestPowerOFF;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultStartGetFuncKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultUpdateBuzzerMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultUpdateLCDMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultUpdateLEDMode;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;

/**
 * HMI処理部
 */
public class HumanMachineInterface {

    /** @brief ログ出力用タグ */
    private static final String TAG = HumanMachineInterface.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static HumanMachineInterface sInstance = new HumanMachineInterface();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IHmiServiceListener> mIHmiServiceListenerList = new ConcurrentHashMap<String, IHmiServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /** @brief 非同期用スレッド(mStartGetFuncKeyThread) */
    private Thread mStartGetFuncKeyThread;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 5000;

    /** @brief データ読み込み終了フラグ */
    private boolean mIsActive;

    /** @brief startGetFuncKeyの最小タイムアウト時間 */
    private static final int TIMEOUT_MIN = 3;

    /** @brief startGetFuncKeyの最大タイムアウト時間 */
    private static final int TIMEOUT_MAX = 180;

    /** @brief Write時のタイムアウト */
    private static final int FUNC_KEY_TIME_OUT = 500;

    /** @brief 文字セット最小の値 */
    private static final int CHARSET_SJIS = 1;

    /** @brief 文字セット最大の値 */
    private static final int CHARSET_UTF8 = 2;

    /** @brief 文字セット */
    private int mCharset = CHARSET_SJIS;

    /** @brief コンテキスト */
    private Context mContext;

    /**
     * @brief コンストラクタ
     */
    private HumanMachineInterface() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static HumanMachineInterface getInstance() {
        return sInstance;
    }

    /**
     * @brief Hmiプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerHmiServiceListener(String tag, IHmiServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIHmiServiceListenerList) {
            mIHmiServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief Hmiプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterHmiServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIHmiServiceListenerList) {
            mIHmiServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief 機能キー押下待ちを開始します【非同期】
     * @return 実行結果
     */
    public ResultStartGetFuncKey startGetFuncKey(int key, final int timeout) {
        RequestAdvanceKeyInput request = new RequestAdvanceKeyInput(Buzzer.ON, key);
        ResultStartGetFuncKey result = new ResultStartGetFuncKey();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue() || !(TIMEOUT_MIN <= timeout && timeout <= TIMEOUT_MAX)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        if (mIsActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_SEQUENCE_ERROR);
            return result;
        }

        mIsActive = true;
        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }

        ResponseAck ack = new ResponseAck();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            mIsActive = false;
            mControlDeviceManager.unlock();
            return result;
        } else if (!ack.inputPinpadResult(buffer)) {
            result.setDevice(ack.getDevice());
            result.setUpos(ack.getUpos());
            mIsActive = false;
            mControlDeviceManager.unlock();
            return result;
        }

        mStartGetFuncKeyThread = new Thread() {
            @Override
            public void run() {
                if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
                    mControlDeviceManager.unlock();
                    sendError(PluginDefine.ECODE_PORT_ERROR, 0,
                            PluginDefine.ERROR_EXT_CODE_NULL, null);
                    return;
                }

                long start = System.currentTimeMillis();
                while (mIsActive) {

                    byte[] buffer;
                    synchronized (mControlDeviceManager.getLockObject()) {
                        buffer = mControlDeviceManager.read(FUNC_KEY_TIME_OUT);
                    }
                    ResponseFuncKey response = new ResponseFuncKey();

                    if (isTimeout(buffer)) {
                        long end = System.currentTimeMillis();
                        if (timeout * 1000 > (end - start)) {
                            continue;
                        } else {
                            response.setResult(false);
                            cancelGetFuncKey();
                        }
                    } else if (!response.inputPinpadResult(buffer)) {
                        mControlDeviceManager.unlock();
                        sendError(PluginDefine.ECODE_EXT_CODE, 0,
                                PluginDefine.ERROR_EXT_CODE_REJECT, null);
                        mIsActive = false;
                        return;
                    }

                    synchronized (mIHmiServiceListenerList) {
                        for (Map.Entry<String, IHmiServiceListener> listener : mIHmiServiceListenerList
                                .entrySet()) {
                            try {
                                listener.getValue().onFuncKeyEvent(response);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    RequestAck requestAck = new RequestAck();
                    synchronized (mControlDeviceManager.getLockObject()) {
                        mControlDeviceManager.write(requestAck, TIME_OUT);
                    }
                    mIsActive = false;
                    break;
                }
                mControlDeviceManager.unlock();
            }
        };
        mStartGetFuncKeyThread.start();

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief 機能キー押下待ち状態を解除します
     * @return 実行結果
     */
    public ResultCancelGetFuncKey cancelGetFuncKey() {
        final RequestInterruption request = new RequestInterruption();
        ResultCancelGetFuncKey result = new ResultCancelGetFuncKey();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!mIsActive) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mIsActive = false;
        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ディスプレイ関連の設定と最新状態を取得します
     * @param[in] mode 表示モードを指定[論理型]
     * @param[in] lump バックライトの点灯を指定[論理型]
     * @param[in] contrast ディスプレイコントラスト値を指定[整数型]
     * @return 実行結果
     */
    public ResultUpdateLCDMode updateLCDMode(int mode, int lump, int contrast) {
        ResultUpdateLCDMode result = new ResultUpdateLCDMode();

        RequestLcdBackLight requestBacklight = new RequestLcdBackLight(lump);
        RequestDeviceSetting requesDeviceSetting = new RequestDeviceSetting(true,
                (byte) contrast, false, 0, false, Language.JAPANESE);
        RequestAdvanceLcdSetting requestAdvanceLcdSetting = new RequestAdvanceLcdSetting(mode);
        RequestDeviceInformation request = new RequestDeviceInformation();

        ResponseLcdBackLight responseLcdBackLight = new ResponseLcdBackLight();
        ResponseDeviceSetting responseDeviceSetting = new ResponseDeviceSetting();
        ResponseAdvanceLcdSetting responseAdvanceLcdSetting = new ResponseAdvanceLcdSetting();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!requestBacklight.isValidValue() || !requesDeviceSetting.isValidValue()
                || !requestAdvanceLcdSetting.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        if (lump != RequestLcdBackLight.BACKLIGHT_NO_CHANGE) {
            mControlDeviceManager.lock();
            synchronized (mControlDeviceManager.getLockObject()) {
                mControlDeviceManager.write(requestBacklight, TIME_OUT);
                buffer = mControlDeviceManager.read(TIME_OUT);
            }
            mControlDeviceManager.unlock();
            if (isTimeout(buffer)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                return result;
            } else if (!responseLcdBackLight.inputPinpadResult(buffer)) {
                result.setDevice(responseLcdBackLight.getDevice());
                result.setUpos(responseLcdBackLight.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        if (contrast != RequestDeviceSetting.CONTRAST_NO_CHANGE) {
            mControlDeviceManager.lock();
            synchronized (mControlDeviceManager.getLockObject()) {
                mControlDeviceManager.write(requesDeviceSetting, TIME_OUT);
                buffer = mControlDeviceManager.read(TIME_OUT);
            }
            mControlDeviceManager.unlock();
            if (isTimeout(buffer)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                return result;
            } else if (!responseDeviceSetting.inputPinpadResult(buffer)) {
                result.setDevice(responseDeviceSetting.getDevice());
                result.setUpos(responseDeviceSetting.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        if (mode != RequestAdvanceLcdSetting.REVERSE_NO_CHANGE) {
            mControlDeviceManager.lock();
            synchronized (mControlDeviceManager.getLockObject()) {
                mControlDeviceManager.write(requestAdvanceLcdSetting, TIME_OUT);
                buffer = mControlDeviceManager.read(TIME_OUT);
            }
            mControlDeviceManager.unlock();
            if (isTimeout(buffer)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                return result;
            } else if (!responseAdvanceLcdSetting.inputPinpadResult(buffer)) {
                result.setDevice(responseAdvanceLcdSetting.getDevice());
                result.setUpos(responseAdvanceLcdSetting.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();
        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ディスプレイに任意の文字列を表示します
     * @param[in] text 表示したい任意の文字列を指定[文字列型]
     * @param[in] sound 音声案内(音源データ)を指定[整数型]
     * @return 実行結果
     */
    public ResultPutLCDString putLCDString(String text, int sound) {

        ResponseAdvanceLcdIndicateString responseAdvanceLcdIndicateString = new ResponseAdvanceLcdIndicateString();
        ResponseBuzzerOn responseBuzzerOn = new ResponseBuzzerOn();
        ResultPutLCDString result = new ResultPutLCDString();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!((1 <= mCharset) && (mCharset <= 2)) || text == null) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] str;
        try {
            if (mCharset == CHARSET_UTF8) {
                if (!text.equals(new String(text.getBytes("Shift-JIS"), "Shift-JIS"))) {
                    str = new String(text.getBytes("UTF-8"), "Shift-JIS").getBytes();
                } else {
                    str = text.getBytes("Shift-JIS");
                }
            } else {
                str = text.getBytes("Shift-JIS");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        RequestAdvanceLcdIndicateString requestAdvanceLcdIndicateString = new RequestAdvanceLcdIndicateString(
                str);
        RequestBuzzerOn requestBuzzerOn = new RequestBuzzerOn(RequestBuzzerOn.VOLUME_DEFAULT,
                false,
                sound);

        if (!requestAdvanceLcdIndicateString.isValidValue() || !requestBuzzerOn.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(requestAdvanceLcdIndicateString, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!responseAdvanceLcdIndicateString.inputPinpadResult(buffer)) {
            result.setDevice(responseAdvanceLcdIndicateString.getDevice());
            result.setUpos(responseAdvanceLcdIndicateString.getUpos());
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        if (sound != RequestBuzzerOn.SOUND_NO_CHANGE) {
            mControlDeviceManager.lock();
            synchronized (mControlDeviceManager.getLockObject()) {
                mControlDeviceManager.write(requestBuzzerOn, TIME_OUT);
                buffer = mControlDeviceManager.read(TIME_OUT);
            }
            mControlDeviceManager.unlock();

            if (isTimeout(buffer)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                return result;
            } else if (!responseBuzzerOn.inputPinpadResult(buffer)) {
                result.setDevice(responseBuzzerOn.getDevice());
                result.setUpos(responseBuzzerOn.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ディスプレイに指定のビットマップイメージを表示します
     * @param[in] x X 座標(横方向)を 0~159(1 ドット単位)で指定[整数型]
     * @param[in] y Y 座標(縦方向)を 0~9(8 ドット単位)で指定[整数型]
     * @param[in] image ビットマップイメージ番号を指定[整数型]
     * @param[in] sound 音声案内(音源データ)を指定[整数型]
     * @return 実行結果
     */
    public ResultPutLCDImage putLCDImage(int x, int y, int image, int sound) {
        RequestAdvanceLcdIndicateRegisteredImage requestAdvanceLcdIndicateRegisteredImage = new RequestAdvanceLcdIndicateRegisteredImage(
                x, y, image);
        RequestBuzzerOn requestBuzzerOn = new RequestBuzzerOn(RequestBuzzerOn.VOLUME_DEFAULT,
                false,
                sound);

        ResponseAdvanceLcdIndicateRegisteredImage responseAdvanceLcdIndicateRegisteredImage = new ResponseAdvanceLcdIndicateRegisteredImage();
        ResponseBuzzerOn responseBuzzerOn = new ResponseBuzzerOn();
        ResultPutLCDImage result = new ResultPutLCDImage();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!requestAdvanceLcdIndicateRegisteredImage.isValidValue()
                || !requestBuzzerOn.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        if (image != RequestAdvanceLcdIndicateRegisteredImage.IMAGE_NO_NUMBER) {
            mControlDeviceManager.lock();
            synchronized (mControlDeviceManager.getLockObject()) {
                mControlDeviceManager.write(requestAdvanceLcdIndicateRegisteredImage, TIME_OUT);
                buffer = mControlDeviceManager.read(TIME_OUT);
            }
            mControlDeviceManager.unlock();

            if (isTimeout(buffer)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                return result;
            } else if (!responseAdvanceLcdIndicateRegisteredImage.inputPinpadResult(buffer)) {
                result.setDevice(responseAdvanceLcdIndicateRegisteredImage.getDevice());
                result.setUpos(responseAdvanceLcdIndicateRegisteredImage.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        if (sound != RequestBuzzerOn.SOUND_NO_CHANGE) {
            mControlDeviceManager.lock();
            synchronized (mControlDeviceManager.getLockObject()) {
                mControlDeviceManager.write(requestBuzzerOn, TIME_OUT);
                buffer = mControlDeviceManager.read(TIME_OUT);
            }
            mControlDeviceManager.unlock();

            if (isTimeout(buffer)) {
                result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
                return result;
            } else if (!responseBuzzerOn.inputPinpadResult(buffer)) {
                result.setDevice(responseBuzzerOn.getDevice());
                result.setUpos(responseBuzzerOn.getUpos());
                if (isShowError(result.getDevice())) {
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                }
                return result;
            }
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ディスプレイ関連の設定と最新状態を取得します
     * @param[in] mode LED#1、LED#2 の設定を指定[整数型]
     * @return 実行結果
     */
    public ResultUpdateLEDMode updateLEDMode(int[] mode) {
        ResultUpdateLEDMode result = new ResultUpdateLEDMode();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        return result;
    }

    /**
     * @brief ブザーの設定(音量)を行い、設定後の最新状態を取得します
     * @param[in] vol ブザー音量を指定[整数型]
     * @return 実行結果
     */
    public ResultUpdateBuzzerMode updateBuzzerMode(int vol) {
        final RequestDeviceSetting request = new RequestDeviceSetting(false,
                (byte) 0x00, true, vol, false, Language.JAPANESE);

        ResultUpdateBuzzerMode result = new ResultUpdateBuzzerMode();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();
        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ブザー鳴動を要求します
     * @param[in] type ブザー鳴動のパターンを指定[整数型]
     * @return 実行結果
     */
    public ResultRequestBuzzerON requestBuzzerON(int type) {
        return requestBuzzerON(type, RequestBuzzerOn.VOLUME_DEFAULT);
    }

    /**
     * @brief ブザー鳴動を要求します【プライベート】
     * @param[in] type ブザー鳴動のパターンを指定[整数型]
     * @param[in] vol ブザー音量を指定[整数型]
     * @return 実行結果
     */
    public ResultRequestBuzzerON requestBuzzerON(int type, int vol) {
        final RequestBuzzerOn request = new RequestBuzzerOn(vol, true,
                type);

        ResultRequestBuzzerON result = new ResultRequestBuzzerON();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!request.isValidValue()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        byte[] buffer;
        mControlDeviceManager.lock();
        synchronized (mControlDeviceManager.getLockObject()) {
            mControlDeviceManager.write(request, TIME_OUT);
            buffer = mControlDeviceManager.read(TIME_OUT);
        }
        mControlDeviceManager.unlock();

        if (isTimeout(buffer)) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_TIMEOUT);
            return result;
        } else if (!result.inputPinpadResult(buffer)) {
            if (isShowError(result.getDevice())) {
                SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
            }
            return result;
        }

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief Bluetooth の切断を要求します
     * @param[in] mode Bluetooth 切断後の周辺装置の振る舞いを指定[整数型]
     * @return 実行結果
     */
    public ResultDisconnectBluetooth disconnectBluetooth(int mode) {
        ResultDisconnectBluetooth result = new ResultDisconnectBluetooth();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        return result;
    }

    /**
     * @brief 電源 OFF を要求します
     * @return 実行結果
     */
    public ResultRequestPowerOFF requestPowerOFF() {
        ResultRequestPowerOFF result = new ResultRequestPowerOFF();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
        return result;
    }

    /**
     * @brief Plug-Inのパッケージ情報を取得します。周辺装置とのやり取りは発生しません。
     * @param[in] verJs JavaScript部バージョン
     * @param[in] verPlugin CordovaPlugin部バージョン
     * @return 実行結果
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, HumanMachineInterface.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief 周辺装置の各種状態を取得します
     * @return 実行結果
     */
    public ResultCheckHealth checkHealth() {
        ResultCheckHealth result = new ResultCheckHealth();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }
        result.setBattery(ResultCheckHealth.BATTERY_NORMAL);
        result.setPower(true);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief HMI Plug-In を初期化します
     * @return 実行結果
     */
    public ResultInitHMI initHMI(int charset) {
        ResultInitHMI result = new ResultInitHMI();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        if (!((1 <= charset) && (charset <= 2))) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            return result;
        }

        mCharset = charset;

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @brief エラーを送信する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private void sendError(int ecode, int vcode, int extcode, String extinfo) {
        ResponseError error = new ResponseError();
        error.setEcode(ecode);
        error.setVcode(vcode);
        error.setExtcode(extcode);
        error.setExtinfo(extinfo);

        synchronized (mIHmiServiceListenerList) {
            for (Map.Entry<String, IHmiServiceListener> listener : mIHmiServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(error);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * エラーアイコン表示確認
     * 
     * @param device deviceの値
     * @retval true 表示
     * @retval false 非表示
     */
    private boolean isShowError(int device) {
        if (device != PluginDefine.RESULT_DEVICE_SCCESS) {
            return true;
        }

        return false;
    }

    /**
     * コンテキストを設定する
     * 
     * @param context コンテキスト
     */
    public void setContext(Context context) {
        mContext = context;
    }

}
