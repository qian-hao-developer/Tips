package com.panasonic.avc.smartpayment.pf.devicemonitor;

import android.os.RemoteException;
import android.os.SystemProperties;
import android.util.Log;

public class DeviceMonitorManager {
    public static final boolean DEBUG = SystemProperties.getBoolean("persist.sys.devmon.debug", false);
    private static String TAG = "DeviceMonitor:Manager";

    public static final String SERVICE_NAME = "DeviceMonitorService";
    private static IDeviceMonitorService mIDeviceMonitorService = null;

    /**
     * 制御対象デバイス:プリンタカバー
     */
    public static final int DEVICE_ID_PRINTER_COVER           = 0;

    /**
     * デバイス監視サービス起動通知のブロードキャストインテント名
     */
    public static final String ACTION_DEVICE_MONITOR_STARTED  = "com.panasonic.avc.smartpayment.pf.devicemonitor.DEVICE_MONITOR_STARTED";

    /**
     * デバイス状態変化通知のブロードキャストインテント名
     */
    public static final String ACTION_DEVICE_STATUS_CHANGED   = "com.panasonic.avc.smartpayment.pf.devicemonitor.DEVICE_STATUS_CHANGED";

    /**
     * ACTION_DEVICE_STAUS_CHANGEDの付加情報。デバイス状態をint型で格納する。
     * 対応するvalueはPRINTER_COVER_OPENED,PRINTER_COVER_CLOSED
     */
    public static final String EXTRA_PRINTER_COVER            = "printer_cover";

    /**
     * プリンタカバー状態:開き
     */
    public static final int PRINTERCOVER_OPENED               = 1;

    /**
     * プリンタカバー状態:閉じ
     */
    public static final int PRINTERCOVER_CLOSED               = 0;


    public DeviceMonitorManager() {
    }

    private static IDeviceMonitorService getService() {
        if (mIDeviceMonitorService != null) {
            if(DEBUG) {Log.d(TAG, "already connect to DeviceMonitorService.");}
            return mIDeviceMonitorService;
        }
        mIDeviceMonitorService = IDeviceMonitorService.Stub.asInterface(android.os.ServiceManager.getService(SERVICE_NAME));
        if(DEBUG) {Log.d(TAG, "connect to DeviceMonitorService.");}
        return mIDeviceMonitorService;
    }

    /**
     * デバイスの監視を開始する
     *
     * @param deviceId:制御対象のデバイスID
     * @retval 成功 true
     * @retval 失敗 false
     */
    public boolean startMonitoring(int deviceId) {
        if(DEBUG) {Log.d(TAG, "startMonitoring invoked");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return false;
        }
        try {
            return mIDeviceMonitorService.startMonitoring(deviceId);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return false;
    }

    /**
     * デバイスの監視を停止する
     *
     * @param deviceId:制御対象のデバイスID
     * @retval 成功 true
     * @retval 失敗 false
     */
    public boolean stopMonitoring(int deviceId) {
        if(DEBUG) {Log.d(TAG, "stopMonitoring invoked");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return false;
        }
        try {
            return mIDeviceMonitorService.stopMonitoring(deviceId);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return false;
    }

    /**
     * タンパ予兆回数をログに残す
     *
     * @param count:タンパ予兆回数
     * @retval 成功 true
     * @retval 失敗 false
     */
    public boolean setTamperIndicationCount(int count) {
        if(DEBUG) {Log.d(TAG, "setTamperIndicationCount invoked");}
        if(getService() == null) {
            Log.e(TAG, "Connecting to service is failed");
            return false;
        }
        try {
            return mIDeviceMonitorService.setTamperIndicationCount(count);
        } catch (RemoteException ex) {
            Log.e(TAG, "Service IPC failed", ex);
        }
        return false;
    }
}
