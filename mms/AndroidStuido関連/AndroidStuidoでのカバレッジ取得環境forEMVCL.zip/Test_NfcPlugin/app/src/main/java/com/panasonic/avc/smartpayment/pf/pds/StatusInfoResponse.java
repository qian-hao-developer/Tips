package com.panasonic.avc.smartpayment.pf.pds;

import java.util.Date;
import android.util.Log;
import android.os.Parcel;
import android.os.Parcelable;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class StatusInfoResponse implements Parcelable{
    private static final boolean DEBUG = PdsClientManager.DEBUG;
    private static final String TAG = "StatusInfoResponse";

    public static final int APPLY_MODE_NONE   = 0;
    public static final int APPLY_MODE_NORMAL = 1;
    public static final int APPLY_MODE_FORCE  = 2;

    public static final int CODE_SUCCESS                = 0;
    public static final int CODE_PARSE_ERROR            = 10;
    public static final int CODE_PARAMETER_ERROR        = 11;
    public static final int CODE_FORMAT_ERROR           = 12;
    public static final int CODE_TERMINAL_ID_ERROR      = 20;
    public static final int CODE_PRODUCT_ERROR          = 30;
    public static final int CODE_CONTRACT_UNKNOWN       = 31;
    public static final int CODE_CONTRACT_CANCELD       = 32;
    public static final int CODE_CONTRACT_NOT_SET       = 33;
    public static final int CODE_LOG_INVALID_SESSION    = 40;
    public static final int CODE_LOG_STATUS_NOT_WAIT    = 41;
    public static final int CODE_LOG_STATUS_NOT_RECIEVE = 42;
    public static final int CODE_LOG_SIZE_OVER          = 43;
    public static final int CODE_LOG_NO_SPACE           = 44;
    public static final int CODE_LOG_SYSTEM_ERROR       = 90;
    public static final int CODE_SERVER_ERROR           = 500; /* http response error */
    public static final int CODE_TIME_OUT               = 600; /* http timeout error  */
    public static final int CODE_INTERNAL_ERROR         = 900;

    private int mApplyMode;
    private String mCampaignName; 
    private String mUnified;
    private String mMessage;
    private Date mCampaignEndDate;
    private Date mCampaignStartDate;
    private int mPdsErrorCode;

    public StatusInfoResponse() {
        mApplyMode = APPLY_MODE_NONE;
        mCampaignName = null;
        mUnified = null;
        mMessage = null;
        mCampaignEndDate = null;
        mCampaignStartDate = null;
        mPdsErrorCode = CODE_SUCCESS;
    }

    public StatusInfoResponse(int applyMode, String campaignName, String unified,
                              String message, Date campaignEndDate, Date campaignStartDate) {
        mApplyMode = applyMode;
        mCampaignName = campaignName;
        mUnified = unified;
        mMessage = message;
        mCampaignEndDate = campaignEndDate;
        mCampaignStartDate = campaignStartDate;
        mPdsErrorCode = CODE_SUCCESS;
    }

    public StatusInfoResponse(int pdsErrorCode) {
        mApplyMode = APPLY_MODE_NONE;
        mCampaignName = null;
        mUnified = null;
        mMessage = null;
        mCampaignEndDate = null;
        mCampaignStartDate = null;
        mPdsErrorCode = pdsErrorCode;
    }

    /**
     * PDSのエラーコードを取得する
     *
     * return PDSのエラーコード
     */
    public int getPdsErrorCode() {
        return mPdsErrorCode;
    }

    /**
     * 更新モードを取得する
     *
     * return 更新モード
     */
    public int getApplyMode() {
        return mApplyMode;
    }

    /**
     * 配信依頼IDを取得する
     *
     * retval 成功 更新依頼ID
     * retval 失敗 null
     */
    public String getCampaignName() {
        return mCampaignName;
    }

    /**
     * 統一バージョンを取得する
     *
     * retval 統一バージョン
     * retval ファームウェア更新なしの場合はnullを返す
     */
    public String getUnified() {
        return mUnified;
    }

    /**
     * 端末表示メッセージを取得する
     *
     * retval 端末表示メッセージ
     * retval ファームウェア更新なしの場合はnullを返す
     */
    public String getMessage() {
        return mMessage;
    }

    /**
     * 配信終了日時を取得する
     *
     * retval 配信終了日時
     * retval ファームウェア更新なしの場合はnullを返す
     */
    public Date getCampaignEndDate() {
        return mCampaignEndDate;
    }

    /**
     * 配信開始日時を取得する
     *
     * retval 配信開始日時
     * retval ファームウェア更新なしの場合はnullを返す
     */
    public Date getCampaignStartDate() {
        return mCampaignStartDate;
    }

    public boolean load(SharedPreferences preference) {
        if(DEBUG) {Log.d(TAG, "load");}
        mApplyMode = preference.getInt("applyMode", APPLY_MODE_NONE);
        mCampaignName = preference.getString("campaignName", "");
        mUnified = preference.getString("unified", "");
        mMessage = preference.getString("message", "");
        long endDate = preference.getLong("campaignEndDate", 0);
        long startDate = preference.getLong("campaignStartDate", 0);
        if(endDate != 0) {
            mCampaignEndDate = new Date(endDate);
        } else {
            mCampaignEndDate = null;
        }
        if(startDate != 0) {
            mCampaignStartDate = new Date(startDate);
        } else {
            mCampaignStartDate = null;
        }
        mPdsErrorCode = preference.getInt("pdsErrorCode", CODE_SUCCESS);

        return true;
    }

    public boolean save(SharedPreferences preference) {
        if(DEBUG) {Log.d(TAG, "save");}
        Editor editor = preference.edit();
        editor.putInt("applyMode", mApplyMode);
        editor.putString("campaignName", mCampaignName);
        editor.putString("unified", mUnified);
        editor.putString("message", mMessage);
        if(mCampaignEndDate != null) {
            editor.putLong("campaignEndDate", mCampaignEndDate.getTime());
        } else {
            editor.putLong("campaignEndDate", 0);
        }
        if(mCampaignStartDate != null) {
            editor.putLong("campaignStartDate", mCampaignStartDate.getTime());
        } else {
            editor.putLong("campaignStartDate", 0);
        }
        editor.putInt("pdsErrorCode", mPdsErrorCode);

        return editor.commit();
    }

    @Override
    public String toString(){
        String mode[] = {"NONE","NORMAL","FORCE"};
        return "StatusInfoResponse:"
            +"\n========================================"
            +"\n    applyMode:"+mode[mApplyMode]
            +"\n    campaignName:"+mCampaignName
            +"\n    unified:"+mUnified
            +"\n    message:"+mMessage
            +"\n    campaignEndDate:"+((mCampaignEndDate==null)?"":mCampaignEndDate.toString())
            +"\n    campaignStartDate:"+((mCampaignStartDate==null)?"":mCampaignStartDate.toString())
            +"\n    pdsErrorCode:"+mPdsErrorCode
            +"\n========================================";
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(mApplyMode);
        out.writeString(mCampaignName);
        out.writeString(mUnified);
        out.writeString(mMessage);
        if(mCampaignEndDate != null) {
            out.writeLong(mCampaignEndDate.getTime());
        } else {
            out.writeLong(0);
        }
        if(mCampaignStartDate != null) {
            out.writeLong(mCampaignStartDate.getTime());
        } else {
            out.writeLong(0);
        }
        out.writeInt(mPdsErrorCode);
   }

    private StatusInfoResponse(Parcel in) {
        mApplyMode = in.readInt();
        mCampaignName = in.readString();
        mUnified = in.readString();
        mMessage = in.readString();
        long endDate = in.readLong();
        long startDate = in.readLong();
        if(endDate != 0) {
            mCampaignEndDate = new Date(endDate);
        } else {
            mCampaignEndDate = null;
        }
        if(startDate != 0) {
        mCampaignStartDate = new Date(startDate);
        } else {
            mCampaignStartDate = null;
        }
        mPdsErrorCode = in.readInt();
    }

    public static final Parcelable.Creator<StatusInfoResponse> CREATOR = new Parcelable.Creator<StatusInfoResponse>() {
        @Override
        public StatusInfoResponse createFromParcel(Parcel in) {
            return new StatusInfoResponse(in);
        }

        @Override
        public StatusInfoResponse[] newArray(int size) {
            return new StatusInfoResponse[size];
        }
    };

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + mApplyMode;
        result = prime * result + ((mCampaignEndDate == null) ? 0 : mCampaignEndDate.hashCode());
        result = prime * result + ((mCampaignName == null) ? 0 : mCampaignName.hashCode());
        result = prime * result
            + ((mCampaignStartDate == null) ? 0 : mCampaignStartDate.hashCode());
        result = prime * result + ((mMessage == null) ? 0 : mMessage.hashCode());
        result = prime * result + mPdsErrorCode;
        result = prime * result + ((mUnified == null) ? 0 : mUnified.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        StatusInfoResponse other = (StatusInfoResponse) obj;
        if (mApplyMode != other.mApplyMode)
            return false;
        if (mCampaignEndDate == null) {
            if (other.mCampaignEndDate != null)
                return false;
        } else if (!mCampaignEndDate.equals(other.mCampaignEndDate))
            return false;
        if (mCampaignName == null) {
            if (other.mCampaignName != null)
                return false;
        } else if (!mCampaignName.equals(other.mCampaignName))
            return false;
        if (mCampaignStartDate == null) {
            if (other.mCampaignStartDate != null)
                return false;
        } else if (!mCampaignStartDate.equals(other.mCampaignStartDate))
            return false;
        if (mMessage == null) {
            if (other.mMessage != null)
                return false;
        } else if (!mMessage.equals(other.mMessage))
            return false;
        if (mPdsErrorCode != other.mPdsErrorCode)
            return false;
        if (mUnified == null) {
            if (other.mUnified != null)
                return false;
        } else if (!mUnified.equals(other.mUnified))
            return false;
        return true;
    }
}
