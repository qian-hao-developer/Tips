
package com.panasonic.avc.smartpayment.devctlservice.contesnts;

/**
 * 管理用データクラス
 */
public class ManagementData {

    /** 印字濃度 **/
    private int mDensity;

    /** フォントサイズ **/
    private int mFont;

    /** カット種類 **/
    private int mSlip;

    /**
     * 印字濃度取得
     * 
     * @return 印字濃度
     */
    public int getDensity() {
        return mDensity + 1;
    }

    /**
     * 印字濃度設定
     * 
     * @param density 印字濃度
     */
    public void setDensity(int density) {
        mDensity = density;
    }

    /**
     * フォント種別を取得する
     * 
     * @return フォント種別
     */
    public boolean getFont() {
        return mFont == 1 ? true : false;
    }

    /**
     * フォント種別を設定する
     * 
     * @param font フォント
     */
    public void setFont(int font) {
        mFont = font;
    }

    /**
     * カット種別を取得する
     * 
     * @return カット種別を取得する
     */
    public int getSlip() {
        return mSlip + 1;
    }

    /**
     * カット種別を設定する
     * 
     * @param slip カット種別
     */
    public void setSlip(int slip) {
        mSlip = slip;
    }

}
