
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetInformation extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x08;

    private static final int LENGTH = 17;

    private static final String MODEL = "model";

    private String mModel;

    private static final String FIRMWARE = "firmware";

    private String mFirmware;

    public ResponseGetInformation(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        byte[] buffer = new byte[9];

        System.arraycopy(result, 1, buffer, 0, buffer.length);
        mModel = CalcUtil.toAscii(buffer);
        mFirmware = String.format("%02x", result[13]);
        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(MODEL, mModel);
            json.put(FIRMWARE, mFirmware);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
}
