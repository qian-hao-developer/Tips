
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * DeactivationIcc処理結果データ
 */
public class ResultDeactivationIcc extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultDeactivationIcc(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultDeactivationIcc() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultDeactivationIcc> CREATOR = new Parcelable.Creator<ResultDeactivationIcc>() {
        public ResultDeactivationIcc createFromParcel(Parcel in) {
            return new ResultDeactivationIcc(in);
        }

        public ResultDeactivationIcc[] newArray(int size) {
            return new ResultDeactivationIcc[size];
        }
    };
}
