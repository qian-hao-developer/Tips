
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * カード状態確認コマンド
 */
public class RequestIcCardStatus extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x05;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x02;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 8;

    /**
     * @brief コンストラクタ
     */
    public RequestIcCardStatus() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);
        parameter[2] = (byte) 0x00;
        parameter[3] = (byte) 0x00;
        parameter[4] = (byte) 0x00;
        parameter[5] = (byte) 0x00;
        parameter[6] = (byte) 0x00;
        parameter[7] = (byte) 0x00;

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }
}
