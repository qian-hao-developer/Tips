
package com.panasonic.avc.smartpayment.devctlservice.share.response.pos;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * event_ReceivePOSのコールバックデータ
 */
public class ResponseReceivePOS implements Parcelable {
    /** @brief 受信データサイズ */
    private int mDataSize;

    /** @brief 受信データ */
    private String mData;

    /** @brief 受信データサイズ情報タグ */
    private static final String DATASZ = "datasz";

    /** @brief 受信データ情報タグ */
    private static final String DATA = "data";

    /**
     * @brief コンストラクタ
     * @param datasz 受信データサイズ
     * @param data 受信データ
     */
    public ResponseReceivePOS(int datasz, String data) {
        mDataSize = datasz;
        mData = data;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseReceivePOS() {

    }

    /**
     * @brief コンストラクタ
     */
    public ResponseReceivePOS(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResponseReceivePOS> CREATOR = new Parcelable.Creator<ResponseReceivePOS>() {
        public ResponseReceivePOS createFromParcel(Parcel in) {
            return new ResponseReceivePOS(in);
        }

        public ResponseReceivePOS[] newArray(int size) {
            return new ResponseReceivePOS[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mDataSize);
        dest.writeString(mData);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mDataSize = in.readInt();
        mData = in.readString();
    }

    /**
     * @brief 受信データサイズを取得します
     * @return 受信データサイズ
     */
    public int getDataSize() {
        return mDataSize;
    }

    /**
     * @brief 受信データサイズを設定します
     * @param result 受信データサイズ
     */
    public void setDataSize(int datasz) {
        mDataSize = datasz;
    }

    /**
     * @brief 受信データを取得します
     * @return 受信データ
     */
    public String getData() {
        return mData;
    }

    /**
     * @brief 受信データを設定します
     * @param result 受信データ
     */
    public void setData(String data) {
        mData = data;
    }

    public boolean inputPinpadResult(byte[] bytes) {

        mData = CalcUtil.toHexString(bytes);
        if (mData == null) {
            mDataSize = 0;
            return false;
        }
        mDataSize = mData.length() / 2;

        return true;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DATASZ, getDataSize());
            json.put(DATA, getData());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
