package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DOWNLOAD_END_RESPONSE;

/**
 * ダウンロード終了BaseResponseクラス.
 * 
 */
public class BaseDownloadEndResponse extends BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = BaseDownloadEndResponse.class.getSimpleName();

    /** @brief MC */
    protected byte mMainCommand = (byte) 0x01;
    /** @brief SC */
    protected byte mSubCommand = (byte) 0x82;

    /** @brief データ長データ2桁目(LittleEndian) */
    private static byte DATALENGTH_HIGH = (byte) 0x08;
    /** @brief データ長データ1桁目(LittleEndian) */
    private static byte DATALENGTH_LOW = (byte) 0x00;

    /** @brief APダウンロード終了処理待ち時間. */
    private byte[] mDownloadTime;

    /**
     * set McSc
     * @param mc MC
     * @param sc SC
     */
    protected void setMCSC(byte mc, byte sc) {
        mMainCommand = mc;
        mSubCommand = sc;
    }

    /**
     * APダウンロード 終了処理待ち時間を返却する.
     * 
     * @return APダウンロード終了処理待ち時間
     */
    public byte[] getDownloadTime() {
        return mDownloadTime;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {  // PT_IMPOSSIBLE_BRANCH
            return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return (cutDeviceResult(bytes) != null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != mMainCommand) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND mismatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != mSubCommand) {
            Logger.e(TAG, "checkResponseData SUBCOMMAND mismatch = "
                    + bytes[SUBCOMMAND_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHHIGH_INDEX] != DATALENGTH_HIGH) {
            Logger.e(TAG, "checkResponseData DATALENGTH_HIGH mismatch = "
                    + bytes[DATALENGTHHIGH_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHLOW_INDEX] != DATALENGTH_LOW) {
            Logger.e(TAG, "checkResponseData DATALENGTH_LOW mismatch = "
                    + bytes[DATALENGTHLOW_INDEX]);
            return false;
        }

        DOWNLOAD_END_RESPONSE[] dataConstArray = DOWNLOAD_END_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        // データ部順の配列を順次処理する
        for (DOWNLOAD_END_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* APダウンロード終了処理待ち時間(予備扱い) */
            case DOWNLOADTIME:
                // チェック不要
                break;

            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ格納を行う
        DOWNLOAD_END_RESPONSE[] dataConstArray = DOWNLOAD_END_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (DOWNLOAD_END_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* ダウンロード終了処理待ち時間 */
            case DOWNLOADTIME:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mDownloadTime = checkByteArray;
                break;
            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return bytes;
    }
}
