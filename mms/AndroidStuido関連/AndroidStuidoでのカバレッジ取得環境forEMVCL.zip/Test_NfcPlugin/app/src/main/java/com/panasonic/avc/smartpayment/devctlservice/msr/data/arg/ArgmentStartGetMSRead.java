
package com.panasonic.avc.smartpayment.devctlservice.msr.data.arg;

/**
 * InitMSR引数用クラス
 */
public class ArgmentStartGetMSRead {
    /** @brief 読み取り対象とするデータ指定 */
    int mMode;

    /** @brief 磁気カード読み取り待ちタイムアウト(秒)_ */
    int mTimeout;

    /**
     * @brief コンストラクタ
     * @param[in] mode 読み取り対象とするデータ指定
     * @param[in] timeout 磁気カード読み取り待ちタイムアウト(秒)_
     */
    public ArgmentStartGetMSRead(int mode, int timeout) {
        mMode = mode;
        mTimeout = timeout;
    }

    /**
     * @brief 読み取り対象とするデータ指定を取得します
     * @return 読み取り対象とするデータ指定
     */
    public int getMode() {
        return mMode;
    }

    /**
     * @brief 読み取り対象とするデータ指定を設定します
     * @param 読み取り対象とするデータ指定
     */
    public void setMode(int mode) {
        mMode = mode;
    }

    /**
     * @brief 磁気カード読み取り待ちタイムアウト(秒)を取得します
     * @return 磁気カード読み取り待ちタイムアウト(秒)
     */
    public int getTimeout() {
        return mTimeout;
    }

    /**
     * @brief 磁気カード読み取り待ちタイムアウト(秒)を設定します
     * @param 磁気カード読み取り待ちタイムアウト(秒)
     */
    public void setTimeout(int timeout) {
        mTimeout = timeout;
    }

}
