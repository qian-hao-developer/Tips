package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

/**
 * コマンドデータ定数クラス
 */
public class CommandDataConstants {

    /** DEBUG */
    public static final boolean DEBUG = false;
    /** ID INDEX except for such as STX*/
    public static final int ID_INDEX = 0;
    /** MC INDEX except for such as STX*/
    public static final int MAINCOMMAND_INDEX = ID_INDEX + 1;
    /** SC INDEX except for such as STX*/
    public static final int SUBCOMMAND_INDEX = MAINCOMMAND_INDEX + 1;
    /** Len high INDEX except for such as STX*/
    public static final int DATALENGTHHIGH_INDEX = SUBCOMMAND_INDEX + 1;
    /** Len low INDEX except for such as STX*/
    public static final int DATALENGTHLOW_INDEX = DATALENGTHHIGH_INDEX + 1;
    /** Data size except for such as STX*/
    public static final int DATA_SIZE_WITHOUT_PARAMETER = DATALENGTHLOW_INDEX + 1;
    /** Data INDEX size except for such as STX*/
    public static final int DATA_INDEX = DATA_SIZE_WITHOUT_PARAMETER;

    /** STX INDEX */
    public static final int STX_INDEX            = 0;
    /** CRC Low reverse INDEX */
    public static final int CRC_LOW_INDEX_REV    = 1;
    /** CRC Low reverse INDEX */
    public static final int CRC_HIGH_INDEX_REV   = 2;
    /** ETX reverse INDEX */
    public static final int ETX_INDEX_REV        = 3;

    /** Data size with prifix */
    public static final int DATA_SIZE_PRIFIX  = 6;
    /** Data size with postfix */
    public static final int DATA_SIZE_POSTFIX = 3;
    /** Data size with header */
    public static final int DATA_SIZE_HEADER  = 5;

    /** STX value */
    public static final byte STX = 02;
    /** ETX value */
    public static final byte ETX = 03;

    /**
     * calculate CRC
     * @param bytes calculation target bytes
     * @return process result
     */
    public static int calcCRC(byte[] bytes) {
        long shiftCRC;
        int crc = 0x0000;
        byte tmp;
        for (int i = 0; i < bytes.length; i++) {
            shiftCRC = crc;
            tmp = bytes[i];
            for (int j = 0; j < 8; j++) {
                if (((tmp ^ shiftCRC) & 1) > 0) {
                    shiftCRC ^= (0x8408 << 1);
                }
                shiftCRC >>= 1;
                tmp >>= 1;
            }
            crc = (int) shiftCRC;
        }
        return crc;
    }

    /**
     * print byte data
     * @param data byte data
     * @param tag Log tag
     */
    public static void printByte(byte[] data, String tag) {
        if (!DEBUG)
            return;
        String dmp = "";  // PT_IMPOSSIBLE_INSTRUCTIONS
        for (int lp = 0; lp < data.length; lp++) {  // PT_IMPOSSIBLE_INSTRUCTIONS
            dmp = dmp.concat(String.format("%02X ", data[lp]));  // PT_IMPOSSIBLE_INSTRUCTIONS
            if ((lp % 16) == 15) {  // PT_IMPOSSIBLE_INSTRUCTIONS
                dmp = dmp.concat("\n");  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
        }
        Logger.d(tag, dmp);  // PT_IMPOSSIBLE_INSTRUCTIONS
    }
}
