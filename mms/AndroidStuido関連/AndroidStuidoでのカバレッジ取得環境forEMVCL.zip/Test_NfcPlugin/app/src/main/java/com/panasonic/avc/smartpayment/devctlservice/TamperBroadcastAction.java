
package com.panasonic.avc.smartpayment.devctlservice;

/**
 * @see タンパ用Broadcastアクション
 */
public class TamperBroadcastAction {

    /** @brief タンパアクション **/
    static final String ACTION_TAMPER_ALARM = "android.intent.action.TAMPER_ALARM";

}
