
package com.panasonic.avc.smartpayment.devctlservice.share.response.ped;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * PINデータ通知イベントクラス
 */
public class ResponsePinData extends ResponseData implements Parcelable {

    /** @brief トレーニングモード tag */
    private static final String TRAINING = "training";

    /** @brief PIN入力情報 tag */
    private static final String RESULT = "result";

    /** @brief PIN入力オプション tag */
    private static final String PINTYPE = "pintype";

    /** @brief 暗号化されたPINデータの16進文字列 tag */
    private static final String PINDATA = "pindata";

    /** @brief ICカード応答 tag */
    private static final String SW = "sw";

    /** @brief PINデータ暗号に使用したDUKPT情報 tag */
    private static final String KSN = "ksn";

    /** @brief トレーニングモード */
    private boolean mTraining;

    /** @brief PIN入力情報 */
    private int mResult;

    /** @brief PIN入力オプション */
    private int mPintype;

    /** @brief 暗号化されたPINデータの16進文字列 */
    private String mPindata;

    /** @brief ICカード応答（Verifyコマンドに対する応答）のStatusWord部（4桁の文字列） */
    private String mSw;

    /** @brief PINデータ暗号に使用したDUKPT情報（80ビット）の16進文字列 */
    private String mKsn;

    /** @brief 暗証番号入力OK(パラメータ有り) */
    private static final int PINPAD_RESULT_OK_PARAM = 0x00;

    /** @brief 暗証番号入力OK(パラメータなし) */
    private static final int PINPAD_RESULT_OK_NO_PARAM = 0x01;

    /** @brief 暗証番号入力OK(バイパス) */
    private static final int PINPAD_RESULT_OK_BY_PASS = 0x02;

    /** @brief 暗証番号入力中止(キャンセル押下) */
    private static final int PINPAD_RESULT_SUSPENSION_CANCEL = 0x03;

    /** @brief 暗証番号入力中止(PIN入力制限回数オーバー) */
    private static final int PINPAD_RESULT_SUSPENSION_PIN_OVER = 0x04;

    /** @brief 暗証番号入力中止(60秒タイムアウト) */
    private static final int PINPAD_RESULT_SUSPENSION_TIMEOUT_60s = 0x05;

    /** @brief 暗証番号入力中止(210秒タイムアウト) */
    private static final int PINPAD_RESULT_SUSPENSION_TIMEOUT_210s = 0x06;

    /** @brief 確定キー押下 */
    private static final int PLUGIN_ENTER = 0x01;

    /** @brief 取り消しキー押下 */
    private static final int PLUGIN_CANCEL = 0x02;

    /** @brief PIN入力規制 */
    private static final int PLUGIN_PIN_OVER = 0x03;

    /** @brief PIN入力タイムアウト */
    public static final int PLUGIN_TIMEOUT = 0x04;

    /**
     * @brief コンストラクタ
     */
    public ResponsePinData() {
        setTraining(false);
        setResult(0);
        setPintype(0);
        setPindata(null);
        setSw(null);
        setKsn(null);
    }

    /**
     * @brief コンストラクタ
     * @param[in] training トレーニングモード（論理型）
     * @param[in] result PIN入力情報（整数型）
     * @param[in] pintype PIN入力オプション（整数型）
     * @param[in] pindata 暗号化されたPINデータの16進文字列
     * @param[in] sw ICカード応答（Verifyコマンドに対する応答）のStatusWord部（4桁の文字列）
     * @param[in] ksn PINデータ暗号に使用したDUKPT情報（80ビット）の16進文字列
     */
    public ResponsePinData(boolean training, int result, int pintype, String pindata, String sw,
            String ksn) {
        setTraining(training);
        setResult(result);
        setPintype(pintype);
        setPindata(pindata);
        setSw(sw);
        setKsn(ksn);
    }

    /**
     * @brief コンストラクタ
     * @param[in] source Parcelデータ
     */
    public ResponsePinData(Parcel source) {
        readFromParcel(source);
    }

    /**
     * @brief トレーニングモードを取得します
     * @return mTraining トレーニングモード
     */
    public boolean getTraining() {
        return mTraining;
    }

    /**
     * @brief トレーニングモードを設定します
     * @param[in] mTraining トレーニングモード
     */
    public void setTraining(boolean mTraining) {
        this.mTraining = mTraining;
    }

    /**
     * @brief PIN入力情報を取得します
     * @return mResult PIN入力情報
     */
    public int getResult() {
        return mResult;
    }

    /**
     * @brief PIN入力情報を設定します
     * @param[in] mResult PIN入力情報
     */
    public void setResult(int mResult) {
        this.mResult = mResult;
    }

    /**
     * @brief PIN入力オプションを取得します
     * @return mPintype PIN入力オプション
     */
    public int getPintype() {
        return mPintype;
    }

    /**
     * @brief PIN入力オプションを設定します
     * @param[in] mPintype PIN入力オプション
     */
    public void setPintype(int mPintype) {
        this.mPintype = mPintype;
    }

    /**
     * @brief 暗号化されたPINデータの16進文字列を取得します
     * @return mPindata 暗号化されたPINデータの16進文字列
     */
    public String getPindata() {
        return mPindata;
    }

    /**
     * @brief 暗号化されたPINデータの16進文字列を設定します
     * @param[in] mPindata 暗号化されたPINデータの16進文字列
     */
    public void setPindata(String mPindata) {
        this.mPindata = mPindata;
    }

    /**
     * @brief ICカード応答を取得します
     * @return mSw ICカード応答
     */
    public String getSw() {
        return mSw;
    }

    /**
     * @brief ICカード応答を設定します
     * @param[in] mSw ICカード応答
     */
    public void setSw(String mSw) {
        this.mSw = mSw;
    }

    /**
     * @brief PINデータの暗号化に使用したDUKPT情報を取得します
     * @return mKsn DUKPT情報
     */
    public String getKsn() {
        return mKsn;
    }

    /**
     * @brief PINデータの暗号化に使用したDUKPT情報を設定します
     * @param[in] mKsn DUKPT情報
     */
    public void setKsn(String mKsn) {
        this.mKsn = mKsn;
    }

    /**
     * @see ResponseData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            if (this.mTraining) {
                json.put(TRAINING, this.mTraining);
                json.put(RESULT, JSONObject.NULL);
                json.put(PINTYPE, JSONObject.NULL);
                json.put(PINDATA, JSONObject.NULL);
                json.put(SW, JSONObject.NULL);
                json.put(KSN, JSONObject.NULL);
            } else {
                json.put(TRAINING, this.mTraining);
                json.put(RESULT, this.mResult);
                json.put(PINTYPE, this.mPintype);
                if (mResult == PLUGIN_ENTER) {
                    json.put(PINDATA, mPindata != null ? mPindata : JSONObject.NULL);
                    json.put(SW, mSw != null ? mSw : JSONObject.NULL);
                    json.put(KSN, mKsn != null ? mKsn : JSONObject.NULL);
                } else {
                    json.put(PINDATA, JSONObject.NULL);
                    json.put(SW, JSONObject.NULL);
                    json.put(KSN, JSONObject.NULL);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[],byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        // メインコマンド
        @SuppressWarnings("unused")
        int master = buffer[PinpadDefine.INDEX_MC];

        // サブコマンド
        @SuppressWarnings("unused")
        int sub = buffer[PinpadDefine.INDEX_SC];

        // 処理結果
        int result = buffer[PinpadDefine.INDEX_PARAMETER];

        if ((result == PINPAD_RESULT_OK_PARAM) || (result == PINPAD_RESULT_OK_NO_PARAM)
                || (result == PINPAD_RESULT_OK_BY_PASS)) {
            mResult = PLUGIN_ENTER;
        } else if (result == PINPAD_RESULT_SUSPENSION_CANCEL) {
            mResult = PLUGIN_CANCEL;
        } else if (result == PINPAD_RESULT_SUSPENSION_PIN_OVER) {
            mResult = PLUGIN_PIN_OVER;
        } else if ((result == PINPAD_RESULT_SUSPENSION_TIMEOUT_60s)
                || (result == PINPAD_RESULT_SUSPENSION_TIMEOUT_210s)) {
            mResult = PLUGIN_TIMEOUT;
        } else {
            return false;
        }

        if (mResult == PLUGIN_ENTER) {
            if (buffer.length < PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER + 9) {
                return false;
            }
        } else {
            return true;
        }

        // PINPAD 状態
        @SuppressWarnings("unused")
        int status = buffer[PinpadDefine.INDEX_PARAMETER + 1];

        if (result == PINPAD_RESULT_OK_PARAM) {
            // PIN 出力 TAG あり
            if (!inputPinOutputTag(buffer)) {
                return false;
            }
        } else {
            // PIN 出力 TAG なし
            mPindata = null;
            mKsn = null;
        }

        mSw = null;

        return true;
    }

    /**
     * 「PIN 出力 TAG」からデータクラスに反映する
     * 
     * @param buffer
     */
    private boolean inputPinOutputTag(byte[] buffer) {

        // 配列要素位置 - PIN出力TAG
        final int INDEX_PIN_OUTPUT_TAG = PinpadDefine.INDEX_PARAMETER + 2;

        // 配列要素位置 - PIN出力TAGサイズ(low)
        final int INDEX_PIN_OUTPUT_TAG_LEN_1 = PinpadDefine.INDEX_PARAMETER + 3;

        // 配列要素位置 - PIN出力TAGサイズ(high)
        final int INDEX_PIN_OUTPUT_TAG_LEN_2 = PinpadDefine.INDEX_PARAMETER + 4;

        // 配列要素位置 - PIN出力サイズ(low)
        final int INDEX_PIN_OUTPUT_LEN_1 = PinpadDefine.INDEX_PARAMETER + 5;

        // 配列要素位置 - PIN出力サイズ(high)
        final int INDEX_PIN_OUTPUT_LEN_2 = PinpadDefine.INDEX_PARAMETER + 6;

        // PIN出力TAG(1バイト) 0x40 固定
        @SuppressWarnings("unused")
        int tag = buffer[INDEX_PIN_OUTPUT_TAG];

        // PIN出力TAGサイズ(2バイト) 0x0016 固定
        @SuppressWarnings("unused")
        int tagSize = CalcUtil.toInt(buffer[INDEX_PIN_OUTPUT_TAG_LEN_1],
                buffer[INDEX_PIN_OUTPUT_TAG_LEN_2]);

        // PIN出力サイズ(2バイト) 0x0008 固定
        int pinOutSize = CalcUtil.toInt(buffer[INDEX_PIN_OUTPUT_LEN_1],
                buffer[INDEX_PIN_OUTPUT_LEN_2]);
        byte[] pin = new byte[pinOutSize];
        byte[] ksn = new byte[10];

        // 配列要素位置 - PINデータ(8バイト)
        final int INDEX_PIN_DATA = PinpadDefine.INDEX_PARAMETER + 7;

        // 配列要素位置 - プション情報有無
        final int INDEX_OPTION_FLAG = INDEX_PIN_DATA + pin.length;

        // 配列要素位置 - PIN入力桁数
        final int INDEX_PIN_INPUT_DIGIT_NUM = INDEX_OPTION_FLAG + 1;

        // 配列要素位置 - PIN入力桁数
        final int INDEX_KSNR = INDEX_OPTION_FLAG + 2;

        // 配列要素位置 - 終端
        final int INDEX_END = INDEX_KSNR + ksn.length;

        if (buffer.length < INDEX_END) {
            // buffer サイズが必要サイズに満たない
            return false;
        }

        // PINデータ(8バイト)
        System.arraycopy(buffer, INDEX_PIN_DATA, pin, 0, pin.length);
        mPindata = CalcUtil.toHexString(pin);

        // オプション情報有無(1バイト)
        @SuppressWarnings("unused")
        int isOption = buffer[INDEX_OPTION_FLAG];

        // PIN入力桁数(1バイト)
        @SuppressWarnings("unused")
        int pinSize = buffer[INDEX_PIN_INPUT_DIGIT_NUM];

        // KSNR(10バイト)
        System.arraycopy(buffer, INDEX_KSNR, ksn, 0, ksn.length);
        mKsn = CalcUtil.toHexString(ksn);

        return true;
    }

    /**
     * @see Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte((byte) (this.mTraining ? 1 : 0));
        dest.writeInt(mResult);
        dest.writeInt(mPintype);
        dest.writeString(mPindata);
        dest.writeString(mSw);
        dest.writeString(mKsn);
    }

    /**
     * @brief Parcel読み込み用
     * @param[in] in Parcelデータ
     */
    public void readFromParcel(Parcel in) {
        setTraining(in.readByte() != 0);
        setResult(in.readInt());
        setPintype(in.readInt());
        setPindata(in.readString());
        setSw(in.readString());
        setKsn(in.readString());
    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponsePinData> CREATOR = new Parcelable.Creator<ResponsePinData>() {

        /**
         * @see Parcelable.Creator#createFromParcel(Parcel)
         */
        @Override
        public ResponsePinData createFromParcel(Parcel source) {
            return new ResponsePinData(source);
        }

        /**
         * @see Parcelable.Creator#newArray(int)
         */
        @Override
        public ResponsePinData[] newArray(int size) {
            return new ResponsePinData[size];
        }
    };

}
