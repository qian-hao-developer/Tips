
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt.Management;

/**
 * IC カードリーダライタ PF 情報
 */
public class EmcrwPlatformData {

    /** @brief バージョン */
    private String mVersion;

    /** @brief インストールファイル */
    private String mFileName;

    /**
     * @brief コンストラクタ
     */
    public EmcrwPlatformData() {
        mVersion = null;
        mFileName = null;
    }

    public String getVersion() {
        return mVersion;
    }

    public void setVersion(String version) {
        mVersion = version;
    }

    public String getFileName() {
        return mFileName;
    }

    public void setFileName(String name) {
        mFileName = name;
    }

    public boolean isNeedUpdate(EmcrwPlatformData newPFData) {

        // PF バージョンの数字部分(前半12桁)のみ使用して判定する(後半4桁は無視する)
        String currentVersionTop12 = getVersionHigh12(mVersion);
        String manageVersionTop12 = getVersionHigh12(newPFData.getVersion());
        int compare = manageVersionTop12.compareToIgnoreCase(currentVersionTop12);
        if (Management.DOWNGRADE_ENABLED) {  // PT_IMPOSSIBLE_BRANCH
            return compare != 0;  // PT_IMPOSSIBLE_INSTRUCTIONS
        } else {
            return compare > 0;
        }
    }

    private static String getVersionHigh12(String pfVersion) {
        return pfVersion.substring(0, 12);
    }
}
