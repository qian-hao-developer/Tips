
package com.panasonic.avc.smartpayment.devctlservice.log;

import android.util.Log;

/**
 * ログ表示クラス
 */
public class Logger {

    /** @brief ログレベル */
    private LogLevel mLogLevel = LogLevel.NONE;

    /** @brief ログレベル */
    public enum LogLevel {
        NONE,
        DEBUG,
        RELEASE,
    }

    /**
     * @brief コンストラクタ
     * @param level ログレベル設定
     */
    public Logger(LogLevel level) {
        setLogLevel(level);
    }

    /**
     * @see Log#v(String, String)
     */
    public void v(String tag, String text) {
        switch (mLogLevel) {
            case DEBUG:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @see Log#d(String, String)
     */
    public void d(String tag, String text) {
        switch (mLogLevel) {
            case DEBUG:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @see Log#i(String, String)
     */
    public void i(String tag, String text) {
        switch (mLogLevel) {
            case DEBUG:
                Log.d(tag, text);
                break;
            case RELEASE:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @see Log#w(String, String)
     */
    public void w(String tag, String text) {
        switch (mLogLevel) {
            case DEBUG:
                Log.d(tag, text);
                break;
            case RELEASE:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @see Log#e(String, String)
     */
    public void e(String tag, String text) {
        switch (mLogLevel) {
            case DEBUG:
                Log.d(tag, text);
                break;
            case RELEASE:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @see Log#a(String, String)
     */
    public void a(String tag, String text) {
        switch (mLogLevel) {
            case DEBUG:
                Log.d(tag, text);
                break;
            case RELEASE:
                Log.d(tag, text);
                break;
            default:
                break;
        }
    }

    /**
     * @brief ログレベルを取得する
     * @return ログレベル
     */
    public LogLevel getLogLevel() {
        return mLogLevel;
    }

    /**
     * @brief ログレベルを設定する
     * @param logLevel ログレベル
     */
    public void setLogLevel(LogLevel logLevel) {
        mLogLevel = logLevel;
    }
}
