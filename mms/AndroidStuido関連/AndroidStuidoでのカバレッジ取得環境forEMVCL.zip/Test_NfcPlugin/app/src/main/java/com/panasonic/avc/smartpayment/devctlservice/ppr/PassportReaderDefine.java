
package com.panasonic.avc.smartpayment.devctlservice.ppr;

/**
 * パスポートリーダ定義
 */
public class PassportReaderDefine {

    /** @brief PassportReader 品番 */
    public static final String PRODUCT_NO = "OCR316";

    /** @brief PassportReader PID */
    public static final int PID = 0x013e;

    /** @brief BarcodeReader VID */
    public static final int VID = 0x0db5;

}
