
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 拡張製品情報取得コマンド
 */
public class RequestAdvanceProductInformation extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x30;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x01;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 2;

    /**
     * @brief コンストラクタ
     */
    public RequestAdvanceProductInformation() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }
}
