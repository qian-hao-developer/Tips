package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * RW切替 非接触PINPADプロトコルRequestクラス.
 * 
 */
public class RWSwitchingRequest extends BaseRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = RWSwitchingRequest.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x24;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x80;

    /** Constructor */
    public RWSwitchingRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        // データ部なし
        return super.toCommand(null);
    }
}
