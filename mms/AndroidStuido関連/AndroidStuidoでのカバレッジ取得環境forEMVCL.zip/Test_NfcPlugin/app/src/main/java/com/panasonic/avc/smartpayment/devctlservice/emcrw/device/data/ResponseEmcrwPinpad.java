
package com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data;


public class ResponseEmcrwPinpad extends ResponseEmcrw {

    private final String TAG = "ResponseEmcrwCCT";

    private final int STX_SIZE = 1;
    private int HEAD_SIZE = 5;
}
