
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import java.util.ArrayList;

import android.bluetooth.BluetoothDevice;
import android.hardware.usb.UsbDevice;

/**
 * デバイスの状態を監視する
 */
public class DeviceTracker {

    /** @brief USBの状態監視用リスナー */
    public interface OnDeviceUsbTrackerListener {

        /**
         * @brief USB接続イベント
         * @param device 接続デバイス
         */
        public void onConnected(UsbDevice device);

        /**
         * @brief USB切断イベント
         * @param device 切断デバイス
         */
        public void onDisconnected(UsbDevice device);

        /**
         * @brief USBホスト許諾イベント
         * @param device 許諾デバイス
         */
        public void onPermitted(UsbDevice device);

    }

    /** @brief Bluetoothの状態監視用リスナー */
    public interface OnDeviceBluetoothTrackerListener {

        /**
         * @brief Bluetooth接続イベント
         * @param device 接続デバイス
         */
        public void onConnected(BluetoothDevice device);

        /**
         * @brief Bluetooth切断イベント
         * @param device 切断デバイス
         */
        public void onDisconnected(BluetoothDevice device);
    }

    /** @brief シングルトンインスタンス */
    private static DeviceTracker sInstance = new DeviceTracker();

    /** @brief USBイベントリスナー */
    private ArrayList<OnDeviceUsbTrackerListener> mUsbListenerList = new ArrayList<OnDeviceUsbTrackerListener>();

    /** @brief Bluetoothイベントリスナー */
    private OnDeviceBluetoothTrackerListener mBluetoothListener;

    /** @brief USB接続デバイスリスト */
    private ArrayList<UsbDevice> mUsbDeviceList = new ArrayList<UsbDevice>();

    /** @brief Bluetooth接続デバイスリスト */
    private ArrayList<BluetoothDevice> mBluetoothDeviceList = new ArrayList<BluetoothDevice>();

    /**
     * @brief コンストラクタ
     */
    private DeviceTracker() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static DeviceTracker getInstance() {
        return sInstance;
    }

    /**
     * @brief USBの接続を通知する
     * @param device
     */
    public void notifyConnectedUsbDevice(UsbDevice device) {
        synchronized (mUsbDeviceList) {
            if (!mUsbDeviceList.contains(device)) {
                mUsbDeviceList.add(device);
            }
        }

        synchronized (mUsbListenerList) {
            for (OnDeviceUsbTrackerListener list : mUsbListenerList) {
                list.onConnected(device);
            }
        }

    }

    /**
     * @brief USBの切断を通知する
     * @param device
     */
    public void notifyDisconnectedUsbDevice(UsbDevice device) {
        synchronized (mUsbDeviceList) {
            if (!mUsbDeviceList.contains(device)) {
                mUsbDeviceList.remove(device);
            }
        }

        synchronized (mUsbListenerList) {
            for (OnDeviceUsbTrackerListener list : mUsbListenerList) {
                list.onDisconnected(device);
            }
        }

    }

    /**
     * @brief USBホスト許諾を通知する
     * @param device
     */
    public void notifyPermittedUsbDevice(UsbDevice device) {
        synchronized (mUsbListenerList) {
            for (OnDeviceUsbTrackerListener list : mUsbListenerList) {
                list.onPermitted(device);
            }
        }

    }

    /**
     * @brief Bluetoothの接続を通知する
     * @param device
     */
    public void notifyConnectedBluetoothDevice(BluetoothDevice device) {
        synchronized (mBluetoothDeviceList) {
            if (!mBluetoothDeviceList.contains(device)) {
                mBluetoothDeviceList.add(device);
            }
        }

        if (mBluetoothListener == null) {
            return;
        }
        mBluetoothListener.onConnected(device);

    }

    /**
     * @brief Bluetoothの切断を通知する
     * @param device
     */
    public void notifyDisconnectedBluetoothDevice(BluetoothDevice device) {
        synchronized (mBluetoothDeviceList) {
            if (!mBluetoothDeviceList.contains(device)) {
                mBluetoothDeviceList.add(device);
            }
        }

        if (mBluetoothListener == null) {
            return;
        }
        mBluetoothListener.onDisconnected(device);
    }

    /**
     * @brief Bluetoothイベントリスナーを設定する
     * @param bluetoothListener リスナー
     */
    public void setBluetoothListener(OnDeviceBluetoothTrackerListener bluetoothListener) {
        mBluetoothListener = bluetoothListener;
    }

    /**
     * @brief USBイベントリスナーを設定する
     * @param usbListener リスナー
     */
    public void registerUsbListener(OnDeviceUsbTrackerListener usbListener) {

        synchronized (mUsbListenerList) {
            if (!mUsbListenerList.contains(usbListener)) {
                mUsbListenerList.add(usbListener);
            }
        }
    }

}
