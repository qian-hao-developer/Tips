
package com.panasonic.avc.smartpayment.devctlservice.spad;

/**
 * バーコードリーダ定義
 */
public class SignpadDefine {

    /** @brief 品番 (STU-430) */
    public static final String PRODUCT_NO_STU_430 = "STU-430";

    /** @brief 品番 (STU-530) */
    public static final String PRODUCT_NO_STU_450 = "STU-530";

    /** @brief Signpad PID (STU-430) */
    public static final int PID_STU_430 = 0x00a4;

    /** @brief Signpad PID (STU-530) */
    public static final int PID_STU_530 = 0x00a5;

    /** @brief Signpad VID */
    public static final int VID = 0x056a;

    /** @brief Signpad PID List */
    public static final int[] PID_LIST = new int[] {
        PID_STU_430, PID_STU_530,
    };

}
