package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

/**
 * PFの詳細状態取得応答
 */
public class PFDetailInformationResponse extends BaseResponse {

    /** @brief マスターコマンド */
    protected static final byte MASTER_COMMAND = (byte) 0x25;

    /** @brief サブコマンド */
    protected static final byte SUB_COMMAND = (byte) 0x04;

    /** @brief 1つのメモリ空間当たりのレスポンスの長さ **/
    protected static final int LENGTH_FOR_UNIT = 0x16;

    /** メモリ番号 */
    protected byte[] mMemoryNo;

    /** AP-ID */
    protected byte[] mApId;

    /** 固定FROM領域サイズ */
    protected byte[] mStaticFROMSize;

    /** 切替FROM領域サイズ */
    protected byte[] mSwitchingFROMSize;

    /** 固定RAM領域サイズ */
    protected byte[] mStaticRAMSize;

    /** 切替RAM領域サイズ */
    protected byte[] mSwitchingRAMSize;

    /** バージョン情報 */
    protected byte[] mVersion;

    /**
     * @brief コンストラクタ
     */
    public PFDetailInformationResponse() {
        super();
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * メモリ番号を取得する
     * @return メモリ番号
     */
    public byte[] cloneMemoryNo() {
        if (mMemoryNo != null) {
            return mMemoryNo.clone();
        } else {
            return null;
        }
    }

	/**
     * AP-IDを取得する
     * @return AP-ID
     */
    public byte[] cloneApId() {
        if (mApId != null) {
            return mApId.clone();
        } else {
            return null;
        }
    }

    /**
     * 固定FROM領域サイズを取得する
     * @return 固定FROM領域サイズ
     */
    public byte[] cloneStaticFROMSize() {
        if (mStaticFROMSize != null) {
            return mStaticFROMSize.clone();
        } else {
            return null;
        }
    }

    /**
     * 切替FROM領域サイズを取得する
     * @return 切替FROM領域サイズ
     */
    public byte[] cloneSwitchingFROMSize() {
        if (mSwitchingFROMSize != null) {
            return mSwitchingFROMSize.clone();
        } else {
            return null;
        }
    }

    /**
     * 固定RAM領域サイズを取得する
     * @return 固定RAM領域サイズ
     */
    public byte[] cloneStaticRAMSize() {
        if (mStaticRAMSize != null) {
            return mStaticRAMSize.clone();
        } else {
            return null;
        }
    }

    /**
     * 切替RAM領域サイズを取得する
     * @return 切替RAM領域サイズ
     */
    public byte[] cloneSwitchingRAMSize() {
        if (mSwitchingRAMSize != null) {
            return mSwitchingRAMSize.clone();
        } else {
            return null;
        }
    }

    /**
     * バージョン情報を取得する
     * @return バージョン情報
     */
    public byte[] cloneVersion() {

        if (mVersion != null) {
            return mVersion.clone();
        } else {
            return null;
        }

    }


    public boolean inputDeviceResult(byte[] bytes) {

        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = cutDeviceResult(bytes);

        if (buffer == null) {
            return false;
        }

        int len = CalcUtil.toInt(buffer[DATALENGTHHIGH_INDEX],
                buffer[DATALENGTHLOW_INDEX]);
        //レスポンスに格納されている、メモリ使用状態の個数
        int unitCount = (len / LENGTH_FOR_UNIT);

        mMemoryNo = new byte[unitCount];
        mApId = new byte[unitCount];
        mStaticFROMSize = new byte[unitCount];
        mSwitchingFROMSize = new byte[unitCount];
        mStaticRAMSize = new byte[unitCount];
        mSwitchingRAMSize = new byte[unitCount];
        mVersion = new byte[unitCount*16];

        int startIndex = DATA_INDEX;
        for (int i = 0; i < unitCount; i++) {
            mMemoryNo[i] = buffer[startIndex];
            mApId[i] = buffer[startIndex + 1];
            mStaticFROMSize[i] = buffer[startIndex + 2];
            mSwitchingFROMSize[i] = buffer[startIndex + 3];
            mStaticRAMSize[i] = buffer[startIndex + 4];
            mSwitchingRAMSize[i] = buffer[startIndex + 5];
            byte[] version = new byte[16];
            System.arraycopy(buffer, startIndex + 6, version, 0, version.length);
            System.arraycopy(version, 0, mVersion, i*16, version.length);
            startIndex += LENGTH_FOR_UNIT;
        }
        return true;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MASTER_COMMAND) {
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != SUB_COMMAND) {
            return false;
        }

        return true;
    }

}

