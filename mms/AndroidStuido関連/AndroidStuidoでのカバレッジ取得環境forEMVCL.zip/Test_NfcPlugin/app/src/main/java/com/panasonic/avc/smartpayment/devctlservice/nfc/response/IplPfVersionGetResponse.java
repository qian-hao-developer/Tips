package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.IPL_PF_VERSION_GET_RESPONSE;

/**
 * IPL、PFのバージョン取得Responseクラス.
 * 
 */
public class IplPfVersionGetResponse extends BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = IplPfVersionGetResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x00;

    /** @brief データ長データ2桁目(LittleEndian) */
    private static byte DATALENGTH_HIGH = (byte) 0x30;
    /** @brief データ長データ1桁目(LittleEndian) */
    private static byte DATALENGTH_LOW = (byte) 0x00;

    /** @brief IPLバージョン . */
    private byte[] mIplVersion;
    /** @brief PFバージョン . */
    private byte[] mPfVersion;
    /** @brief PFモデル . */
    private byte[] mPfModelNo;

    /**
     * IPLバージョンを返却する.
     * 
     * @return IPLバージョン
     */
    public byte[] getIplVersion() {
        return mIplVersion;
    }

    /**
     * PFバージョンを返却する.
     * 
     * @return PFバージョン
     */
    public int getPfVersion() {
        return 0;
    }

    /**
     * PFモデルを返却する.
     * 
     * @return PFモデル
     */
    public byte[] getPfModelNo() {
        return mPfModelNo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {  // PT_IMPOSSIBLE_BRANCH
            return false;  // PT_IMPOSSIBLE_INSTRUCTIONS
        }

        return (cutDeviceResult(bytes) != null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MAINCOMMAND) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND unmatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND) {
            Logger.e(TAG, "checkResponseData SUBCOMMAND unmatch = "
                    + bytes[SUBCOMMAND_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHHIGH_INDEX] != DATALENGTH_HIGH) {
            Logger.e(TAG, "checkResponseData DATALENGTH_HIGH unmatch = "
                    + bytes[DATALENGTHHIGH_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHLOW_INDEX] != DATALENGTH_LOW) {
            Logger.e(TAG, "checkResponseData DATALENGTH_LOW unmatch = "
                    + bytes[DATALENGTHLOW_INDEX]);
            return false;
        }

        IPL_PF_VERSION_GET_RESPONSE[] dataConstArray = IPL_PF_VERSION_GET_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        // データ部順の配列を順次処理する
        for (IPL_PF_VERSION_GET_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* IPLバージョン:(2016/03/07データ仕様が無い為チェック処理無し) */
            case IPLVERSION:
                break;
            /* PFバージョン:(2016/03/07データ仕様が無い為チェック処理無し) */
            case PFVERSION:
                break;
            /* PFモデル:(2016/03/07データ仕様が無い為チェック処理無し) */
            case PFMODELNO:
                break;
            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ格納を行う
        IPL_PF_VERSION_GET_RESPONSE[] dataConstArray = IPL_PF_VERSION_GET_RESPONSE
                .values();
        int indexPosition = DATA_INDEX;

        byte[] checkByteArray;
        // データ部順の配列を順次処理する
        for (IPL_PF_VERSION_GET_RESPONSE dataConst : dataConstArray) {

            switch (dataConst) {  // PT_IMPOSSIBLE_BRANCH
            /* IPLバージョン */
            case IPLVERSION:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mIplVersion = checkByteArray;
                break;
            /* PFバージョン */
            case PFVERSION:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mPfVersion = checkByteArray;
                break;
            /* PFモデル */
            case PFMODELNO:
                checkByteArray = new byte[dataConst.getDataLength()];
                System.arraycopy(bytes, indexPosition, checkByteArray, 0,
                        dataConst.getDataLength());
                mPfModelNo = checkByteArray;
                break;
            default:
                break;
            }

            indexPosition = indexPosition + dataConst.getDataLength();
        }

        return bytes;
    }

}
