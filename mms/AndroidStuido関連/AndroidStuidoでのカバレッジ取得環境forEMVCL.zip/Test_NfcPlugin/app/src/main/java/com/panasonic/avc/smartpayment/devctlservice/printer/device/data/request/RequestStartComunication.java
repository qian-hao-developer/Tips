
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * 通信開始要求
 */
public class RequestStartComunication extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x8002;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x8000;

    /**
     * @brief コンストラクタ
     */
    public RequestStartComunication() {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }

}
