
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import java.util.ArrayList;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.hardware.usb.UsbDevice;

import com.panasonic.avc.smartpayment.devctlservice.bcr.device.data.RequestBarcodeReaderData;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data.RequestEmcrwData;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.pos.device.data.request.RequestSendPos;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprDataListener;
import com.panasonic.avc.smartpayment.devctlservice.share.response.spad.ResponseSignpad;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.RequestSpadData;

/**
 * コントロールするデバイスを管理する抽象化クラス
 */
public abstract class ControlDeviceManager {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = ControlDeviceManager.class.getSimpleName();

    /** @brief デバイスの種別 */
    public enum DeviceType {
        NONE,
        USB,
        SERIAL,
    }

    /** @brief 管理クラスのステータス定義 */
    protected enum ManagerStatus {
        NONE,
        INIT,
        ACTIVE,
    }

    /** @brief USB コネクションリスナー */
    public interface NotifyUsbDeviceConnectionListener {

        /**
         * @brief USB コネクションオープン通知
         * @param device デバイス
         */
        public void onOpened(UsbDevice device);

        /**
         * @brief USB コネクションクローズ通知
         * @param device デバイス
         */
        public void onClosed(UsbDevice device);

    }

    /** @brief USB承認リスナーリスト */
    protected ArrayList<NotifyUsbDeviceConnectionListener> mNotifyUsbDeviceConnectionListenerList = new ArrayList<NotifyUsbDeviceConnectionListener>();

    /** @brief ステータス */
    protected ManagerStatus mStatus = ManagerStatus.NONE;

    /** @brief コンテキスト */
    protected Context mContext;

    /** @brief デバイス制御クラス */
    protected DeviceController mDeviceController;

    /** @brief BroadcastReciever */
    protected BroadcastReceiver mBroadcastReceiver;

    public interface SignpadDataListener {
        public void sendSpadData(ResponseSignpad spadData);

        public void sendSpadControlData(byte[] result);
    }

    /** @brief 初期化 */
    abstract public boolean init(int venderId, int productId);

    /** @brief 初期化【マルチデバイス対応】 */
    abstract public boolean init(int vendorId, int[] productIds, boolean[] busPower);

    /**
     * @brief Serialデバイス用初期化メソッド
     * @param deviceInterface 通信インタフェース シリアル:0 USB:1
     * @param baudrate 通信速度
     * @param parity パリティ種別 パリティチェックなし:0 奇数パリティ:1 偶数パリティ:2
     * @return 成功したかどうか
     */
    abstract public boolean init(int deviceInterface, int baudrate, int parity);

    /** @brief 最大シーケンス番号 */
    private static final int MAX_SEQUENCE = 0xFFFF;

    /** @brief シーケンス番号 */
    protected int mSequence;

    /** @brief USBデバイス */
    private UsbDevice mUsbDevice;

    /**
     * @brief 初期化
     */
    protected void init() {
        mSequence = 0;
        mDeviceController.init();
        mStatus = ManagerStatus.INIT;
    }

    /**
     * @brief 終了処理
     * @return 成功したかどうか
     */
    public boolean term(UsbDevice device) {
        if (mStatus == ManagerStatus.NONE) {
            return false;
        }

        if (mDeviceController.term(device) == false) {
            return false;
        }

        if (mContext != null) {
            mContext.unregisterReceiver(mBroadcastReceiver);
        }

        mStatus = ManagerStatus.NONE;
        return true;
    }

    /**
     * @brief 終了処理
     * @return 成功したかどうか
     */
    public boolean term() {
        if (mStatus == ManagerStatus.NONE) {
            return false;
        }

        if (mDeviceController.term() == false) {
            return false;
        }

        mStatus = ManagerStatus.NONE;
        return true;
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param data 書込するデータ
     * @param timeout タイムアウト
     * @return 書き込みに成功したかどうか
     */
    public boolean write(byte[] data, int timeout) {
        return mDeviceController.write(data, timeout);
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込するデータ
     * @param timeout タイムアウト
     * @return 書き込みに成功したかどうか
     */
    public synchronized boolean write(RequestData request, int timeout) {
        if (mStatus != ManagerStatus.ACTIVE) {
            return false;
        }

        mSequence++;
        if (MAX_SEQUENCE < mSequence) {
            mSequence = 0;
        }
        request.setSequence(mSequence);

        return write(request.toCommand(), timeout);
    }

    public synchronized void clearBuffer() {
        if (mStatus != ManagerStatus.ACTIVE) {
            return;
        }
        mDeviceController.read(1);
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込するデータ
     * @param timeout タイムアウト
     * @return 書き込みに成功したかどうか
     */
    public synchronized boolean write(RequestPrinterData request, int timeout) {
        if (mStatus != ManagerStatus.ACTIVE) {
            return false;
        }

        mSequence++;
        if (MAX_SEQUENCE < mSequence) {
            mSequence = 0;
        }
        request.setSequence(mSequence);

        return write(request.toCommand(), timeout);
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込するデータ
     * @return 書き込みに成功したかどうか
     */
    public synchronized boolean write(RequestSendPos request) {
        if (mStatus != ManagerStatus.ACTIVE) {
            return false;
        }

        return write(request.toCommand(), -1);
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込みするデータ
     * @param timeout タイムアウト
     * @return 書き込みが成功したか否か
     */
    public synchronized boolean write(RequestSpadData request, int timeout) {
        if (mStatus != ManagerStatus.ACTIVE) {
            return false;
        }
        return write(request.toCommand(), timeout);
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込するデータ
     * @param timeout タイムアウト
     * @return 書き込みに成功したかどうか
     */
    public synchronized boolean write(RequestEmcrwData request, int timeout) {
        return write(request.toPacket(), timeout);
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param request 書込するデータ
     * @param timeout タイムアウト
     * @return 書き込みに成功したかどうか
     */
    public boolean write(RequestBarcodeReaderData request, int timeout) {
        if (mStatus != ManagerStatus.ACTIVE) {
            return false;
        }

        return write(request.toCommand(), timeout);
    }

    /**
     * @brief デバイスからデータを読み込む
     * @return データ
     */
    public synchronized byte[] read(int timeout) {
        if (mStatus != ManagerStatus.ACTIVE) {
            return null;
        }

        return mDeviceController.read(timeout);
    }

    /**
     * データ読み出し(Pinpad)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    public byte[] read(byte[] buffer, int timeout) {
        return mDeviceController.read(buffer, timeout);
    }

    public void clearSequence() {
        mSequence = 0;
    }

    public int getSequence() {
        return mSequence;
    }

    public void setSequence(int seq) {
        mSequence = seq;
    }

    /**
     * @brief USBデバイスと接続する
     * @param device USBデバイス
     * @return 接続したかどうか
     */
    protected boolean connect(UsbDevice device) {

        if (mDeviceController.connect(device)) {

            mUsbDevice = device;
            clearSequence();
            mStatus = ManagerStatus.ACTIVE;
        } else {
            return false;
        }
        return true;
    }

    /**
     * USBデバイスを取得する
     * 
     * @return USBデバイス
     */
    public UsbDevice getUsbDevice() {
        return mUsbDevice;
    }

    /**
     * USBデバイスを設定する
     * 
     * @param usbDevice
     */
    public void setUsbDevice(UsbDevice usbDevice) {
        mUsbDevice = usbDevice;
    }

    /**
     * パスポートリーダコールバック用リスナーを設定する
     * 
     * @param listener リスナー
     */
    public void setPprDataListener(IPprDataListener listener) {
    }

    /**
     * パスポートリーダコールバック用リスナーを削除する
     * 
     * @param listener リスナー
     */
    public void removePprDataListener(IPprDataListener listener) {
    }

    public void setSpadDataListener(SignpadDataListener listener) {
    }

    public void removeSpadDataListener(SignpadDataListener listener) {
    }

    /**
     * @brief デバイスの有無
     * @return 有無
     */
    public boolean isActive() {
        if (mDeviceController == null) {
            return false;
        }
        return mDeviceController.isActive();
    }

    protected boolean isStart = true;

    public void setStart(boolean isStart) {
        this.isStart = isStart;
        mDeviceController.setStart(isStart);
    }

    /**
     * @brief USBの接続承認リスナーを設定する
     * @param onUsbDeviceListener リスナー
     */
    public void registerNotifyUsbDeviceConnectionListener(
            NotifyUsbDeviceConnectionListener notifyUsbDeviceConnectionListener) {
        synchronized (mNotifyUsbDeviceConnectionListenerList) {
            if (!mNotifyUsbDeviceConnectionListenerList.contains(notifyUsbDeviceConnectionListener)) {
                mNotifyUsbDeviceConnectionListenerList.add(notifyUsbDeviceConnectionListener);
            }
        }
    }

    /**
     * @brief USBの接続承認リスナーを設定する
     * @param onUsbDeviceListener リスナー
     */
    public void unregisterNotifyUsbDeviceConnectionListener(
            NotifyUsbDeviceConnectionListener notifyUsbDeviceConnectionListener) {
        synchronized (mNotifyUsbDeviceConnectionListenerList) {
            mNotifyUsbDeviceConnectionListenerList.remove(notifyUsbDeviceConnectionListener);
        }
    }

    /**
     * @brief 接続デバイスのプロダクトIDを取得する
     * @return プロダクトID
     * @see UsbDeviceManager#getProductId()
     */
    public int getProductId() {
        return -1;
    }

    /**
     * @brief デバイスのread/write権限をロックする
     */
    public void lock() {
        mDeviceController.lock();
        return;
    }

    /**
     * @brief デバイスのread/write権限を解除する
     */
    public void unlock() {
        mDeviceController.unlock();
        return;
    }

    /**
     * @brief デバイスのロック状態を解除する
     */
    public void clearLock() {
        mDeviceController.clearLock();
        return;
    }

    /**
     * @brief デバイスのread/write権限を取得する
     */
    public boolean isLocked() {
        return mDeviceController.isLocked();
    }

    /**
     * @brief デバイスのread/write権限を取得する
     */
    public Object getLockObject() {
        return mDeviceController.getLockObject();
    }

}
