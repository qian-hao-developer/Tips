
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * デバイスへの要求用クラス
 */
public class RequestSpadData {

    /** @brief ログ用タグ */
    private static final String TAG = RequestSpadData.class.getSimpleName();

    /** @brief コマンド文字列 (String) */
    private String mCommandMsg;

    /**
     * コンストラクタ
     */
    public RequestSpadData() {

    }

    /**
     * @brief コマンド文字列を取得する
     * @return CommandMessage
     */
    public String getCommand() {
        return mCommandMsg;
    }

    /**
     * @brief コマンド文字列を設定する
     * @param command CommandMessage
     */
    public void setCommand(String command) {
        mCommandMsg = command;
    }

    /**
     * @brief コマンド文字列を整形し、コマンドに変換する
     */
    public byte[] toCommand() {
        return CalcUtil.toByte(mCommandMsg);
    }

    /**
     * @brief データのチェック
     * @return 問題があるかどうか
     */
    public boolean isValidValue() {
        if (mCommandMsg == null || mCommandMsg.isEmpty()) {
            return false;
        }
        try {
            byte[] byteArray = toCommand();
            if (byteArray == null) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

}
