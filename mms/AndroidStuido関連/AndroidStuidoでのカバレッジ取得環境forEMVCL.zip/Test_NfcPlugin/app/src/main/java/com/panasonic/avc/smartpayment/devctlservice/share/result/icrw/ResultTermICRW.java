
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * TermICRW処理結果データ
 */
public class ResultTermICRW extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermICRW(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermICRW() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermICRW> CREATOR = new Parcelable.Creator<ResultTermICRW>() {
        public ResultTermICRW createFromParcel(Parcel in) {
            return new ResultTermICRW(in);
        }

        public ResultTermICRW[] newArray(int size) {
            return new ResultTermICRW[size];
        }
    };
}
