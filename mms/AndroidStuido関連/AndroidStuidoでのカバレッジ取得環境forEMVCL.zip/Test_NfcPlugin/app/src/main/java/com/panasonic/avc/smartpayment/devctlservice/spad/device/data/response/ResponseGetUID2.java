
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetUID2 extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x0b;

    private static final int LENGTH = 11;

    private static final String UID2 = "uid2";

    private String mUid2;

    public ResponseGetUID2(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        byte[] buffer = new byte[10];

        System.arraycopy(result, 1, buffer, 0, buffer.length);
        mUid2 = CalcUtil.toAscii(buffer);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(UID2, mUid2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

}
