
package com.panasonic.avc.smartpayment.devctlservice;

import java.util.Calendar;
import java.util.List;

import org.jssec.android.shared.PkgCert;
import org.jssec.android.shared.PkgCertWhitelists;
import org.jssec.android.shared.Utils;

import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;

import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReader;
import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.cfg.Configuration;
import com.panasonic.avc.smartpayment.devctlservice.contesnts.ManagementDatabase;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwApplicationDataMap;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwDefine;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwPlatformData;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwUpdateInfo;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwUpdateInfoCreator;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.msr.MagneticStripeCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.NfcPlugin;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.DeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.DeviceType;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.NotifyUsbDeviceConnectionListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.UsbDeviceReceiver;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestAdvanceLcdSetting;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceSetting;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestLcdBackLight;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.duk.DeriveUniqueKeyPerTransaction;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.hmi.HumanMachineInterface;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.icrw.ContactIcCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt.Management;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt.Management.CallbackType;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.ped.PinEnterDevice;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.reset.PinpadReset.NotifyRebootingListener;
import com.panasonic.avc.smartpayment.devctlservice.pos.PointOfSaleSystem;
import com.panasonic.avc.smartpayment.devctlservice.ppr.PassportReader;
import com.panasonic.avc.smartpayment.devctlservice.ppr.PassportReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.printer.Printer;
import com.panasonic.avc.smartpayment.devctlservice.share.IBcrService;
import com.panasonic.avc.smartpayment.devctlservice.share.IBcrServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.ICfgService;
import com.panasonic.avc.smartpayment.devctlservice.share.ICfgServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IDukService;
import com.panasonic.avc.smartpayment.devctlservice.share.IDukServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IEmcrwInternalService;
import com.panasonic.avc.smartpayment.devctlservice.share.IEmcrwService;
import com.panasonic.avc.smartpayment.devctlservice.share.IEmcrwServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IHmiPrivateService;
import com.panasonic.avc.smartpayment.devctlservice.share.IHmiService;
import com.panasonic.avc.smartpayment.devctlservice.share.IHmiServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IIcrwService;
import com.panasonic.avc.smartpayment.devctlservice.share.IIcrwServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IMgtPrivateService;
import com.panasonic.avc.smartpayment.devctlservice.share.IMgtPrivateServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IMgtService;
import com.panasonic.avc.smartpayment.devctlservice.share.IMgtServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrService;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.INfcService;
import com.panasonic.avc.smartpayment.devctlservice.share.INfcServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IPedService;
import com.panasonic.avc.smartpayment.devctlservice.share.IPedServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IPosService;
import com.panasonic.avc.smartpayment.devctlservice.share.IPosServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprService;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IPrnService;
import com.panasonic.avc.smartpayment.devctlservice.share.IPrnServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.ISpadService;
import com.panasonic.avc.smartpayment.devctlservice.share.ISpadServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.UpdateDeviceType;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultInitBCR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultScanOFF;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultScanON;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultSendBCR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.bcr.ResultTermBCR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultBuzzerOn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultGetPrinter;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultInitCfg;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultSetBrightness;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultSetBuzzer;
import com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultSetLowPower;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultInitDuk;
import com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultMakeTransactionKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultAplVersion;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCarrierOff;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCarrierOn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultInitEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultPolling;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultRegistEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSendFeliCaAplOff;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSendFeliCaCmd;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetHmi;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetSound;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultSetVolume;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultTermEmcrw;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultCancelGetFuncKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultDisconnectBluetooth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultInitHMI;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultPutLCDImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultPutLCDString;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultRequestBuzzerON;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultRequestPowerOFF;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultStartGetFuncKey;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultUpdateBuzzerMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultUpdateLCDMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultUpdateLEDMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultActivationIcc;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultDeactivationIcc;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultGetICStatus;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultGetIFDInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultInitICRW;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultSendAPDU;
import com.panasonic.avc.smartpayment.devctlservice.share.result.icrw.ResultTermICRW;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultExecUpdate;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultInitMgt;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultStartGetFile;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultStartSendFile;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultCancelGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultInitMSR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultStartGetMSRead;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultTermMSR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultCancelGetPin;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultInitPed;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultStartGetEMPinData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultStartGetPinData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ped.ResultTermPed;
import com.panasonic.avc.smartpayment.devctlservice.share.result.pos.ResultInitPOS;
import com.panasonic.avc.smartpayment.devctlservice.share.result.pos.ResultSendPOS;
import com.panasonic.avc.smartpayment.devctlservice.share.result.pos.ResultTermPOS;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ppr.ResultInitPPR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ppr.ResultSendPPR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ppr.ResultTermPPR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultInitPrn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintCheckImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintCutPaper;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintEscText;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintFlush;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintLineFeed;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintQrCode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintSetImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultPrintText;
import com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultTermPrn;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultClearSPAD;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultDispImage;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultEraseArea;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetArea;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetBackgroundColor;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetBootScreenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetBrightness;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetCapability;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetInformation;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetInking;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetInkingThreshold;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetPenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetStatus;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetUID;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultGetUID2;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultInitSPAD;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultIntervalON;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSendSPAD;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetArea;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBackgroundColor;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBootScreenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetInking;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetInkingThreshold;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetPenMode;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetUID;
import com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultTermSPAD;
import com.panasonic.avc.smartpayment.devctlservice.spad.Signpad;
import com.panasonic.avc.smartpayment.devctlservice.spad.SignpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.system.util.CreateAlartView;
import com.panasonic.avc.smartpayment.devctlservice.system.util.CreateAlartView2Button;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;
import com.panasonic.avc.smartpayment.devctlservice.system.util.Util;
import com.panasonic.avc.smartpayment.pf.devicemonitor.DeviceMonitorManager;
import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;
import com.panasonic.avc.smartpayment.pf.pds.StatusInfoResponse;

/**
 * PINPADサービス
 */
public class CordovaPluginService extends Service {

    /** @brief ログ出力用タグ */
    private static final String TAG = CordovaPluginService.class.getSimpleName();

    /** @brief ログ出力制御 */
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief デバイス操作用管理クラス */
    private DeviceManager mDeviceManager = DeviceManager.getInstance();

    /** @brief 接触ICカードリーダライタコントロールクラス */
    private ContactIcCard mContactIcCard = ContactIcCard.getInstance();

    /** @brief Pin入力デバイスコントロールクラス */
    private PinEnterDevice mPinEnterDevice = PinEnterDevice.getInstance();

    /** @brief MSRコントロールクラス */
    private MagneticStripeCard mMagneticStripeCard = MagneticStripeCard.getInstance();

    /** @brief HMIコントロールクラス */
    private HumanMachineInterface mHumanMachineInterface = HumanMachineInterface.getInstance();

    /** @brief DUKコントロールクラス */
    private DeriveUniqueKeyPerTransaction mDeriveUniqueKeyPerTransaction = DeriveUniqueKeyPerTransaction
            .getInstance();

    /** @brief プリンタコントロールクラス */
    private Printer mPrinter = Printer.getInstance();

    /** @brief パスポートリーダコントロールクラス */
    private PassportReader mPassportReader = PassportReader.getInstance();

    /** @brief 端末管理コントロールクラス */
    private Management mManagement = Management.getInstance();

    /** @brief PINPAD リセットコントロールクラス */
    private PinpadReset mPinpadReset = PinpadReset.getInstance();

    /** @brief サインパッドコントロールクラス（STU-430/STU-530共通） */
    private Signpad mSignpad = Signpad.getInstance();

    private Configuration mConfiguration = Configuration.getInstance();

    /** @brief POSコントロールクラス */
    private PointOfSaleSystem mPointOfSaleSystem = PointOfSaleSystem.getInstance();

    /** @brief BCRコントロールクラス */
    private BarcodeReader mBarcodeReader = BarcodeReader.getInstance();

    /** @brief 非接触ICカードコントロールクラス */
    private NonContactICCard mNonContactICCard = NonContactICCard.getInstance();

    /** @brief 非接触ICRW EMVコントロールクラス */
    private NfcPlugin mNfcPlugin = NfcPlugin.getInstance();

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlPinpadDeviceManager;

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlSerialDeviceManager;

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlPrinterDeviceManager;

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlPassportReaderDeviceManager;

    /** @brief デバイス操作クラス(STU-430/STU-530共通) */
    private ControlDeviceManager mControlSignpadDeviceManager;

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlPosDeviceManager;

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlEmcrwDeviceManager;

    /** @brief デバイス操作クラス */
    private ControlDeviceManager mControlBarcodeReaderDeviceManager;

    /** @brief Panasonic プログラム配信システム */
    private PdsClientManager mPdsClientManager = new PdsClientManager();

    /** @brief 端末情報通知 */
    private TerminalStatusManager mTerminalStatusManager;

    /** @brief データベース管理クラス */
    private ManagementDatabase mManagementDatabase = ManagementDatabase.getInstance();

    /** @brief IME非表示用アクション */
    private final static String ACTION_LAUNCHER_HIDE_IME = "android.intent.action.HIDE_IME";

    /** @brief 署名対応用ホワイトリスト */
    private static PkgCertWhitelists sWhitelists = null;

    /** @brief 署名対応用ホワイトリスト1 */
    private static final String WHITE_LIST_1 =
            "3B8185F72C34DDC390FF9989D9ED0A1F72C2A2568B666B2827F7A0D792254E40";

    /** @brief 署名対応用ホワイトリスト2 */
    private static final String WHITE_LIST_2 =
            "0B0B6014B0E4301B529B1A277C1EFAC1CC9487934A241D316FAF8B2B80F2FC87";

    /** @brief PRN初回バージョンチェックフラグ */
    private boolean mFirstPrnCheck = true;

    /** @brief PRNバージョンエラーフラグ */
    private boolean mPrnVersionError = false;

    /** @brief MSR初回バージョンチェックフラグ */
    private boolean mFirstMsrCheck = true;

    /** @brief MSRバージョンエラーフラグ */
    private boolean mMsrVersionError = false;

    private boolean mLock;

    private boolean mIsShowPaperLess;

    private boolean mIsShowFatal;

    /** @brief 状態異常用ハンドラ */
    private Handler mHandler = new Handler();

    /**
     * ホワイトリスト作成
     * 
     * @param context コンテキスト
     */
    private static void buildWhitelists(Context context) {
        sWhitelists = new PkgCertWhitelists();

        PackageManager packageManager = context.getPackageManager();

        List<ApplicationInfo> applicationInfo = packageManager
                .getInstalledApplications(PackageManager.GET_META_DATA);

        String local = PkgCert.hash(context, "com.panasonic.avc.smartpayment.devctlservice");

        for (ApplicationInfo info : applicationInfo) {
            String hash = PkgCert.hash(context, info.packageName);
            if (WHITE_LIST_1.equals(hash)) {
                sWhitelists.add(info.packageName, WHITE_LIST_1);
            } else if (WHITE_LIST_2.equals(hash)) {
                sWhitelists.add(info.packageName, WHITE_LIST_2);
            } else if (local.equals(hash)) {
                sWhitelists.add(info.packageName, local);
            }
        }

    }

    /**
     * パートナー署名チェック
     * 
     * @param pid PID
     * @retval true 許諾
     * @retval false 拒否
     */
    private synchronized boolean checkPartner(int pid) {
        Context context = CordovaPluginService.this;
        if (sWhitelists == null)
            buildWhitelists(context);
        return sWhitelists.test(context, Utils.getPackageNameFromPid(context, pid));
    }

    /** @brief プリンタカバー開閉監視開始用BroadcastReceiver */
    private BroadcastReceiver mDeviceMonitorStartReceiver = new BroadcastReceiver() {

        /**
         * @see BroadcastReceiver#onReceive(Context, Intent)
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            mLoggingManager.d(TAG, "Service Receive NoPaperEvent Intent");

            if (intent == null) {
                return;
            }
            mDeviceMonitorManager.startMonitoring(DeviceMonitorManager.DEVICE_ID_PRINTER_COVER);
        }

    };

    /** @brief 状態異常用ハンドラ */
    private CreateAlartView mNoPaperAlertView = null;

    /** @brief 用紙なしダイアログ表示BroadcastReceiver */
    private BroadcastReceiver mNoPaperEventShowReceiver = new BroadcastReceiver() {

        /**
         * @see BroadcastReceiver#onReceive(Context, Intent)
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            mLoggingManager.d(TAG, "Service Receive NoPaperEvent Intent");

            if (intent == null) {
                return;
            }

            mLoggingManager.d(TAG, "Service ReceiveAction [show]");
            // 紙送りダイアログを消去
            if (mIsShowAlert) {
                dissmissAlertDialog();
                mIsShowAlert = false;
            }
            showNoPaperAlertDialog(context);
        }

    };

    /** @brief 用紙なしダイアログ非表示BroadcastReceiver */
    private BroadcastReceiver mNoPaperEventDismissReceiver = new BroadcastReceiver() {

        /**
         * @see BroadcastReceiver#onReceive(Context, Intent)
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            mLoggingManager.d(TAG, "Service Receive NoPaperEvent Intent");

            if (intent == null) {
                return;
            }

            mLoggingManager.d(TAG, "Service ReceiveAction [dismiss]");
            dissmissNoPaperAlertDialog();
        }

    };

    /**
     * 用紙なしダイアログ表示
     * 
     * @param context コンテキスト
     */
    private void showNoPaperAlertDialog(Context context) {
        if (mNoPaperAlertView == null) {

            Intent intent = new Intent(ACTION_LAUNCHER_HIDE_IME);
            context.sendBroadcast(intent);

            mLoggingManager.d(TAG, "No Printer Paper [showAlertDialog]");
            mNoPaperAlertView = new CreateAlartView();

            View.OnClickListener Buttonlistener = new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mLoggingManager.d(TAG, "No Printer Paper [onClick]");
                    mNoPaperAlertView = null;
                }
            };
            mNoPaperAlertView.setButtonListener(Buttonlistener);

            mNoPaperAlertView.showView(context, R.string.paper_event_nopaper_title,
                    R.drawable.no_paper,
                    R.string.paper_event_nopaper_message,
                    R.string.paper_event_common_confirm_button,
                    R.drawable.ic_check_mark);
        }
    }

    /**
     * 用紙なしダイアログ非表示
     */
    private void dissmissNoPaperAlertDialog() {
        if (mNoPaperAlertView != null) {
            mNoPaperAlertView.dismissView();
            mNoPaperAlertView = null;
        }
    }

    /** @brief アラートダイアログ用インスタンス */
    private CreateAlartView2Button mAlertView = null;

    /** @brief アラートダイアログ表示するかどうかのフラグ */
    private boolean mIsShowAlert = false;

    /** @brief 初回のイベントを無視するフラグ */
    private boolean mFirstEvent = true;

    /** @brief 蓋開閉確認用インスタンス */
    private DeviceMonitorManager mDeviceMonitorManager = null;

    /** @brief 蓋開閉イベント用BroadcastReceiver */
    private BroadcastReceiver mDeviceMonitorReceiver = new BroadcastReceiver() {

        /**
         * @see BroadcastReceiver#onReceive(Context, Intent)
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            // mLoggingManager.d(TAG, "Service Receive Printer Closed Intent");

            if (intent == null) {
                return;
            }

            mLoggingManager.d(TAG, "Service ReceiveAction [" + intent.getAction() + "]");
            int device_status = intent.getIntExtra(DeviceMonitorManager.EXTRA_PRINTER_COVER,
                    DeviceMonitorManager.PRINTERCOVER_OPENED);

            if (device_status == DeviceMonitorManager.PRINTERCOVER_CLOSED) {
                mLoggingManager.d(TAG, "Printer Closed");

                if (mFirstEvent) {
                    mFirstEvent = false;
                    return;
                }

                ResultInitPrn resultInit = mPrinter.initPrn(0, 0, 1, 1);
                if (resultInit.getDevice() != 0 || resultInit.getUpos() != 0) {
                    return;
                }

                com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultCheckHealth resultCheck = mPrinter
                        .checkHealth();

                // 用紙がセットされていればアラートを表示する
                if (resultCheck.getDevice() == 0 && resultCheck.getUpos() == 0) {
                    if (resultCheck.getSts() != 1) {

                        // フェールセーフのために用紙切れダイアログを非表示にする
                        dissmissNoPaperAlertDialog();

                        if (mIsShowAlert == false) {
                            showAlertDialog(context);
                            mIsShowAlert = true;
                        }
                    } else {

                        // 用紙がセットされていない状態になったらアラートを非表示にする
                        if (mIsShowAlert) {
                            dissmissAlertDialog();
                            mIsShowAlert = false;
                        }
                    }
                } else if (resultCheck.getDevice() == 0 && resultCheck.getUpos() == 113) {

                    // フェールセーフのために用紙切れダイアログを非表示にする
                    dissmissNoPaperAlertDialog();

                    // 用紙カット中であれば用紙カットダイアログを表示する
                    if (mIsShowAlert == false) {
                        showAlertDialog(context);
                        mIsShowAlert = true;
                    }
                }

            }
        }
    };

    private BroadcastReceiver mPinpadResetReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            mLoggingManager.d(TAG, "Service Receive PinpadReset Intent");

            if (intent == null) {
                return;
            }

            mLoggingManager.d(TAG, "Service ReceiveAction [resetPinpad]");
            mPinpadReset.resetPinpad();

        }

    };

    private final static String PRINTER_PAPER_CUT = "PAPER_PAPER_CUT_ACTION";

    /** @brief 用紙カットダイアログ用BroadcastReceiver */
    private BroadcastReceiver mDialogReceiver = new BroadcastReceiver() {

        /**
         * @see BroadcastReceiver#onReceive(Context, Intent)
         */
        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent == null) {
                return;
            }
            com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultCheckHealth resultCheck = mPrinter
                    .checkHealth();

            // 用紙がセットされていれば紙送りを実行する
            if (resultCheck.getDevice() == 0 && resultCheck.getUpos() == 0) {
                if (resultCheck.getSts() != 1) {

                    if (isSuccess(mPrinter.printLineFeed())) {
                        if (isSuccess(mPrinter.printLineFeed())) {
                            if (isSuccess(mPrinter.printLineFeed())) {
                                if (isSuccess(mPrinter.printFlush())) {
                                    if (isSuccess(mPrinter.printCutPaper(2))) {
                                    }
                                }
                            }
                        }
                    }

                }
            } else if (resultCheck.getDevice() == 0 && resultCheck.getUpos() == 113) {
                // フェールセーフのために用紙切れダイアログを非表示にする
                dissmissNoPaperAlertDialog();

                // 用紙カット中であればアラートを表示する
                if (mIsShowAlert == false) {
                    showAlertDialog(context);
                    mIsShowAlert = true;
                }

            }

        }
    };

    /** @brief USB デバイスイベント用 BroadcastReceiver */
    private BroadcastReceiver mUsbDeviceReceiver = new UsbDeviceReceiver();

    /**
     * 用紙カットダイアログ表示
     * 
     * @param context コンテキスト
     */
    private void showAlertDialog(final Context context) {

        Intent intent = new Intent(ACTION_LAUNCHER_HIDE_IME);
        context.sendBroadcast(intent);

        mLoggingManager.d(TAG, "showAlertDialog [Papper Send and Cut]");

        mAlertView = new CreateAlartView2Button();

        View.OnClickListener cancelButtonlistener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mLoggingManager.d(TAG, "onClick [Papper Send and Cut]");
                mIsShowAlert = false;

                // printerのtermは時間がかかる場合があるので別スレッドで実行する
                Handler handler = new Handler();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        mPrinter.termPrn();
                        return;
                    }
                });
            }
        };
        mAlertView.setLeftButtonListener(cancelButtonlistener);

        View.OnClickListener executeButtonlistener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mIsShowAlert = false;

                // 用紙カットを別スレッドで実行する
                Intent intent = new Intent(PRINTER_PAPER_CUT);
                if (intent != null) {
                    context.sendBroadcast(intent);
                }
            }
        };
        mAlertView.setRightButtonListener(executeButtonlistener);

        mAlertView.showView(context, R.string.paper_event_paper_cut_title,
                R.drawable.paper, R.string.paper_event_paper_cut_message,
                R.string.paper_event_common_cancel_button,
                R.string.paper_event_common_execute_button);
    }

    /**
     * 用紙カットダイアログ非表示
     */
    public void dissmissAlertDialog() {
        if (mAlertView != null) {
            mLoggingManager.d(TAG, "dismissAlertDialog [Papper Send and Cut]");
            mAlertView.dismissView();
        }
    }

    /**
     * 各種コマンドの成功失敗確認
     * 
     * @param data 結果
     * @retval true 成功
     * @retval false 失敗
     */
    private boolean isSuccess(ResultData data) {
        if (data.getDevice() == 0 && data.getUpos() == 0) {
            return true;
        }
        // mLoggingManager.d(TAG, "Service Paper send and cut Error :" +
        // data.toJSON());
        return false;
    }

    /**
     * @see Service#onCreate()
     */
    @Override
    public void onCreate() {
        super.onCreate();
        // mLoggingManager.d(TAG, "onCreate");
        mManagementDatabase.setContentResolver(getContentResolver());

        IntentFilter filter = new IntentFilter();
        filter.addAction(SystemNotification.PRINTER_DEVICE_SHOW);
        filter.addAction(SystemNotification.PRINTER_DEVICE_DISMISS);
        filter.addAction(SystemNotification.OTHER_DEVICE_DISMISS);
        filter.addAction(SystemNotification.OTHER_DEVICE_SHOW);
        registerReceiver(mSystemIconReceiver, filter);

        mTerminalStatusManager = new TerminalStatusManager(mPdsClientManager);

        filter = new IntentFilter();
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        filter.addAction(UsbDeviceReceiver.ACTION_USB_PERMISSION);
        registerReceiver(mUsbDeviceReceiver, filter);

        filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);

        LoggingManager.getInstance().init(this);
        // TODO Bluetooth対応
        if (DevCtlServiceDefine.SERIAL) {
            mControlSerialDeviceManager = mDeviceManager.createDeviceController(this,
                    DeviceType.USB);
            mControlSerialDeviceManager.init(0x0403, 0x6001);
            mContactIcCard.setControlDeviceManager(mControlSerialDeviceManager);
            mContactIcCard.setContext(this);
            mPinEnterDevice.setControlDeviceManager(mControlSerialDeviceManager);
            mPinEnterDevice.setContext(this);
            mDeriveUniqueKeyPerTransaction.setControlDeviceManager(mControlSerialDeviceManager);
            mDeriveUniqueKeyPerTransaction.setContext(this);
            mHumanMachineInterface.setControlDeviceManager(mControlSerialDeviceManager);
            mHumanMachineInterface.setContext(this);
            mManagement.putControlDeviceManager(UpdateDeviceType.PINPAD,
                    mControlSerialDeviceManager);
            mPinpadReset.setControlDeviceManager(mControlSerialDeviceManager);
            mPinpadReset.setContext(this);
            mPinpadReset.setNotifyOnRebootingListener(mNotifyRebootingListener);
            mPrinter.setControlDeviceManager(mControlSerialDeviceManager);
            mPrinter.setContext(this);
            mManagement.putControlDeviceManager(UpdateDeviceType.PRINTER,
                    mControlSerialDeviceManager);
            mPassportReader.setControlDeviceManager(mControlSerialDeviceManager);
            mMagneticStripeCard.setContext(this);
            mConfiguration.setContext(this);
            mBarcodeReader.setControlDeviceManager(mControlSerialDeviceManager);
            mControlSerialDeviceManager
                    .registerNotifyUsbDeviceConnectionListener(mOnEmcrwPermissionListener);
            mNonContactICCard.setControlDeviceManager(mControlSerialDeviceManager);
            mNonContactICCard.setContext(this);
            mNfcPlugin.setContext(mControlSerialDeviceManager, mNonContactICCard);
        } else {
            mControlPinpadDeviceManager = mDeviceManager.createDeviceController(this,
                    DeviceType.USB);
            mControlPinpadDeviceManager.init(PinpadDefine.VID, PinpadDefine.PID);

            mContactIcCard.setControlDeviceManager(mControlPinpadDeviceManager);
            mContactIcCard.setContext(this);
            mPinEnterDevice.setControlDeviceManager(mControlPinpadDeviceManager);
            mPinEnterDevice.setContext(this);
            mDeriveUniqueKeyPerTransaction.setControlDeviceManager(mControlPinpadDeviceManager);
            mDeriveUniqueKeyPerTransaction.setContext(this);
            mHumanMachineInterface.setControlDeviceManager(mControlPinpadDeviceManager);
            mHumanMachineInterface.setContext(this);
            mManagement.putControlDeviceManager(UpdateDeviceType.PINPAD,
                    mControlPinpadDeviceManager);
            mPinpadReset.setControlDeviceManager(mControlPinpadDeviceManager);
            mPinpadReset.setContext(this);
            mPinpadReset.setNotifyOnRebootingListener(mNotifyRebootingListener);
            mControlPinpadDeviceManager
                    .registerNotifyUsbDeviceConnectionListener(mOnPinpadPermissionListener);

            mControlPrinterDeviceManager = mDeviceManager.createDeviceController(this,
                    DeviceType.USB);
            mControlPrinterDeviceManager.init(0x0483, 0x5740);
            mPrinter.setControlDeviceManager(mControlPrinterDeviceManager);
            mManagement.putControlDeviceManager(UpdateDeviceType.PRINTER,
                    mControlPrinterDeviceManager);
            mPrinter.setContext(this);

            // PassportReader
            mControlPassportReaderDeviceManager =
                    mDeviceManager.createDeviceController(this, DeviceType.USB);
            mControlPassportReaderDeviceManager
                    .registerNotifyUsbDeviceConnectionListener(mTerminalStatusManager);
            mControlPassportReaderDeviceManager.init(PassportReaderDefine.VID,
                    PassportReaderDefine.PID);
            mPassportReader.setControlDeviceManager(mControlPassportReaderDeviceManager);

            mMagneticStripeCard.setContext(this);
            mConfiguration.setContext(this);

            // Signpad
            mControlSignpadDeviceManager = mDeviceManager.createDeviceController(this,
                    DeviceType.USB);
            mControlSignpadDeviceManager
                    .registerNotifyUsbDeviceConnectionListener(mTerminalStatusManager);
            mControlSignpadDeviceManager.init(SignpadDefine.VID, SignpadDefine.PID_LIST, null);
            mSignpad.setControlDeviceManager(mControlSignpadDeviceManager);

            // BarcodeReader (OPTICON M-10/C-40/C-41)
            mControlBarcodeReaderDeviceManager =
                    mDeviceManager.createDeviceController(this, DeviceType.USB);
            mControlBarcodeReaderDeviceManager
                    .registerNotifyUsbDeviceConnectionListener(mTerminalStatusManager);
            mControlBarcodeReaderDeviceManager.init(BarcodeReaderDefine.VID,
                    BarcodeReaderDefine.PID_LIST, null);
            mBarcodeReader.setControlDeviceManager(mControlBarcodeReaderDeviceManager);

            mControlEmcrwDeviceManager = mDeviceManager
                    .createDeviceController(this, DeviceType.USB);
            mControlEmcrwDeviceManager
                    .registerNotifyUsbDeviceConnectionListener(mOnEmcrwPermissionListener);
            mControlEmcrwDeviceManager.init(EmcrwDefine.VID, EmcrwDefine.PID_LIST, EmcrwDefine.USB_BUS_POWER_LIST);

            mNonContactICCard.setControlDeviceManager(mControlEmcrwDeviceManager);
            mNonContactICCard.setContext(this);
            mNfcPlugin.setContext(mControlEmcrwDeviceManager, mNonContactICCard);

            mManagement.setNonContactICCard(mNonContactICCard);
            mManagement.setTerminalStatusManager(mTerminalStatusManager);
        }
        mControlPosDeviceManager =
                mDeviceManager.createDeviceController(this,
                        DeviceType.SERIAL);
        mPointOfSaleSystem.setControlDeviceManager(mControlPosDeviceManager);
        mPointOfSaleSystem.setContext(this);

        registerReceiver(mNoPaperEventShowReceiver, new IntentFilter(
                SystemNotification.PRINTER_DEVICE_SHOW));
        registerReceiver(mNoPaperEventDismissReceiver, new IntentFilter(
                SystemNotification.PRINTER_DEVICE_DISMISS));

        registerReceiver(mDeviceMonitorStartReceiver, new IntentFilter(
                DeviceMonitorManager.ACTION_DEVICE_MONITOR_STARTED));

        registerReceiver(mDeviceMonitorReceiver, new IntentFilter(
                DeviceMonitorManager.ACTION_DEVICE_STATUS_CHANGED));

        registerReceiver(mPinpadResetReceiver, new IntentFilter(
                PinpadReset.RESET_PINPAD_EXECUTE));

        registerReceiver(mDialogReceiver, new IntentFilter(PRINTER_PAPER_CUT));

        mDeviceMonitorManager = new DeviceMonitorManager();
        mDeviceMonitorManager.startMonitoring(DeviceMonitorManager.DEVICE_ID_PRINTER_COVER);

        Intent intent = new Intent(this, TamperDecideService.class);
        startService(intent);
    }

    /**
     * @see Service#onBind(Intent)
     */
    @Override
    public IBinder onBind(Intent intent) {
        // mLoggingManager.d(TAG, "onBind " + intent.getAction());

        if (IIcrwService.class.getName().equals(intent.getAction())) {
            return mIIcrwService;
        } else if (IPedService.class.getName().equals(intent.getAction())) {
            return mIPedService;
        } else if (IMsrService.class.getName().equals(intent.getAction())) {
            return mIMsrService;
        } else if (IHmiService.class.getName().equals(intent.getAction())) {
            return mIHmiService;
        } else if (IHmiPrivateService.class.getName().equals(intent.getAction())) {
            return mIHmiPrivateService;
        } else if (IDukService.class.getName().equals(intent.getAction())) {
            return mIDukService;
        } else if (IPrnService.class.getName().equals(intent.getAction())) {
            return mIPrnService;
        } else if (IMgtService.class.getName().equals(intent.getAction())) {
            return mIMgtService;
        } else if (IPprService.class.getName().equals(intent.getAction())) {
            return mIPprService;
        } else if (ICfgService.class.getName().equals(intent.getAction())) {
            return mICfgService;
        } else if (IPosService.class.getName().equals(intent.getAction())) {
            return mIPosService;
        } else if (IMgtPrivateService.class.getName().equals(intent.getAction())) {
            return mIMgtPrivateService;
        } else if (ISpadService.class.getName().equals(intent.getAction())) {
            return mISpadService;
        } else if (IBcrService.class.getName().equals(intent.getAction())) {
            return mIBcrService;
        } else if (IEmcrwService.class.getName().equals(intent.getAction())) {
            return mIEmcrwService;
        } else if (INfcService.class.getName().equals(intent.getAction())) {
            return mINfcService;
        } else if (IEmcrwInternalService.class.getName().equals(intent.getAction())) {
            return mIEmcrwInternalService;
        }

        return null;
    }

    /**
     * @see Service#onStartCommand(Intent, int, int)
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return Service.START_REDELIVER_INTENT;
    }

    /**
     * @see Service#onDestroy()
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        // mLoggingManager.d(TAG, "onDestroy");
        LoggingManager.getInstance().term(this);
        mDeviceMonitorManager.stopMonitoring(DeviceMonitorManager.DEVICE_ID_PRINTER_COVER);
        unregisterReceiver(mDeviceMonitorReceiver);
        unregisterReceiver(mNoPaperEventShowReceiver);
        unregisterReceiver(mNoPaperEventDismissReceiver);
        unregisterReceiver(mDeviceMonitorStartReceiver);
        unregisterReceiver(mPinpadResetReceiver);
        unregisterReceiver(mSystemIconReceiver);
        unregisterReceiver(mUsbDeviceReceiver);
        startService(new Intent(this, CordovaPluginService.class));
    }

    /** @see IIcrwService */
    private IIcrwService.Stub mIIcrwService = new IIcrwService.Stub() {

        /**
         * @see IIcrwService.Stub#initICRW(int)
         */
        @Override
        public ResultInitICRW initICRW(int ictimeout) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (mLock) {
                ResultInitICRW lock = new ResultInitICRW();
                lock.setUpos(PluginDefine.RESULT_UPOS_OFFLINE);
                lock.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                return lock;
            }

            mLoggingManager.d(TAG, "initICRW ictimeout: " + ictimeout);
            ResultInitICRW ret = mContactIcCard.initICRW(ictimeout);
            mLoggingManager.d(TAG, "initICRW " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#activateIcc(boolean)
         */
        @Override
        public ResultActivationIcc activateIcc(boolean req) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "activateIcc req: " + req);
            ResultActivationIcc ret = mContactIcCard.activateIcc(req);
            mLoggingManager.d(TAG, "activateIcc " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#sendAPDU(boolean, int, String, int)
         */
        @Override
        public ResultSendAPDU sendAPDU(boolean encrypt, int num, String apdu, int id)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "sendAPDU encrypt: " + encrypt + " num: " + num + " apdu: "
                    + apdu + " id: " + id);
            ResultSendAPDU ret = mContactIcCard.sendAPDU(encrypt, num, apdu, id);
            mLoggingManager.d(TAG, "sendAPDU " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#deactivateIcc()
         */
        @Override
        public ResultDeactivationIcc deactivateIcc() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "deactivateIcc");
            ResultDeactivationIcc ret = mContactIcCard.deactivateIcc();
            mLoggingManager.d(TAG, "deactivateIcc " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#termICRW()
         */
        @Override
        public ResultTermICRW termICRW() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "termICRW");
            ResultTermICRW ret = mContactIcCard.termICRW();
            mLoggingManager.d(TAG, "termICRW " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#registerContactIcCardServiceListener(IIcrwServiceListener)
         */
        @Override
        public void registerIcrwServiceListener(String tag, IIcrwServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerContactIcCardServiceListener");
            mContactIcCard.registerContactIcCardServiceListener(tag, listener);
        }

        /**
         * @see IIcrwService.Stub#unregisterContactIcCardServiceListener(IIcrwServiceListener)
         */
        @Override
        public void unregisterIcrwServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterContactIcCardServiceListener");
            mContactIcCard.unregisterContactIcCardServiceListener(tag);
        }

        /**
         * @see IIcrwService.Stub#getVersionInfo()
         */
        @Override
        public ResultGetVersionInfo getVersionInfo()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getVersionInfo");
            ResultGetVersionInfo ret = mContactIcCard.getVersionInfo();
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mContactIcCard.getPackageInfo(jsName, jsVer, pluginName,
                    pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#getIFDInfo()
         */
        @Override
        public ResultGetIFDInfo getIFDInfo() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getIFDInfo");
            ResultGetIFDInfo ret = mContactIcCard.getIFDInfo();
            mLoggingManager.d(TAG, "getIFDInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#getICStatus()
         */
        @Override
        public ResultGetICStatus getICStatus() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getICStatus");
            ResultGetICStatus ret = mContactIcCard.getICStatus();
            mLoggingManager.d(TAG, "getICStatus " + ret.toJSON());
            return ret;
        }

        /**
         * @see IIcrwService.Stub#checkHealth()
         */
        @Override
        public ResultCheckHealth checkHealth() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "checkHealth");
            ResultCheckHealth ret = mContactIcCard.checkHealth();
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }
    };

    /**
     * @see IPedService
     */
    private IPedService.Stub mIPedService = new IPedService.Stub() {

        /**
         * @see IPedService#initPed(String)
         */
        @Override
        public ResultInitPed initPed(String args) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (mLock) {
                ResultInitPed lock = new ResultInitPed();
                lock.setUpos(PluginDefine.RESULT_UPOS_OFFLINE);
                lock.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                return lock;
            }

            mLoggingManager.d(TAG, "initPed");
            ResultInitPed ret = mPinEnterDevice.initPed(args);
            mLoggingManager.d(TAG, "initPed " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService#startGetPinData(boolean, int, int, String, String, int, int, int, int,
         *      String, String, int)
         */
        @Override
        public ResultStartGetPinData startGetPinData(boolean isTraining, int pintype, int country,
                String currency, String amount, int screen, int min, int max, int indicate,
                String exp, String pubkey, int isSound)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "startGetPedData isTraining: " + isTraining + " PinType: "
                    + pintype
                    + " Country: " + country + " Currency: " + currency + " Amount: " + amount
                    + " Screen: " + screen + " Min: " + min + " Max: " + max + " Indicate: "
                    + indicate + " Exp: " + exp + " pubkey: " + pubkey + " isSound: " + isSound);

            ResultStartGetPinData ret = mPinEnterDevice.startGetPinData(isTraining, pintype,
                    country, currency, amount, screen, min, max, indicate, exp, pubkey, isSound);
            mLoggingManager.d(TAG, "startGetPinData " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService#startGetEMPinData(boolean, int, int, int, boolean, String, int, int,
         *      int)
         */
        @Override
        public ResultStartGetEMPinData startGetEMPinData(boolean isTraining, int pintype,
                int title1, int title2, boolean isShowCountry, String amount, int min, int max,
                int isSound) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "startGetEMPinData isTraining: " + isTraining + " PinType: "
                    + pintype + " title1: " + title1 + " title2: " + title2 + " isShowCountry: "
                    + isShowCountry + " Amount: " + amount + " Min: " + min + " Max: " + max
                    + " isSound: " + isSound);
            ResultStartGetEMPinData ret = mPinEnterDevice.startGetEMPinData(isTraining, pintype,
                    title1, title2, isShowCountry, amount, min, max, isSound);
            mLoggingManager.d(TAG, "startGetEMPinData " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService#cancelGetPed()
         */
        @Override
        public ResultCancelGetPin cancelGetPin() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "cancelGetPed");
            ResultCancelGetPin ret = mPinEnterDevice.cancelGetPin();
            mLoggingManager.d(TAG, "cancelGetPed " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService#termPed()
         */
        @Override
        public ResultTermPed termPed() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "termPed");
            ResultTermPed ret = mPinEnterDevice.termPed();
            mLoggingManager.d(TAG, "termPed " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService#registerPedServiceListener(IPedServiceListener)
         */
        @Override
        public void registerPedServiceListener(String tag, IPedServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerPedServiceListener");
            mPinEnterDevice.registerPedServiceListener(tag, listener);
        }

        /**
         * @see IPedService#unregisterPedServiceListener(IPedServiceListener)
         */
        @Override
        public void unregisterPedServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterPedServiceListener");
            mPinEnterDevice.unregisterPedServiceListener(tag);
        }

        /**
         * @see IPedService#getVersionInfo()
         */
        @Override
        public ResultGetVersionInfo getVersionInfo() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getVersionInfo");
            ResultGetVersionInfo ret = mPinEnterDevice.getVersionInfo();
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService#checkHealth()
         */
        @Override
        public ResultCheckHealth checkHealth()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "checkHealth");
            ResultCheckHealth ret = mPinEnterDevice.checkHealth();
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPedService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mPinEnterDevice.getPackageInfo(jsName, jsVer, pluginName,
                    pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

    };

    /**
     * @see IMsrService
     */
    private IMsrService.Stub mIMsrService = new IMsrService.Stub() {

        /**
         * @see IMsrService.Stub#registerMsrServiceListener(IMsrServiceListener)
         */
        @Override
        public void registerMsrServiceListener(String tag, IMsrServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerMsrServiceListener");
            mMagneticStripeCard.registerMsrServiceListener(tag, listener);
        }

        /**
         * @see IMsrService.Stub#unregisterMsrServiceListener(IMsrServiceListener)
         */
        @Override
        public void unregisterMsrServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterMsrServiceListener");
            mMagneticStripeCard.unregisterMsrServiceListener(tag);
        }

        /**
         * @see IMsrService.Stub#initMSR()
         */
        @Override
        public ResultInitMSR initMSR() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initMSR");
            ResultInitMSR ret = mMagneticStripeCard.initMSR();

            if (mPdsClientManager == null) {
                mLoggingManager.d(TAG, "initMSR " + ret.toJSON());
                return ret;
            }

            if (mFirstMsrCheck) {
                String msr = Util.getFirmVersion(PdsClientManager.KEY_FMV_PAYMENT2);

                if (msr == null) {
                    mLoggingManager.d(TAG, "initMSR " + ret.toJSON());
                    return ret;
                }

                // msr
                ResultGetVersionInfo info = mMagneticStripeCard.getVersionInfo();

                if (info == null) {
                    mLoggingManager.d(TAG, "initMSR " + ret.toJSON());
                    return ret;
                }

                String[] pfver = msr.split("_");
                if (pfver == null || pfver.length != 3 || info.getPfVer() == null) {
                    mLoggingManager.d(TAG, "initMSR " + ret.toJSON());
                    return ret;
                } else if (info.getPfVer().indexOf(pfver[2]) < 0) {
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            SystemNotification.notifyShowIcon(CordovaPluginService.this,
                                    IconType.OTHER_DEVICE);
                        }
                    });
                }
                mFirstMsrCheck = false;
            } else if (mMsrVersionError) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        SystemNotification.notifyShowIcon(CordovaPluginService.this,
                                IconType.OTHER_DEVICE);
                    }
                });
            }

            mLoggingManager.d(TAG, "initMSR " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMsrService.Stub#startGetMSRead(int, int)
         */
        @Override
        public ResultStartGetMSRead startGetMSRead(int mode, int timeout) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "startGetMSRead mode: " + mode + " timeout: " + timeout);
            ResultStartGetMSRead ret = mMagneticStripeCard.startGetMSRead(mode, timeout);
            mLoggingManager.d(TAG, "startGetMSRead " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMsrService.Stub#cancelGetMSRead()
         */
        @Override
        public ResultCancelGetMSRead cancelGetMSRead() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "cancelGetMSRead");
            ResultCancelGetMSRead ret = mMagneticStripeCard.cancelGetMSRead();
            mLoggingManager.d(TAG, "cancelGetMSRead " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMsrService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mMagneticStripeCard.getPackageInfo(jsName, jsVer,
                    pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMsrService.Stub#checkHealth()
         */
        @Override
        public ResultCheckHealth checkHealth() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "checkHealth");
            ResultCheckHealth ret = mMagneticStripeCard.checkHealth();
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMsrService.Stub#getVersionInfo()
         */
        @Override
        public ResultGetVersionInfo getVersionInfo() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getVersionInfo");
            ResultGetVersionInfo ret = mMagneticStripeCard.getVersionInfo();
            ret.setModel(mPdsClientManager.getTerminalStatus(PdsClientManager.KEY_PRODUCT_NO));
            ret.setSno(mPdsClientManager.getTerminalStatus(PdsClientManager.KEY_PRODUCT_ID));
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMsrService.Stub#termMSR()
         */
        @Override
        public ResultTermMSR termMSR() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termMSR");
            ResultTermMSR ret = mMagneticStripeCard.termMSR();
            mLoggingManager.d(TAG, "termMSR " + ret.toJSON());
            return ret;
        }
    };

    /**
     * @see IHmiService
     */
    private IHmiService.Stub mIHmiService = new IHmiService.Stub() {

        /**
         * @see IHmiService.Stub#registerHmiServiceListener(IHmiServiceListener)
         */
        @Override
        public void registerHmiServiceListener(String tag, IHmiServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerHmiServiceListener");
            mHumanMachineInterface.registerHmiServiceListener(tag, listener);
        }

        /**
         * @see IHmiService.Stub#unregisterHmiServiceListener(IHmiServiceListener)
         */
        @Override
        public void unregisterHmiServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterHmiServiceListener");
            mHumanMachineInterface.unregisterHmiServiceListener(tag);
        }

        /**
         * @see IHmiService.Stub#startGetFuncKey(int, int)
         */
        @Override
        public ResultStartGetFuncKey startGetFuncKey(int key, int timeout) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "startGetFuncKey key: " + key + "timeout" + timeout);
            ResultStartGetFuncKey ret = mHumanMachineInterface.startGetFuncKey(key, timeout);
            mLoggingManager.d(TAG, "startGetFuncKey " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#cancelGetFuncKey()
         */
        @Override
        public ResultCancelGetFuncKey cancelGetFuncKey() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "cancelGetFuncKey");
            ResultCancelGetFuncKey ret = mHumanMachineInterface.cancelGetFuncKey();
            mLoggingManager.d(TAG, "cancelGetFuncKey " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#updateLCDMode(boolean, boolean, int)
         */
        @Override
        public ResultUpdateLCDMode updateLCDMode(int mode, int lump, int contrast)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "updateLCDMode mode: " + mode + " lump: " + lump + " contrast: "
                    + contrast);
            ResultUpdateLCDMode ret = mHumanMachineInterface.updateLCDMode(mode, lump, contrast);
            mLoggingManager.d(TAG, "updateLCDMode " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#putLCDString(String, int)
         */
        @Override
        public ResultPutLCDString putLCDString(String text, int sound) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "putLCDString text: " + text);
            ResultPutLCDString ret = mHumanMachineInterface.putLCDString(text, sound);
            mLoggingManager.d(TAG, "putLCDString " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#putLCDImage(int, int, int, int)
         */
        @Override
        public ResultPutLCDImage putLCDImage(int x, int y, int image, int sound)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "putLCDImage x: " + x + " y: " + y + " image: " + image
                    + " sound: " + sound);
            ResultPutLCDImage ret = mHumanMachineInterface.putLCDImage(x, y, image, sound);
            mLoggingManager.d(TAG, "putLCDImage " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#updateLEDMode(int[])
         */
        @Override
        public ResultUpdateLEDMode updateLEDMode(int[] mode) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            String str = "";
            if (mode != null) {
                for (int i = 0; i < mode.length; i++) {
                    str += " mode[" + i + "]: " + mode[i];
                }
            }
            mLoggingManager.d(TAG, "updateLEDMode" + str);

            ResultUpdateLEDMode ret = mHumanMachineInterface.updateLEDMode(mode);
            mLoggingManager.d(TAG, "updateLEDMode " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#updateBuzzerMode(int)
         */
        @Override
        public ResultUpdateBuzzerMode updateBuzzerMode(int vol) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "updateBuzzerMode vol: " + vol);
            ResultUpdateBuzzerMode ret = mHumanMachineInterface.updateBuzzerMode(vol);
            mLoggingManager.d(TAG, "updateBuzzerMode " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#requestBuzzerON(int)
         */
        @Override
        public ResultRequestBuzzerON requestBuzzerON(int type) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "requestBuzzerON type: " + type);
            ResultRequestBuzzerON ret = mHumanMachineInterface.requestBuzzerON(type);
            mLoggingManager.d(TAG, "requestBuzzerON " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#disconnectBluetooth(int)
         */
        @Override
        public ResultDisconnectBluetooth disconnectBluetooth(int mode) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "disconnectBluetooth mode: " + mode);
            ResultDisconnectBluetooth ret = mHumanMachineInterface.disconnectBluetooth(mode);
            mLoggingManager.d(TAG, "disconnectBluetooth " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#requestPowerOFF()
         */
        @Override
        public ResultRequestPowerOFF requestPowerOFF() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "requestPowerOFF");
            ResultRequestPowerOFF ret = mHumanMachineInterface.requestPowerOFF();
            mLoggingManager.d(TAG, "requestPowerOFF " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mHumanMachineInterface.getPackageInfo(jsName, jsVer,
                    pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#checkHealth()
         */
        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultCheckHealth checkHealth()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "checkHealth");
            com.panasonic.avc.smartpayment.devctlservice.share.result.hmi.ResultCheckHealth ret = mHumanMachineInterface
                    .checkHealth();
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }

        /**
         * @see IHmiService.Stub#initHMI()
         */
        @Override
        public ResultInitHMI initHMI(int charset) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (mLock) {
                ResultInitHMI lock = new ResultInitHMI();
                lock.setUpos(PluginDefine.RESULT_UPOS_OFFLINE);
                lock.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                return lock;
            }

            mLoggingManager.d(TAG, "initHMI");
            ResultInitHMI ret = mHumanMachineInterface.initHMI(charset);
            mLoggingManager.d(TAG, "initHMI " + ret.toJSON());
            return ret;
        }

    };

    /**
     * @see IHmiPrivateService
     */
    private IHmiPrivateService.Stub mIHmiPrivateService = new IHmiPrivateService.Stub() {

        /**
         * @see IHmiPrivateService.Stub#requestBuzzerON(int, int)
         */
        @Override
        public ResultRequestBuzzerON requestBuzzerON(int type, int vol) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "requestBuzzerON type: " + type);
            ResultRequestBuzzerON ret = mHumanMachineInterface.requestBuzzerON(type, vol);
            mLoggingManager.d(TAG, "requestBuzzerON " + ret.toJSON());
            return ret;
        }

    };

    /**
     * @see IDukService
     */
    private IDukService.Stub mIDukService = new IDukService.Stub() {
        /**
         * @see IDukService.Stub#makeTransactionKey(int)
         */
        @Override
        public ResultMakeTransactionKey makeTransactionKey(int req) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "makeTransactionKey req: " + req);
            if (req == PluginDefine.DUKPT_MAKE_TRANSACTION_MSR) {
                return mMagneticStripeCard.makeTransactionKey();
            } else if (req == PluginDefine.DUKPT_MAKE_TRANSACTION_ICRW) {
                return mDeriveUniqueKeyPerTransaction.makeTransactionKey(req);
            }

            ResultMakeTransactionKey ret = new ResultMakeTransactionKey();
            ret.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            ret.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);
            mLoggingManager.d(TAG, "makeTransactionKey " + ret.toJSON());
            return ret;
        }

        /**
         * @see IDukService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mDeriveUniqueKeyPerTransaction.getPackageInfo(jsName, jsVer,
                    pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IDukService.Stub#checkHealth()
         */
        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultCheckHealth checkHealth()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "checkHealth");
            com.panasonic.avc.smartpayment.devctlservice.share.result.duk.ResultCheckHealth ret = mDeriveUniqueKeyPerTransaction
                    .checkHealth();
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }

        /**
         * @see IDukService.Stub#getVersionInfo()
         */
        @Override
        public ResultGetVersionInfo getVersionInfo() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getVersionInfo");
            ResultGetVersionInfo ret = mDeriveUniqueKeyPerTransaction.getVersionInfo();
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IDukService.Stub#registerDukptServiceListener(IDukServiceListener)
         */
        @Override
        public void registerDukptServiceListener(String tag, IDukServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerDukptServiceListener");
            mDeriveUniqueKeyPerTransaction.registerDukptServiceListener(tag, listener);
        }

        /**
         * @see IDukService.Stub#unregisterDukptServiceListener(IDukServiceListener)
         */
        @Override
        public void unregisterDukptServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterDukptServiceListener");
            mDeriveUniqueKeyPerTransaction.unregisterDukptServiceListener(tag);
        }

        /**
         * @see IDukService.Stub#initDuk()
         */
        @Override
        public ResultInitDuk initDuk() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "initDuk");
            ResultInitDuk ret = mDeriveUniqueKeyPerTransaction.initDuk();
            mLoggingManager.d(TAG, "initDuk " + ret.toJSON());
            return ret;
        }
    };

    /**
     * @see IMgtService
     */
    private IMgtService.Stub mIMgtService = new IMgtService.Stub() {

        /**
         * @see IMgtService#registerMgtServiceListener(IMgtServiceListener)
         */
        @Override
        public void registerMgtServiceListener(String tag, IMgtServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerMgtServiceListener");
            mManagement.registerMgtServiceListener(tag, listener);
        }

        /**
         * @see IMgtService#unregisterMgtServiceListener(IMgtServiceListener)
         */
        @Override
        public void unregisterMgtServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterMgtServiceListener");
            mManagement.unregisterMgtServiceListener(tag);
        }

        /**
         * @see IMgtService#initMtg()
         */
        @Override
        public ResultInitMgt initMgt() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initMgt");
            ResultInitMgt ret = mManagement.initMtg();
            mLoggingManager.d(TAG, "initMgt " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMgtService#startSendFile(String, int, int, String)
         */
        @Override
        public ResultStartSendFile startSendFile(String name, int flen, int crc, String data)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "startSendFile name: " + name + " flen: " + flen + " crc: "
                    + crc + " data: " + data);
            ResultStartSendFile ret = mManagement.startSendFile(name, flen, crc, data);
            mLoggingManager.d(TAG, "startSendFile " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMgtService#execUpdate()
         */
        @Override
        public ResultExecUpdate execUpdate() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "execUpdate");
            ResultExecUpdate ret = mManagement.execUpdate();
            mLoggingManager.d(TAG, "execUpdate " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMgtService#startGetFile(String)
         */
        @Override
        public ResultStartGetFile startGetFile(String name) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "startGetFile name: " + name);
            ResultStartGetFile ret = mManagement.startGetFile(name);
            mLoggingManager.d(TAG, "startGetFile " + ret.toJSON());
            return ret;
        }

        /**
         * @see IMgtService#getPackageInfo(String, String, String, String)
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mManagement.getPackageInfo(jsName, jsVer, pluginName,
                    pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

    };

    private IMgtPrivateService.Stub mIMgtPrivateService = new IMgtPrivateService.Stub() {

        @Override
        public void registerMgtPrivateServiceListener(String tag,
                IMgtPrivateServiceListener listener) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerMgtPrivateServiceListener");
            mManagement.registerMgtPrivateServiceListener(tag, listener);
        }

        @Override
        public void unregisterMgtPrivateServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterMgtPrivateServiceListener");
            mManagement.unregisterMgtPrivateServiceListener(tag);
        }

        @Override
        public boolean isDifferentVersionPinpad() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            mLoggingManager.d(TAG, "isDefferentVersionPinpad");

            if (!mContactIcCard.isEnableDevice()) {
                return false;
            }

            boolean ret = mManagement.isDefferentVersion(UpdateDeviceType.PINPAD);
            mLoggingManager.d(TAG, "isDefferentVersionPinpad " + ret);
            return ret;
        }

        @Override
        public boolean startSendFilePinpad() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }

            mLoggingManager.d(TAG, "startSendFilePinpad");
            boolean ret = mManagement.startSendFile(UpdateDeviceType.PINPAD);
            mLoggingManager.d(TAG, "startSendFilePinpad " + ret);
            return ret;
        }

        @Override
        public boolean execUpdatePinpad() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            mLoggingManager.d(TAG, "execUpdatePinpad");
            boolean ret = mManagement.execUpdate(CallbackType.PRIVATE, UpdateDeviceType.PINPAD);
            mLoggingManager.d(TAG, "execUpdatePinpad " + ret);
            return ret;
        }

        /**
         * FW 更新情報と接続中非接触ICカードリーダライタを比較しアップデートの必要有無を判定する
         */
        @Override
        public boolean needUpdateNonContactICCard() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            mLoggingManager.d(TAG, "needUpdateNonContactICCard");

            if (!mNonContactICCard.isEnableDevice()) {
                return false;
            }

            int count = 0;

            if (!mNonContactICCard.isPrepared()) {
                return false;
            }

            EmcrwApplicationDataMap curtAPDataMap = mNonContactICCard.getAPDataMap();
            EmcrwPlatformData curtPFData = mNonContactICCard.getPFData();
            EmcrwUpdateInfo updateInfo = EmcrwUpdateInfoCreator.create(
                    Management.FIRMWARE_DIRECTORY_NON_CONTACT_ICCARD_RW);

            if (curtAPDataMap == null || curtPFData == null || updateInfo == null) {
                // FW 更新情報がない or 非接触ICカードリーダライタが接続されていない
                return false;
            }

            boolean ret = mManagement.needUpdateNonContactICCard(updateInfo, curtPFData,
                    curtAPDataMap);

            mLoggingManager.d(TAG, "needUpdateNonContactICCard " + ret);
            return ret;
        }

        @Override
        public boolean execUpdateNonContactICCard() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            mLoggingManager.d(TAG, "execUpdateNonContactICCard");
            // ファームウェア情報はこちら「firmware2/rw/firmware」

            // アップデートが必要なものを確認し、リストアップ
            // リストアップされたアップデート用のアプリバイナリを読み込む
            // APアップデートを行う
            // PFのアップデートを行う
            // リセットを行う

            boolean ret = mManagement.execUpdate(CallbackType.PRIVATE,
                    UpdateDeviceType.CONTACT_LESS_ICRW);
            return ret;
        }

        @Override
        public boolean debugExecUpdateNonContactICCardRWAPSync(byte[] data) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            return mNonContactICCard.execUpdateAP(data);
        }

        @Override
        public boolean debugExecUpdateNonContactICCardRWPFSync(byte[] data) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            return mNonContactICCard.execUpdatePF(data);
        }

        @Override
        public boolean debugExecReset() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return false;
            }
            return mNonContactICCard.reset();
        }
    };

    /**
     * @see IPrnService
     */
    private IPrnService.Stub mIPrnService = new IPrnService.Stub() {

        /**
         * @see IPrnService#registerPrnServiceListener(IPrnServiceListener)
         */
        @Override
        public void registerPrnServiceListener(String tag, IPrnServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerPrnServiceListener");
            mPrinter.registerPrnServiceListener(tag, listener);
        }

        /**
         * @see IPrnService#unregisterPrnServiceListener(IPrnServiceListener)
         */
        @Override
        public void unregisterPrnServiceListener(String tag)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterPrnServiceListener");
            mPrinter.unregisterPrnServiceListener(tag);
        }

        /**
         * @see IPrnService#initPrn(boolean, int)
         */
        @Override
        public ResultInitPrn initPrn(int bold, int density, int charset, int width)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initPrn bold: " + bold + " density: " + density + " charset: "
                    + charset + " width: " + width);
            ResultInitPrn ret = mPrinter.initPrn(bold, density, charset, width);

            if (mPdsClientManager == null) {
                mLoggingManager.d(TAG, "initPrn " + ret.toJSON());
                return ret;
            }

            if (mFirstPrnCheck) {
                String printer =
                        Util.getFirmVersion(PdsClientManager.KEY_FMV_PAYMENT1);

                if (printer == null) {
                    mLoggingManager.d(TAG, "initPrn " + ret.toJSON());
                    return ret;
                }

                // Printer
                com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultGetVersionInfo
                info = mPrinter
                        .getVersionInfo();

                if (info == null) {
                    mLoggingManager.d(TAG, "initPrn " + ret.toJSON());
                    return ret;
                }

                String[] pfver = info.getPfVer().split("____");
                String[] prn = printer.split("_");
                if (pfver == null || pfver.length != 2 || prn.length != 3 ||
                        info.getPfVer() == null) {
                    mLoggingManager.d(TAG, "initPrn " + ret.toJSON());
                    return ret;
                } else if (pfver[1].indexOf(prn[2]) < 0) {
                    mPrnVersionError = true;
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            SystemNotification.notifyShowIcon(CordovaPluginService.this,
                                    IconType.OTHER_DEVICE);
                        }
                    });
                }
                mFirstPrnCheck = false;
            } else if (mPrnVersionError) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        SystemNotification.notifyShowIcon(CordovaPluginService.this,
                                IconType.OTHER_DEVICE);
                    }
                });
            }

            mLoggingManager.d(TAG, "initPrn " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printEscText(String)
         */
        @Override
        public ResultPrintEscText printEscText(String text) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printEscText text: " + text);
            ResultPrintEscText ret = mPrinter.printEscText(text);
            mLoggingManager.d(TAG, "printEscText " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printText(String, int)
         */
        @Override
        public ResultPrintText printText(String text, int scale) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printText text: " + text + " scale: " + scale);
            ResultPrintText ret = mPrinter.printText(text, scale);
            mLoggingManager.d(TAG, "printText " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printImage(int, int, int)
         */
        @Override
        public ResultPrintImage printImage(int image, int scale, int posx) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printImage image: " + image + " scale: " + scale + " posx: "
                    + posx);
            ResultPrintImage ret = mPrinter.printImage(image, scale, posx, false);
            mLoggingManager.d(TAG, "printImage " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printLineFeed()
         */
        @Override
        public ResultPrintLineFeed printLineFeed() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printLineFeed");
            ResultPrintLineFeed ret = mPrinter.printLineFeed();
            mLoggingManager.d(TAG, "printLineFeed " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printCutPaper(int)
         */
        @Override
        public ResultPrintCutPaper printCutPaper(int type) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printCutPaper type: " + type);
            ResultPrintCutPaper ret = mPrinter.printCutPaper(type);
            mLoggingManager.d(TAG, "printCutPaper " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printSetImage(int, String, boolean, String, int, int)
         */
        @Override
        public ResultPrintSetImage printSetImage(int num, String image, boolean isRemove,
                String name, int x, int y) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printSetImage num: " + num + " imageLen: " + image.length()
                    + " isRemove: " + isRemove + " name: " + name + " x: " + x + " y: " + y);

            // if (image != null) {
            // int count = image.length() / 40;
            // for (int i = 0; i < count - 1; i++) {
            // String str = image.substring(i * 40, ((i + 1) * 40 - 1));
            // mLoggingManager.d(TAG, str);
            // }
            // String str = image
            // .substring(image.length() - (image.length() % 40),
            // image.length());
            // }

            ResultPrintSetImage ret = mPrinter.printSetImage(num, image, isRemove, name, x, y, false);
            mLoggingManager.d(TAG, "printSetImage " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printCheckImage(int)
         */
        @Override
        public ResultPrintCheckImage printCheckImage(int num) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printCheckImage num: " + num);
            ResultPrintCheckImage ret = mPrinter.printCheckImage(num, false);
            mLoggingManager.d(TAG, "printCheckImage " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#getPackageInfo(String, String, String, String)
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mPrinter
                    .getPackageInfo(jsName, jsVer, pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#checkHealth()
         */
        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultCheckHealth checkHealth()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "checkHealth");
            com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultCheckHealth ret = mPrinter
                    .checkHealth();
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#getVersionInfo()
         */
        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultGetVersionInfo
                getVersionInfo() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getVersionInfo");
            com.panasonic.avc.smartpayment.devctlservice.share.result.printer.ResultGetVersionInfo ret = mPrinter
                    .getVersionInfo();
            ret.setModel(mPdsClientManager.getTerminalStatus(PdsClientManager.KEY_PRODUCT_NO));
            ret.setSno(mPdsClientManager.getTerminalStatus(PdsClientManager.KEY_PRODUCT_ID));
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#termPrn()
         */
        @Override
        public ResultTermPrn termPrn() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termPrn");
            ResultTermPrn ret = mPrinter.termPrn();
            mLoggingManager.d(TAG, "termPrn " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPrnService#printFlush()
         */
        @Override
        public ResultPrintFlush printFlush() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "printFlush");
            ResultPrintFlush ret = mPrinter.printFlush();
            mLoggingManager.d(TAG, "printFlush " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultPrintQrCode printQrCode(int qrVer, int qrSize, String qrData, int posx)
                throws RemoteException {
            mLoggingManager.d(TAG, "printQrCode");
            ResultPrintQrCode ret = mPrinter.printQrCode(qrVer, qrSize, qrData, posx);
            mLoggingManager.d(TAG, "printQrCode " + ret.toJSON());
            return ret;
        }

    };

    /** @see IPprService */
    private IPprService.Stub mIPprService = new IPprService.Stub() {

        /**
         * @see IPprService#registerPPRServiceListener(IPprServiceListener)
         */
        @Override
        public void registerPPRServiceListener(String tag, IPprServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerPPRServiceListener");
            mPassportReader.registerPprServiceListener(tag, listener);
        }

        /**
         * @see IPprService#unregisterPPRServiceListener(IPprServiceListener)
         */
        @Override
        public void unregisterPPRServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterPPRServiceListener");
            mPassportReader.unregisterPprServiceListener(tag);
        }

        /**
         * @see IPprService#initPPR()
         */
        @Override
        public ResultInitPPR initPPR() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initPPR");
            ResultInitPPR ret = mPassportReader.initPPR();
            mLoggingManager.d(TAG, "initPPR " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPprService#termPPR()
         */
        @Override
        public ResultTermPPR termPPR() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termPPR");
            ResultTermPPR ret = mPassportReader.termPPR();
            mLoggingManager.d(TAG, "termPPR " + ret.toJSON());
            return ret;
        }

        /*
         * @see IPprService#getPackageInfo(java.lang.String, java.lang.String, java.lang.String,
         * java.lang.String)
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mPassportReader.getPackageInfo(jsName, jsVer, pluginName,
                    pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSendPPR sendPPR(int datasz, String data) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "sendPPR");
            ResultSendPPR ret = mPassportReader.sendPPR(datasz, data);
            mLoggingManager.d(TAG, "sendPPR " + ret.toJSON());
            return ret;
        }
    };

    /**
     * @see ICfgService
     */
    private ICfgService.Stub mICfgService = new ICfgService.Stub() {

        /**
         * @see ICfgService.Stub#registerCfgServiceListener(String, ICfgServiceListener)
         */
        @Override
        public void registerCfgServiceListener(String tag, ICfgServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerCfgServiceListener");
            mConfiguration.registerCfgServiceListener(tag, listener);
        }

        /**
         * @see ICfgService.Stub#unregisterCfgServiceListener(String)
         */
        @Override
        public void unregisterCfgServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterCfgServiceListener");
            mConfiguration.unregisterCfgServiceListener(tag);
        }

        /**
         * @see ICfgService.Stub#setBuzzer(int)
         */
        @Override
        public ResultSetBuzzer setBuzzer(int volume) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "setBuzzer");
            ResultSetBuzzer ret = mConfiguration.setBuzzer(volume);
            mLoggingManager.d(TAG, "setBuzzer " + ret.toJSON());
            return ret;
        }

        /**
         * @see ICfgService.Stub#initCfg()
         */
        @Override
        public ResultInitCfg initCfg() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "initCfg");
            ResultInitCfg ret = mConfiguration.initCfg();
            mLoggingManager.d(TAG, "initCfg " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetLowPower setLowPower(int time)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setLowPower time: " + time);
            ResultSetLowPower ret = mConfiguration.setLowPower(time);
            mLoggingManager.d(TAG, "setLowPower " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetBrightness setBrightness(int brightness) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setBrightness brightness: " + brightness);
            ResultSetBrightness ret = mConfiguration.setBrightness(brightness);
            mLoggingManager.d(TAG, "setBrightness " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultGetPrinter getPrinter() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPrinter");
            ResultGetPrinter ret = mConfiguration.getPrinter();
            mLoggingManager.d(TAG, "getPrinter " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultBuzzerOn buzzerOn(int time) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "buzzerOn time: " + time);
            ResultBuzzerOn ret = mConfiguration.buzzerOn(time);
            mLoggingManager.d(TAG, "buzzerOn " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mConfiguration.getPackageInfo(jsName, jsVer, pluginName,
                    pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultCheckHealth checkHealth()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            com.panasonic.avc.smartpayment.devctlservice.share.result.cfg.ResultCheckHealth ret;

            StatusInfoResponse status = mPdsClientManager.getLocalStatusInfo();
            boolean hasUpdate = false;
            if (status == null || status.getCampaignStartDate() == null
                    || status.getCampaignEndDate() == null) {
                hasUpdate = false;
            } else {
                Calendar start = Calendar.getInstance();
                start.setTime(status.getCampaignStartDate());
                Calendar now = Calendar.getInstance();
                long difference = start.getTime().getTime() - now.getTime().getTime();

                if (difference > 0) {
                    hasUpdate = false;
                } else {
                    hasUpdate = true;
                }
            }

            boolean isWired = mManagementDatabase.getSettingIsWired();

            mLoggingManager.d(TAG, "checkHealth");
            ret = mConfiguration.checkHealth(mIsShowPaperLess, mIsShowFatal, hasUpdate, isWired);
            mLoggingManager.d(TAG, "checkHealth " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultGetVersionInfo getVersionInfo() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getVersionInfo");
            ResultGetVersionInfo ret = mConfiguration.getVersionInfo();
            ret.setModel(mPdsClientManager.getTerminalStatus(PdsClientManager.KEY_PRODUCT_NO));
            ret.setSno(mPdsClientManager.getTerminalStatus(PdsClientManager.KEY_PRODUCT_ID));
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }

    };

    private BroadcastReceiver mSystemIconReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (SystemNotification.PRINTER_DEVICE_SHOW.equals(action)) {
                mIsShowPaperLess = true;
            } else if (SystemNotification.PRINTER_DEVICE_DISMISS.equals(action)) {
                mIsShowPaperLess = false;
            } else if (SystemNotification.OTHER_DEVICE_DISMISS.equals(action)) {
                mIsShowFatal = false;
            } else if (SystemNotification.OTHER_DEVICE_SHOW.equals(action)) {
                mIsShowFatal = true;
            }
        }
    };

    /**
     * @see IPosService
     */
    private IPosService.Stub mIPosService = new IPosService.Stub() {

        /**
         * @see IPosService.Stub#registerPosServiceListener(IPosServiceListener)
         */
        @Override
        public void registerPosServiceListener(String tag, IPosServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerPosServiceListener");
            mPointOfSaleSystem.registerPosServiceListener(tag, listener);
        }

        /**
         * @see IPosService.Stub#unregisterPosServiceListener(IPosServiceListener)
         */
        @Override
        public void unregisterPosServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterPosServiceListener");
            mPointOfSaleSystem.unregisterPosServiceListener(tag);
        }

        /**
         * @see IPosService.Stub#initPOS()
         */
        @Override
        public ResultInitPOS initPOS() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initPOS");
            ResultInitPOS ret = mPointOfSaleSystem.initPOS();

            mLoggingManager.d(TAG, "initPOS " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPosService.Stub#sendPOS(int, String, int)
         */
        @Override
        public ResultSendPOS sendPOS(int datasz, String data, int blocksz) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "sendPOS datasz: " + datasz + " data: " + data + " blocksz: "
                    + blocksz);
            ResultSendPOS ret = mPointOfSaleSystem.sendPOS(datasz, data, blocksz);
            mLoggingManager.d(TAG, "sendPOS " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPosService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mPointOfSaleSystem.getPackageInfo(jsName, jsVer,
                    pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IPosService.Stub#termPOS()
         */
        @Override
        public ResultTermPOS termPOS() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termPOS");
            ResultTermPOS ret = mPointOfSaleSystem.termPOS();
            mLoggingManager.d(TAG, "termPOS " + ret.toJSON());
            return ret;
        }
    };

    /** @see ISpadService */
    private ISpadService.Stub mISpadService = new ISpadService.Stub() {

        /**
         * @see ISpadService.Stub#registerSPADServiceListener(String, ISpadServiceListener)
         */
        @Override
        public void registerSPADServiceListener(String tag, ISpadServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerSPADServiceListener");
            mSignpad.registerSpadServiceListener(tag, listener);

        }

        /** @see ISpadService.Stub#unregisterSPADServiceListener(String) */
        @Override
        public void unregisterSPADServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterSPADServiceListener (STU-300)");
            mSignpad.unregisterSpadServiceListener(tag);

        }

        /** @see ISpadService.Stub#initSPAD(boolean) */
        @Override
        public ResultInitSPAD initSPAD(boolean isAdvanced) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initSPAD");
            ResultInitSPAD ret = mSignpad.initSPAD(isAdvanced);
            mLoggingManager.d(TAG, "initSPAD " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#sendSPAD(int, String) */
        @Override
        public ResultSendSPAD sendSPAD(int datasz, String data) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (mSignpad.isAdvanced()) {
                ResultSendSPAD error = new ResultSendSPAD();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "sendSPAD");
            ResultSendSPAD ret = mSignpad.sendSPAD(datasz, data);
            mLoggingManager.d(TAG, "sendSPAD " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getPackageInfo(String, String, String, String) */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + "jsVer: " + jsVer
                    + "pluginName: " + pluginName + "pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mSignpad.getPackageInfo(jsName, jsVer, pluginName,
                    pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#termSPAD() */
        @Override
        public ResultTermSPAD termSPAD() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termSPAD");
            ResultTermSPAD ret = mSignpad.termSPAD();
            mLoggingManager.d(TAG, "termSPAD " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#intervalON(boolean) */
        @Override
        public ResultIntervalON intervalON(boolean interval) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "intervalON");
            ResultIntervalON ret = mSignpad.intervalON(interval);
            mLoggingManager.d(TAG, "intervalON " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setArea(int, int, int, int) */
        @Override
        public ResultSetArea setArea(int ulx, int uly, int lrx, int lry) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetArea error = new ResultSetArea();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setArea uly: " + ulx + " uly: " + uly + " lrx: " + lrx
                    + " lry: " + lry);
            ResultSetArea ret = mSignpad.setArea(ulx, uly, lrx, lry);
            mLoggingManager.d(TAG, "setArea " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getArea() */
        @Override
        public ResultGetArea getArea() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetArea error = new ResultGetArea();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getArea");
            ResultGetArea ret = mSignpad.getArea();
            mLoggingManager.d(TAG, "getArea " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setInking(boolean) */
        @Override
        public ResultSetInking setInking(boolean status) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetInking error = new ResultSetInking();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setInking status: " + status);
            ResultSetInking ret = mSignpad.setInking(status);
            mLoggingManager.d(TAG, "setInking " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getInking() */
        @Override
        public ResultGetInking getInking() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetInking error = new ResultGetInking();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getInking");
            ResultGetInking ret = mSignpad.getInking();
            mLoggingManager.d(TAG, "getInking " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setInkingThreshold(int, int) */
        @Override
        public ResultSetInkingThreshold setInkingThreshold(int on, int off) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetInkingThreshold error = new ResultSetInkingThreshold();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setInkingThreshold on: " + on + " off: " + off);
            ResultSetInkingThreshold ret = mSignpad.setInkingThreshold(on, off);
            mLoggingManager.d(TAG, "setInkingThreshold " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getInkingThreshold() */
        @Override
        public ResultGetInkingThreshold getInkingThreshold() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetInkingThreshold error = new ResultGetInkingThreshold();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getInkingThreshold");
            ResultGetInkingThreshold ret = mSignpad.getInkingThreshold();
            mLoggingManager.d(TAG, "getInkingThreshold " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#clearSPAD() */
        @Override
        public ResultClearSPAD clearSPAD() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultClearSPAD error = new ResultClearSPAD();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "clearSPAD");
            ResultClearSPAD ret = mSignpad.clearSPAD();
            mLoggingManager.d(TAG, "clearSPAD " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#eraseArea(int, int, int, int) */
        @Override
        public ResultEraseArea eraseArea(int ulx, int uly, int lrx, int lry) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultEraseArea error = new ResultEraseArea();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "eraseArea ulx: " + ulx + " uly: " + uly + " lrx: " + lrx
                    + " lry: " + lry);
            ResultEraseArea ret = mSignpad.eraseArea(ulx, uly, lrx, lry);
            mLoggingManager.d(TAG, "eraseArea " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#dispImage(int, int, int, int, int, int, String) */
        @Override
        public ResultDispImage dispImage(int encode, int ulx, int uly, int lrx, int lry,
                int datasz, String data)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultDispImage error = new ResultDispImage();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "dispImage encode: " + encode + " ulx: " + ulx + " uly: " + uly
                    + " lrx: " + lrx + " lry: " + lry);
            ResultDispImage ret = mSignpad.dispImage(encode, ulx, uly, lrx, lry, datasz, data);
            mLoggingManager.d(TAG, "dispImage " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setBackgroundColor(String) */
        @Override
        public ResultSetBackgroundColor setBackgroundColor(String color) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetBackgroundColor error = new ResultSetBackgroundColor();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setBackgroundColor color: " + color);
            ResultSetBackgroundColor ret = mSignpad.setBackgroundColor(color);
            mLoggingManager.d(TAG, "setBackgroundColor " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getBackgroundColor() */
        @Override
        public ResultGetBackgroundColor getBackgroundColor() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetBackgroundColor error = new ResultGetBackgroundColor();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getBackgroundColor");
            ResultGetBackgroundColor ret = mSignpad.getBackgroundColor();
            mLoggingManager.d(TAG, "getBackgroundColor " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setPenMode(String, int) */
        @Override
        public ResultSetPenMode setPenMode(String color, int thickness) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetPenMode error = new ResultSetPenMode();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setPenMode color: " + color + " thickness: " + thickness);
            ResultSetPenMode ret = mSignpad.setPenMode(color, thickness);
            mLoggingManager.d(TAG, "setPenMode " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getPenMode() */
        @Override
        public ResultGetPenMode getPenMode() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetPenMode error = new ResultGetPenMode();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getPenMode");
            ResultGetPenMode ret = mSignpad.getPenMode();
            mLoggingManager.d(TAG, "getPenMode " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setBrightness(int) */
        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBrightness setBrightness(
                int brightness)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBrightness error = new com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBrightness();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setBrightness brightness: " + brightness);
            com.panasonic.avc.smartpayment.devctlservice.share.result.spad.ResultSetBrightness ret = mSignpad
                    .setBrightness(brightness);
            mLoggingManager.d(TAG, "setBrightness " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getBrightness() */
        @Override
        public ResultGetBrightness getBrightness() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetBrightness error = new ResultGetBrightness();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getBrightness");
            ResultGetBrightness ret = mSignpad.getBrightness();
            mLoggingManager.d(TAG, "getBrightness " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getInformation() */
        @Override
        public ResultGetInformation getInformation() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetInformation error = new ResultGetInformation();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getInformation");
            ResultGetInformation ret = mSignpad.getInformation();
            mLoggingManager.d(TAG, "getInformation " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getCapability() */
        @Override
        public ResultGetCapability getCapability() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetCapability error = new ResultGetCapability();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getCapability");
            ResultGetCapability ret = mSignpad.getCapability();
            mLoggingManager.d(TAG, "getCapability " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getStatus() */
        @Override
        public ResultGetStatus getStatus() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetStatus error = new ResultGetStatus();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getStatus");
            ResultGetStatus ret = mSignpad.getStatus();
            mLoggingManager.d(TAG, "getStatus " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getUID() */
        @Override
        public ResultGetUID getUID() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetUID error = new ResultGetUID();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getUID");
            ResultGetUID ret = mSignpad.getUID();
            mLoggingManager.d(TAG, "getUID " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setUID(String) */
        @Override
        public ResultSetUID setUID(String uid) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetUID error = new ResultSetUID();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setUID");
            ResultSetUID ret = mSignpad.setUID(uid);
            mLoggingManager.d(TAG, "setUID " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getUID2() */
        @Override
        public ResultGetUID2 getUID2() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetUID2 error = new ResultGetUID2();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getUID2");
            ResultGetUID2 ret = mSignpad.getUID2();
            mLoggingManager.d(TAG, "getUID2 " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#setBootScreenMode(boolean) */
        @Override
        public ResultSetBootScreenMode setBootScreenMode(boolean bootscreen) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultSetBootScreenMode error = new ResultSetBootScreenMode();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "setBootScreenMode bootscreen: " + bootscreen);
            ResultSetBootScreenMode ret = mSignpad.setBootScreenMode(bootscreen);
            mLoggingManager.d(TAG, "setBootScreenMode " + ret.toJSON());
            return ret;
        }

        /** @see ISpadService.Stub#getBootScreenMode() */
        @Override
        public ResultGetBootScreenMode getBootScreenMode() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            if (!mSignpad.isAdvanced()) {
                ResultGetBootScreenMode error = new ResultGetBootScreenMode();
                error.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
                error.setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
                return error;
            }

            mLoggingManager.d(TAG, "getBootScreenMode");
            ResultGetBootScreenMode ret = mSignpad.getBootScreenMode();
            mLoggingManager.d(TAG, "getBootScreenMode " + ret.toJSON());
            return ret;
        }

    };

    /**
     * @see IBcrService
     */
    private IBcrService.Stub mIBcrService = new IBcrService.Stub() {

        /**
         * @see IBcrService.Stub#registerBcrServiceListener(IBcrServiceListener)
         */
        @Override
        public void registerBcrServiceListener(String tag, IBcrServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerBcrServiceListener");
            mBarcodeReader.registerBcrServiceListener(tag, listener);
        }

        /**
         * @see IBcrService.Stub#unregisterBcrServiceListener(IBcrServiceListener)
         */
        @Override
        public void unregisterBcrServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterBcrServiceListener");
            mBarcodeReader.unregisterBcrServiceListener(tag);
        }

        /**
         * @see IBcrService.Stub#initBCR()
         */
        @Override
        public ResultInitBCR initBCR(int model) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initBCR model:" + model);
            ResultInitBCR ret = mBarcodeReader.initBCR(model);

            mLoggingManager.d(TAG, "initBCR " + ret.toJSON());
            return ret;
        }

        /**
         * @see IBcrService.Stub#sendBCR(int, String)
         */
        @Override
        public ResultSendBCR sendBCR(int datasz, String data) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "sendBCR datasz: " + datasz + " data: " + data);
            ResultSendBCR ret = mBarcodeReader.sendBCR(datasz, data);
            mLoggingManager.d(TAG, "sendBCR " + ret.toJSON());
            return ret;
        }

        /**
         * @see IBcrService.Stub#scanON()
         */
        @Override
        public ResultScanON scanON() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "scanON");
            ResultScanON ret = mBarcodeReader.scanON();
            mLoggingManager.d(TAG, "scanON " + ret.toJSON());
            return ret;
        }

        /**
         * @see IBcrService.Stub#scanOFF()
         */
        @Override
        public ResultScanOFF scanOFF() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "scanOFF");
            ResultScanOFF ret = mBarcodeReader.scanOFF();
            mLoggingManager.d(TAG, "scanOFF " + ret.toJSON());
            return ret;
        }

        /**
         * @see IBcrService.Stub#getPackageInfo()
         */
        @Override
        public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
                String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            ResultGetPackageInfo ret = mBarcodeReader.getPackageInfo(jsName, jsVer,
                    pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        /**
         * @see IBcrService.Stub#termBCR()
         */
        @Override
        public ResultTermBCR termBCR() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termBCR");
            ResultTermBCR ret = mBarcodeReader.termBCR();
            mLoggingManager.d(TAG, "termBCR " + ret.toJSON());
            return ret;
        }

    };

    /**
     * @see IEmcrw Service
     */
    private IEmcrwService.Stub mIEmcrwService = new IEmcrwService.Stub() {

        @Override
        public void registerEmcrwServiceListener(String tag, IEmcrwServiceListener listener)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "registerEmcrwServiceListener");
            mNonContactICCard.registerNonContactIcCardServiceListener(tag, listener);
        }

        @Override
        public void unregisterEmcrwServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return;
            }
            mLoggingManager.d(TAG, "unregisterEmcrwServiceListener");
            mNonContactICCard.unregisterNonContactIcCardServiceListener(tag);
        }

        @Override
        public ResultSendFeliCaCmd sendFeliCaCmd(int timeout, int count,
                int cardCommandPacketLength, String cardCommandPacket) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "sendFelicaCmd timeout:" + timeout + " count:" + count
                    + " cardCommandPacketLength:" + cardCommandPacketLength + " cardCommandPacket:"
                    + cardCommandPacket);

            long start = System.currentTimeMillis();
            // mLoggingManager.d(TAG, (start%1000000) +
            // " sendFelicaCmd: START");
            mLoggingManager.d(TAG, "sendFelicaCmd: START");

            ResultSendFeliCaCmd ret = mNonContactICCard.sendFeliCaCmd(timeout, count,
                    cardCommandPacketLength, cardCommandPacket);

            long end = System.currentTimeMillis();
            // mLoggingManager.d(TAG, (end%1000000) +
            // " sendFelicaCmd: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "sendFelicaCmd: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "sendFelicaCmd " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultInitEmcrw initEmcrw(String stime, int charset) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "initEmcrw stime:" + stime + " charset:" + charset);

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "initEmcrw: START");

            ResultInitEmcrw ret = mNonContactICCard.initEmcrw(stime, charset,
                    (byte) EmcrwDefine.FELICA_APID);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "initEmcrw: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "initEmcrw " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultTermEmcrw termEmcrw() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "termEmcrw");

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "termEmcrw: START");

            ResultTermEmcrw ret = mNonContactICCard.termEmcrw();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "termEmcrw: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "termEmcrw" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultCarrierOn carrierOn() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "carrierOn");

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "carrierOn: START");

            ResultCarrierOn ret = mNonContactICCard.carrierOn();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "carrierOn: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "carrierOn" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultCarrierOff carrierOff() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "carrierOff");

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "carrierOff: START");

            ResultCarrierOff ret = mNonContactICCard.carrierOff();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "carrierOff: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "carrierOff" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetHmi setHmi(int antennaMode, int antennaOntime, int antennaBlinkOn,
                int antennaBlinkOff, int soundNumber, int soundLoop, int lcdImage_A,
                String lcdText_B, int lcdImage_C, String lcdText_D, int lcdImage_E, int lcdImage_B,
                String lcdText_C, int lcdImage_D, String lcdText_F, int lcdImage_F)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setHmi antenaMode:" + antennaMode + " antennaOntime:"
                    + antennaOntime + " antennaBlinkOn:" + antennaBlinkOn + " antennaBlinkOff:"
                    + antennaBlinkOff + " soundNumber:" + soundNumber + " soundLoop:" + soundLoop
                    + " lcdImage_A:" + lcdImage_A + " lcdText_B:" + lcdText_B + " lcdImage_C:"
                    + lcdImage_C + " lcdText_D:" + lcdText_D + " lcdImage_E:" + lcdImage_E
                    + " lcdImage_B:" + lcdImage_B
                    + " lcdText_C:" + lcdText_C + " lcdImage_D:" + lcdImage_D + " lcdText_F:"
                    + lcdText_F + " lcdImage_F:" + lcdImage_F);

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setHmi: START");

            ResultSetHmi ret = mNonContactICCard
                    .setHmi(antennaMode, antennaOntime, antennaBlinkOn, antennaBlinkOff,
                            soundNumber, soundLoop, lcdImage_A, lcdText_B, lcdImage_C, lcdText_D,
                            lcdImage_E, lcdImage_B, lcdText_C, lcdImage_D, lcdText_F, lcdImage_F);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setHmi: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "setHmi" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSendFeliCaAplOff sendFeliCaAplOff() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "sendFelicaAplOff");

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "sendFelicaAplOff: START");

            ResultSendFeliCaAplOff ret = mNonContactICCard.sendFeliCaAplOff();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "sendFelicaAplOff: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "sendFelicaAplOff" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetVolume setVolume(int volume) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setVolume volume:" + volume);

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setVolume: START");

            ResultSetVolume ret = mNonContactICCard.setVolume(volume);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setVolume: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "setVolume" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetImage setImage(int area, int number, String data) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setImage area:" + area + " number:" + number + " data" + data);

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setImage: START");

            ResultSetImage ret = mNonContactICCard.setImage(area, number, data);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setImage: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "setImage" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetSound setSound(int number, String checksum, int dataLength, String data)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setSound number:" + number + " checksum:" + checksum
                    + " dataLength:" + dataLength + " data" + data);

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setSound: START");

            ResultSetSound ret = mNonContactICCard.setSound(number, checksum, dataLength, data);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "setSound: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "setSound" + ret.toJSON());
            return ret;
        }

        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCheckHealth checkHealth()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "checkHealth");

            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "checkHealth: START");

            com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCheckHealth ret = mNonContactICCard
                    .checkHealth();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "checkHealth: END  : time = " + (end - start));

            mLoggingManager.d(TAG, "checkHealth" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultPolling polling(String systemCode, int timeslot, int timeout)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "polling systemCode:" + systemCode + " timeslot:" + timeslot
                    + " timeout:" + timeout);
            ResultPolling ret = mNonContactICCard.polling(systemCode, timeslot, timeout);
            return ret;
        }

        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultGetPackageInfo getPackageInfo(
                String jsName, String jsVer, String pluginName, String pluginVer)
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultGetPackageInfo ret = mNonContactICCard
                    .getPackageInfo(jsName, jsVer, pluginName, pluginVer);
            mLoggingManager.d(TAG, "getPackageInfo " + ret.toJSON());
            return ret;
        }

        @Override
        public com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultGetVersionInfo getVersionInfo()
                throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }

            mLoggingManager.d(TAG, "getVersionInfo");
            com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultGetVersionInfo ret = mNonContactICCard
                    .getVersionInfo();
            mLoggingManager.d(TAG, "getVersionInfo " + ret.toJSON());
            return ret;
        }
    };

    /**
     * @see IEmcrw Internal Service
     */
    private IEmcrwInternalService.Stub mIEmcrwInternalService = new IEmcrwInternalService.Stub() {

        @Override
        public ResultRegistEmcrw registEmcrw(String number) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "registEmcrw number:" + number);

            ResultRegistEmcrw ret = mNonContactICCard.registEmcrw(number);

            mLoggingManager.d(TAG, "registEmcrw" + ret.toJSON());
            return ret;
        }

        @Override
        public ResultSetVolume setVolume(int volume) throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "setVolume Internal volume:" + volume);

            ResultSetVolume ret = mNonContactICCard.setVolumeInternal(volume);

            mLoggingManager.d(TAG, "setVolume Internal " + ret.toJSON());
            return ret;
        }

        @Override
        public ResultAplVersion getAplDataList() throws RemoteException {
            if (!checkPartner(getCallingPid())) {
                return null;
            }
            mLoggingManager.d(TAG, "getAplDataList");

            ResultAplVersion ret = mNonContactICCard.getAplDataList();

            mLoggingManager.d(TAG, "getAplDataList " + ret.toJSON());
            return ret;
        }

    };

    NotifyUsbDeviceConnectionListener mOnEmcrwPermissionListener = new NotifyUsbDeviceConnectionListener() {

        /** 統一バージョンと一致する */
        private boolean mIsCcorrectVersion = false;

        @Override
        public void onOpened(UsbDevice device) {
            mLoggingManager.d(TAG, " EMCRW USB onOpened");

            mNonContactICCard.createEmcrw();
            mNonContactICCard.createEmcrwJoin();

            EmcrwApplicationDataMap curtAPDataMap = mNonContactICCard.getAPDataMap();
            EmcrwPlatformData curtPFData = mNonContactICCard.getPFData();
            EmcrwUpdateInfo updateInfo = EmcrwUpdateInfoCreator.create(
                    Management.FIRMWARE_DIRECTORY_NON_CONTACT_ICCARD_RW);

            if (curtAPDataMap != null && curtPFData != null && updateInfo != null) {
                if (mManagement.needUpdateNonContactICCard(updateInfo, curtPFData, curtAPDataMap)) {
                    SystemNotification.notifyShowIcon(CordovaPluginService.this,
                            IconType.OTHER_DEVICE);
                    mIsCcorrectVersion = false;
                } else {
                    mIsCcorrectVersion = true;
                }
            } else {
                mIsCcorrectVersion = true;
            }

        }

        @Override
        public void onClosed(UsbDevice device) {
            mLoggingManager.d(TAG, " EMCRW USB onClosed");

            if (mIsCcorrectVersion) {
                SystemNotification.notifyShowIcon(CordovaPluginService.this,
                        IconType.OTHER_DEVICE);

            }

            mNonContactICCard.destroyEmcrw();
        }

    };

    private NotifyUsbDeviceConnectionListener mOnPinpadPermissionListener = new NotifyUsbDeviceConnectionListener() {

        /** シンクラ起動後、1 回目の PINPAD 接続 */
        private boolean mFirstConnected = true;

        /** 統一バージョンと一致する */
        private boolean mIsCcorrectVersion = false;

        /**
         * @see OnUsbPermissionListener#onUsbPermission()
         */
        @Override
        public void onOpened(UsbDevice device) {
            if (mManagement.isDefferentVersion(UpdateDeviceType.PINPAD)) {
                SystemNotification.notifyShowIcon(CordovaPluginService.this, IconType.OTHER_DEVICE);
                mIsCcorrectVersion = false;
            } else {
                mIsCcorrectVersion = true;
            }

            // PINPAD バックライトを消灯 (起動後 1 回のみ)
            if (mFirstConnected) {
                mHumanMachineInterface.updateLCDMode(
                        RequestAdvanceLcdSetting.REVERSE_NO_CHANGE,
                        RequestLcdBackLight.BACKLIGHT_OFF,
                        RequestDeviceSetting.CONTRAST_NO_CHANGE);
                mFirstConnected = false;
            }

        }

        @Override
        public void onClosed(UsbDevice device) {
            if (mIsCcorrectVersion) {
                SystemNotification.notifyShowIcon(CordovaPluginService.this, IconType.OTHER_DEVICE);
            }
        }

    };

    /** @brief PINPAD リブート状態通知リスナー */
    private NotifyRebootingListener mNotifyRebootingListener = new NotifyRebootingListener() {

        /**
         * @brief リブート開始通知
         */
        @Override
        public void onStartRebooting() {
            mLock = true;
        }

        /**
         * @brief リブート終了通知
         */
        @Override
        public void onFinishRebooting() {
            mLock = false;
        }

    };

    /**
     * @see INfc Service
     */
    private INfcService.Stub mINfcService = new INfcService.Stub() {

        @Override
        public void registerNfcServiceListener(String tag, INfcServiceListener listener) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "registerNfcServiceListener");
            mNfcPlugin.registerNfcServiceListener(tag, listener);
        }

        @Override
        public void unregisterNfcServiceListener(String tag) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "unregisterNfcServiceListener");
            mNfcPlugin.unregisterNfcServiceListener(tag);
        }

        @Override
        public String OpenDevice() throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "OpenDevice");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "OpenDevice: START");

            String ret = mNfcPlugin.OpenDevice();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "OpenDevice: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "OpenDevice" + ret);
            return ret;
        }

        @Override
        public String CloseDevice() throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "CloseDevice");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "CloseDevice: START");

            String ret = mNfcPlugin.CloseDevice();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "CloseDevice: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "CloseDevice" + ret);
            return ret;
        }

        @Override
        public String DoDeviceSettingData(int fileNumber, String fileData) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "DoDeviceSettingData");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "DoDeviceSettingData: START");

            String ret = mNfcPlugin.DoDeviceSettingData(fileNumber, fileData);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "DoDeviceSettingData: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "DoDeviceSettingData" + ret);
            return ret;
        }

        @Override
        public String DoDCCSettingData(int fileNumber, String fileData, String currencyAbbData) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "DoDCCSettingData");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "DoDCCSettingData: START");

            String ret = mNfcPlugin.DoDCCSettingData(fileNumber, fileData, currencyAbbData);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "DoDCCSettingData: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "DoDCCSettingData" + ret);
            return ret;
        }

        @Override
        public String StartTransaction(String transactionData, int isTraining, String rsaModulusData, String rsaExponentData) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "StartTransaction");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "StartTransaction: START");

            String ret = mNfcPlugin.StartTransaction(transactionData, isTraining, rsaModulusData, rsaExponentData);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "StartTransaction: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "StartTransaction" + ret);
            return ret;
        }

        @Override
        public String CancelTransaction() throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "CancelTransaction");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "CancelTransaction: START");

            String ret = mNfcPlugin.CancelTransaction();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "CancelTransaction: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "CancelTransaction" + ret);
            return ret;
        }

        @Override
        public String SendDataExchange(String deinfo) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "SendDataExchange");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "SendDataExchange: START");

            String ret = mNfcPlugin.SendDataExchange(deinfo);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "SendDataExchange: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "SendDataExchange" + ret);
            return ret;
        }

        @Override
        public String CheckHealth() throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "CheckHealth");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "CheckHealth: START");

            String ret = mNfcPlugin.CheckHealth();

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "CheckHealth: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "CheckHealth" + ret);
            return ret;
        }

        @Override
        public String SetConfiguration(String inKey, String inValue) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "SetConfiguration");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "SetConfiguration: START");

            int ret = mNfcPlugin.SetConfiguration(inKey, inValue);
            String retString = String.valueOf(ret);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "SetConfiguration: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "SetConfiguration" + retString);
            return retString;
        }

        @Override
        public String GetConfiguration(String inKey) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "GetConfiguration");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "GetConfiguration: START");

            String ret = mNfcPlugin.GetConfiguration(inKey);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "GetConfiguration: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "GetConfiguration" + ret);
            return ret;
        }

        @Override
        public String GetPackageInfo(String jsName, String jsVer, String pluginName, String pluginVer) throws RemoteException {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "GetPackageInfo jsName: " + jsName + " jsVer: " + jsVer
                    + " pluginName: " + pluginName + " pluginVer: " + pluginVer);
            String ret = mNfcPlugin.GetPackageInfo(jsName, jsVer, pluginName, pluginVer);
            mLoggingManager.d(TAG, "GetPackageInfo " + ret);
            return ret;
        }

        @Override
        public String SetResult(int hostResult, int showTime) {
            if (!checkPartner(getCallingPid())) {  // PT_IMPOSSIBLE_BRANCH
                return null;  // PT_IMPOSSIBLE_INSTRUCTIONS
            }
            mLoggingManager.d(TAG, "SetResult");
            long start = System.currentTimeMillis();
            mLoggingManager.d(TAG, "SetResult: START");

            String ret = mNfcPlugin.SetResult(hostResult, showTime);

            long end = System.currentTimeMillis();
            mLoggingManager.d(TAG, "SetResult: END  : time = " + (end - start));
            mLoggingManager.d(TAG, "SetResult" + ret);
            return ret;
        }
    };

}
