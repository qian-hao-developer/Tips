
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * PINPADリブート要求クラス
 */
public class RequestRebootPinpad extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x40;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x00;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 2;

    /**
     * @briefコンストラクタ
     * @param[in] encrypt APDUデータの暗号化状態を指定
     * @param[in] num apduのデータ数
     * @param[in] apdu 暗号化した結果
     * @param[in] id データを識別するための番号
     */
    public RequestRebootPinpad() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] paramater = new byte[LENGTH];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }
}
