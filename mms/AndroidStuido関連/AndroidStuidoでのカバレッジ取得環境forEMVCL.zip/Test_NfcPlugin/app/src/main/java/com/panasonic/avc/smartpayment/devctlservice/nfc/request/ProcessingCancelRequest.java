package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * 処理キャンセルRequestクラス.
 * 
 */
public class ProcessingCancelRequest extends BaseRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = ProcessingCancelRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x42;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x03;

    /** Constructor */
    public ProcessingCancelRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        // データ部無し
        return super.toCommand(null);
    }
}
