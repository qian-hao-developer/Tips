
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetInking extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetInking(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetInking() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetInking> CREATOR = new Parcelable.Creator<ResultGetInking>() {

        @Override
        public ResultGetInking createFromParcel(Parcel in) {
            return new ResultGetInking(in);
        }

        @Override
        public ResultGetInking[] newArray(int size) {
            return new ResultGetInking[size];
        }
    };
}
