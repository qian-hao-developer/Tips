package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * AP切替 非接触PINPADプロトコルRequestクラス.
 * 
 */
public class APSwitchingRequest extends BaseRequest {

    /** @brief ログ用タグ */
    private static final String TAG = APSwitchingRequest.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x24;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x02;

    /** @brief AP-ID . */
    private byte mApId;

    /**
     * AP-IDを設定する.
     * 
     * @param apId AP-ID
     */
    public void setApId(byte apId) {
        mApId = apId;
    }

    /** Constructor */
    public APSwitchingRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // AP-ID:0x01~0xFD
        if (ByteUtil.checkTargetValueByte(mApId, (byte) 0x00, (byte) 0x00,
                (byte) 0xfe, (byte) 0xff)) {
            Logger.e(TAG, "isValidValue mApId mismatch =" + mApId);
            return false;
        }
        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return toCommand(new byte[] { mApId });
    }
}
