
package com.panasonic.avc.smartpayment.devctlservice.share.response.ppr;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * PPR通知イベントクラス
 */
public class ResponsePassportReader implements Parcelable {

    /** @brief 受信データサイズ tag */
    private static final String DATASZ = "datasz";

    /** @brief 受信データの16進文字列 tag */
    private static final String DATA = "data";

    /** @brief 受信データサイズ */
    private int mDataSize;

    /** @brief 受信データ */
    private String mData;

    /**
     * コンストラクタ
     */
    public ResponsePassportReader() {
        setDatasz(0);
        setData("");
    }

    /**
     * コンストラクタ
     * 
     * @param[in] dataSize 受信データサイズ（整数型）
     * @param[in] data 受信データの16進文字列
     */
    public ResponsePassportReader(int dataSize, String data) {
        setDatasz(dataSize);
        setData(data);
    }

    /**
     * コンストラクタ
     * 
     * @param[in] source Parcelデータ
     */
    public ResponsePassportReader(Parcel source) {
        readFromParcel(source);
    }

    /**
     * @brief 受信データサイズを取得します
     * @return mDataSize 受信データサイズ
     */
    public int getDatasz() {
        return mDataSize;
    }

    /**
     * @brief 受信データサイズを設定します
     * @param[in] dataSize 受信データサイズ
     */
    public void setDatasz(int dataSize) {
        this.mDataSize = dataSize;
    }

    /**
     * @brief 受信データを取得します
     * @return mData 受信データ
     */
    public String getData() {
        return mData;
    }

    /**
     * @brief 受信データを設定します
     * @param[in] data 受信データ
     */
    public void setData(String data) {
        this.mData = data;
    }

    /**
     * @brief JSON形式で各フィールドの値を出力します
     * @return 各フィールドの値をJSON形式に整形した文字列（失敗時null）
     */
    public String toJSON() {
        JSONObject retobj = new JSONObject();
        try {
            retobj.put(DATASZ, this.mDataSize);
            retobj.put(DATA, this.mData);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return retobj.toString();

    }

    /**
     * @brief Parcelable
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief Parcelable
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mDataSize);
        dest.writeString(mData);
    }

    /**
     * @brief Parcelable
     * @param[in] in Parcelデータ
     */
    public void readFromParcel(Parcel in) {
        setDatasz(in.readInt());
        setData(in.readString());
    }

    /**
     * @brief 復元用
     */
    public static final Parcelable.Creator<ResponsePassportReader> CREATOR = new Parcelable.Creator<ResponsePassportReader>() {

        @Override
        public ResponsePassportReader createFromParcel(Parcel source) {
            return new ResponsePassportReader(source);
        }

        @Override
        public ResponsePassportReader[] newArray(int size) {
            return new ResponsePassportReader[size];
        }
    };

}
