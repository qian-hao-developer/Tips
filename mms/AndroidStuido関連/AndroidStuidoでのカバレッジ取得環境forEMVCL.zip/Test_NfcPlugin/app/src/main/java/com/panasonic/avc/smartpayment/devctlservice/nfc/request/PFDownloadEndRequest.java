package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * PFダウンロード終了Requestクラス.
 * 
 */
public class PFDownloadEndRequest extends BaseDownloadEndRequest {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = PFDownloadEndRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC2;

    /** Constructor */
    public PFDownloadEndRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
