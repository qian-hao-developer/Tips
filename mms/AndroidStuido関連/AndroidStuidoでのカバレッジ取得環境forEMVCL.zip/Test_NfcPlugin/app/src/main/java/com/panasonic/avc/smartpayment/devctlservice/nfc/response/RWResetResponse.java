package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * RWリセットResponseクラス.
 * 
 */
public class RWResetResponse extends BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = RWResetResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x20;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x00;

    /** @brief データ長データ2桁目(LittleEndian) */
    private static byte DATALENGTH_HIGH = (byte) 0x00;
    /** @brief データ長データ1桁目(LittleEndian) */
    private static byte DATALENGTH_LOW = (byte) 0x00;

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean inputDeviceResult(byte[] bytes) {
        if (!checkResponseData(bytes)) {
            return false;
        }

        byte[] buffer = super.cutDeviceResult(bytes);
        if (buffer == null) {
            return false;
        }

        return (cutDeviceResult(bytes) != null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean checkResponseData(byte[] bytes) {
        if (!super.checkResponseData(bytes)) {
            Logger.e(TAG, "checkResponseData header Data error.");
            return false;
        }

        if (bytes[MAINCOMMAND_INDEX] != MAINCOMMAND) {
            Logger.e(TAG, "checkResponseData MAINCOMMAND mismatch = "
                    + bytes[MAINCOMMAND_INDEX]);
            return false;
        }

        if (bytes[SUBCOMMAND_INDEX] != SUBCOMMAND) {
            Logger.e(TAG, "checkResponseData SUBCOMMAND mismatch = "
                    + bytes[SUBCOMMAND_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHHIGH_INDEX] != DATALENGTH_HIGH) {
            Logger.e(TAG, "checkResponseData DATALENGTH_HIGH mismatch = "
                    + bytes[DATALENGTHHIGH_INDEX]);
            return false;
        }

        if (bytes[DATALENGTHLOW_INDEX] != DATALENGTH_LOW) {
            Logger.e(TAG, "checkResponseData DATALENGTH_LOW mismatch = "
                    + bytes[DATALENGTHLOW_INDEX]);
            return false;
        }

        // データ部無し
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected byte[] cutDeviceResult(byte[] bytes) {
        byte[] data = super.cutDeviceResult(bytes);
        if (data == null) {
            return null;
        }

        // データ部無し
        return bytes;
    }

}
