
package com.panasonic.avc.smartpayment.devctlservice.pinpad.reset;

import android.os.CountDownTimer;

public class PinpadResetCountDownTimer extends CountDownTimer {

    private static final int REMAIN_TIME_1MINITUSE = 1 * 60 * 1000;
    private static final int REMAIN_INTERVAL_1SEC = 1 * 1000;

    private PinpadResetCountDownTimerListener mListener;

    public interface PinpadResetCountDownTimerListener {
        public void notifyTimeUp();
    }

    public PinpadResetCountDownTimer() {
        super(REMAIN_TIME_1MINITUSE, REMAIN_INTERVAL_1SEC);
    }

    public void setListener(PinpadResetCountDownTimerListener listener) {
        mListener = listener;
    }

    @Override
    public void onTick(long millisUntilFinished) {
        // NOP
    }

    @Override
    public void onFinish() {
        mListener.notifyTimeUp();
    }

}
