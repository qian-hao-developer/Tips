
package com.panasonic.avc.smartpayment.devctlservice;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.os.UEventObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;

import com.panasonic.avc.smartpayment.devctlservice.msr.MagneticStripeCard;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrService;
import com.panasonic.avc.smartpayment.devctlservice.share.IMsrServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseMsData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.msr.ResultTermMSR;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification;
import com.panasonic.avc.smartpayment.devctlservice.system.util.SystemNotification.IconType;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * タンパ要因判定サービス
 */
public class TamperDecideService extends Service {

    /** @brief タグ **/
    private static final String TAG = TamperDecideService.class.getSimpleName();

    /** @brief ログ出力制御 */
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief MSRコントロールクラス */
    private MagneticStripeCard mMagneticStripeCard = MagneticStripeCard.getInstance();
    /** @brief MSRサービス用インターフェース */
    private IMsrService mIMsrService;

    /** @brief 非同期用スレッド(TamperDecide) */
    private Thread mTamperDecideThread;

    private int rxFactor = TAMPER_DETECT_NONE;

    private static boolean normalMode = true;

    private static final int TAMPER_STS_INIT = 1;
    private static final int TAMPER_STS_UEVENT = 2;

    private static final int TAMPER_DETECT_NONE = 0;

    private static final int REBOOT_MAX_CNT = 5;
    private static final int REBOOT_ERROR_DISP_TIME = (10 * 1000);

    private static final int MSR_SUCCESS = 0;
    private static final int MSR_FAILED_RESET = -1;
    private static final int MSR_FAILED_DET24 = -2;
    private static final int MSR_FAILED_COMMUNICATION = -3;
    private static final int MSR_STATUS_READ_COUNT_MAX = 1;

    private static final int MAIN_WAKEUP_LOW = 0;
    private static final int MAIN_WAKEUP_HIGH = 1;

    private static final int MSR_STATUS_DISABLE = 0;
    private static final int MSR_STATUS_ENABLE = 1;
    private static final int MSR_STATUS_ERROR = -1;
    private static final int MSR_STATUS_RESET_COUNT_MAX = 5;

    private static final int DET24_LOW = 0;
    private static final int DET24_HIGH = 1;
    private static final int DET24_ERROR = -1;

    private static final int MSR_CAUSE_ERROR = -1;

    private static final int MESSAGE_TAMPER = 0;
    private static final int MESSAGE_BROKEN = 1;
    private static final int MESSAGE_LOW_VOLTAGE = 2;
    private static final int MESSAGE_ABNORMAL = 3;

    private static final int MSR_INTERRUPT_SUCCESS = 0;
    /** @brief タンパ割り込み - 成功 */
    private static final int MER_INTERRUPT_FAIL = -1;
    /** @brief タンパ割り込み - 失敗 */
    private static final int MSR_INTERRUPT_ILLEGAL = -2;
    /** @brief タンパ割り込み - 状態不正 */

    private static final int LOG_DEVICE_ERROR_CODE_MAIN_BROKEN = 0x0001;
    private static final int LOG_DEVICE_ERROR_CODE_ABNORMAL = 0x0002;
    private static final int LOG_DEVICE_ERROR_CODE_LOW_VOLTAGE = 0x0003;
    private static final int LOG_DEVICE_ERROR_CODE_INVALID_DETECTION = 0x0004;

    private static final String TAMPER_PATH = "DEVPATH=/devices/platform/msm_ssbi.0/pm8921-core/pm8921-charger";
    private static final String FILE_TAMPER_CAUSE = "/sys/devices/platform/msm_ssbi.0/pm8921-core/pm8921-charger/tamper";
    private static final String FILE_DET24 = "/sys/devices/platform/msm_ssbi.0/pm8921-core/pm8921-charger/det24";
    private static final String FILE_MSR_STATUS = "/sys/devices/platform/msm_ssbi.0/pm8921-core/pm8921-charger/msr_status";
    private static final String FILE_MAIN_WAKEUP = "/sys/devices/platform/msm_ssbi.0/pm8921-core/pm8921-charger/set_subcpu_wakeup";

    private static final String FILE_ERROR_COUNT = "/log/tamper_error_count";

    private Context mContext;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (!normalMode) {
                // 運用モード以外は何も表示しない
                return;
            }

            View view = null;
            LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            switch (msg.what) {
                case MESSAGE_TAMPER:
                case MESSAGE_ABNORMAL:
                    // タンパ検出は画面表示無し
                    // ステータス icon「異常」表示に設定(処理継続)
                    SystemNotification.notifyShowIcon(mContext, IconType.OTHER_DEVICE);
                    break;
                case MESSAGE_BROKEN:
                    // E9999
                    view = layoutInflater.inflate(
                            com.panasonic.avc.smartpayment.devctlservice.R.layout.error, null);
                    break;
                case MESSAGE_LOW_VOLTAGE:
                    // E9002
                    view = layoutInflater
                            .inflate(
                                    com.panasonic.avc.smartpayment.devctlservice.R.layout.low_voltage,
                                    null);
                    break;
                default:
                    // mLoggingManager.e(TAG, "Invalid parameter for handle");
                    break;
            }

            if (view == null) {
                return;
            }

            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

            // mLoggingManager.d(TAG, "Display Message " + msg.what);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.RGB_565);

            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

            wm.addView(view, params);
        }
    };

    public TamperDecideService() {

    }

    /**
     * @see Service#onCreate()
     */
    @Override
    public void onCreate() {
        super.onCreate();
        // mLoggingManager.d(TAG, "onCreate");

        mContext = this;

        Intent intent = new Intent(TamperDecideService.class.getName());
        intent.setAction(IMsrService.class.getName());
        this.bindService(intent, mServiceConnectionMsr, Activity.BIND_AUTO_CREATE);

    }

    /**
     * @see Service#onBind(Intent)
     */
    @Override
    public IBinder onBind(Intent intent) {
        // mLoggingManager.d(TAG, "onBind");
        return null;
    }

    /**
     * @see Service#onStartCommand(Intent, int, int)
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // mLoggingManager.d(TAG, "onStartCommand");
        return Service.START_REDELIVER_INTENT;
    }

    /**
     * @see Service#onDestroy()
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        // mLoggingManager.d(TAG, "onDestroy");

        // タンパUEVENT監視終了
        // mLoggingManager.d(TAG, "Tamper stopObserving");
        mTamperDecideObserver.stopObserving();

        if (mServiceConnectionMsr != null) {
            unbindService(mServiceConnectionMsr);
        }

        startService(new Intent(this, TamperDecideService.class));
    }

    /**
     * タンパ検知イベント処理
     */
    private final UEventObserver mTamperDecideObserver = new UEventObserver() {
        @Override
        public void onUEvent(UEventObserver.UEvent event) {
            // mLoggingManager.d(TAG, "TamperDecideObserver : " +
            // event.get("EVENT"));
            if ("TAMPER".equals(event.get("EVENT"))) {
                // タンパUEVENT監視終了
                // mLoggingManager.d(TAG, "Tamper stopObserving");
                mTamperDecideObserver.stopObserving();

                // mLoggingManager.d(TAG, "onUEvent TAMPER");

                // 有り得ないと思うが、一応チェック
                if (mTamperDecideThread != null && mTamperDecideThread.isAlive()) {
                    // 判定処理中のタンパUEVENTは無視する
                    // mLoggingManager.d(TAG, "onUEvent TAMPER Thread Alive");
                    return;
                }

                tamperDecide(TAMPER_STS_UEVENT);
            }
        }
    };

    private void tamperDecide(final int status) {

        final boolean fwupdate = SystemProperties.getBoolean("persist.sys.fwupdate.debug", false);
        final int factorymode = SystemProperties.getInt("ro.factorymode", 0);
        final int maintenance = SystemProperties.getInt("persist.sys.maintenance", 0);

        // mLoggingManager.e(TAG, "fwupdate : " + fwupdate);
        // mLoggingManager.e(TAG, "factorymode : " + factorymode);
        // mLoggingManager.e(TAG, "maintenance : " + maintenance);

        if ((fwupdate) // FW更新
                || (factorymode == 1) // 工程モード
                || (maintenance == 1)) { // 保守モード
            normalMode = false;
        } else {
            normalMode = true;
        }

        mTamperDecideThread = new Thread() {
            @Override
            public void run() {
                // MSR CPUからタンパ要因取得
                int cause = getTamperCause();

                // mLoggingManager.d(TAG, "Uevent getTamperCause : " + cause);

                if (cause == MSR_FAILED_RESET) {
                    failedGetTamperCause();
                    return;
                } else if (cause == MSR_FAILED_DET24) {
                    lowVoltageOccurred();
                    return;
                } else if (cause == MSR_FAILED_COMMUNICATION) {
                    abnormalOccurred(rxFactor);
                    return;
                }

                // タンパ要因取得失敗回数ファイルが存在する場合、削除する
                File file = new File(FILE_ERROR_COUNT);
                // ファイルの有無
                if (file.exists()) {
                    // mLoggingManager.d(TAG, "Delete error count file");
                    // ファイル削除
                    file.delete();
                }

                if (rxFactor == TAMPER_DETECT_NONE) {
                    // タンパ誤検知
                    // mLoggingManager.e(TAG, "Invalid detection");

                    if (status == TAMPER_STS_INIT) {
                        // 起動時の誤検知はLog記録しない
                        // 正常起動時は、タンパ予兆監視サービス起動
                        Intent intent = new Intent(mContext, TamperMonitorService.class);
                        startService(intent);
                    } else {
                        // 運用ログ保存(タンパ誤検知)
                        mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.MS,
                                LOG_DEVICE_ERROR_CODE_INVALID_DETECTION, -1, -1,
                                "log_error_info_invalid_detection");
                        // mLoggingManager.d(TAG, "putLogDevice : "
                        // + "log_error_info_invalid_detection");
                    }

                    // タンパ監視再開
                    mTamperDecideObserver.startObserving(TAMPER_PATH);
                    // mLoggingManager.d(TAG, "Tamper startObserving");
                } else if (rxFactor > TAMPER_DETECT_NONE) {
                    // タンパ検知(タンパ要因有り)
                    tamperOccurred(rxFactor);
                } else {
                    // タンパ監視再開
                    mTamperDecideObserver.startObserving(TAMPER_PATH);
                    // mLoggingManager.e(TAG, "Unknown cause value " +
                    // rxFactor);
                    // mLoggingManager.d(TAG, "Tamper startObserving");
                }
                return;
            }
        };
        mTamperDecideThread.start();
    }

    /**
     * タンパ要因を取得する
     * 
     * @return タンパ要因（0より大きい値） TAMPER_DETECT_NONE : 未検知 MSR_FAILED_RESET :
     *         MSR_STATUSのリセット失敗（MSR故障） MSR_FAILED_DET24 : タンパ要因取得失敗（電源異常）
     *         MSR_FAILED_COMMUNICATION : MSR通信異常（MSR異常）
     */
    private int getTamperCause() {
        int msrStateReadCount = 0;
        int cause = TAMPER_DETECT_NONE;
        int msrState = MSR_STATUS_DISABLE;
        int msrDet24 = DET24_LOW;
        int msrCause = MSR_CAUSE_ERROR;

        while (true) {
            // MSR状態チェック
            msrState = getMsrStatus();
            if (msrState == MSR_STATUS_ENABLE) {
                // mLoggingManager.d(TAG, "MSR is ENABLED.");
                break;
            } else if (msrState == MSR_STATUS_DISABLE) {
                // mLoggingManager.d(TAG, "MSR is DISABLED.");
            } else {
                // mLoggingManager.d(TAG, "Failed to get MSR_STATE " +
                // (msrStateReadCount + 1)
                // + " times");
            }

            if (msrStateReadCount >= MSR_STATUS_READ_COUNT_MAX) {
                // mLoggingManager.d(TAG, "Finally, Failed to get MSR_STATE");
                break;
            }

            // DET24状態チェック
            msrDet24 = getDet24();
            if (msrDet24 != DET24_HIGH) {
                // mLoggingManager.e(TAG,
                // "Failed to get MSR_STATE because DET24 is low");
                return MSR_FAILED_DET24;
            }

            // mLoggingManager.d(TAG, "Trying to wakeup MSR.");

            // リセット後、５秒待ち
            resetMsrState();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                // mLoggingManager.e(TAG,
                // "getTamperCause InterruptedException occured.");
            }

            msrStateReadCount = msrStateReadCount + 1;
        }

        if (msrState != MSR_STATUS_ENABLE) {
            // mLoggingManager.e(TAG, "MSR does not wake up.");
            return MSR_FAILED_RESET;
        }

        // タンパ要因チェック
        msrCause = getMsrCause();
        if (msrCause == MSR_CAUSE_ERROR) {
            return MSR_FAILED_COMMUNICATION;
        }

        return cause;
    }

    /**
     * MSRの状態を取得する。
     * 
     * @return MSR_STATUS_DISABLE : MSRがスタンバイ状態 MSR_STATUS_ENABLE : MSRが動作中
     *         MSR_STATUS_ERROR : MSR状態異常
     */
    private int getMsrStatus() {
        int ret = MSR_STATUS_ERROR;

        try {
            // 文字列１行単位で取得してチェック
            BufferedReader br = new BufferedReader(new FileReader(FILE_MSR_STATUS));
            String line = br.readLine();
            br.close();

            // mLoggingManager.d(TAG, "getMsrStatus ret = " + line);

            if ("0".equals(line)) {
                ret = MSR_STATUS_DISABLE;

            } else if ("1".equals(line)) {
                ret = MSR_STATUS_ENABLE;

            } else {
                ret = MSR_STATUS_ERROR;
            }
        } catch (IOException e) {
            // mLoggingManager.e(TAG, "getMsrStatus IOException occurred");
            e.printStackTrace();
            ret = MSR_STATUS_ERROR;
        }
        return ret;
    }

    /**
     * DET24の状態を取得する。
     * 
     * @return DET24_HIGH : DET24がHIGH DET24_LOW : DET24がLOW DET24_ERROR :
     *         DET24状態異常
     */
    private int getDet24() {
        int ret = DET24_ERROR;
        int det24HighCnt = 0;
        int det24LowCnt = 0;
        int det24ErrorCnt = 0;

        try {
            // 100ms毎の10回連続Highチェック
            for (int i = 0; i < 10; i++) {
                // 文字列１行単位で取得してチェック
                BufferedReader br = new BufferedReader(new FileReader(FILE_DET24));
                String line = br.readLine();
                br.close();

                // mLoggingManager.d(TAG, "getDet24 ret = " + line);

                if ("1".equals(line)) {
                    det24HighCnt += 1;
                } else if ("0".equals(line)) {
                    // １回でもLow有ると電源異常判定なので、breakで抜けて即for文止める
                    det24LowCnt += 1;
                    break;
                } else {
                    det24ErrorCnt += 1;
                }

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    det24HighCnt = 0;
                    det24LowCnt = 0;
                    det24ErrorCnt = 0;
                }
            }

            if (det24HighCnt == 10) {
                ret = DET24_HIGH;
            } else {
                ret = DET24_LOW;
            }

            // mLoggingManager.d(TAG, "Det24 High Count  = " + det24HighCnt);
            // mLoggingManager.d(TAG, "Det24 Low Count   = " + det24LowCnt);
            // mLoggingManager.d(TAG, "Det24 Error Count = " + det24ErrorCnt);
        } catch (IOException e) {
            // mLoggingManager.e(TAG, "getDet24 IOException occurred");
            e.printStackTrace();
            ret = DET24_ERROR;
        }
        return ret;
    }

    /**
     * タンパ要因を取得する。
     * 
     * @return 正常 : 読み込んだbyte数(1byte：0x00) 異常 タンパ要因 : 読み込んだbyte数(1byte：0x00以外)
     *         異常 通信異常 : MSR_CAUSE_ERROR
     */
    private int getMsrCause() {
        int cause = TAMPER_DETECT_NONE;

        // ※シリアル通信処理が重い場合は、別スレッド実行
        // 1.「磁気トラックデータ」読み取り待ち時は、「読み取り停止」要求（停止失敗時は、タンパ確定）
        // 2.「タンパ要因取得」要求（5sec以内に応答無しは、タンパ確定）
        // 3.1.にて「読み取り待ち」で有った場合、「磁気トラックデータ」読み取り開始要求実行

        // タンパ要因取得通信処理(MSR CPUシリアル通信)
        ResultData result = null;
        rxFactor = TAMPER_DETECT_NONE;

        // mLoggingManager.d(TAG, "mIMsrService : " + mIMsrService);

        if (mIMsrService == null) {
            // タンパ処理とは無関係なので、タンパ「異常無し」とする
            return TAMPER_DETECT_NONE;
        }

        try {
            result = mIMsrService.initMSR();
            // mLoggingManager.d(TAG, "mIMsrService.initMSR()");
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        // mLoggingManager.d(TAG, "MsrInit : " + result);

        if (result != null) {
            // mLoggingManager.d(TAG, "Decide MsrInit Device : " +
            // result.getDevice());
            // mLoggingManager.d(TAG, "Decide MsrInit Upos : " +
            // result.getUpos());

            if ((result.getDevice() == PluginDefine.RESULT_DEVICE_SCCESS)
                    && ((result.getUpos() == PluginDefine.RESULT_UPOS_SEQUENCE_ERROR) || (result
                            .getUpos() == PluginDefine.RESULT_UPOS_SCCESS))) {
                if (result.getUpos() == PluginDefine.RESULT_UPOS_SEQUENCE_ERROR) {
                    // init済みの場合のみ、Read停止処理
                    if (mMagneticStripeCard.suspendGetMSRead() == MER_INTERRUPT_FAIL) {
                        // 停止出来なかった時は、タンパ確定とする（termに意味が無いので実行しないで戻る）
                        // mLoggingManager.d(TAG, "SuspendGetMSRead Error");
                        rxFactor = MSR_CAUSE_ERROR;
                        return MSR_CAUSE_ERROR;
                    }
                }

                // タンパ要因取得通信処理
                rxFactor = mMagneticStripeCard.getFactorOfTamper();

                // mLoggingManager.d(TAG, "GetFactorOfTamper : " + rxFactor);

                if (rxFactor == MER_INTERRUPT_FAIL) {
                    // CPU通信異常
                    // mLoggingManager.d(TAG, "GetFactorOfTamper Error");
                    cause = MSR_CAUSE_ERROR;
                }

                // 自らinitした時以外は、termしない
                if ((result.getDevice() == 0)
                        && (result.getUpos() == PluginDefine.RESULT_UPOS_SEQUENCE_ERROR)) {
                    try {
                        ResultTermMSR resultTerm = mIMsrService.termMSR();
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        return cause;
    }

    /**
     * MSRデバイスをリセット（再起動）する。 ※MAIN_WAKEUP_HIGHエッジにてデバイス初期化
     */
    private void resetMsrState() {
        File file = null;
        PrintWriter pw = null;
        try {
            file = new File(FILE_MAIN_WAKEUP);
            pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
            pw.println(Integer.toHexString(MAIN_WAKEUP_LOW));
            pw.flush();
            Thread.sleep(100); // Low期間はベース周到（仕様は未調査）
            pw.println(Integer.toHexString(MAIN_WAKEUP_HIGH));
            pw.flush();
        } catch (IOException e) {
            // mLoggingManager.e(TAG, "Save tamper cause IOException occurred");
            e.printStackTrace();
        } catch (InterruptedException e) {
            // mLoggingManager.e(TAG,
            // "resetMsrState InterruptedException occured.");
            e.printStackTrace();
        } finally {
            if (pw != null) {
                // mLoggingManager.e(TAG, "close PrintWriter");
                pw.close();
            }
        }
        return;
    }

    /**
     * タンパSTATUSエラー処理 STATUSエラー回数５回以内の場合、端末再起動を行う（エラーコード:E9999）
     * STATUSエラー回数が５回に達した場合、icon「異常」表示を行う（処理継続）
     */
    private void failedGetTamperCause() {
        try {
            File file = new File(FILE_ERROR_COUNT);
            if (!file.exists()) {
                // 再起動回数保持ファイル作成
                // mLoggingManager.d(TAG, "Create error count file");
                file.createNewFile();
                PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
                pw.println("1");
                pw.close();
            } else {
                BufferedReader br = new BufferedReader(new FileReader(FILE_ERROR_COUNT));
                String savedCount = br.readLine();
                br.close();
                // mLoggingManager.d(TAG, "Read error count = " + savedCount);

                int count = Integer.valueOf(savedCount);

                if (count < REBOOT_MAX_CNT) {
                    // 再起動回数５回未満
                    PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
                    pw.println(Integer.toString(count + 1));
                    pw.close();
                } else {
                    // 再起動回数５回
                    // mLoggingManager.d(TAG, "Error count is max!!");
                    // タンパ要因判定不可設定
                    tamperOccurred(0xFF);
                    return;
                }
            }
        } catch (IOException e) {
            // mLoggingManager.e(TAG, "Fail access to Error count file" + e);
            e.printStackTrace();
        }

        // 運用ログ保存(端末故障通知)
        mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.MS,
                LOG_DEVICE_ERROR_CODE_MAIN_BROKEN, -1, -1, "log_error_info_broken");
        // mLoggingManager.d(TAG, "putLogDevice : " + "log_error_info_broken");

        // エラーコード：E9999
        mHandler.sendMessage(Message.obtain(mHandler, MESSAGE_BROKEN));

        // 10秒間表示後に端末再起動
        Runnable reboot = new Runnable() {
            @Override
            public void run() {
                // 端末再起動
                // mLoggingManager.d(TAG, "REBOOT");
                PowerManager pwm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                pwm.reboot("Failed to get tamper cause");
            }
        };
        mHandler.postDelayed(reboot, REBOOT_ERROR_DISP_TIME);
    }

    /**
     * 電圧異常発生処理 電圧異常通知の表示を行う
     */
    private void lowVoltageOccurred() {
        // 電源異常発生表示
        // mLoggingManager.d(TAG, "lowVoltageOccurred");

        // 運用ログ保存(電源異常)
        mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.MS,
                LOG_DEVICE_ERROR_CODE_LOW_VOLTAGE, -1, -1, "log_error_info_low_voltage");
        // mLoggingManager.d(TAG, "putLogDevice : " +
        // "log_error_info_low_voltage");

        // エラーコード：E9002（処理停止）
        mHandler.sendMessage(Message.obtain(mHandler, MESSAGE_LOW_VOLTAGE));
    }

    /**
     * 端末異常発生処理 端末異常通知の表示を行う
     */
    private void abnormalOccurred(int cause) {
        // 端末異常発生表示
        // mLoggingManager.d(TAG, "abnormalOccurred : " + cause);

        // 運用ログ保存(MSR異常)
        mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.MS,
                LOG_DEVICE_ERROR_CODE_ABNORMAL, -1, -1, "log_error_info_abnormal");
        // mLoggingManager.d(TAG, "putLogDevice : " +
        // "log_error_info_abnormal");

        // ステータス icon「異常」表示に設定(処理継続)
        mHandler.sendMessage(Message.obtain(mHandler, MESSAGE_ABNORMAL));
    }

    /**
     * タンパ検知処理 タンパ通知画面の表示を行う
     * 
     * @param cause タンパ要因
     */
    private void tamperOccurred(int cause) {

        // タンパ要因不揮発書き込み
        if (normalMode) {
            // 不揮発に書き込むと点滅表示となる為、運用モード以外は書き込まない
            try {
                File file = new File(FILE_TAMPER_CAUSE);
                PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
                pw.println(Integer.toHexString(cause));
                pw.close();
            } catch (IOException e) {
                // mLoggingManager.e(TAG,
                // "Save tamper cause IOException occurred");
                e.printStackTrace();
            }
        }

        // 運用ログ保存(タンパ検出)
        mLoggingManager.putLogSecurity(ITcLogServiceConstants.DeviceType.MS, cause);
        // mLoggingManager.d(TAG, "putLogSecurity");

        // ステータス icon「異常」表示に設定(処理継続)
        mHandler.sendMessage(Message.obtain(mHandler, MESSAGE_TAMPER));
    }

    /**
     * @see ServiceConnection
     */
    private ServiceConnection mServiceConnectionMsr = new ServiceConnection() {

        /**
         * @see ServiceConnection#onServiceConnected(ComponentName, IBinder)
         */
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // mLoggingManager.d(TAG, "MSR onServiceConnected");
            mIMsrService = IMsrService.Stub.asInterface(service);
            try {
                mIMsrService.registerMsrServiceListener(
                        TamperDecideService.class.getName(),
                        mIMsrServiceListener);
            } catch (RemoteException e) {
                e.printStackTrace();
            }

            tamperDecide(TAMPER_STS_INIT);
        }

        /**
         * @see ServiceConnection#onServiceDisconnected(ComponentName)
         */
        @Override
        public void onServiceDisconnected(ComponentName name) {
            // mLoggingManager.d(TAG, "MSR onServiceDisconnected");
            try {
                mIMsrService
                        .unregisterMsrServiceListener(TamperDecideService.class
                                .getName());
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            mIMsrService = null;
        }

    };

    /**
     * @see mIMsrServiceListener
     */
    private IMsrServiceListener.Stub mIMsrServiceListener = new IMsrServiceListener.Stub() {

        /**
         * @see IMsrServiceListener#onResultMsData(ResponseMsData)
         */
        @Override
        public void onResultMsData(ResponseMsData result)
                throws RemoteException {
            // mLoggingManager.d(TAG, "onPPREvent " + result.toJSON());
        }

        /**
         * @see IMsrServiceListener#onError(com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseError)
         */
        @Override
        public void onError(
                com.panasonic.avc.smartpayment.devctlservice.share.response.msr.ResponseError result)
                throws RemoteException {
            // mLoggingManager.d(TAG, "onError " + result.toJSON());
        }
    };

}
