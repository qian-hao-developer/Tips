
package com.panasonic.avc.smartpayment.devctlservice.share.result.ppr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPPRの実行結果データ
 */
public class ResultInitPPR extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultInitPPR(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitPPR() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitPPR> CREATOR = new Parcelable.Creator<ResultInitPPR>() {
        public ResultInitPPR createFromParcel(Parcel in) {
            return new ResultInitPPR(in);
        }

        public ResultInitPPR[] newArray(int size) {
            return new ResultInitPPR[size];
        }
    };

}
