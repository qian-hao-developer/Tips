package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * PFダウンロードデータRequestクラス.
 * 
 */
public class PFDownloadDataRequest extends BaseDownloadDataRequest {

    /** @brief ログ用タグ */
    private static final String TAG = PFDownloadDataRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC1;

    /** Constructor */
    public PFDownloadDataRequest() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
