
package com.panasonic.avc.smartpayment.devctlservice.emcrw;

public class EmcrwApplicationData {

    /** @brief アプリケーションID */
    private String mID;

    /** @brief バージョン */
    private String mVersion;

    /** @brief インストールファイル */
    private String mFileName;

    /**
     * @brief コンストラクタ
     */
    public EmcrwApplicationData() {
        mID = null;
        mVersion = null;
        mFileName = null;
    }

    public String getID() {
        return mID;
    }

    public void setID(String id) {
        mID = id;
    }

    public String getVersion() {
        return mVersion;
    }

    public void setVersion(String version) {
        mVersion = version;
    }

    public String getFileName() {
        return mFileName;
    }

    public void setFileName(String name) {
        mFileName = name;
    }

    /**
     * バージョンの上位 15 文字を取得する
     * 
     * @return バージョンの上位 15 文字
     */
    public String getVersionHigh15() {
        return mVersion.substring(0, 15);
    }

    /**
     * バージョン最下位の判定フラグを取得する
     * 
     * @return {@code != 0}
     */
    public boolean isVersionLowFlag() {
        try {
            String flag_str = mVersion.substring(mVersion.length() - 1);
            return Integer.parseInt(flag_str, 16) != 0;
        } catch (NumberFormatException e) {
            return true;
        }
    }

    /**
     * 更新の必要有無を判定する
     * 
     * @param newAPData
     * @return
     */
    public boolean isNeedUpdate(EmcrwApplicationData newAPData) {
        String curtAPVerTop15 = this.getVersionHigh15();
        String newAPVerTop15 = newAPData.getVersionHigh15();

        // バージョン上位 15 文字が異なっている場合は更新を実施する
        int compare = curtAPVerTop15.compareToIgnoreCase(newAPVerTop15);
        if (!newAPData.isVersionLowFlag()) {
            // ただし、バージョン最下位の判定フラグが 0 の場合
            // デグレードは実施しない
            return compare < 0;
        }
        return compare != 0;
    }

}
