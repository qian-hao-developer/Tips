
package com.panasonic.avc.smartpayment.devctlservice.share.response.hmi;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * EventFuncKeyデータ
 */
public class ResponseFuncKey extends ResponseData implements Parcelable {

    /** @brief イベントの種類 */
    private boolean mResult;

    /** @brief イベントの種類タグ */
    private static final String RESULT = "result";

    /** @brief イベントの種類 */
    private int mKey;

    /** @brief イベントの種類タグ */
    private static final String KEY = "key";

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 3;

    /** @brief 確定キー **/
    private static final int KEY_ENTER = 0x0d;

    /** @brief 取り消しキー **/
    private static final int KEY_CANCEL = 0x18;

    /** @brief 訂正キー **/
    private static final int KEY_CLEAR = 0x7f;

    /** @brief F1キー **/
    private static final int KEY_F1 = 0x41;

    /** @brief F2キー **/
    private static final int KEY_F2 = 0x42;

    /** @brief F3キー **/
    private static final int KEY_F3 = 0x43;

    /** @brief F1キー **/
    public static final int RESULT_KEY_F1 = 1;

    /** @brief F2キー **/
    public static final int RESULT_KEY_F2 = 2;

    /** @brief F3キー **/
    public static final int RESULT_KEY_F3 = 3;

    /** @brief 確定キー **/
    public static final int RESULT_KEY_ENTER = 4;

    /** @brief 訂正キー **/
    public static final int RESULT_KEY_CLEAR = 5;

    /** @brief 取り消しキー **/
    public static final int RESULT_KEY_CANCEL = 6;

    /**
     * @brief コンストラクタ
     */
    public ResponseFuncKey(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     * @param[in] result キー押下状況[論理型]
     * @param[in] key 押下有効とする機能キーを指定[整数型]
     */
    public ResponseFuncKey(boolean result, int key) {
        mResult = result;
        mKey = key;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseFuncKey() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResponseFuncKey> CREATOR = new Parcelable.Creator<ResponseFuncKey>() {
        public ResponseFuncKey createFromParcel(Parcel in) {
            return new ResponseFuncKey(in);
        }

        public ResponseFuncKey[] newArray(int size) {
            return new ResponseFuncKey[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mResult ? 1 : 0);
        dest.writeInt(mKey);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mResult = in.readInt() == 1 ? true : false;
        mKey = in.readInt();
    }

    /**
     * @brief イベントの種類を取得する
     * @return イベントの種類
     */
    public boolean isResult() {
        return mResult;
    }

    /**
     * @brief イベントの種類を設定する
     * @param イベントの種類
     */
    public void setResult(boolean result) {
        mResult = result;
    }

    /**
     * @brief イベントの種類を取得する
     * @return イベントの種類
     */
    public int getFuncKey() {
        return mKey;
    }

    /**
     * @brief イベントの種類を設定する
     * @param イベントの種類
     */
    public void setFuncKey(int key) {
        mKey = key;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            return false;
        }

        int result = buffer[PinpadDefine.INDEX_PARAMETER];
        if (result != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.HMI, result, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        int key = buffer[PinpadDefine.INDEX_PARAMETER + 2];

        switch (key) {
            case KEY_ENTER:
                mKey = RESULT_KEY_ENTER;
                break;
            case KEY_CANCEL:
                mKey = RESULT_KEY_CANCEL;
                break;
            case KEY_CLEAR:
                mKey = RESULT_KEY_CLEAR;
                break;
            case KEY_F1:
                mKey = RESULT_KEY_F1;
                break;
            case KEY_F2:
                mKey = RESULT_KEY_F2;
                break;
            case KEY_F3:
                mKey = RESULT_KEY_F3;
                break;
            default:
                return false;
        }

        mResult = true;

        return true;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(RESULT, isResult());
            if (isResult()) {
                json.put(KEY, getFuncKey());
            } else {
                json.put(KEY, JSONObject.NULL);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
