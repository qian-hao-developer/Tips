
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * IPL開始応答
 */
public class ResponseIplData extends ResponseData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x03;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x01;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0x04;

    /** @brief 結果 **/
    private int mResult;

    private int mNumber;

    /**
     * @brief コンストラクタ
     */
    public ResponseIplData() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @return 結果を取得する
     */
    public int getResult() {
        return mResult;
    }

    /**
     * 結果を設定する
     * 
     * @param 結果
     */
    public void setResult(int result) {
        mResult = result;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        mResult = buffer[PinpadDefine.INDEX_PARAMETER];
        if (mResult != PluginDefine.RESULT_DEVICE_SCCESS) {
            mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.PED, mResult, -1,
                    buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(mResult);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        mNumber = CalcUtil.toInt(buffer[PinpadDefine.INDEX_PARAMETER + 2],
                buffer[PinpadDefine.INDEX_PARAMETER + 3]);

        return true;
    }

    public int getNumber() {
        return mNumber;
    }

}
