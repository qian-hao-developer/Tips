/**
 * 
 */

package com.panasonic.avc.smartpayment.devctlservice.share;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author smori
 */
public enum UpdateDeviceType implements Parcelable {
    PINPAD,
    MSR,
    PRINTER,
    CONTACT_LESS_ICRW;

    /*
     * (non-Javadoc)
     * @see android.os.Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        // TODO Auto-generated method stub
        return 0;
    }

    /*
     * (non-Javadoc)
     * @see android.os.Parcelable#writeToParcel(android.os.Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(ordinal());

    }

    public static final Parcelable.Creator<UpdateDeviceType> CREATOR =
            new Parcelable.Creator<UpdateDeviceType>() {
                @Override
                public UpdateDeviceType[] newArray(int size) {
                    return new UpdateDeviceType[size];
                }

                @Override
                public UpdateDeviceType createFromParcel(Parcel source) {
                    return UpdateDeviceType.values()[source.readInt()];
                }
            };

}
