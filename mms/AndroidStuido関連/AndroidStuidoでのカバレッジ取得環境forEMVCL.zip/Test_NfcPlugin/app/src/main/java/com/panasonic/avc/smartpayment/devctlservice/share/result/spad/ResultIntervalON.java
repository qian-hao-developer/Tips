
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultIntervalON extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultIntervalON(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultIntervalON() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultIntervalON> CREATOR = new Parcelable.Creator<ResultIntervalON>() {

        @Override
        public ResultIntervalON createFromParcel(Parcel in) {
            return new ResultIntervalON(in);
        }

        @Override
        public ResultIntervalON[] newArray(int size) {
            return new ResultIntervalON[size];
        }
    };

}
