
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetInking extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x21;

    private static final int LENGTH = 2;

    private static final String STATUS = "status";

    private boolean mStatus;

    public ResponseGetInking(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mStatus = CalcUtil.toBoolean(result[1]);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(STATUS, mStatus);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
}
