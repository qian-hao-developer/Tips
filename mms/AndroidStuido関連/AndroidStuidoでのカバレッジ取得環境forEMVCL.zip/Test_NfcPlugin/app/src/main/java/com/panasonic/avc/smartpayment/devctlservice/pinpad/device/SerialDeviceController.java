
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import android.content.Context;
import android.hardware.usb.UsbManager;
import android.os.SystemProperties;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.DeviceType;
import com.panasonic.avc.smartpayment.devctlservice.pos.device.PosConnectionNative;

/**
 * Serial操作クラス
 */
public class SerialDeviceController extends DeviceController {

    /** @brief ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = SerialDeviceController.class.getSimpleName();

    /** @brief DeviceInterfaceType: Serial */
    private static final int DEVICE_IF_TYPE_SERIAL = 0;

    /** @brief DeviceInterfaceType: USB */
    private static final int DEVICE_IF_TYPE_USB = 1;

    /** @brief SystemProperties用キー値(USBコンフィグ) */
    private static final String PROP_KEY_USB_CONFIG = "persist.sys.usb.config";

    /** @brief SystemProperties用デフォルト値(acm_tty,adb) */
    private static final String USB_CONFIG_ACM_ADB = "acm_tty,adb";

    /** @brief SystemProperties用デフォルト値(acm_tty) */
    private static final String USB_CONFIG_ACM = "acm_tty";

    /** @brief SYSTEMPROPERTIES用デフォルト値(ADB) */
    private static final String USB_CONFIG_ADB = "adb";

    /** @brief SystemProperties用デフォルト値(none) */
    private static final String USB_CONFIG_NONE = "none";

    /** @brief PosPortのオープン時に使用するブロックモード定義 */
    private static final int PORTTX_BLOCKMODE = 1;

    /** @brief SharedPreferences用デフォルト値(ストップビット) */
    private static final int DEFAULT_STOP_BIT = 0;

    /** @brief 通信インタフェース */
    private int mInterface;

    /** @brief 通信速度 */
    private int mBaudrate;

    /** @brief パリティチェック */
    private int mParity;

    /** @brief ファイルディスクリプタ */
    private int mFD;

    /** @brief ブロックサイズ */
    private int mBlockSize;

    /** @brief 呼び出し元UsbDeviceManager オブジェクト */
    private SerialDeviceManager mManager;

    /** @brief POS接続制御 */
    private PosConnectionNative mConnection = PosConnectionNative.getInstance();

    /**
     * @brief コンストラクタ
     * @param context コンテキスト
     */
    public SerialDeviceController(Context context) {
        super(context);
        mType = DeviceType.SERIAL;
        mFD = -1;
    }

    /**
     * @brief データをデバイスに書き込む
     * @param timeout unused
     * @see DeviceController#write(byte[])
     */
    @Override
    public boolean write(byte[] buffer, int timeout) {
        if (buffer == null) {
            return false;
        }
        int ret = mConnection.nativePosSend(mFD, mBlockSize, buffer, buffer.length);

        return (ret >= 0);
    }

    /**
     * @brief データ読み出し(POS)
     * @param timeout unused
     * @return 読みだしたデータ
     * @see DeviceController#read()
     */
    @Override
    public byte[] read(int timeout) {
        return mConnection.nativePosReceive(mFD);
    }

    /**
     * @see DeviceController#init()
     */
    @Override
    public synchronized boolean init() {

        if (mContext == null) {
            return false;
        }

        switch (mInterface) {
            case DEVICE_IF_TYPE_SERIAL:
            case DEVICE_IF_TYPE_USB:
                break;
            default:
                return false;
        }

        setUpUsbConfig();

        mFD = mConnection.nativePosPortOpen(mInterface, PORTTX_BLOCKMODE);

        if (mFD == -1) {
            return false;
        }

        // USB ではポートコンフィグを行わない
        if (mInterface == DEVICE_IF_TYPE_USB) {
            return true;
        }

        if (mConnection.nativePosPortConfig(mFD, mBaudrate, 8, DEFAULT_STOP_BIT, mParity) == -1) {
            mConnection.nativePosPortClose(mFD);
            mFD = -1;
            return false;
        }

        return true;
    }

    /**
     * @see DeviceController#term()
     */
    @Override
    public synchronized boolean term() {
        mConnection.nativePosPortClose(mFD);
        mFD = -1;
        return true;
    }

    /**
     * @brief デバイスの有無
     * @return 有無
     * @warning term をせずにデバイスと切断された場合は検知不可
     * @see DeviceController#isActive()
     */
    public synchronized boolean isActive() {
        return mFD != -1;
    }

    /**
     * @brief 通信インタフェースを設定する
     * @param deviceInterface 通信インタフェース シリアル:0 USB:1
     */
    public void setInterface(int deviceInterface) {
        mInterface = deviceInterface;
    }

    /**
     * @brief 通信速度を設定する
     * @param baudrate 通信速度
     */
    public void setBaudrate(int baudrate) {
        mBaudrate = baudrate;
    }

    /**
     * @brief パリティ種別を設定する
     * @param parity パリティ種別 パリティチェックなし:0 奇数パリティ:1 偶数パリティ:2
     */
    public void setParity(int parity) {
        mParity = parity;
    }

    /**
     * @brief ブロックサイズを設定する
     * @param blocksz ブロックサイズ ブロック分割しない:0
     */
    public void setBlockSize(int blocksz) {
        mBlockSize = blocksz;
    }

    /**
     * 管理クラス取得
     * 
     * @return 管理クラス
     */
    public SerialDeviceManager getManager() {
        return mManager;
    }

    /**
     * 管理クラス設定
     * 
     * @param manager 管理クラス
     */
    public void setManager(SerialDeviceManager manager) {
        mManager = manager;
    }

    /**
     * @brief 端末の USB コンフィグを行う
     */
    protected void setUpUsbConfig() {

        UsbManager usbManager = (UsbManager) mContext.getSystemService(Context.USB_SERVICE);
        String usbConfig = SystemProperties.get(PROP_KEY_USB_CONFIG, USB_CONFIG_NONE);
        if (mInterface == 0) {
            if (usbConfig.equals(USB_CONFIG_ACM_ADB)) {
                usbManager.setCurrentFunction(USB_CONFIG_ADB, true);
            } else if (usbConfig.equals(USB_CONFIG_ACM)) {
                usbManager.setCurrentFunction(USB_CONFIG_NONE, true);
            } else {
                // NOP(acm_ttyが存在しない状態なら何もしない)
            }
        } else {
            if (usbConfig.equals(USB_CONFIG_ADB)) {
                usbManager.setCurrentFunction(USB_CONFIG_ACM_ADB, true);
            } else if (usbConfig.equals(USB_CONFIG_NONE)) {
                usbManager.setCurrentFunction(USB_CONFIG_ACM, true);
            } else {
                // NOP(acm_ttyが存在する状態なら何もしない)
            }
        }
    }

}
