
package com.panasonic.avc.smartpayment.devctlservice.share.result.bcr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ScanONの実行結果データ
 */
public class ResultScanON extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultScanON(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultScanON() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultScanON> CREATOR = new Parcelable.Creator<ResultScanON>() {
        public ResultScanON createFromParcel(Parcel in) {
            return new ResultScanON(in);
        }

        public ResultScanON[] newArray(int size) {
            return new ResultScanON[size];
        }
    };
}
