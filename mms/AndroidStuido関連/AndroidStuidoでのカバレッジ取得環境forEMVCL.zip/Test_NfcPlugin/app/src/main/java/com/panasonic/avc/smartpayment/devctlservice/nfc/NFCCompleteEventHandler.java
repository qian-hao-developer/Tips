package com.panasonic.avc.smartpayment.devctlservice.nfc;

/**
 * EMVCL_TransactionまたはEMVCL_TRtransactionが終了した際に通知されるハンドラIF<br>
 *
 */
public interface NFCCompleteEventHandler {

    /**
     * EMVCL_TransactionまたはEMVCL_TRtransactionが終了した際に呼ばれるメソッド<br>
     * ハンドラ側の実装で呼ばれた際の処理を実装すること<br>
     */
    void WM_CompleteEvent();
}
