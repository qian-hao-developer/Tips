
package com.panasonic.avc.smartpayment.devctlservice;

import android.hardware.usb.UsbDevice;

import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.NotifyUsbDeviceConnectionListener;
import com.panasonic.avc.smartpayment.devctlservice.ppr.PassportReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.spad.SignpadDefine;
import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;

/**
 * PDS 端末情報通知用の周辺機器情報を設定
 */
public class TerminalStatusManager implements NotifyUsbDeviceConnectionListener {

    private PdsClientManager mPdsClientManager;

    public TerminalStatusManager(PdsClientManager pdsClientManager) {
        mPdsClientManager = pdsClientManager;

        // 非接続は NULL を設定するので、NULL 初期化を行う
        setPinpadStatus(null, null, null);
        setRWStatus(null, null, null);
        setPassportStatus(null);
        setBarcodeReaderStatus(null);
        setSignpadStatus(null);

    }

    /**
     * PINPAD の情報を設定
     * 
     * @param model 品番
     * @param sno 製造番号
     * @param fwv ファームウェアバージョン
     */
    public void setPinpadStatus(String model, String sno, String fwv) {
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_FMV_PINPAD, fwv);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_NO_PINPAD, model);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_ID_PINPAD, sno);
    }

    /**
     * 非接続 IC カードリーダライタの情報を設定
     * 
     * @param model 品番
     * @param sno 製造番号
     * @param fwv ファームウェアバージョン
     */
    public void setRWStatus(String model, String sno, String fwv) {
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_FMV_RW, fwv);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_NO_RW, model);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_ID_RW, sno);
    }

    /**
     * パスポートリーダの情報を設定
     * 
     * @param model 品番
     */
    private void setPassportStatus(String model) {
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_FMV_PASSPORT, null);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_NO_PASSPORT, model);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_ID_PASSPORT, null);
    }

    /**
     * バーコードリーダの情報を設定
     * 
     * @param model 品番
     */
    private void setBarcodeReaderStatus(String model) {
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_FMV_BARCODE, null);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_NO_BARCODE, model);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_ID_BARCODE, null);
    }

    /**
     * サインパッドの情報を設定
     * 
     * @param model 品番
     */
    private void setSignpadStatus(String model) {
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_FMV_SIGNPAD, null);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_NO_SIGNPAD, model);
        mPdsClientManager.setTerminalStatus(PdsClientManager.KEY_PRODUCT_ID_SIGNPAD, null);
    }

    /**
     * PDS(管理) への通知用に、周辺機器の品番を設定する。
     * 
     * @param device パスポートリーダ/バーコードリーダ/サインパッド
     */
    private void setPdsInformation(UsbDevice device) {

        // PINPAD, RW 以外のデバイスは接続時に品番を設定する

        if (device.getVendorId() == PassportReaderDefine.VID
                && device.getProductId() == PassportReaderDefine.PID) {
            // パスポートリーダ
            setPassportStatus(PassportReaderDefine.PRODUCT_NO);
        } else if (device.getVendorId() == BarcodeReaderDefine.VID) {
            // バーコードリーダ
            if (device.getProductId() == BarcodeReaderDefine.PID_M_10) {
                setBarcodeReaderStatus(BarcodeReaderDefine.PRODUCT_NO_M_10);
            } else if (device.getProductId() == BarcodeReaderDefine.PID_C_40_C_41) {
                setBarcodeReaderStatus(BarcodeReaderDefine.PRODUCT_NO_40_C_41);
            }
        } else if (device.getVendorId() == SignpadDefine.VID) {
            // サインパッド
            if (device.getProductId() == SignpadDefine.PID_STU_430) {
                setSignpadStatus("STU-430");
            } else if (device.getProductId() == SignpadDefine.PID_STU_530) {
                setSignpadStatus("STU-530");
            }
        }

    }

    /**
     * @see NotifyUsbDeviceConnectionListener#onOpened(UsbDevice)
     */
    @Override
    public void onOpened(UsbDevice device) {
        setPdsInformation(device);
    }

    /**
     * @see NotifyUsbDeviceConnectionListener#onClosed(UsbDevice)
     */
    @Override
    public void onClosed(UsbDevice device) {
        // NOP: デバイスが抜かれても設定している値はクリアしない
    }

}
