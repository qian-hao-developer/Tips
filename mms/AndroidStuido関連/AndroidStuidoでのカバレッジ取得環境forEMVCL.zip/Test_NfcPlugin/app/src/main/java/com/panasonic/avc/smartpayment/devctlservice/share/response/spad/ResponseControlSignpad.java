
package com.panasonic.avc.smartpayment.devctlservice.share.response.spad;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class ResponseControlSignpad implements Parcelable {

    /** @brief データ tag */
    private static final String DATA = "data";

    /** @brief データ tag */
    private static final String DATA_SIZE = "datasz";

    /** @brief 結果 */
    private String mResultData;

    private boolean mIsAdvanced;

    /**
     * @brief コンストラクタ
     * @param[in] resultData 結果
     */
    public ResponseControlSignpad(boolean isAdvanced) {
        mIsAdvanced = isAdvanced;
    }

    /**
     * @brief コンストラクタ
     * @param[in] source Parcelデータ
     */
    public ResponseControlSignpad(Parcel source) {
        readFromParcel(source);
    }

    /**
     * @brief 結果データを取得します
     * @return mResultData 結果
     */
    public String getResultData() {
        return mResultData;
    }

    /**
     * @brief 結果データを設定します
     * @param[in] resultData 結果
     */
    public void setResultData(String resultData) {
        mResultData = resultData;
    }

    /**
     * @brief JSON形式で各フィールドの値を出力します
     * @return 各フィールドの値をJSON形式に整形した文字列（失敗時null）
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            if (mResultData != null) {
                if (mIsAdvanced) {
                    JSONObject obj = new JSONObject(mResultData);
                    json.put(DATA, obj);
                    json.put(DATA_SIZE, obj.toString().length());
                } else {
                    json.put(DATA, mResultData);
                }

            } else {
                json.put(DATA, JSONObject.NULL);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mIsAdvanced ? 1 : 0);
        dest.writeString(mResultData.toString());

    }

    /**
     * @brief Parcel読み込み用
     * @param[in] in Parcelデータ
     */
    public void readFromParcel(Parcel in) {
        mIsAdvanced = in.readInt() == 1;
        mResultData = in.readString();
    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponseControlSignpad> CREATOR = new Parcelable.Creator<ResponseControlSignpad>() {

        @Override
        public ResponseControlSignpad createFromParcel(Parcel source) {
            return new ResponseControlSignpad(source);
        }

        @Override
        public ResponseControlSignpad[] newArray(int size) {
            return new ResponseControlSignpad[size];
        }
    };

}
