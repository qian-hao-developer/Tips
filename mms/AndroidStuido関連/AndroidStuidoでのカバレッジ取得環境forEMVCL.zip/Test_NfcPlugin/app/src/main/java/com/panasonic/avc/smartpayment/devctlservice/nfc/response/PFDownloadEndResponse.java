package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

/**
 * PFダウンロード終了Responseクラス.
 * 
 */
public class PFDownloadEndResponse extends BaseDownloadEndResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = PFDownloadEndResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC2;

    /** Constructor */
    public PFDownloadEndResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}
