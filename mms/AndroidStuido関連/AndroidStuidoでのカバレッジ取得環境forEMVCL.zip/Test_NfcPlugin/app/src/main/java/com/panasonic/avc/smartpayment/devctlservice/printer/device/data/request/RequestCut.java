
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * カット要求
 */
public class RequestCut extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x000A;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x8000;

    /** @brief コマンド長 */
    private static final int LENGTH = 0x0004;

    /** @brief カット種別 */
    private int mCutType;

    /** @brief フルカット */
    private static final int PLUGIN_FULL_CUT = 2;

    /** @brief パーシャルカット */
    public static final int PLUGIN_PARTIAL_CUT = 1;

    /** @brief フルカット */
    private static final byte FULL_CUT = (byte) 0x00;

    /** @brief パーシャルカット */
    private static final byte PARTIAL_CUT = (byte) 0x01;

    /**
     * @brief コンストラクタ
     * @param cutType カットの種類
     */
    public RequestCut(int cutType) {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
        mCutType = cutType;
    }

    /**
     * @brief カットの種類を取得する
     * @return カットの種類
     */
    public int getCutType() {
        return mCutType;
    }

    /**
     * @brief カットの種類を設定する
     * @param cutType カットの種類
     */
    public void setCutType(int cutType) {
        mCutType = cutType;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = 0x1D;
        parameter[1] = 0x56;

        byte type;
        switch (mCutType) {
            case PLUGIN_PARTIAL_CUT:
                type = PARTIAL_CUT;
                break;
            case PLUGIN_FULL_CUT:
                type = FULL_CUT;
                break;
            default:
                return null;
        }

        parameter[2] = (byte) type;
        parameter[3] = 0x00;

        return toCommand(parameter);
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mCutType < 1 || mCutType > 2) {
            return false;
        }

        return true;
    }

}
