
package com.panasonic.avc.smartpayment.devctlservice.share.result.msr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * StartGetMSReadの実行結果データ
 */
public class ResultStartGetMSRead extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultStartGetMSRead(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultStartGetMSRead() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultStartGetMSRead> CREATOR = new Parcelable.Creator<ResultStartGetMSRead>() {
        public ResultStartGetMSRead createFromParcel(Parcel in) {
            return new ResultStartGetMSRead(in);
        }

        public ResultStartGetMSRead[] newArray(int size) {
            return new ResultStartGetMSRead[size];
        }
    };
}
