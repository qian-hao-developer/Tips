package com.panasonic.avc.smartpayment.devctlservice.nfc;

/**
 * 独自APIのReturnValueClass
 */
public class ApiReturnValues {

    public static final int SUCCESS      = 0;
    public static final int E_CLOSED     = 101;
    public static final int E_NOTCLAIMED = 103;
    public static final int E_NOSERVICE  = 104;
    public static final int E_ILLEGAL    = 106;
    public static final int E_NOHARDWARE = 107;
    public static final int E_FAILURE    = 111;
    public static final int E_TIMEOUT    = 112;
    public static final int E_BUSY       = 113;

    /**
     * EMVCL_OpenのReturnValueEnum
     */
    public enum Open {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_NOSERVICE(ApiReturnValues.E_NOSERVICE),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_NOHARDWARE(ApiReturnValues.E_NOHARDWARE)
        ;
        private final int status;

        Open(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }
    }
    
    /**
     * EMVCL_CloseのReturnValueEnum
     */
    public enum Close {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED (ApiReturnValues.E_CLOSED),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        Close(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }
    }

    /**
     * EMVCL_ClaimのReturnValueEnum
     */
    public enum Claim {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_NOHARDWARE(ApiReturnValues.E_NOHARDWARE),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_TIMEOUT(ApiReturnValues.E_TIMEOUT)
        ;
        private final int status;

        Claim(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }
    }
    
    /**
     * EMVCL_ReleaseのReturnValueEnum
     */
    public enum Release {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        Release(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static Release getTargetStatus(int target) {
            for (Release returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_GetLibraryVersionのReturnValueEnum
     */
    public enum GetLibraryVersion {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        GetLibraryVersion(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }
    }

    /**
     * EMVCL_FileDllのReturnValueEnum
     */
    public enum FileDll {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        FileDll(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static FileDll getTargetStatus(int target) {
            for (FileDll returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_SetEMVのReturnValueEnum
     */
    public enum SetEMV {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        SetEMV(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static SetEMV getTargetStatus(int target) {
            for (SetEMV returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_DeviceSettingのReturnValueEnum
     */
    public enum DeviceSetting {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        DeviceSetting(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static DeviceSetting getTargetStatus(int target) {
            for (DeviceSetting returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_ClearSettingのReturnValueEnum
     */
    public enum ClearSetting {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        ClearSetting(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static ClearSetting getTargetStatus(int target) {
            for (ClearSetting returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_GetInfoのReturnValueEnum
     */
    public enum GetInfo {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        GetInfo(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static GetInfo getTargetStatus(int target) {
            for (GetInfo returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_TransactionのReturnValueEnum
     */
    public enum Transaction {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        Transaction(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static Transaction getTargetStatus(int target) {
            for (Transaction returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_DataExchangeのReturnValueEnum
     */
    public enum DataExchange {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        DataExchange(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static DataExchange getTargetStatus(int target) {
            for (DataExchange returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_ClearのReturnValueEnum
     */
    public enum Clear {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        Clear(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static Clear getTargetStatus(int target) {
            for (Clear returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_GetTransactionResultのReturnValueEnum
     */
    public enum GetTransactionResult {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        GetTransactionResult(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static GetTransactionResult getTargetStatus(int target) {
            for (GetTransactionResult returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_SetResultのReturnValueEnum
     */
    public enum SetResult {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        SetResult(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static SetResult getTargetStatus(int target) {
            for (SetResult returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_CancelのReturnValueEnum
     */
    public enum Cancel {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL)
        ;
        private final int status;

        Cancel(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }
    }

    /**
     * EMVCL_SetCompleteEventのReturnValueEnum
     */
    public enum SetCompleteEvent {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL)
        ;
        private final int status;

        SetCompleteEvent(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }
    }

    /**
     * EMVCL_SetEncryptionKeyのReturnValueEnum
     */
    public enum SetEncryptionKey {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        SetEncryptionKey(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static SetEncryptionKey getTargetStatus(int target) {
            for (SetEncryptionKey returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }

    /**
     * EMVCL_SetCurrencyAbbreviationのReturnValueEnum
     */
    public enum SetCurrencyAbbreviation {
        SUCCESS(ApiReturnValues.SUCCESS),
        E_CLOSED(ApiReturnValues.E_CLOSED),
        E_NOTCLAIMED(ApiReturnValues.E_NOTCLAIMED),
        E_ILLEGAL(ApiReturnValues.E_ILLEGAL),
        E_FAILURE(ApiReturnValues.E_FAILURE),
        E_BUSY(ApiReturnValues.E_BUSY)
        ;
        private final int status;

        SetCurrencyAbbreviation(int setStatus) {
            this.status = setStatus;
        }

        public int getStatus() {
            return this.status;
        }

        public static SetCurrencyAbbreviation getTargetStatus(int target) {
            for (SetCurrencyAbbreviation returnStatus :
                    values()) {
                if (returnStatus.status == target) {
                    return returnStatus;
                }
            }
            return E_ILLEGAL;
        }
    }
}
