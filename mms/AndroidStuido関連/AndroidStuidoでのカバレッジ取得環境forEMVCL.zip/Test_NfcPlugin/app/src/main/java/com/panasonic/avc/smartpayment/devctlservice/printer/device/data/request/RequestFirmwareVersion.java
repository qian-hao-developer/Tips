
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * ファームウェアバージョン情報取得要求
 */
public class RequestFirmwareVersion extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x001E;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x0000;

    /** @brief コマンド長 */
    private static final int LENGTH = 0x0001;

    /** @brief ファームウェアバージョン */
    private Firmware mFirmware;

    /** @brief 対象ファーム */
    public enum Firmware {
        FIRMWARE((byte) 0x00),
        JAPANESE_FONT((byte) 0x01),
        CHINESE_FONT((byte) 0x02),
        TAIWAN_FONT((byte) 0x03),
        KOREAN_FONT((byte) 0x04);

        private final byte mValue;

        private Firmware(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }

    }

    /**
     * @brief コンストラクタ
     * @param cutType カットの種類
     */
    public RequestFirmwareVersion(Firmware firm) {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
        mFirmware = firm;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = mFirmware.getValue();

        return toCommand(parameter);
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mFirmware == null) {
            return false;
        }

        return true;
    }

}
