
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * InitPRNの実行結果データ
 */
public class ResultInitPrn extends ResultPrnData {
    /** @brief 周辺装置処理結果タグ */
    protected static final String DEVICE = "device";

    /**
     * @brief コンストラクタ
     */
    public ResultInitPrn(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitPrn() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitPrn> CREATOR = new Parcelable.Creator<ResultInitPrn>() {
        public ResultInitPrn createFromParcel(Parcel in) {
            return new ResultInitPrn(in);
        }

        public ResultInitPrn[] newArray(int size) {
            return new ResultInitPrn[size];
        }
    };
}
