
package com.panasonic.avc.smartpayment.devctlservice.share.result;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * デフォルト処理結果データ
 */
public class ResultData implements Parcelable {
    /** @brief 周辺装置処理結果 */
    private int mDevice;

    /** @brief 周辺装置処理結果タグ */
    protected static final String DEVICE = "device";

    /** @brief UPOS処理結果 */
    private int mUpos;

    /** @brief UPOS処理結果タグ */
    protected static final String UPOS = "upos";

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    /**
     * コンストラクタ
     */
    public ResultData(Parcel in) {
        readFromParcel(in);
    }

    /**
     * コンストラクタ
     */
    public ResultData() {

    }

    /**
     * @brief 周辺装置処理結果を取得します
     * @return 周辺装置処理結果
     */
    public int getDevice() {
        return mDevice;
    }

    /**
     * @brief 周辺装置処理結果を設定します
     * @param[in] device 周辺装置処理結果
     */
    public void setDevice(int device) {
        mDevice = device;
    }

    /**
     * @brief 周辺装置処理結果を取得します
     * @return
     */
    public int getUpos() {
        return mUpos;
    }

    /**
     * @brief UPOS処理結果を設定します
     * @param[in] upos UPOS処理結果
     */
    public void setUpos(int upos) {
        mUpos = upos;
    }

    /**
     * @brief 処理結果を設定します
     * @param[in] result 処理結果
     * @see ResultData#setDevice(int)
     * @see ResultData#setUpos(int)
     */
    public void setResult(ResultData result) {
        setDevice(result.getDevice());
        setUpos(result.getUpos());
    }
    
    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultData> CREATOR = new Parcelable.Creator<ResultData>() {
        public ResultData createFromParcel(Parcel in) {
            return new ResultData(in);
        }

        public ResultData[] newArray(int size) {
            return new ResultData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mDevice);
        dest.writeInt(mUpos);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mDevice = in.readInt();
        mUpos = in.readInt();
    }
}
