
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 液晶バックライト制御コマンド
 */
public class RequestLcdBackLight extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x20;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x02;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 3;

    /** @brief バックライトの設定を変更しない */
    public static final int BACKLIGHT_NO_CHANGE = 0;

    /** @brief バックライトOFF */
    public static final int BACKLIGHT_OFF = 2;

    /** @brief バックライトON */
    @SuppressWarnings("unused")
    private static final int BACKLIGHT_ON = 1;

    /** @brief バックライト定義 */
    public enum BackLight {
        OFF((byte) 0x00),
        ON((byte) 0x01);

        private final byte mValue;

        private BackLight(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }
    }

    /** @brief バックライト */
    private int mBackLight;

    /**
     * @brief コンストラクタ
     * @param light バックライト設定
     */
    public RequestLcdBackLight(int light) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mBackLight = light;
    }

    /**
     * @brief バックライトの設定を取得する
     * @return バックライト設定
     */
    public int getBackLight() {
        return mBackLight;
    }

    /**
     * @brief バックライトの設定をする
     * @param backLight バックライト設定
     */
    public void setBackLight(int backLight) {
        mBackLight = backLight;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);

        if (mBackLight == BACKLIGHT_OFF) {
            parameter[2] = BackLight.OFF.getValue();
        } else {
            parameter[2] = BackLight.ON.getValue();
        }

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (!(0 <= mBackLight && mBackLight <= 2)) {
            return false;
        }

        return true;
    }

}
