package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_SIZE_WITHOUT_PARAMETER;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.ID_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;

import java.math.BigInteger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * デバイスResponseBaseクラス.
 */
abstract public class BaseResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = BaseResponse.class.getSimpleName();

    /** @brief ID */
    private byte mId = (byte) 0x03;

    /** @brief MC */
    protected byte mMainCommand;

    /** @brief SC */
    protected byte mSubCommand;

    /** @brief データ部Length */
    protected int mDataLength;

    /**
     * MCを返却する.
     * 
     * @return MCbyteデータ
     */
    public byte getMainCommand() {
        return mMainCommand;
    }

    /**
     * SCのbyteデータを返却する.
     * 
     * @return SCbyteデータ
     */
    public byte getSubCommand() {
        return mSubCommand;
    }

    /**
     * LEN長を返却する.
     * 
     * @return LEN長
     */
    public int getDataLength() {
        return mDataLength;
    }

    /**
     * 指定のbyte配列をデータチェックおよびデータ抽出を行う抽象メソッド.
     * 
     * @param bytes
     *            チェック抽出対象のbyte配列
     * @return チェックおよび抽出成功時true
     */
    abstract public boolean inputDeviceResult(byte[] bytes);

    /**
     * 指定byte配列からデータを抽出する.
     * 
     * @param bytes
     *            抽出対象byte配列（header部付）
     * @return 切り出しが成功した場合、引数のbyte配列を返却する。それ以外はnullを返却する
     */
    protected byte[] cutDeviceResult(byte[] bytes) {
        if (bytes == null) {
            Logger.e(TAG, "cutDeviceResult bytes is null.");
            return null;
        }

        if (bytes.length < DATA_SIZE_WITHOUT_PARAMETER) {
            Logger.e(TAG, "cutDeviceResult bytes bytes.length = " + bytes.length);
            return null;
        }

        mMainCommand = bytes[MAINCOMMAND_INDEX];
        mSubCommand = bytes[SUBCOMMAND_INDEX];
        // データ長をセットする
        mDataLength = new BigInteger(new byte[]{(byte) 0x00,
                bytes[DATALENGTHLOW_INDEX], bytes[DATALENGTHHIGH_INDEX]})
                .intValue();
        // byte配列はそのまま返却する
        return bytes;
    }

    /**
     * 指定byte配列のデータチェックを行う.
     * 
     * 
     * @param bytes
     *            チェック対象byte配列
     * @return チェックでOKの場合true
     */
    protected boolean checkResponseData(byte[] bytes) {
        // チェック前最低長確認
        if (bytes == null) {
            Logger.e(TAG, "checkResponseData bytes[] null.");
            return false;
        }

        if (bytes.length < DATALENGTHLOW_INDEX) {
            Logger.e(TAG, "checkResponseData bytes length short. length= "
                    + bytes.length);
            return false;
        }

        // midチェック
        if (bytes[ID_INDEX] != mId) {
            Logger.e(TAG, "checkResponseData response mid mismatch. = "
                    + bytes[ID_INDEX]);
            return false;
        }

        // データ部LEN指定値と実データ長比較
        int setLength = new BigInteger(new byte[] { (byte) 0x00,
                bytes[DATALENGTHLOW_INDEX], bytes[DATALENGTHHIGH_INDEX] })
                .intValue();

        if (bytes.length != setLength + DATA_SIZE_WITHOUT_PARAMETER) {
            Logger.e(TAG, "checkResponseData DATALENGTH_LOW :setLength ="
                    + setLength + ",bytes.length = " + bytes.length);
            return false;
        }
        return true;
    }
}
