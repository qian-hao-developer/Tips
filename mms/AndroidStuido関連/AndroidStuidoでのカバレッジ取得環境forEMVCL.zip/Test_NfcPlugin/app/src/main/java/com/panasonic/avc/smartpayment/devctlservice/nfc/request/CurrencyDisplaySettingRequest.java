package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.CURRENCY_DISPLAY_SETTING_REQUEST.CURRENCYABBDATA;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * 決済通貨表示設定Requestクラス.
 * 
 */
public class CurrencyDisplaySettingRequest extends BaseRequest {

    /** @brief ログ用タグ */
    private static final String TAG = CurrencyDisplaySettingRequest.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x80;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x42;

    /** @brief 決済通貨名称 . */
    private byte[] mCurrencyAbbData;

    /**
     * 決済通貨名称を設定する.
     * 
     * @param currencyAbbData
     *            決済通貨名称
     */
    public void setCurrencyAbbData(byte[] currencyAbbData) {
        mCurrencyAbbData = currencyAbbData;
    }

    /** Constructor */
    public CurrencyDisplaySettingRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // 決済通貨名称:必須チェック
        if (mCurrencyAbbData == null) {
            Logger.e(TAG, "isValidValue mCurrencyAbbData is null ");
            return false;
        }

        // サイズチェック（通貨表示は3文字未満になることが無い）
        if (mCurrencyAbbData.length != CURRENCYABBDATA.getDataLength()) {
            Logger.e(TAG, "isValidValue mCurrencyAbbData length unmatch = "
                    + Arrays.toString(mCurrencyAbbData));
            return false;
        }

        byte[] checkArray = mCurrencyAbbData;

        for (int i = 0; i < checkArray.length; i++) {
            // 表示可能文字範囲に含まれているか確認する
            if (checkArray[i] < 0x20 || checkArray[i] > 0x7e) {
                Logger.e(TAG, "isValidValue mCurrencyAbbData unmatch data[" + i
                        + "] = " + checkArray[i] + ":mCurrencyAbbData = "
                        + mCurrencyAbbData);
                return false;
            }
        }

        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return toCommand(mCurrencyAbbData);
    }
}
