
package com.panasonic.avc.smartpayment.devctlservice.share.result;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;

/**
 * CheckHealth処理結果データ
 */
public class ResultCheckHealth extends AnalyzeResultData {

    /** @brief 接触ICカードリーダライタ状態タグ */
    protected static final String CONDITION = "condition";

    /** @brief 接触ICカードリーダライタの利用可否情報 */
    protected boolean mSts;

    /** @brief 接触ICカードリーダライタの利用可否情報タグ */
    protected static final String STS = "sts";

    /** @brief 不正開封検知情報 */
    protected boolean mTamper;

    /** @brief 不正開封検知情報タグ */
    protected static final String TAMPER = "tamper";

    /** @brief マスターコマンド **/
    protected static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド **/
    protected static final byte SUB_COMMAND = 0x02;

    /** @brief コマンドの長さ **/
    protected static final int LENGTH = 0x21;

    /**
     * @brief コンストラクタ
     */
    public ResultCheckHealth(Parcel in) {
        super(in);
    }

    /**
     * コンストラクタ
     */
    public ResultCheckHealth() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCheckHealth> CREATOR = new Parcelable.Creator<ResultCheckHealth>() {
        public ResultCheckHealth createFromParcel(Parcel in) {
            return new ResultCheckHealth(in);
        }

        public ResultCheckHealth[] newArray(int size) {
            return new ResultCheckHealth[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mSts ? 1 : 0);
        dest.writeInt(mTamper ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mSts = in.readInt() == 1 ? true : false;
        mTamper = in.readInt() == 1 ? true : false;
    }

    /**
     * @brief 接触ICカードリーダライタの利用可否情報を取得します
     * @retun 接触ICカードリーダライタの利用可否情報
     */
    public boolean isSts() {
        return mSts;
    }

    /**
     * @brief 接触ICカードリーダライタの利用可否情報を設定します
     * @param[in] 接触ICカードリーダライタの利用可否情報
     */
    public void setSts(boolean sts) {
        mSts = sts;
    }

    /**
     * @brief 不正開封検知情報を取得します
     * @param[in] 不正開封検知情報
     */
    public boolean isTamper() {
        return mTamper;
    }

    /**
     * @brief 不正開封検知情報を設定します
     * @retun 不正開封検知情報
     */
    public void setTamper(boolean tamper) {
        mTamper = tamper;
    }

    /**
     * @see AnalyzeResultData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int result = buffer[PinpadDefine.INDEX_PARAMETER];

        if (result != PluginDefine.RESULT_DEVICE_SCCESS) {
            setDevice(result);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        // 応答が返ってきたためタンパが発生してないためtrueを設定する
        mTamper = true;
        mSts = true;

        return true;
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        JSONObject jsonCondtion = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            jsonCondtion.put(STS, isSts());
            jsonCondtion.put(TAMPER, isTamper());
            if (getDevice() != PluginDefine.RESULT_DEVICE_SCCESS
                    || getUpos() != PluginDefine.RESULT_UPOS_SCCESS) {
                json.put(CONDITION, JSONObject.NULL);
            } else {
                json.put(CONDITION, jsonCondtion);
            }
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
