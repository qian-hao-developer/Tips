package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATA_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.BITMAP_TRANSFER_RESPONSE;

/**
 * トレーニング用ビットマップ転送
 * 
 */
public class TRBitmapTransferResponse extends BitmapTransferResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = TRBitmapTransferResponse.class.getSimpleName();

    /** @brief SC */
    protected static byte SUBCOMMAND = (byte) 0x07;

    public TRBitmapTransferResponse() {
        super(SUBCOMMAND);
    }

}

