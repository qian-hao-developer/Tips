
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * Ackデータ
 */
public class ResponseAck extends ResponseData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0xff;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x00;

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 0;

    /**
     * @brief コンストラクタ
     */
    public ResponseAck() {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        return true;
    }

}
