
package com.panasonic.avc.smartpayment.devctlservice.share.result.pos;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPOSの実行結果データ
 */
public class ResultInitPOS extends ResultData {

    /** @brief ブロックサイズタグ */
    private static final String BLOCKSZ = "blocksz";

    /** @brief ブロックサイズ */
    private int mBlockSize;

    /**
     * @brief コンストラクタ
     */
    public ResultInitPOS(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitPOS() {

    }

    /**
     * @brief ブロックサイズを取得します
     * @return ブロックサイズ ブロック分割しない:0
     */
    public int getBlockSize() {
        return mBlockSize;
    }

    /**
     * @brief ブロックサイズを設定します
     * @param[in] blocksz ブロックサイズ ブロック分割しない:0
     */
    public void setBlockSize(int blocksz) {
        mBlockSize = blocksz;
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitPOS> CREATOR = new Parcelable.Creator<ResultInitPOS>() {
        public ResultInitPOS createFromParcel(Parcel in) {
            return new ResultInitPOS(in);
        }

        public ResultInitPOS[] newArray(int size) {
            return new ResultInitPOS[size];
        }
    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mBlockSize);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mBlockSize = in.readInt();
    }

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            json.put(UPOS, getUpos());
            json.put(BLOCKSZ, getBlockSize());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

}
