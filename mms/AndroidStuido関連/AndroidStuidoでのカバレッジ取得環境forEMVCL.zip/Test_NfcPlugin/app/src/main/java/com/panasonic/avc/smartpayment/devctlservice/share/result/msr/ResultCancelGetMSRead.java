
package com.panasonic.avc.smartpayment.devctlservice.share.result.msr;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * CancelGetMSReadの実行結果データ
 */
public class ResultCancelGetMSRead extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultCancelGetMSRead(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultCancelGetMSRead() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCancelGetMSRead> CREATOR = new Parcelable.Creator<ResultCancelGetMSRead>() {
        public ResultCancelGetMSRead createFromParcel(Parcel in) {
            return new ResultCancelGetMSRead(in);
        }

        public ResultCancelGetMSRead[] newArray(int size) {
            return new ResultCancelGetMSRead[size];
        }
    };
}
