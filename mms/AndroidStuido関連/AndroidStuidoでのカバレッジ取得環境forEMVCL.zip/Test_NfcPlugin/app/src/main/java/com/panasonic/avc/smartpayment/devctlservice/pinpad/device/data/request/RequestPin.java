
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateCrtKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 暗証番号入力要求クラス
 */
public class RequestPin extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x04;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x00;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 91;

    /** @brief トレーニングモード */
    private boolean mTraining;

    /** @brief カードの保有者認証方式 */
    private int mPintype;

    /** @brief 画面 1 行目の左端に表示する文字列番号 */
    private int mTitle1;

    /** @brief 画面 1 行目の右端に表示(反転表示)する文字列番号 */
    private int mTitle2;

    /** @brief 表示する国モード（通貨表示） */
    private int mCountry;

    /** @brief 通貨コード */
    private String mCurrency;

    /** @brief 金額 */
    private String mAmount;

    /** @brief 表示する画面パターン */
    private int mScreen;

    /** @brief 入力PINの最小桁数 */
    private int mMin;

    /** @brief 入力PINの最大桁 */
    private int mMax;

    /** @brief PINバイパス表示のパターン */
    private int mIndicate;

    /** @brief エクスポーネント16進文字列 */
    private String mExp;

    /** @brief PINデータ暗号用公開鍵の16進文字列（最大248bytes） */
    private String mPubkey;

    /** @brief 音声案内 */
    private int mSound;

    /** @brief チャレンジコード */
    private byte[] mChallenge;

    /** @brief チャレンジコードの長さ */
    private static final int CHALLENGE_LENGTH = 16;

    /** @brief タンパ領域 ID5/ID6 */
    private byte[] mKey;

    /** @brief タンパ領域 ID5/ID6の最大の長さ */
    private static final int KEY_LENGTH_MAX = 2048;

    /** @brief タンパ領域 ID5/ID6で使用する鍵の長さ */
    private static final int KEY_LENGTH = 1664;

    private static final byte[] PREFIX = {
            (byte) 0x30, (byte) 0x31, (byte) 0x30, (byte) 0x0d, (byte) 0x06, (byte) 0x09,
            (byte) 0x60, (byte) 0x86,
            (byte) 0x48, (byte) 0x01, (byte) 0x65, (byte) 0x03, (byte) 0x04, (byte) 0x02,
            (byte) 0x01, (byte) 0x05,
            (byte) 0x00, (byte) 0x04, (byte) 0x20
    };

    /** @brief 暗号指定鍵ID - 機種別 PINPAD 使用鍵 <NTT-Dシンクラ> ON PIN PEK(DUKPT) */
    private static final int ON_PIN_PEK_ID = 0x0400;

    /** @brief PIN暗号指定鍵サブID 1 - 機種別 PINPAD 使用鍵 <NTT-Dシンクラ> ON PIN PEK(DUKPT) */
    private static final int ON_PIN_PEK_SUB_ID_1 = 0x0001;

    /** @brief PIN暗号指定鍵サブID 2 - 機種別 PINPAD 使用鍵 <NTT-Dシンクラ> ON PIN PEK(DUKPT) */
    private static final int ON_PIN_PEK_SUB_ID_2 = 0x0002;

    /** @brief 電子マネー用フラグ */
    private boolean mIsEmcrw;

    /**
     * @brief コンストラクタ(電子マネー用)
     */
    public RequestPin(boolean isTraining, int pintype, int title1, int title2,
            boolean isShowCountry, String amount, int min, int max, int isSound) {
        this();
        mIsEmcrw = true;

        setTraining(isTraining);
        setPintype(pintype);
        setTitle1(title1);
        setTitle2(title2);
        setCountry(isShowCountry ? 1 : 2);
        setCurrency(null);
        setAmount(amount);
        setScreen(1);
        setMin(min);
        setMax(max);
        setIndicate(0);
        setExp(null);
        setPubkey(null);
        setSound(isSound);
    }

    /**
     * @brief コンストラクタ
     */
    public RequestPin(boolean isTraining, int pintype, int country, String currency,
            String amount, int screen, int min, int max, int indicate, String exp, String pubkey,
            int isSound) {
        this();
        mIsEmcrw = false;

        setTraining(isTraining);
        setPintype(pintype);
        setCountry(country);
        setCurrency(currency);
        setAmount(amount);
        setScreen(screen);
        setMin(min);
        setMax(max);
        setIndicate(indicate);
        setExp(exp);
        setPubkey(pubkey);
        setSound(isSound);
    }

    /**
     * @brief コンストラクタ
     */
    private RequestPin() {
        setChallenge(null);
        setKey(null);

        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
    }

    /**
     * @brief トレーニングモードを取得します
     * @return mTraining トレーニングモード
     */
    public boolean getTraining() {
        return mTraining;
    }

    /**
     * @brief トレーニングモードを設定します
     * @param[in] mTraining トレーニングモード
     */
    public void setTraining(boolean mTraining) {
        this.mTraining = mTraining;
    }

    /**
     * @brief カードの保有者認証方式を取得します
     * @return mPintype カードの保有者認証方式
     */
    public int getPintype() {
        return mPintype;
    }

    /**
     * @brief カードの保有者認証方式を設定します
     * @param[in] mPintype カードの保有者認証方式
     */
    public void setPintype(int mPintype) {
        this.mPintype = mPintype;
    }

    /**
     * @brief 表示する国モードを取得します
     * @return mCountry 表示する国モード
     */
    public int getCountry() {
        return mCountry;
    }

    /**
     * @brief 表示する国モードを設定します
     * @param[in] mCountry 表示する国モード
     */
    public void setCountry(int mCountry) {
        this.mCountry = mCountry;
    }

    /**
     * @brief 通貨コードを取得します
     * @return mCurrency 通貨コード
     */
    public String getCurrency() {
        return mCurrency;
    }

    /**
     * @brief 通貨コードを設定します
     * @param[in] mCurrency 通貨コード
     */
    public void setCurrency(String mCurrency) {
        this.mCurrency = mCurrency;
    }

    /**
     * @brief 金額を取得します
     * @return mAmount 金額
     */
    public String getAmount() {
        return mAmount;
    }

    /**
     * @brief 金額を設定します
     * @param[in] mAmount 金額
     */
    public void setAmount(String mAmount) {
        this.mAmount = mAmount;
    }

    /**
     * @brief 表示する画面パターンを取得します
     * @return mScreen 画面パターン
     */
    public int getScreen() {
        return mScreen;
    }

    /**
     * @brief 表示する画面パターンを設定します
     * @param[in] mScreen 画面パターン
     */
    public void setScreen(int mScreen) {
        this.mScreen = mScreen;
    }

    /**
     * @brief 入力PINの最小桁数を取得します
     * @return mMin 入力PINの最小桁数
     */
    public int getMin() {
        return mMin;
    }

    /**
     * @brief 入力PINの最小桁数を設定します
     * @param[in] mMin 入力PINの最小桁数
     */
    public void setMin(int mMin) {
        this.mMin = mMin;
    }

    /**
     * @brief 入力PINの最大桁を取得します
     * @return mMax 入力PINの最大桁
     */
    public int getMax() {
        return mMax;
    }

    /**
     * @brief 入力PINの最大桁を設定します
     * @param[in] mMax 入力PINの最大桁
     */
    public void setMax(int mMax) {
        this.mMax = mMax;
    }

    /**
     * @brief PINバイパス表示パターンを取得します
     * @return mIndicate PINバイパス表示パターン
     */
    public int getIndicate() {
        return mIndicate;
    }

    /**
     * @brief PINバイパス表示パターンを設定します
     * @param[in] mIndicate PINバイパス表示パターン
     */
    public void setIndicate(int mIndicate) {
        this.mIndicate = mIndicate;
    }

    /**
     * @brief エクスポーネントを取得します
     * @return mExp エクスポーネント
     */
    public String getExp() {
        return mExp;
    }

    /**
     * @brief エクスポーネントを設定します
     * @param[in] mExp エクスポーネント
     */
    public void setExp(String mExp) {
        this.mExp = mExp;
    }

    /**
     * @brief PINデータ暗号用公開鍵（16進文字列）を取得します
     * @return mPubkey PINデータ暗号用公開鍵
     */
    public String getPubkey() {
        return mPubkey;
    }

    /**
     * @brief PINデータ暗号用公開鍵（16進文字列）を設定します
     * @param[in] mPubkey PINデータ暗号用公開鍵
     */
    public void setPubkey(String mPubkey) {
        this.mPubkey = mPubkey;
    }

    /**
     * @brief 音声案内を取得します
     * @return mSound 音声案内
     */
    public int getSound() {
        return mSound;
    }

    /**
     * @brief 音声案内を設定します
     * @param[in] mSound 音声案内
     */
    public void setSound(int mSound) {
        this.mSound = mSound;
    }

    public void setChallenge(byte[] challenge) {
        if (challenge == null) {
            return;
        }

        if (mChallenge != null) {
            mChallenge = null;
        }

        mChallenge = new byte[challenge.length];
        for (int i = 0; i < challenge.length; i++) {
            mChallenge[i] = challenge[i];
        }
    }

    public void setKey(byte[] key) {
        if (key == null) {
            return;
        }
        if (key.length > KEY_LENGTH_MAX) {
            return;
        }
        if (mKey != null) {
            mKey = null;
        }

        mKey = new byte[key.length];
        for (int i = 0; i < key.length; i++) {
            mKey[i] = key[i];
        }
    }

    /**
     * 画面 1 行目の左端に表示する文字列番号を指定
     * 
     * @param title1 画面 1 行目の左端に表示する文字列番号
     */
    public void setTitle1(int title1) {
        this.mTitle1 = title1;
    }

    /**
     * 画面 1 行目の右端に表示(反転表示)する文字列番号を指定
     * 
     * @param title2 画面 1 行目の右端に表示(反転表示)する文字列番号
     */
    public void setTitle2(int title2) {
        this.mTitle2 = title2;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {
        if (!isValidValue()) {
            return null;
        }

        // ----------シーケンス----------
        byte[] sequence = new byte[2];
        sequence[0] = (byte) (mSequence & 0x00ff);
        sequence[1] = (byte) ((mSequence >> 8) & 0x00ff);

        // ----------PIN暗号指定フォーマット、PIN入力コマンドパラメータ----------
        byte[] pin_input = new byte[LENGTH - sequence.length];
        pin_input[0] = (byte) 0x30;// PIN入力情報TAG
        pin_input[1] = (byte) 0x08;// TAGサイズ
        pin_input[2] = (byte) 0x00;
        pin_input[3] = (byte) 0x00;// オン/オフPINモード指定
        pin_input[4] = (byte) 0x02;// ISO 9564 Format1
        pin_input[5] = (byte) 0x01;// PINフォーマット指定
        pin_input[6] = (byte) 0x00;// PINフォーマット拡張指定

        int onPinPekSubID = mIsEmcrw ? ON_PIN_PEK_SUB_ID_2 : ON_PIN_PEK_SUB_ID_1;
        pin_input[7] = (byte) (ON_PIN_PEK_ID & 0x00ff);// 暗号指定鍵ID
        pin_input[8] = (byte) ((ON_PIN_PEK_ID >> 8) & 0x00ff);
        pin_input[9] = (byte) (onPinPekSubID & 0x00ff);// PIN暗号指定鍵サブID
        pin_input[10] = (byte) ((onPinPekSubID >> 8) & 0x00ff);

        pin_input[11] = (byte) 0x50;// チケット情報TAG
        pin_input[12] = (byte) 0x21;// TAGサイズ
        pin_input[13] = (byte) 0x00;
        pin_input[14] = (byte) 0x00;// チケット情報
        pin_input[15] = (byte) 0x00;// チケットデータ
        pin_input[16] = (byte) 0x00;
        pin_input[17] = (byte) 0x00;
        pin_input[18] = (byte) 0x00;
        pin_input[19] = (byte) 0x00;
        pin_input[20] = (byte) 0x00;
        pin_input[21] = (byte) 0x00;
        pin_input[22] = (byte) 0x00;
        pin_input[23] = (byte) 0x00;
        pin_input[24] = (byte) 0x00;
        pin_input[25] = (byte) 0x00;
        pin_input[26] = (byte) 0x00;
        pin_input[27] = (byte) 0x00;
        pin_input[28] = (byte) 0x00;
        pin_input[29] = (byte) 0x00;
        pin_input[30] = (byte) 0x00;
        pin_input[31] = (byte) 0x00;
        pin_input[32] = (byte) 0x00;
        pin_input[33] = (byte) 0x00;
        pin_input[34] = (byte) 0x00;
        pin_input[35] = (byte) 0x00;
        pin_input[36] = (byte) 0x00;
        pin_input[37] = (byte) 0x00;
        pin_input[38] = (byte) 0x00;
        pin_input[39] = (byte) 0x00;
        pin_input[40] = (byte) 0x00;
        pin_input[41] = (byte) 0x00;
        pin_input[42] = (byte) 0x00;
        pin_input[43] = (byte) 0x00;
        pin_input[44] = (byte) 0x00;
        pin_input[45] = (byte) 0x00;
        pin_input[46] = (byte) 0x00;

        pin_input[47] = (byte) ((mMin & 0x0f) << 4 | mMax & 0x0f); // 入力桁数

        // 入力制御
        if (mSound != 0) {
            pin_input[48] = (byte) 0x80;
        } else {
            pin_input[48] = (byte) 0x00;
        }

        // 画面制御
        if (mMin == mMax) {
            pin_input[49] = (byte) 0x40;
        } else {
            pin_input[49] = (byte) 0x48;
        }

        pin_input[50] = (byte) 0xa1; // 表示指定

        if (mCountry == 1) {
            pin_input[51] = (byte) 0x01; // アプリ名称ID "金額"
        } else if (mCountry == 2) {
            pin_input[51] = (byte) 0x00; // アプリ名称ID ""(表示なし)
        } else {
            pin_input[51] = (byte) 0x04; // アプリ名称ID "AMOUNT"
        }

        pin_input[52] = (byte) 0x00; // 金額表示文字種別

        // 通貨コード
        pin_input[53] = (byte) 0x00;
        pin_input[54] = (byte) 0x00;
        pin_input[55] = (byte) 0x00;

        if (mCurrency != null && !mCurrency.isEmpty()) {
            for (int i = 0; i < mCurrency.length(); i++) {
                pin_input[53 + i] = (byte) mCurrency.getBytes()[i];
            }
        }

        for (int i = 0; i < 21; i++) {
            pin_input[56 + i] = 0x20;
        }

        for (int i = 0; i < mAmount.length(); i++) {
            pin_input[56 + i] = mAmount.getBytes()[i];
        }

        // 暗証番号入力(前段)
        // 暗証番号入力(中段)
        // 暗証番号入力(後段)
        // 暗証番号入力(後段)
        // 暗証番号入力(後段)
        // 暗証番号入力(後段)
        // 暗証番号入力(後段)
        if (mCountry == 3) {
            if (mScreen == 1) {
                pin_input[77] = (byte) 0x1b;
                pin_input[78] = (byte) 0x06;
                pin_input[79] = (byte) 0x00;
                pin_input[80] = (byte) 0x00;
                pin_input[81] = (byte) 0x00;
                pin_input[82] = (byte) 0x00;
                pin_input[83] = (byte) 0x00;
            } else {
                pin_input[77] = (byte) 0x1a;
                pin_input[78] = (byte) 0x06;
                pin_input[79] = (byte) 0x00;
                pin_input[80] = (byte) 0x00;
                pin_input[81] = (byte) 0x00;
                pin_input[82] = (byte) 0x00;
                pin_input[83] = (byte) 0x00;
            }
        } else {
            if (mScreen == 1) {
                pin_input[77] = (byte) 0x07;
                pin_input[78] = (byte) 0x01;
                pin_input[79] = (byte) 0x00;
                pin_input[80] = (byte) 0x00;
                pin_input[81] = (byte) 0x00;
                pin_input[82] = (byte) 0x00;
                pin_input[83] = (byte) 0x00;
            } else {
                pin_input[77] = (byte) 0x06;
                pin_input[78] = (byte) 0x01;
                pin_input[79] = (byte) 0x00;
                pin_input[80] = (byte) 0x00;
                pin_input[81] = (byte) 0x00;
                pin_input[82] = (byte) 0x00;
                pin_input[83] = (byte) 0x00;
            }

        }

        pin_input[84] = (byte) 0x00; // 取引中止確認画面番号指定
        pin_input[85] = (byte) 0x00; // PIN不知メッセージ画面番号指定
        pin_input[86] = (byte) 0x00; // PINスキップ確認画面番号指定
        pin_input[87] = (byte) 0x00; // 業名称ID
        pin_input[88] = (byte) 0x00; // 支払い方法ID

        byte[] signature = generatePinSignature(pin_input, mChallenge);
        if (signature == null) {
            return null;
        }

        byte[] paramater = new byte[LENGTH + signature.length];

        System.arraycopy(sequence, 0, paramater, 0, sequence.length);
        System.arraycopy(pin_input, 0, paramater, sequence.length, pin_input.length);
        System.arraycopy(signature, 0, paramater, LENGTH, signature.length);

        // Log.d("hashbyte", CalcUtil.toHexString(hashbyte));
        // Log.d("hash", CalcUtil.toHexString(hash));
        // Log.d("signature", CalcUtil.toHexString(signature));
        // Log.d("sign", CalcUtil.toHexString(sign));

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (!isValidAmount()) {
            return false;
        }

        if (mMin > mMax) {
            return false;
        }

        if (mMax > 12) {
            return false;
        }

        if (mMin <= 0) {
            return false;
        }

        if (!(mSound == 0 || mSound == 1)) {
            return false;
        }

        if (mChallenge == null) {
            return false;
        }

        if (mKey == null) {
            return false;
        }

        return mIsEmcrw ? isValidValueEmcrw() : isValidValueDefault();
    }

    private boolean isValidValueDefault() {

        if (mIndicate < 0 || mIndicate > 4) {
            return false;
        }

        if (mCurrency != null && mCurrency.length() > 3) {
            return false;
        }

        if (!(1 <= mCountry && mCountry <= 3)) {
            return false;
        }

        if (!(1 <= mScreen && mScreen <= 2)) {
            return false;
        }

        if (mPintype == 1) {
            if (mExp != null && mExp.getBytes().length > 3) {
                return false;
            }
        } else {
            if (mExp != null && mExp.length() != 0) {
                return false;
            }
        }

        if (mPintype == 1) {
            if (mPubkey != null) {
                byte[] pubkey = CalcUtil.toByte(mPubkey);
                if (pubkey != null && pubkey.length > 248) {
                    return false;
                }
            }
        } else {
            if (mPubkey != null && mPubkey.length() != 0) {
                return false;
            }
        }

        if (mPintype != 5) {
            return false;
        }

        return true;
    }

    private boolean isValidValueEmcrw() {

        // ※1~5 は、StartGetPINData で定義されています。
        if (mPintype != 6) {
            return false;
        }

        // ※据置型[P]の場合は、null を指定します。
        // Ped.js にて null は 0 に変換済み
        if (mTitle1 != 0) {
            return false;
        }

        // ※据置型[P]の場合は、null を指定します。
        // Ped.js にて null は 0 に変換済み
        if (mTitle2 != 0) {
            return false;
        }

        return true;
    }

    private boolean isValidAmount() {

        // null や空文字列は許容しない
        if (mAmount == null || mAmount.equals("")) {
            return false;
        }

        // 文字列の長さをチェック
        if (mAmount.getBytes().length > (mIsEmcrw ? 16 : 20)) {
            return false;
        }

        // 使用できる文字は、30h~39h、20h、2Ch(,)、2Dh(-)、2Eh(.)、5Ch(\)の半角文字です。
        byte[] bytes = mAmount.getBytes();
        for (byte b : bytes) {
            if ((byte) 0x30 <= b && b <= (byte) 0x39) {
                continue;
            }
            if ((byte) 0x20 == b) {
                continue;
            }
            if ((byte) 0x2C == b) {
                continue;
            }
            if ((byte) 0x2D == b) {
                continue;
            }
            if ((byte) 0x2E == b) {
                continue;
            }
            if ((byte) 0x5C == b) {
                continue;
            }
            return false;
        }

        return true;
    }

    protected byte[] generatePinSignature(byte[] pin_input, byte[] challenge) {
        if (pin_input == null) {
            return null;
        }
        if (challenge == null) {
            return null;
        }
        if (challenge.length != CHALLENGE_LENGTH) {
            return null;
        }
        ByteBuffer byteBuffPinInput = ByteBuffer.allocate(pin_input.length);
        byteBuffPinInput.put(pin_input);

        byte[] hash = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(byteBuffPinInput.array());
            hash = md.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
        if (hash == null) {
            return null;
        }

        ByteBuffer byteBuffSignature = ByteBuffer.allocate(challenge.length + PREFIX.length
                + hash.length);
        byteBuffSignature.put(challenge);
        byteBuffSignature.put(PREFIX);
        byteBuffSignature.put(hash);

        Key key = createKey();
        if (key == null) {
            return null;
        }

        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return cipher.doFinal(byteBuffSignature.array());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected Key createKey() {
        if (mKey == null) {
            return null;
        }
        if (mKey.length < KEY_LENGTH) {
            return null;
        }
        StringBuilder modulusDump = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            modulusDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder publicExponentDump = new StringBuilder();
        for (int i = 256; i < 512; i++) {
            publicExponentDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder privateExponentDump = new StringBuilder();
        for (int i = 512; i < 768; i++) {
            privateExponentDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder primePDump = new StringBuilder();
        for (int i = 1024; i < 1152; i++) {
            primePDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder primeQDump = new StringBuilder();
        for (int i = 1152; i < 1280; i++) {
            primeQDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder primeExponentPDump = new StringBuilder();
        for (int i = 1280; i < 1408; i++) {
            primeExponentPDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder primeExponentQDump = new StringBuilder();
        for (int i = 1408; i < 1536; i++) {
            primeExponentQDump.append(String.format("%02x", mKey[i]));
        }
        StringBuilder coefficientDump = new StringBuilder();
        for (int i = 1536; i < 1664; i++) {
            coefficientDump.append(String.format("%02x", mKey[i]));
        }

        String modulus = modulusDump.toString();
        String publicExponent = publicExponentDump.toString();
        String privateExponent = privateExponentDump.toString();
        String primeP = primePDump.toString();
        String primeQ = primeQDump.toString();
        String primeExponentP = primeExponentPDump.toString();
        String primeExponentQ = primeExponentQDump.toString();
        String coefficient = coefficientDump.toString();

        RSAPrivateCrtKeySpec spec = new RSAPrivateCrtKeySpec(
                new BigInteger(modulus, 16),
                new BigInteger(publicExponent, 16),
                new BigInteger(privateExponent, 16),
                new BigInteger(primeP, 16),
                new BigInteger(primeQ, 16),
                new BigInteger(primeExponentP, 16),
                new BigInteger(primeExponentQ, 16),
                new BigInteger(coefficient, 16));

        Key key = null;
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            key = keyFactory.generatePrivate(spec);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }

        return key;
    }
}
