
package com.panasonic.avc.smartpayment.devctlservice.share.result.printer;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultPrnData;

/**
 * Prn_CutPaperの実行結果データ
 */
public class ResultPrintCutPaper extends ResultPrnData {
    /**
     * @brief コンストラクタ
     */
    public ResultPrintCutPaper(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrintCutPaper() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrintCutPaper> CREATOR = new Parcelable.Creator<ResultPrintCutPaper>() {
        public ResultPrintCutPaper createFromParcel(Parcel in) {
            return new ResultPrintCutPaper(in);
        }

        public ResultPrintCutPaper[] newArray(int size) {
            return new ResultPrintCutPaper[size];
        }
    };
}
