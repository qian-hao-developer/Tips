
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * 印刷開始要求
 */
public class RequestStartPrint extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x0008;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x8000;

    /** @brief コマンド詳細 */
    private static final int LENGTH = 0x0004;

    /** @brief 太字にするかどうか */
    private boolean mBold;

    /** @brief 印字濃度 */
    private int mDensity;

    /** @brief スペースを入れるかどうか */
    private boolean mSpace;

    /** @brief 印字幅 */
    private int mWidth;

    /** @brief 印字濃度(淡い) */
    private static final int DENSITY_PALE = 1;

    /** @brief 印字濃度(やや淡い) */
    private static final int DENSITY_LITTLE_PALE = 2;

    /** @brief 印字濃度(普通) */
    public static final int DENSITY_DEFAULT = 3;

    /** @brief 印字濃度(やや濃い) */
    private static final int DENSITY_LITTLE_DEEP = 4;

    /** @brief 印字濃度(濃い) */
    private static final int DENSITY_DEEP = 5;

    /** @brief 印字濃度 */
    private enum Density {
        PALE((byte) 90),
        LITTLE_PALE((byte) 100),
        DEFAULT((byte) 110),
        LITTLE_DEEP((byte) 120),
        DEEP((byte) 130);

        private final byte mValue;

        private Density(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }

    }

    /**
     * @brief コンストラクタ
     * @param bold 太字設定
     * @param density 印字濃度
     * @param space 行間設定
     * @param width 印字幅
     */
    public RequestStartPrint(boolean bold, int density, boolean space, int width) {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
        mBold = bold;
        mDensity = density;
        mSpace = space;
        mWidth = width;
    }

    /**
     * @brief 太字設定かどうか
     * @return 設定状態
     */
    public boolean isBold() {
        return mBold;
    }

    /**
     * @brief 太字を設定する
     * @param bold 太字かどうか
     */
    public void setBold(boolean bold) {
        mBold = bold;
    }

    /**
     * @brief 印字濃度を取得する
     * @return 印字濃度
     */
    public int getDensity() {
        return mDensity;
    }

    /**
     * @brief 印字濃度を設定する
     * @param density 印字濃度
     */
    public void setDensity(int density) {
        mDensity = density;
    }

    /**
     * @brief 行間をとるかどうか
     * @return 行間ありなし
     */
    public boolean isSpace() {
        return mSpace;
    }

    /**
     * @brief 行間を設定する
     * @param space 行間設定
     */
    public void setSpace(boolean space) {
        mSpace = space;
    }

    /**
     * @brief 印字幅を取得する
     * @return 印字幅
     */
    public int getWidth() {
        return mWidth;
    }

    /**
     * @brief 印字幅を設定する
     * @param width 印字幅
     */
    public void setWidth(int width) {
        mWidth = width;
    }

    /**
     * @see RequestPrinterData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = mBold ? (byte) 0x01 : (byte) 0x00;

        Density density;
        switch (mDensity) {
            case DENSITY_PALE:
                density = Density.PALE;
                break;
            case DENSITY_LITTLE_PALE:
                density = Density.LITTLE_PALE;
                break;
            case DENSITY_DEFAULT:
                density = Density.DEFAULT;
                break;
            case DENSITY_LITTLE_DEEP:
                density = Density.LITTLE_DEEP;
                break;
            case DENSITY_DEEP:
                density = Density.DEEP;
                break;
            default:
                return null;
        }

        parameter[1] = density.getValue();
        parameter[2] = mSpace ? (byte) 0x03 : (byte) 0x00;
        parameter[3] = (byte) (mWidth & 0xff);

        return toCommand(parameter);
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mDensity < 1 || mDensity > 5) {
            return false;
        }

        if (mWidth < 1 || mWidth > 2) {
            return false;
        }

        return true;
    }
}
