
package com.panasonic.avc.smartpayment.devctlservice.share.result.icrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * SendAPDU処理結果データ
 */
public class ResultSendAPDU extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultSendAPDU(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSendAPDU() {
    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSendAPDU> CREATOR = new Parcelable.Creator<ResultSendAPDU>() {
        public ResultSendAPDU createFromParcel(Parcel in) {
            return new ResultSendAPDU(in);
        }

        public ResultSendAPDU[] newArray(int size) {
            return new ResultSendAPDU[size];
        }
    };
}
