
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.response;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.PrinterDefine;
import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.ResponsePrinterData;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * 基本情報取得応答
 */
public class ResponseBasicInformation extends ResponsePrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x000D;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x0000;

    /** @brief コマンド詳細(シーケンスエラー) */
    private static final int COMMAND_DETAIL_SEQUENCE_ERROR = 0x0002;

    /** @brief コマンド長 */
    private static final int LENGTH = 4;

    /**
     * @brief コンストラクタ
     */
    public ResponseBasicInformation() {
        mCommandId = COMMAND_ID;
        mCommandDetail = 0xFFFF;
    }

    /**
     * @see ResponsePrinterData#inputPrinterResult(byte[])
     */
    @Override
    public boolean inputPrinterResult(byte[] bytes) {
        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            mLackDataSize = true;
            return false;
        }

        mCommandDetail = CalcUtil.toInt(buffer[PrinterDefine.INDEX_DETAIL_1],
                buffer[PrinterDefine.INDEX_DETAIL_2]);

        int len = CalcUtil.toInt(buffer[PrinterDefine.INDEX_LEN_1],
                buffer[PrinterDefine.INDEX_LEN_2]);

        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!isValidValue()) {
            mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.PRT, mCommandDetail, -1,
                    CalcUtil.toInt(buffer[PrinterDefine.INDEX_ID_1],
                            buffer[PrinterDefine.INDEX_ID_2]), null);
            setDevice(mCommandDetail);
            setUpos(PluginDefine.RESULT_DEVICE_SCCESS);
            return false;
        }

        byte status0 = buffer[PrinterDefine.INDEX_PARAMETER];
        byte status1 = buffer[PrinterDefine.INDEX_PARAMETER + 1];
        byte status2 = buffer[PrinterDefine.INDEX_PARAMETER + 2];
        byte status3 = buffer[PrinterDefine.INDEX_PARAMETER + 3];

        mStatus = (0xff000000 & (status3 << 24)) | (0x00ff0000 & (status2 << 16))
                | (0x0000ff00 & (status1 << 8)) | (0x000000ff & status0);

        if (!checkStatus()) {
            return false;
        }

        return true;
    }

    /**
     * @see ResponsePrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mCommandDetail != COMMAND_DETAIL) {
            return false;
        }

        return true;
    }

    public boolean isSequenceError() {
        if (mCommandDetail == COMMAND_DETAIL_SEQUENCE_ERROR) {
            return true;
        }
        return false;
    }
}
