
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultSetVolume extends ResultFeliCaApl {

    /** @brief 音量 */
    private int mVolume;

    /**
     * @brief コンストラクタ
     */
    public ResultSetVolume(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultSetVolume() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultSetVolume> CREATOR = new Parcelable.Creator<ResultSetVolume>() {

        @Override
        public ResultSetVolume createFromParcel(Parcel in) {
            return new ResultSetVolume(in);
        }

        @Override
        public ResultSetVolume[] newArray(int size) {
            return new ResultSetVolume[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(mVolume);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        mVolume = in.readInt();
    }

    /**
     * @brief 音量を取得する
     * @return　音量
     */
    public int getVolume() {
        return mVolume;
    }

    /**
     * @brief 音量を設定する
     * @param volume　音量
     */
    public void setVolume(int volume) {
        this.mVolume = volume;
    }
}
