package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * PFの詳細状態取得.
 * 
 */
public class PFGetStatusRequest extends BaseRequest {

    /** ログ用タグ */
    @SuppressWarnings("unused")
    private static final String TAG = PFGetStatusRequest.class
            .getSimpleName();

    /** MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** SC */
    private static byte SUBCOMMAND = (byte) 0x04;

    /** Constructor */
    public PFGetStatusRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {
        // データ部なし
        return super.toCommand(null);
    }
}
