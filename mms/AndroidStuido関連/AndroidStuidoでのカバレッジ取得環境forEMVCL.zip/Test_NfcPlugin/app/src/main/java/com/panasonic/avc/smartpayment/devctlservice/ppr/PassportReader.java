
package com.panasonic.avc.smartpayment.devctlservice.ppr;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.os.RemoteException;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprDataListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ppr.ResponseError;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ppr.ResponsePassportReader;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ppr.ResultInitPPR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ppr.ResultSendPPR;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ppr.ResultTermPPR;

public class PassportReader {

    /** @brief ログ出力用タグ */
    private static final String TAG = PassportReader.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static PassportReader sInstance = new PassportReader();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IPprServiceListener> mIPprServiceListenerList = new ConcurrentHashMap<String, IPprServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ControlDeviceManager mControlDeviceManager;

    /**
     * @brief コンストラクタ
     */
    private PassportReader() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static PassportReader getInstance() {
        return sInstance;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void setControlDeviceManager(ControlDeviceManager controlDeviceManager) {
        mControlDeviceManager = controlDeviceManager;
    }

    /**
     * @brief パスポートリーダプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerPprServiceListener(String tag, IPprServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIPprServiceListenerList) {
            mIPprServiceListenerList.put(tag, listener);
        }
    }

    /**
     * @brief パスポートリーダプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterPprServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIPprServiceListenerList) {
            mIPprServiceListenerList.remove(tag);
        }
    }

    /**
     * @brief パスポートリーダデバイスを初期化します
     * @return
     * @throws RemoteException
     */

    public ResultInitPPR initPPR() throws RemoteException {
        ResultInitPPR result = new ResultInitPPR();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        mControlDeviceManager.setPprDataListener(mIPprDataListener);
        mControlDeviceManager.read(0);
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief パスポートリーダデバイスをターミネートします
     */
    public ResultTermPPR termPPR() throws RemoteException {
        ResultTermPPR result = new ResultTermPPR();

        if (mControlDeviceManager == null || !mControlDeviceManager.isActive()) {
            result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            result.setUpos(PluginDefine.RESULT_UPOS_PORT_ERROR);
            return result;
        }

        mControlDeviceManager.removePprDataListener(mIPprDataListener);

        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief パスポートリーダにデータを送信します
     * @param datasz
     * @param data
     * @return
     * @throws RemoteException 注意：OCR-316Eでは常にパラメータ不正(E_ILLEGAL(106))を返却します
     */
    public ResultSendPPR sendPPR(int datasz, String data) throws RemoteException {
        ResultSendPPR ret = new ResultSendPPR();

        ret.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        ret.setUpos(PluginDefine.RESULT_UPOS_PRAMETER_ERROR);

        return ret;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {
        ResultGetPackageInfo result = new ResultGetPackageInfo();
        result.setName(jsName, pluginName, PassportReader.class.getSimpleName());
        result.setVer(jsVer, pluginVer, DevCtlServiceDefine.VERSION);
        return result;
    }

    /**
     * @brief エラーを送信する
     * @param ecode エラーの種類
     * @param vcode デバイスベンダ識別コード
     * @param extcode 拡張コード
     * @param extinfo 拡張情報
     */
    private void sendError(int ecode, int vcode, int extcode, String extinfo) {
        ResponseError error = new ResponseError();
        error.setEcode(ecode);
        error.setVcode(vcode);
        error.setExtcode(extcode);
        error.setExtinfo(extinfo);

        synchronized (mIPprServiceListenerList) {
            for (Map.Entry<String, IPprServiceListener> listener : mIPprServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onError(error);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @brief PassportReaderで読み取ったデータを送信する
     * @param data
     */
    private void sendData(String data) {
        ResponsePassportReader read = new ResponsePassportReader();

        read.setData(data);
        byte[] tmpData = CalcUtil.toByte(data);

        if (tmpData != null) {
            read.setDatasz(tmpData.length);
        } else {
            read.setDatasz(0);
        }

        synchronized (mIPprServiceListenerList) {
            for (Map.Entry<String, IPprServiceListener> listener : mIPprServiceListenerList
                    .entrySet()) {
                try {
                    listener.getValue().onPPREvent(read);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @see mIPprDataListener
     */
    private IPprDataListener mIPprDataListener = new IPprDataListener.Stub() {

        @Override
        public void sendPprData(String pprData) throws RemoteException {
            sendData(pprData);
            return;
        }
    };
}
