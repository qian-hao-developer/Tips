
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.hardware.usb.UsbRequest;
import android.os.RemoteException;
import android.util.Log;

import com.panasonic.avc.smartpayment.devctlservice.DevCtlServiceDefine;
import com.panasonic.avc.smartpayment.devctlservice.bcr.BarcodeReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwDefine;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.DeviceType;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.NotifyUsbDeviceConnectionListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager.SignpadDataListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.UsbDeviceManager.OnUsbDeviceListener;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.ppr.PassportReaderDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.IPprDataListener;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.spad.SignpadDefine;

/**
 * USB操作クラス
 */
public class UsbDeviceController extends DeviceController {

    /** @brief ログ用タグ */
    private static final String TAG = UsbDeviceController.class.getSimpleName();

    /** @brief プリンタテスト用コマンド識別タグ */
    private static final boolean PRINTER = false;

    /** @brief ログ表示 */
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief USBデバイス */
    private UsbDevice mUsbDevice;

    /** @brief USB管理 */
    private UsbManager mUsbManager;

    /** @brief USBデバイス接続制御 */
    private UsbDeviceConnection mConnection;

    /** @brief コントロールインターフェース */
    private UsbInterface mUsbControlInterface;

    /** @brief CDCインターフェース */
    private UsbInterface mUsbCDCInterface;

    /** @brief シリアル通信テスト用インターフェース */
    private UsbInterface mUsbSrlInterface;

    /** @brief 読み込み用エンドポイント */
    private UsbEndpoint mUsbReadEndpoint;

    /** @brief 書き込み用エンドポイント */
    private UsbEndpoint mUsbWriteEndpoint;

    /** @brief 割り込み用エンドポイント */
    private UsbEndpoint mUsbInterruptndpoint;

    /** @brief ベンダーID */
    private int mVendorId;

    /** @brief プロダクトID */
    private int mProductId;

    /** @brief USBのACM設定 */
    private static final int USB_RECIP_INTERFACE = 0x01;

    /** @brief DTR設定用リクエストタイプ */
    private static final int USB_RT_ACM = UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE;

    /** @brief DTR設定用リクエスト */
    private static final int SET_CONTROL_LINE_STATE = 0x22;

    /** @brief DeviceType: UnknownDevice */
    private static final int DEVICE_TYPE_UNKNOWN = 0;

    /** @brief DeviceType: Pinpad */
    private static final int DEVICE_TYPE_PINPAD = 1;

    /** @brief DeviceType: Printer */
    private static final int DEVICE_TYPE_PRINTER = 2;

    /** @brief DeviceType: PassportReader */
    private static final int DEVICE_TYPE_PASSPORT_READER = 3;

    /** @brief DeviceType: USBSerial */
    private static final int DEVICE_TYPE_SERIALTEST = 4;

    /** @brief DeviceType: Signpad */
    private static final int DEVICE_TYPE_SIGNPAD = 5;

    /** @brief DeviceType: EMCRW */
    private static final int DEVICE_TYPE_EMCRW = 6;

    /** @brief DeviceType: BarcodeReader */
    private static final int DEVICE_TYPE_BARCODE_READER = 7;

    /** @brief DeviceType */
    private int mDeviceType = DEVICE_TYPE_UNKNOWN;

    /** @brief パスポートデータリード用スレッド */
    private PassportDataReadThread mPassportDataReadThread = null;

    /** @brief パスポートデータ返却用リスナー */
    private IPprDataListener pprDataListener = null;

    /** @brief サインパッドデータ返却用リスナー */
    private SignpadDataListener spadDataListener = null;

    /** @brief 呼び出し元UsbDeviceManager オブジェクト */
    private UsbDeviceManager mManager;

    private static final byte COMMAND_SET = (byte) 0x01;
    private static final byte COMMAND_GET = (byte) 0x02;

    /* 割り込みスレッド */
    Thread mInterruptThread = null;

    private static boolean mActive = false;

    /* RTSモード */
    private boolean mEnableRTS = true;

    /**
     * @brief コンストラクタ
     * @param context コンテキスト
     */
    public UsbDeviceController(Context context) {
        super(context);
        mType = DeviceType.USB;
        mPassportDataReadThread = new PassportDataReadThread();
    }

    /**
     * @see DeviceController#write(byte[])
     */
    @Override
    public boolean write(byte[] buffer, int timeout) {
        switch (mDeviceType) {
            case DEVICE_TYPE_PINPAD:
            case DEVICE_TYPE_PRINTER:
            case DEVICE_TYPE_SERIALTEST:
            case DEVICE_TYPE_BARCODE_READER:
                return writeDeviceDefault(buffer, timeout);
            case DEVICE_TYPE_SIGNPAD:
                return writeSignpad(buffer, timeout);
            case DEVICE_TYPE_EMCRW:
                return writeEmcrw(buffer, timeout);
            case DEVICE_TYPE_UNKNOWN:
            default:
                break;
        }
        return false;
    }

    /**
     * @see DeviceController#write(byte[])
     */
    private boolean writeDeviceDefault(byte[] buffer, int timeout) {
        if (buffer == null) {
            return false;
        }

        String log = "";
        for (int i = 0; i < buffer.length; i++) {
            log += (Integer.toHexString(buffer[i] & 0xff) + " ");
        }
        mLoggingManager.d(TAG, "write data: " + log);

        if (mConnection == null) {
            return false;
        }
        int ret = mConnection.bulkTransfer(mUsbWriteEndpoint, buffer, buffer.length, timeout);

        return (ret >= 0);
    }

    /**
     * @see DeviceController#write(byte[])
     */
    private boolean writeSignpad(byte[] buffer, int timeout) {

        boolean ret = false;

        // 先頭1バイトはコマンドタイプなのでカットする
        ByteBuffer cmd = ByteBuffer.wrap(buffer);
        cmd.position(0);
        byte commandType = cmd.get(); // コマンドタイプ
        byte[] command = new byte[buffer.length - 1]; // 先頭を1バイトカットしたので1バイト短いbyte配列を用意する
        cmd.get(command);

        int value = 0x0300 | command[0];
        Log.d(TAG, dumpBytes(command));
        Log.d(TAG, "Write to Signpad: " + value);

        int res = 0;
        switch (commandType) {
            case COMMAND_SET:
                // setの時は0x21, 0x09
                res = mConnection.controlTransfer(0x21, 0x09, value, 0, command, command.length,
                        timeout);
                break;
            case COMMAND_GET:
                // getの時は0xa1, 0x01
                res = mConnection.controlTransfer(0xa1, 0x01, value, 0, command, command.length,
                        timeout);
                if (res > 0) {
                    Log.d(TAG, dumpBytes(command));
                    spadDataListener.sendSpadControlData(command);
                }
                break;
        }
        Log.d(TAG, dumpBytes(command));
        Log.d(TAG, "result: " + res);

        if (res > 0) {
            ret = true;
        }

        return ret;
    }

    /**
     * @see DeviceController#write(byte[])
     */
    public boolean writeEmcrw(byte[] buffer, int timeout) {
        if (buffer == null) {
            return false;
        }

        // String log = "";
        // for (int i = 0; i < buffer.length; i++) {
        // log += (Integer.toHexString(buffer[i] & 0xff) + " ");
        // }
        // mLoggingManager.d(TAG, "write data: " + log);

        if (mConnection == null) {
            return false;
        }

        isStart = false;
        if (isStart) {
            int ret = mConnection.controlTransfer(0x21, 0x22, 0x03, 0, null, 0, timeout);
            isStart = false;
            wait(1);
        }

        int ret = mConnection.bulkTransfer(mUsbWriteEndpoint, buffer,
                buffer.length, timeout);

        // NG
        // int ret = mConnection.controlTransfer(UsbConstants.USB_DIR_OUT, 0, 0,
        // 0, buffer,
        // buffer.length, 0);

        return (ret >= 0);
    }

    private void wait(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static final byte[] INT2BCD = new byte[] {
            (byte) 0x0, (byte) 0x1, (byte) 0x2, (byte) 0x3, (byte) 0x4,
            (byte) 0x5, (byte) 0x6, (byte) 0x7, (byte) 0x8, (byte) 0x9,
            (byte) 0x10, (byte) 0x11, (byte) 0x12, (byte) 0x13, (byte) 0x14,
            (byte) 0x15, (byte) 0x16, (byte) 0x17, (byte) 0x18, (byte) 0x19,
            (byte) 0x20, (byte) 0x21, (byte) 0x22, (byte) 0x23, (byte) 0x24,
            (byte) 0x25, (byte) 0x26, (byte) 0x27, (byte) 0x28, (byte) 0x29,
            (byte) 0x30, (byte) 0x31, (byte) 0x32, (byte) 0x33, (byte) 0x34,
            (byte) 0x35, (byte) 0x36, (byte) 0x37, (byte) 0x38, (byte) 0x39,
            (byte) 0x40, (byte) 0x41, (byte) 0x42, (byte) 0x43, (byte) 0x44,
            (byte) 0x45, (byte) 0x46, (byte) 0x47, (byte) 0x48, (byte) 0x49,
            (byte) 0x50, (byte) 0x51, (byte) 0x52, (byte) 0x53, (byte) 0x54,
            (byte) 0x55, (byte) 0x56, (byte) 0x57, (byte) 0x58, (byte) 0x59,
            (byte) 0x60, (byte) 0x61, (byte) 0x62, (byte) 0x63, (byte) 0x64,
            (byte) 0x65, (byte) 0x66, (byte) 0x67, (byte) 0x68, (byte) 0x69,
            (byte) 0x70, (byte) 0x71, (byte) 0x72, (byte) 0x73, (byte) 0x74,
            (byte) 0x75, (byte) 0x76, (byte) 0x77, (byte) 0x78, (byte) 0x79,
            (byte) 0x80, (byte) 0x81, (byte) 0x82, (byte) 0x83, (byte) 0x84,
            (byte) 0x85, (byte) 0x86, (byte) 0x87, (byte) 0x88, (byte) 0x89,
            (byte) 0x90, (byte) 0x91, (byte) 0x92, (byte) 0x93, (byte) 0x94,
            (byte) 0x95, (byte) 0x96, (byte) 0x97, (byte) 0x98, (byte) 0x99
    };

    private static int byte2Int(byte a) {
        int ret = 0;
        for (int i = 0; i < INT2BCD.length; i++) {
            if (a == INT2BCD[i]) {
                ret = i;
                break;
            }
        }
        return ret;
    }

    private static int byte2bcd(byte a, byte b, byte c) {
        int ret = 0;
        int a1 = byte2Int(a);
        int b1 = byte2Int(b);
        int c1 = byte2Int(c);
        ret = (a1 * 100) + (b1 * 10) + c1;
        return ret;
    }

    /**
     * @see DeviceController#read()
     */
    @Override
    public byte[] read(int timeout) {
        switch (mDeviceType) {
            case DEVICE_TYPE_PINPAD:
                return readPinpad(timeout);
            case DEVICE_TYPE_PRINTER:
                return readPrinter(timeout);
            case DEVICE_TYPE_PASSPORT_READER:
                return readPassportReader();
            case DEVICE_TYPE_BARCODE_READER:
                return readBarcodeReader(timeout);
            case DEVICE_TYPE_SERIALTEST:
                return readSerialTest(timeout);
            case DEVICE_TYPE_SIGNPAD:
                return readSignpad(timeout);
            case DEVICE_TYPE_EMCRW:
                return readPinpad(timeout);
            case DEVICE_TYPE_UNKNOWN:
            default:
                break;
        }
        return null;
    }

    /**
     * データ読み出し(Pinpad)の完了を確認
     * 
     * @param buffer 読み出し中のバッファ
     * @param length 読み出し中のバッファサイズ
     * @return 読み出しが完了したか
     */
    private boolean isReadEndPinpad(byte[] buffer, int length) {

        if (length <= PinpadDefine.INDEX_LEN_2) {
            // データ長の位置まで読み込みが済んでいない
            return false;
        }

        byte low = buffer[PinpadDefine.INDEX_LEN_1];
        byte high = buffer[PinpadDefine.INDEX_LEN_2];
        int len = CalcUtil.toInt(low, high) + PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER;
        if (length < len) {
            // データの終端まで読み込みが済んでいない
            return false;
        }

        return true;
    }

    /**
     * データ読み出し(Pinpad)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    private byte[] readPinpad(int timeout) {
        byte[] buffer_total = new byte[1024];
        int length_total = 0;
        if (mConnection == null) {
            return null;
        }
        while (!isReadEndPinpad(buffer_total, length_total)) {
            byte[] buffer = new byte[1024];
            int length = mConnection.bulkTransfer(mUsbReadEndpoint, buffer, buffer.length, timeout);
            if (length < 0 || buffer_total.length < length_total + length) {
                // 受信エラー または 1024 のオーバーフロー
                return buffer_total;
            }
            System.arraycopy(buffer, 0, buffer_total, length_total, length);
            length_total += length;
        }
        return buffer_total;
    }

    /**
     * データ読み出し(Printer)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    private byte[] readPrinter(int timeout) {
        byte[] buffer = new byte[1024];

        if (mConnection == null) {
            return null;
        }
        int length = mConnection.bulkTransfer(mUsbReadEndpoint, buffer, buffer.length, timeout);

        if (length < 0) {
            return null;
        }

        byte[] ret = new byte[length];

        System.arraycopy(buffer, 0, ret, 0, length);

        String log = "";
        for (int i = 0; i < ret.length; i++) {
            log += (Integer.toHexString(ret[i] & 0xff) + " ");
        }
        mLoggingManager.d(TAG, "read data: " + log);
        return ret;
    }

    /**
     * データ読み出し(BarcodeReader)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     * @retval null 受信エラー
     */
    private byte[] readBarcodeReader(int timeout) {
        byte[] buffer = new byte[1024]; // 受信バッファ
        if (mConnection == null) {
            return null; // 受信エラー
        }
        int length = mConnection.bulkTransfer(mUsbReadEndpoint, buffer, buffer.length, timeout);
        if (length < 0) {
            return new byte[0]; // タイムアウト(受信データ無し)
        }
        mLoggingManager.d(
                TAG, "read data: " + CalcUtil.toHexString(CalcUtil.cutArray(buffer, length)));
        return CalcUtil.cutArray(buffer, length);
    }

    private byte[] readSerialTest(int timeout) {
        byte[] buffer = new byte[1088];
        int j = 0;
        // USBシリアルを使用する場合、最低でも500msecは保証する
        try {
            Thread.sleep(100); // 100ミリ秒Sleepする
        } catch (InterruptedException e) {
        }
        int lnum = ((int) (timeout / 100) < 5) ? 4 : (timeout / 100) - 1;
        boolean flag = false;
        for (int loop = 0; loop < lnum; loop++) {
            if (mConnection == null) {
                return null;
            }
            mConnection.bulkTransfer(mUsbReadEndpoint, buffer, buffer.length, 100);
            for (j = 0; j < 5; j++) {
                if (buffer[j] == 0x02) { // STX
                    if (PRINTER) {
                        flag = true;
                        break;
                    } else if ((buffer[j + 1] == 0x07)) {
                        // ID一致 (Pinpad)
                        flag = true;
                        break;
                    } else if ((buffer[j + 1] == 0x03)) {
                        // ID一致 (Emcrw)
                        flag = true;
                        break;
                    }

                }
            }
            if (flag) {
                break;
            }
        }

        // length取得
        int com_length;
        if (PRINTER) {
            com_length = ((int) buffer[j + 8] & 0xFF) + (((int) buffer[j + 9] & 0xFF) << 8) + 12;
        } else {
            com_length = ((int) buffer[j + 4] & 0xFF) + (((int) buffer[j + 5] & 0xFF) << 8) + 9;
        }
        byte[] command = new byte[com_length];
        // mLoggingManager.d(TAG, "length:" + com_length);
        if (com_length <= 62) {
            // bufferをトリミング
            System.arraycopy(buffer, j, command, 0, com_length);
        } else {// TODO 64Byte毎のデータ取得
            int cut = com_length / 62;
            int remainder = com_length % 62;
            for (int i = 0; i < cut; i++) {
                // 厳密に1024バイトのコマンド取得は現状不可
                mLoggingManager.d(TAG, "ArrayCopy " + i);
                System.arraycopy(buffer, j + (64 * i), command, 62 * i, 62);
            }
            if (remainder != 0) {
                // 最終のバッファを取得
                mLoggingManager.d(TAG, "ArrayCopy devide cut:" + cut + ",remainder:" + remainder);
                System.arraycopy(buffer, j + (64 * cut), command, 62 * cut, remainder);
            }
        }
        String log = "";
        for (int i = 0; i < command.length; i++) {
            log += " " + (CalcUtil.byte2hex(command[i]));
        }
        mLoggingManager.d(TAG, "read data:" + log);
        return command;
    }

    /**
     * データ読み出し(PassportReader)
     * 
     * @return 読みだしたデータ
     */
    private byte[] readPassportReader() {

        if (mPassportDataReadThread.mRunning != true) {
            mPassportDataReadThread.start();
        }

        return null;
    }

    /**
     * データ読み出し(Emcrw)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    @Override
    public byte[] read(byte[] buffer, int timeout) {
        if (DevCtlServiceDefine.SERIAL) {
            return readSerialTest(timeout);
        } else {
            return readEmcrw(buffer, timeout);
        }
    }

    /**
     * データ読み出し(Emcrw)
     * 
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    private byte[] readEmcrw(byte[] buffer, int timeout) {
        byte[] buf = new byte[buffer.length];

        if (mConnection == null) {
            return null;
        }

        int read_length = 0;
        int total_length = 0;
        int data_length = -1;

        while (true) {
            byte[] data = new byte[buf.length];
            read_length = mConnection.bulkTransfer(mUsbReadEndpoint, data, data.length, timeout);
            // read_length = readBulkTransfer(data, timeout);
            if (read_length <= 0) {
                break;
            }
            System.arraycopy(data, 0, buf, total_length, read_length);
            total_length += read_length;

            if (data_length < 0 && total_length > 6) {
                data_length = CalcUtil.toInt(buf[4], buf[5]);
            }

            if (data_length >= 0
                    && (total_length >= (data_length + EmcrwDefine.DATA_SIZE_WITHOUT_PARAMETER))) {
                if (total_length < buf.length) {
                    byte[] response = new byte[total_length];
                    System.arraycopy(buf, 0, response, 0, total_length);
                    buf = response;
                }
                break;
            }

        }
        return buf;
    }

    protected int readBulkTransfer(byte[] buffer, int timeout) {
        return mConnection.bulkTransfer(mUsbReadEndpoint, buffer, buffer.length, timeout);
    }

    /**
     * @brief Signpadから座標データを読み取る
     * @param timeout
     * @return
     */
    private byte[] readSignpad(int timeout) {

        if (mConnection == null) {
            Log.d(TAG, "ERROR: mConnection is null");
            return null;
        }

        if (mUsbReadEndpoint == null) {
            Log.d(TAG, "ERROR: mUsbReadEndpoint is null");
            return null;
        }

        byte[] buffer = new byte[7];

        int res = mConnection.bulkTransfer(mUsbReadEndpoint, buffer, buffer.length, timeout);

        if (res < 0) {
            // timeoutしたらここへ来る
            return null;
        }
        return buffer;
    }

    // byte列をダンプする // あとで消す
    public String dumpBytes(byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        StringBuilder buf = new StringBuilder(bytes.length * 3);
        for (int i = 0; i < bytes.length; i++) {
            int d = bytes[i];
            if (d < 0) {
                // byte型では128～255が負値になっているので補正
                d += 256;
            }
            if (d < 16) {
                // 0～15は16進数で1けたになるので、2けたになるよう頭に0を追加
                buf.append("0");
            }
            // 1バイトを16進数2けたで表示
            buf.append(Integer.toString(d, 16));
            buf.append(" ");
        }
        return buf.toString();
    }

    /**
     * @see DeviceController#init()
     */
    @Override
    public synchronized boolean init() {

        if (mContext == null) {
            return false;
        }

        mUsbManager = (UsbManager) mContext.getSystemService(Context.USB_SERVICE);

        if (mUsbManager == null) {
            return false;
        }

        PendingIntent permissionIntent = PendingIntent.getBroadcast(mContext, 0, new Intent(
                UsbDeviceReceiver.ACTION_USB_PERMISSION), 0);
        if (permissionIntent == null) {
            return false;
        }
        
        HashMap<String, UsbDevice> deviceList = mUsbManager.getDeviceList();
        if (deviceList == null) {
            return false;
        }

        mUsbDevice = null;

        for (UsbDevice d : deviceList.values()) {
            d.getVendorId();
            if (d.getVendorId() == mVendorId && d.getProductId() == mProductId) {
                mUsbDevice = d;
                break;
            }
        }

        if (mUsbDevice != null) {
            mUsbManager.requestPermission(mUsbDevice, permissionIntent);
        } else {
            return false;
        }

        mLockCounter = 0;
        mUSBLocked = false;

        return true;
    }

    /**
     * @see DeviceController#init()
     */
    @Override
    public boolean init(UsbDevice device) {
        if (mUsbDevice == null) {
            return init();
        } else {
            return false;
        }
    }

    /**
     * @see DeviceController#term()
     */
    @Override
    public synchronized boolean term(UsbDevice device) {
        if (mConnection == null) {
            return false;
        }

        if (mUsbDevice == null || !mUsbDevice.equals(device)) {
            return false;
        }

        mActive = false;
        if (mInterruptThread != null) {
            mInterruptThread = null;
        }

        if (mUsbControlInterface != null) {
            mConnection.releaseInterface(mUsbControlInterface);
        }
        if (mUsbCDCInterface != null) {
            mConnection.releaseInterface(mUsbCDCInterface);
        }
        if (mUsbSrlInterface != null) {
            mConnection.releaseInterface(mUsbSrlInterface);
        }
        mConnection.close();
        mConnection = null;
        mUsbDevice = null;
        return true;
    }

    /**
     * @brief DTRをカーネルに設定を施す
     * @param DTRを設定するかどうか
     * @return 設定できたかどうか
     */
    private int setDTR(boolean dtr) {
        if (mConnection == null) {
            return -1;
        }
        return mConnection.controlTransfer(USB_RT_ACM, SET_CONTROL_LINE_STATE, dtr ? 0x01 : 0x00,
                0, null, 0, 500);
    }

    /**
     * @brief RTSをカーネルに設定を施す
     * @param RTSを設定するかどうか
     * @return 設定できたかどうか
     */
    private int setRTS(boolean rts) {
        if (mConnection == null) {
            return -1;
        }
        return mConnection.controlTransfer(USB_RT_ACM, SET_CONTROL_LINE_STATE, rts ? 0x02 : 0x00,
                0, null, 0, 500);
    }

    /**
     * @see DeviceController#connect(UsbDevice)
     */
    @Override
    public boolean connect(UsbDevice device) {
        if (mConnection != null) {
            return false;
        }

        if (device == null || device.getVendorId() != mVendorId || device.getProductId() != mProductId) {
            return false;
        }

        boolean ret = false;
        mUsbDevice = device;
        mConnection = mUsbManager.openDevice(device);
        if (mConnection == null) {
            mUsbDevice = null;
            return false;
        }

        if (device.getProductId() == 0x0ebe && device.getVendorId() == 0x04da) {
            mLoggingManager.d(TAG, "Pinpad");
            mDeviceType = DEVICE_TYPE_PINPAD;
            ret = connectPinpadDevice(device);
        } else if (device.getProductId() == 0x5740 && device.getVendorId() == 0x0483) {
            mLoggingManager.d(TAG, "Printer");
            mDeviceType = DEVICE_TYPE_PRINTER;
            ret = connectPrinterDevice(device);
        } else if (device.getProductId() == PassportReaderDefine.PID
                && device.getVendorId() == PassportReaderDefine.VID) {
            mLoggingManager.d(TAG, "OCR316E PassportReader");
            mDeviceType = DEVICE_TYPE_PASSPORT_READER;
            ret = connectPassportReaderDevice(device);
        } else if (device.getProductId() == BarcodeReaderDefine.PID_M_10
                && device.getVendorId() == BarcodeReaderDefine.VID) {
            mLoggingManager.d(TAG, "M-10 BarcodeReader");
            mDeviceType = DEVICE_TYPE_BARCODE_READER;
            ret = connectBarcodeReaderDevice(device);
        } else if (device.getProductId() ==
                BarcodeReaderDefine.PID_C_40_C_41
                && device.getVendorId() == BarcodeReaderDefine.VID) {
            mLoggingManager.d(TAG, "C-40/41 BarcodeReader");
            mDeviceType = DEVICE_TYPE_BARCODE_READER;
            ret = connectBarcodeReaderDevice(device);
        } else if (device.getProductId() == 0x6001 && device.getVendorId() == 0x0403) {
            mLoggingManager.d(TAG, "Serial Test Device connect try");
            mDeviceType = DEVICE_TYPE_SERIALTEST;
            ret = connectSerialtestDevice(device);
        } else if (device.getProductId() == SignpadDefine.PID_STU_430
                && device.getVendorId() == SignpadDefine.VID) {
            mLoggingManager.d(TAG, "STU-430");
            mDeviceType = DEVICE_TYPE_SIGNPAD;
            ret = connectSignpadDevice(device);
        } else if (device.getProductId() == SignpadDefine.PID_STU_530
                && device.getVendorId() == SignpadDefine.VID) {
            mLoggingManager.d(TAG, "STU-530");
            mDeviceType = DEVICE_TYPE_SIGNPAD;
            ret = connectSignpadDevice(device);
        } else if (device.getProductId() == EmcrwDefine.PID_JT_R500CR
                && device.getVendorId() == EmcrwDefine.VID) {
            mLoggingManager.d(TAG, "JT-R550CR");
            mDeviceType = DEVICE_TYPE_EMCRW;
            ret = connectEmcrwDevice(device);
        } else if (device.getProductId() == EmcrwDefine.PID_JT_R500CR_41
                && device.getVendorId() == EmcrwDefine.VID) {
            mLoggingManager.d(TAG, "JT-R550CR-41");
            mDeviceType = DEVICE_TYPE_EMCRW;
            ret = connectEmcrwDevice(device);
        } else {
            ret = false;
        }

        if (!ret) {
            mConnection.close();
            mConnection = null;
            mUsbDevice = null;
        }

        return ret;
    }

    /**
     * USBデバイスとの接続(Pinpad)
     * 
     * @param device USBデバイス
     * @return 接続できたかどうか
     */
    private boolean connectPinpadDevice(UsbDevice device) {
        int count = mUsbDevice.getInterfaceCount();
        mLoggingManager.d(TAG, "claiming interfaces, count : " + mUsbDevice.getInterfaceCount());

        if (count != 2) {
            // CommunicationsとCDCの２種類
            return false;
        }

        if (mUsbDevice.getDeviceClass() != UsbConstants.USB_CLASS_COMM) {
            // Not CDC device
            mLoggingManager.d(TAG, "Not CDC device : " + mUsbDevice.getDeviceClass());
            return false;
        }
        
        if (mUsbDevice.getInterfaceCount() < 2) {
            // UsbInterface の数を確認
            return false;
        }

        mUsbControlInterface = mUsbDevice.getInterface(0);
        mLoggingManager.d(TAG, "mUsbControlInterface : " + mUsbControlInterface);

        mUsbCDCInterface = mUsbDevice.getInterface(1);
        mLoggingManager.d(TAG, "mUsbCDCInterface : " + mUsbCDCInterface);

        if (!mConnection.claimInterface(mUsbControlInterface, true)) {
            mLoggingManager.d(TAG, "claimInterface error mUsbControlInterface");
            return false;
        }

        if (!mConnection.claimInterface(mUsbCDCInterface, true)) {
            mLoggingManager.d(TAG, "claimInterface error mUsbCDCInterface");
            return false;
        }

        mLoggingManager.d(TAG, "getEndpointCount : " + mUsbCDCInterface.getEndpointCount());
        if (mUsbCDCInterface.getEndpointCount() < 2) {
            // UsbEndpoint の数を確認
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            UsbEndpoint ep = mUsbCDCInterface.getEndpoint(i);
            if (ep.getDirection() == UsbConstants.USB_DIR_IN) {
                mUsbReadEndpoint = ep;
            } else {
                mUsbWriteEndpoint = ep;
            }
        }

        if (mUsbReadEndpoint == null || mUsbWriteEndpoint == null) {
            if (mUsbWriteEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbWriteEndpoint error");
            }

            if (mUsbReadEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbReadEndpoint error");
            }
            return false;
        }

        setDTR(true);

        RequestDeviceInformation rps = new RequestDeviceInformation();
        if (write(rps.toCommand(), PluginDefine.PINPAD_DEFAULT_WRITE_TIMEOUT)) {
            read(5000);
        }

        return true;
    }

    /**
     * USBデバイスとの接続(Serial)
     * 
     * @param device USBデバイス
     * @return 接続できたかどうか
     */
    private boolean connectSerialtestDevice(UsbDevice device) {
        mLoggingManager.d(TAG, "claiming interfaces, count : " + mUsbDevice.getInterfaceCount());

        if (mUsbDevice.getInterfaceCount() < 1) {
            // UsbInterface の数を確認
            return false;
        }
        mUsbSrlInterface = mUsbDevice.getInterface(0);

        mConnection.claimInterface(mUsbSrlInterface, true);

        if (mUsbSrlInterface.getEndpointCount() < 2) {
            // UsbEndpoint の数を確認
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            UsbEndpoint ep = mUsbSrlInterface.getEndpoint(i);
            mLoggingManager.d(TAG, "Endpoint :" + ep.getType());
            switch (ep.getType()) {
                case UsbConstants.USB_ENDPOINT_XFER_BULK:
                    mLoggingManager.d(TAG, "Endpoint Bulk");
                    if (ep.getDirection() == UsbConstants.USB_DIR_IN) {
                        mUsbReadEndpoint = ep;
                    } else {
                        mUsbWriteEndpoint = ep;
                    }
                    break;
                case UsbConstants.USB_ENDPOINT_XFER_CONTROL:
                case UsbConstants.USB_ENDPOINT_XFER_INT:
                case UsbConstants.USB_ENDPOINT_XFER_ISOC:
                    break;
            }
        }

        if (mUsbReadEndpoint == null || mUsbWriteEndpoint == null) {
            if (mUsbWriteEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbWriteEndpoint error");
            }

            if (mUsbReadEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbReadEndpoint error");
            }
            return false;
        }
        mLoggingManager.d(TAG, "USB Write Endpoint: " + mUsbWriteEndpoint);
        mLoggingManager.d(TAG, "USB Read  Endpoint: " + mUsbReadEndpoint);
        setDTR(true);
        setSerialTestDeviceParameter();

        return true;
    }

    /**
     * シリアルテスト用パラメータ設定
     */
    private void setSerialTestDeviceParameter() {
        int counter = 0;

        if (mConnection == null) {
            return;
        }
        counter += mConnection.controlTransfer(0x40, 0x00, 0x0000, 0, null, 0, 0); // reset
        counter += mConnection.controlTransfer(0x40, 0x00, 0x0001, 0, null, 0, 0); // clear
        // Rx
        counter += mConnection.controlTransfer(0x40, 0x00, 0x0002, 0, null, 0, 0); // clear
        // Tx
        counter += mConnection.controlTransfer(0x40, 0x02, 0x0000, 0, null, 0, 0); // flow
                                                                                   // control
                                                                                   // none
        counter += mConnection.controlTransfer(0x40, 0x03, 0x001A, 0, null, 0, 0); // baudrate
                                                                                   // 115200
        counter += mConnection.controlTransfer(0x40, 0x04, 0x0008, 0, null, 0, 0); // data
                                                                                   // bit8,
                                                                                   // parity
                                                                                   // none,
                                                                                   // stopbit
                                                                                   // 1,
                                                                                   // tx
                                                                                   // off
        mLoggingManager.d("Set Serial", "Parameter Setting Finish");

        if (counter != 0) {
            mLoggingManager.d("Set Serial", "Parameter Setting Failured");
        }
    }

    /**
     * USBデバイスとの接続(Printer)
     * 
     * @param device USBデバイス
     * @return 接続できたかどうか
     */
    private boolean connectPrinterDevice(UsbDevice device) {
        if (device.getInterfaceCount() < 2 || mUsbDevice.getInterfaceCount() < 2) {
            // UsbInterface の数を確認
            return false;
        }

        if (!mConnection.claimInterface(device.getInterface(0), true)) {
            return false;
        }

        if (!mConnection.claimInterface(device.getInterface(1), true)) {
            return false;
        }

        mUsbCDCInterface = mUsbDevice.getInterface(1);

        for (int i = 0; i < mUsbCDCInterface.getEndpointCount(); i++) {
            if (mUsbCDCInterface.getEndpoint(i).getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {

                if (mUsbCDCInterface.getEndpoint(i).getDirection() == UsbConstants.USB_DIR_IN) {
                    mUsbReadEndpoint = mUsbCDCInterface.getEndpoint(i);
                } else {
                    mUsbWriteEndpoint = mUsbCDCInterface.getEndpoint(i);
                }
            }
        }

        if (mUsbReadEndpoint == null || mUsbWriteEndpoint == null) {
            if (mUsbWriteEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbWriteEndpoint error");
            }

            if (mUsbReadEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbReadEndpoint error");
            }
            return false;
        }

        return true;
    }

    /**
     * USBデバイスとの接続(PassportReader)
     * 
     * @param device USBデバイス
     * @return 接続できたかどうか
     */
    private boolean connectPassportReaderDevice(UsbDevice device) {

        if (device.getInterfaceCount() < 1) {
            // UsbInterface の数を確認
            return false;
        }
        mUsbControlInterface = device.getInterface(0x00);

        if (mUsbControlInterface.getEndpointCount() != 1) {
            mLoggingManager.e(TAG, "Error: Connected PassportReader is not OCR316E");
            return false;
        } else {
            mUsbReadEndpoint = mUsbControlInterface.getEndpoint(0);
        }

        if (mUsbReadEndpoint == null) {
            mLoggingManager.e(TAG, "Error: Failed to get Endpoint");
            return false;
        }

        if (mUsbReadEndpoint.getType() == UsbConstants.USB_ENDPOINT_XFER_INT) {
            if (mUsbReadEndpoint.getDirection() != UsbConstants.USB_DIR_IN) {
                mLoggingManager.e(TAG, "USB Endpoint failure");
                return false;
            }
        }

        mConnection.claimInterface(mUsbControlInterface, true);

        boolean ret = setPassportReaderDeviceParameter();

        return ret;

    }

    private boolean connectSignpadDevice(UsbDevice device) {

        boolean ret = false;

        for (int i = 0; i < device.getInterfaceCount(); i++) {
            mUsbControlInterface = device.getInterface(i);
            for (int j = 0; j < mUsbControlInterface.getEndpointCount(); j++) {
                UsbEndpoint ep = mUsbControlInterface.getEndpoint(j);
                switch (ep.getType()) {
                    case UsbConstants.USB_CLASS_HID:
                        if (ep.getDirection() == UsbConstants.USB_DIR_IN) {
                            mUsbReadEndpoint = ep;
                            mConnection.claimInterface(mUsbControlInterface, true);
                        }

                        ret = true;

                        break;
                    default:
                        break;
                }
            }
        }

        return ret;
    }

    private void sendCommand(int control) {
        synchronized (this) {
            if (mConnection != null) {
                byte[] message = new byte[1];
                message[0] = (byte) control;
                // Send command via a control request on endpoint zero
                if (mConnection.controlTransfer(0x21, 0x9, 0x200, 0, message, message.length, 0) > 0) {
                    Log.d(TAG, "Sending Failed");
                }
            }
        }
    }

    /**
     * USBデバイスとの接続(PassportReader)
     * 
     * @param device USBデバイス
     * @return 接続できたかどうか
     */
    private boolean connectEmcrwDevice(UsbDevice device) {

        int count = mUsbDevice.getInterfaceCount();
        Log.d(TAG, "claiming interfaces, count: " + count);

        if (count != 2) {
            // CommunicationsとCDCの2種類っぽい
            return false;
        }

        if (mUsbDevice.getDeviceClass() != UsbConstants.USB_CLASS_COMM) {
            // CDC deviceじゃないっぽい
            Log.d(TAG,
                    "Connected device was not CDC device: "
                            + mUsbDevice.getDeviceClass());
            return false;
        }

        mUsbControlInterface = mUsbDevice.getInterface(0);
        Log.d(TAG, "mUsbControlInterface: " + mUsbControlInterface);

        mUsbCDCInterface = mUsbDevice.getInterface(1);
        Log.d(TAG, "mUsbCDCInterface: " + mUsbCDCInterface);

        if (!mConnection.claimInterface(mUsbControlInterface, true)) {
            Log.d(TAG, "claimInterface Error on mUsbControlInterface");
            return false;
        }

        for (int i = 0; i < device.getInterfaceCount(); i++) {

            UsbInterface ui = device.getInterface(i);
            for (int j = 0; j < ui.getEndpointCount(); j++) {

                UsbEndpoint endPoint = ui.getEndpoint(j);

                switch (endPoint.getType()) {

                    case UsbConstants.USB_ENDPOINT_XFER_BULK:
                        break;
                    case UsbConstants.USB_ENDPOINT_XFER_CONTROL:
                        break;
                    case UsbConstants.USB_ENDPOINT_XFER_INT:
                        mUsbInterruptndpoint = endPoint;

                        if (mConnection.claimInterface(ui, true)) {

                            if (mInterruptThread == null) {

                                mInterruptThread = new Thread() {
                                    @Override
                                    public void run() {
                                        UsbRequest request = new UsbRequest();
                                        request.initialize(mConnection, mUsbInterruptndpoint);
                                        byte status = -1;
                                        ByteBuffer buffer = ByteBuffer
                                                .allocate(mUsbInterruptndpoint
                                                        .getMaxPacketSize());

                                        while (mActive) {
                                            request.queue(buffer,
                                                    mUsbInterruptndpoint.getMaxPacketSize());

                                            // wait for status event
                                            if (mConnection != null) {

                                                if (mConnection.requestWait() == request) {
                                                    byte newStatus = buffer.get(0);
                                                    request.getClientData();
                                                    if (newStatus != status) {
                                                        status = newStatus;
                                                        sendCommand(7);
                                                    }

                                                } else {
                                                    try {
                                                        Thread.sleep(10);
                                                    } catch (InterruptedException e) {
                                                    }
                                                }
                                            }

                                        }
                                    }
                                };
                                mActive = true;

                                if (mEnableRTS) {
                                    mInterruptThread.start();
                                }
                            }

                        }
                        break;
                    case UsbConstants.USB_ENDPOINT_XFER_ISOC:
                        break;

                }

            }

        }

        Log.d(TAG, "EndpointCount: " + mUsbCDCInterface.getEndpointCount());
        if (mUsbCDCInterface.getEndpointCount() < 2) {
            // UsbEndpoint の数を確認
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            UsbEndpoint ep = mUsbCDCInterface.getEndpoint(i);
            if (ep.getDirection() == UsbConstants.USB_DIR_IN) {
                mUsbReadEndpoint = ep;
                Log.d(TAG, "mUsbReadEndpoint added");
            } else {
                mUsbWriteEndpoint = ep;
                Log.d(TAG, "mUsbWriteEndpoint added");
            }
        }

        if (mUsbReadEndpoint == null) {
            Log.d(TAG, "mUsbReadEndpoint Error");
            return false;
        }
        if (mUsbWriteEndpoint == null) {
            Log.d(TAG, "mUsbWriteEndpoint Error");
            return false;
        }
        if (mEnableRTS) {
            setRTS(true);
        }
        return true;
    }

    /**
     * USBデバイスとの接続(BarcodeReader)
     * 
     * @param device USBデバイス
     * @return 接続できたかどうか
     */
    private boolean connectBarcodeReaderDevice(UsbDevice device) {

        int count = mUsbDevice.getInterfaceCount();
        mLoggingManager.d(TAG, "claiming interfaces, count : " + mUsbDevice.getInterfaceCount());

        // CommunicationsとCDCの２種類
        mUsbControlInterface = null;
        mUsbCDCInterface = null;
        for (int i = 0; i < count; i++) {
            UsbInterface usbif = mUsbDevice.getInterface(i);
            switch (usbif.getInterfaceClass()) {
                case UsbConstants.USB_CLASS_COMM:
                    mUsbControlInterface = usbif;
                    mLoggingManager.d(TAG, "mUsbControlInterface : " + mUsbControlInterface);
                    break;
                case UsbConstants.USB_CLASS_CDC_DATA:
                    mUsbCDCInterface = usbif;
                    mLoggingManager.d(TAG, "mUsbCDCInterface : " + mUsbCDCInterface);
                    break;

                default:
                    break;
            }
        }

        if (mUsbControlInterface == null || mUsbCDCInterface == null) {
            // Not CDC device
            mLoggingManager.d(TAG, "Not CDC device : " + mUsbDevice.getDeviceClass());
            return false;
        }

        if (!mConnection.claimInterface(mUsbControlInterface, true)) {
            mLoggingManager.d(TAG, "claimInterface error mUsbControlInterface");
            return false;
        }

        if (!mConnection.claimInterface(mUsbCDCInterface, true)) {
            mLoggingManager.d(TAG, "claimInterface error mUsbCDCInterface");
            return false;
        }

        mLoggingManager.d(TAG, "getEndpointCount : " + mUsbCDCInterface.getEndpointCount());
        if (mUsbCDCInterface.getEndpointCount() < 2) {
            // UsbEndpoint の数を確認
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            UsbEndpoint ep = mUsbCDCInterface.getEndpoint(i);
            if (ep.getDirection() == UsbConstants.USB_DIR_IN) {
                mUsbReadEndpoint = ep;
            } else {
                mUsbWriteEndpoint = ep;
            }
        }

        if (mUsbReadEndpoint == null || mUsbWriteEndpoint == null) {
            if (mUsbWriteEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbWriteEndpoint error");
            }

            if (mUsbReadEndpoint == null) {
                mLoggingManager.e(TAG, "mUsbReadEndpoint error");
            }
            return false;
        }

        setDTR(true);

        return true;
    }

    /**
     * @see UsbDeviceController#disconnect()
     */
    @Override
    public boolean disconnect() {
        return false;
    }

    /**
     * パスポートリーダー用パラメータ設定
     * 
     * @return 設定できたかどうか
     */
    private boolean setPassportReaderDeviceParameter() {

        boolean ret = false;

        byte[] DataToSend = new byte[2];
        DataToSend[0] = (byte) 0x00;
        DataToSend[1] = (byte) 0x80;

        int bufferDataLength = 8;
        byte[] buffer = new byte[bufferDataLength];

        if ((DataToSend[0] != (byte) 0x00) && ((DataToSend[1] & 0x80) > 0)) {
            for (int i = 0; i < bufferDataLength; i++) {
                buffer[i] = DataToSend[i + 1];
            }
        } else {
            buffer[0] = (byte) (0x80 + DataToSend.length);
            if (DataToSend.length < (bufferDataLength - 1)) {
                bufferDataLength = DataToSend.length + 1;
            }
            for (int i = 1; i < bufferDataLength; i++) {
                buffer[i] = DataToSend[i - 1];
            }
        }
        if (mConnection == null) {
            return false;
        }
        int transfer = mConnection.controlTransfer(0x21, 0x09, 0x0200, 0x00, buffer, buffer.length,
                0);

        if (transfer >= 0) {
            mLoggingManager.d(TAG, "controlTransfer succeeded");
            ret = true;
        } else {
            mLoggingManager.e(TAG, "controlTransfer failed status: " + transfer);
            ret = false;
        }
        return ret;
    }

    /**
     * @brief 接続デバイスのベンダーIDを取得する
     * @return ベンダーID
     */
    public int getVendorId() {
        return mVendorId;
    }

    /**
     * @brief 接続デバイスのベンダーIDを設定する
     * @param venderId ベンダーID
     */
    public void setVendorId(int venderId) {
        mVendorId = venderId;
    }

    /**
     * @brief 接続デバイスのプロダクトIDを取得する
     * @return プロダクトID
     */
    public int getProductId() {
        return mProductId;
    }

    /**
     * @brief 接続デバイスのプロダクトIDを設定する
     * @param productId プロダクトID
     */
    public void setProductId(int productId) {
        mProductId = productId;
    }

    /**
     * @brief Thread
     */
    class PassportDataReadThread extends Thread {

        private boolean mRunning = false;
        private boolean mTerminated = false;
        private String mBuffer = "";
        private static final String OCR_SUFFIX = "031d";
        private static final String MSR_SUFFIX = "030f";

        /**
         * @see Thread#run()
         */
        @Override
        public void run() {

            // Log.d(TAG, "[PassportDataReadThread] run start");

            while (!mTerminated) {
                mRunning = true;
                int packetSize = mUsbReadEndpoint.getMaxPacketSize();
                ByteBuffer buffer = ByteBuffer.allocate(packetSize);
                buffer.clear();

                if (mConnection == null) {
                    return;
                }

                UsbRequest request = new UsbRequest();
                request.initialize(mConnection, mUsbReadEndpoint);
                request.queue(buffer, packetSize);
                if (request.equals(mConnection.requestWait())) {

                    byte[] byteArray = new byte[packetSize + 1];
                    buffer.rewind();
                    buffer.get(byteArray, 0, packetSize);
                    String readData = "";
                    for (int i = 0; i < packetSize; i++) {
                        readData += String.format("%02x", byteArray[i]);
                    }
                    // Log.d(TAG, "[PassportDataReadThread] read data: " +
                    // readData);

                    if (readData.equals("0000000000000000")) {
                        // Log.d(TAG,
                        // "[PassportDataReadThread] read data error. Thread terminate.");
                        mTerminated = true;
                    }

                    mBuffer += parsePacket(readData);
                    if (mBuffer.endsWith(OCR_SUFFIX) || mBuffer.endsWith(MSR_SUFFIX)) {

                        if (pprDataListener == null) {
                            // Log.d(TAG,
                            // "[PassportDataReadThread] pprDataListener is null");
                            mBuffer = "";
                            continue;
                        }

                        try {
                            synchronized (this) {
                                pprDataListener.sendPprData(mBuffer);
                            }
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                        // Log.d(TAG, "[PassportDataReadThread] " + mBuffer);
                        mBuffer = "";
                    }
                } else {
                    // deviceがUSBからdisconnectされて(ACTION_USB_DEVICE_DETACHEDが通知されて)
                    // mConnection.requestWait()がnullで返される場合を想定。
                    // requestとconnectionをclose()し、強制的にスレッドをTerminateする。
                    // 再度deviceをconnectした場合、InitPPR()からのやり直しで再開できる。
                    // connect時に初期化が自動で再実行され、BindServiceは先に完了済なので動作する。
                    // ACTION_USB_DEVICE_DETACHEDの時にmConnection.close()するのでここではrequestのみclose()する。
                    request.close();
                    return;
                }
            }
            mRunning = false;
            mTerminated = false;
            return;
        }

        /**
         * パケット分解
         * 
         * @param readData データ
         * @return 分解後データ
         */
        private String parsePacket(String readData) {

            /*
             * OCR316Eで読み取れるデータは8バイト長のバイト列
             * 1バイトを2文字のStringで表す仕様なので、Stringに変換すると16文字。
             * Stringの0番目はパケットのバイト長、Stringの1番目はパケットの有効バイト長（ペイロード長）になっている模様。
             * （受領したドキュメントに解説がないので推定）
             */

            int dataLength = Integer.valueOf(readData.substring(0, 1));
            int validLength = Integer.valueOf(readData.substring(1, 2));
            readData = readData.substring(2, 2 + validLength * 2);

            return readData;

        }
    }

    /**
     * パスポートリーダコールバック用リスナーを設定する
     * 
     * @param listener リスナー
     */
    public void setPprDataListener(IPprDataListener listener) {
        synchronized (this) {
            pprDataListener = listener;
        }
    }

    /**
     * パスポートリーダコールバック用リスナーを削除する
     * 
     * @param listener リスナー
     */
    public void removePprDataListener(IPprDataListener listener) {
        synchronized (this) {
            pprDataListener = null;
        }
    }

    /**
     * @brief サインパッドデータ
     */
    public void setSpadDataListener(SignpadDataListener listener) {
        Log.d(TAG, "setSpadDataListener");
        synchronized (this) {
            spadDataListener = listener;
        }
    }

    public void removeSpadDataListener(SignpadDataListener listener) {
        synchronized (this) {
            spadDataListener = null;
        }
    }

    /**
     * 管理クラス取得
     * 
     * @return 管理クラス
     */
    public UsbDeviceManager getManager() {
        return mManager;
    }

    /**
     * 管理クラス設定
     * 
     * @param manager 管理クラス
     */
    public void setManager(UsbDeviceManager manager) {
        this.mManager = manager;
        setUsbDeviceListener();
    }

    /**
     * USBデバイス用リスナー設定
     */
    private void setUsbDeviceListener() {
        mManager.registerOnUsbDeviceListener(mOnUsbDeviceListener);
    }

    /**
     * @see UsbDeviceController#isActive()
     */
    public synchronized boolean isActive() {
        if (mContext == null || mUsbManager == null || mConnection == null) {
            return false;
        }

        HashMap<String, UsbDevice> deviceList = mUsbManager.getDeviceList();
        if (deviceList == null) {
            return false;
        }

        for (UsbDevice d : deviceList.values()) {
            if (d.getVendorId() == mVendorId && d.getProductId() == mProductId) {
                return true;
            }
        }
        return false;
    }

    /** @brief USBの状態監視用リスナー */
    private OnUsbDeviceListener mOnUsbDeviceListener = new OnUsbDeviceListener() {

        /**
         * @see OnUsbDeviceListener#onConnected(UsbDevice)
         */
        @Override
        public void onConnected(UsbDevice device) {
            if (device.getVendorId() == mVendorId && device.getProductId() == mProductId) {
                if (device.getVendorId() == PassportReaderDefine.VID
                        && device.getProductId() == PassportReaderDefine.PID) {
                    // PassportDataReadThreadを作りなおす
                    if (mPassportDataReadThread != null) {
                        mPassportDataReadThread = null;
                    }
                    mPassportDataReadThread = new PassportDataReadThread();
                }
                init(device);
            }
        }

        /**
         * @see OnUsbDeviceListener#onDisconnected(UsbDevice)
         */
        @Override
        public void onDisconnected(UsbDevice device) {
            if (device.getVendorId() == mVendorId && device.getProductId() == mProductId) {
                if (device.getVendorId() == PassportReaderDefine.VID
                        && device.getProductId() == PassportReaderDefine.PID) {
                    if (mPassportDataReadThread != null) {
                        mPassportDataReadThread = null;
                    }
                }
                if (term(device)) {
                    ArrayList<NotifyUsbDeviceConnectionListener> list = mManager.mNotifyUsbDeviceConnectionListenerList;
                    synchronized (list) {
                        for (NotifyUsbDeviceConnectionListener listener : list) {
                            listener.onClosed(device);
                        }
                    }
                }
            }
        }
    };

    /** @brief USBデバイスロック用 */
    private Object mUSBLock = new Object();

    /** @brief USBデバイスロックカウンタ */
    private int mLockCounter = 0;

    /** @brief */
    private boolean mUSBLocked = false;

    @Override
    public void lock() {
        synchronized (mUSBLock) {
            mLockCounter++;
            mUSBLocked = true;
        }
        return;
    }

    @Override
    public void unlock() {
        synchronized (mUSBLock) {
            if (mLockCounter > 0) {
                mLockCounter--;
            }
            if (mLockCounter == 0) {
                mUSBLocked = false;
            }
        }
        return;
    }

    @Override
    public void clearLock() {
        synchronized (mUSBLock) {
            mLockCounter = 0;
            mUSBLocked = false;
        }
        return;
    };

    @Override
    public boolean isLocked() {
        boolean ret = false;
        synchronized (mUSBLock) {
            ret = mUSBLocked;
        }
        return ret;
    }

    @Override
    public Object getLockObject() {
        return mUSBLock;
    }

}
