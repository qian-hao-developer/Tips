package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

/**
 * PFダウンロードの開始Responseクラス.
 * 
 */
public class PFDownloadStartResponse extends BaseDownloadStartResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = PFDownloadStartResponse.class.getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0xC0;

    /** Constructor */
    public PFDownloadStartResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}

