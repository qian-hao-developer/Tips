package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;


/**
 * APの強制アンインストールクラス
 * 
 */
public class APUninstallForceRequest extends BaseRequest {

    /** ログ用タグ */
    private static final String TAG = APUninstallForceRequest.class.getSimpleName();

    /** MC */
    private static byte MAINCOMMAND = (byte) 0x25;
    /** SC */
    private static byte SUBCOMMAND = (byte) 0x31;

	/** AP-ID . */
    private byte mApId;
	
    /**
     * AP-IDを設定する.
     * 
     * @param apId AP-ID
     */
    public void setApId(byte apId) {
        mApId = apId;
    }

    /** Constructor */
    public APUninstallForceRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // AP-ID:0x01~0xFD
        if (ByteUtil.checkTargetValueByte(mApId, (byte) 0x00, (byte) 0x00,
                (byte) 0xfe, (byte) 0xff)) {
            Logger.e(TAG, "isValidValue mApId unmatch =" + mApId);
            return false;
        }
        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return toCommand(new byte[] { mApId });
    }
}
