
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetUID extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetUID(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetUID() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetUID> CREATOR = new Parcelable.Creator<ResultGetUID>() {

        @Override
        public ResultGetUID createFromParcel(Parcel in) {
            return new ResultGetUID(in);
        }

        @Override
        public ResultGetUID[] newArray(int size) {
            return new ResultGetUID[size];
        }
    };
}
