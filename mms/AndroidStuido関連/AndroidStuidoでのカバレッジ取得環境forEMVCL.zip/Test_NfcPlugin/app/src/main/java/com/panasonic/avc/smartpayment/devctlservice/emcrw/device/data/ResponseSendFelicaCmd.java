
package com.panasonic.avc.smartpayment.devctlservice.emcrw.device.data;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * Felica Command応答
 */
public class ResponseSendFelicaCmd {

    private static final String TAG = "ResponseSendFelicaCmd";

    private int mEndCode;

    private int mEndSubCode;

    private int mCardResponsePacketLength;

    private String mCardResponsePacket;

    private final int INDEX_END_CODE = 1;
    private final int INDEX_END_SUB_CODE = 2;
    private final int INDEX_RESPONSE_LENGTH = 3;

    public boolean inputSendFelicaCmdResult(byte[] bytes) {

        if (bytes == null || bytes.length < INDEX_END_SUB_CODE) {
            return false;
        }

        byte[] buffer = new byte[bytes.length];
        System.arraycopy(bytes, 0, buffer, 0, bytes.length);

        setEndCode(CalcUtil.toInt(buffer[INDEX_END_CODE], (byte) 0x00));
        setEndSubCode(CalcUtil.toInt(buffer[INDEX_END_SUB_CODE], (byte) 0x00));

        if (buffer.length < 4) {
            return false;
        }

        byte length = buffer[INDEX_RESPONSE_LENGTH];

        if (length > 231) {
            return false;
        }

        mCardResponsePacketLength = CalcUtil.toInt(length, (byte) 0x00);

        byte[] data = new byte[0];
        if (mCardResponsePacketLength != 0) {
            data = new byte[mCardResponsePacketLength - 1];
            for (int i = 0; i < mCardResponsePacketLength - 1; i++) {
                data[i] = buffer[INDEX_RESPONSE_LENGTH + 1 + i];
            }
            setCardResponsePacket(CalcUtil.byte2hex(data));
        }

        return true;
    }

    public int getEndCode() {
        return mEndCode;
    }

    public void setEndCode(int mEndCode) {
        this.mEndCode = mEndCode;
    }

    public int getEndSubCode() {
        return mEndSubCode;
    }

    public void setEndSubCode(int mEndSubCode) {
        this.mEndSubCode = mEndSubCode;
    }

    public String getCardResponsePacket() {
        return mCardResponsePacket;
    }

    public void setCardResponsePacket(String mCardResponsePacket) {
        this.mCardResponsePacket = mCardResponsePacket;
    }

    public int getCardResponsePacketLength() {
        return mCardResponsePacketLength;
    }

    public void setCardResponsePacketLength(int mCardResponsePacketLength) {
        this.mCardResponsePacketLength = mCardResponsePacketLength;
    }
}
