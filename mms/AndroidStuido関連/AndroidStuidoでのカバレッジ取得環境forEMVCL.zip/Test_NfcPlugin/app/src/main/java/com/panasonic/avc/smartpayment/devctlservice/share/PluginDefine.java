
package com.panasonic.avc.smartpayment.devctlservice.share;

/**
 * プラグイン用定数クラス
 */
public class PluginDefine {

    /** @brief 正常 */
    public static final int RESULT_DEVICE_SCCESS = 0;

    /** @brief 正常 */
    public static final int RESULT_UPOS_SCCESS = 0;

    /** @brief ポート異常 */
    public static final int RESULT_UPOS_PORT_ERROR = 104;

    /** @brief パラメータ不正 */
    public static final int RESULT_UPOS_PRAMETER_ERROR = 106;

    /** @brief オフライン */
    public static final int RESULT_UPOS_OFFLINE = 108;

    /** @brief 競合エラー */
    public static final int RESULT_UPOS_CONFLICT_ERROR = 109;

    /** @brief BUSYエラー */
    public static final int RESULT_UPOS_SEQUENCE_ERROR = 113;

    /** @brief 受信データ不正 */
    public static final int RESULT_UPOS_RECEIVE_DATA_ERROR = 111;

    /** @brief 応答なし */
    public static final int RESULT_UPOS_TIMEOUT = 112;

    /** @brief 復旧不可能エラー */
    public static final int RESULT_UPOS_FATAL = 114;

    /** @brief 復旧不可能エラー */
    public static final int ECODE_PORT_ERROR = 104;

    /** @brief 復旧不可能エラー */
    public static final int ECODE_EXT_CODE = 114;

    /** @brief EXTエラーなし */
    public static final int ERROR_EXT_CODE_NULL = 0;

    /** @brief プラグイン内部エラー */
    public static final int ERROR_EXT_CODE_PLUGIN = 1;

    /** @brief 周辺装置初期化エラー */
    public static final int ERROR_EXT_CODE_INITILAIZE = 2;

    /** @brief 周辺装置内部エラー */
    public static final int ERROR_EXT_CODE_DEVICE = 3;

    /** @brief 拒否応答受信 */
    public static final int ERROR_EXT_CODE_REJECT = 4;

    /** @brief 通信デバイス異常 */
    public static final int ERROR_EXT_CODE_NETWORK = 5;

    /** @brief 周辺装置Ver不正 */
    public static final int ERROR_EXT_CODE_VERSION = 6;

    /** @brief MSR鍵更新 */
    public static final int DUKPT_MAKE_TRANSACTION_MSR = 1;

    /** @brief ICRW鍵更新 */
    public static final int DUKPT_MAKE_TRANSACTION_ICRW = 2;

    /** @brief USBデバイス情報ファイル名(sys/bus/usb/devices) */
    public static final String USB_DEVICE_INFORMATION_PRDUCT = "product";

    /** @brief USBデバイス情報ファイル名(sys/bus/usb/devices) */
    public static final String USB_DEVICE_INFORMATION_SERIAL = "serial";

    /** @brief デバイス異常 */
    public static final int RESULT_DEVICE_FAILURE = -1;

    /** @brief 書き込みタイムアウト */
    public static final int PINPAD_DEFAULT_WRITE_TIMEOUT = 5000;

    /** @brief 紙切れ検出 */
    public static final int ERROR_EXT_PRINTER_PAPER_LESS = 101;

    /** @brief ヘッド状態異常 */
    public static final int ERROR_EXT_PRINTER_HEAD_STATUS = 102;

    /** @brief ヘッド温度異常(HW) */
    public static final int ERROR_EXT_PRINTER_HEAD_HW = 103;

    /** @brief ヘッド温度異常(SW) */
    public static final int ERROR_EXT_PRINTER_HEAD_SW = 104;

    /** @brief モーター異常 */
    public static final int ERROR_EXT_PRINTER_MORTER = 105;

    /** @brief 電源電圧異常 */
    public static final int ERROR_EXT_PRINTER_VOLTAGE = 106;

    /** @brief プリンタカバーオープン */
    public static final int ERROR_EXT_PRINTER_COVER_OPEN = 107;

    /** @brief フォントデータ異常 */
    public static final int ERROR_EXT_PRINTER_FONT = 108;

    /** @brief イメージデータ異常 */
    public static final int ERROR_EXT_PRINTER_IMAGE = 109;

    /** @brief 印字データ不正 */
    public static final int ERROR_EXT_PRINTER_PARAM = 110;

    /** @brief その他エラー発生 */
    public static final int ERROR_EXT_PRINTER_OTHER = 111;

    /** @brief 磁気データ読み取り操作情報 - 読み取り操作 */
    public static final int MSDATA_RESULT_READING = 1;

    /** @brief 磁気データ読み取り操作情報 - 訂正キー押下(取消操作) */
    public static final int MSDATA_RESULT_CANCEL = 2;

    /** @brief 磁気データ読み取り操作情報 - タイムアウト */
    public static final int MSDATA_RESULT_TIMEOUT = 3;

    /** @brief 磁気データ読み取りオプション - 磁気カード検査読み取り */
    public static final int MSREAD_MODE_CHECK = 0;

    /** @brief 磁気データ読み取りオプション - JIS-II */
    public static final int MSREAD_MODE_JIS2 = 1;

    /** @brief 磁気データ読み取りオプション - JIS-ITrack1(IATA) */
    public static final int MSREAD_MODE_JIS1TRACK1 = 2;

    /** @brief 磁気データ読み取りオプション - JIS-ITrack2(ABA) */
    public static final int MSREAD_MODE_JIS1TRACK2 = 4;

    /** @brief PRN CRCエラー */
    public static final int ERROR_EXT_PRINTER_CRC = 0x8001;

    /** @brief PRN シーケンスエラー */
    public static final int ERROR_EXT_PRINTER_SEQUENCE = 0x8002;

}
