
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultTermEmcrw extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultTermEmcrw(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultTermEmcrw() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultTermEmcrw> CREATOR = new Parcelable.Creator<ResultTermEmcrw>() {

        @Override
        public ResultTermEmcrw createFromParcel(Parcel in) {
            return new ResultTermEmcrw(in);
        }

        @Override
        public ResultTermEmcrw[] newArray(int size) {
            return new ResultTermEmcrw[size];
        }

    };

}
