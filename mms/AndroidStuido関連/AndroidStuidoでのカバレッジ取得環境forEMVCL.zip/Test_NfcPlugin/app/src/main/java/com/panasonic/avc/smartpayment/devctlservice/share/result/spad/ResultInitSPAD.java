
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultInitSPAD extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultInitSPAD(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitSPAD() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitSPAD> CREATOR = new Parcelable.Creator<ResultInitSPAD>() {

        @Override
        public ResultInitSPAD createFromParcel(Parcel in) {
            return new ResultInitSPAD(in);
        }

        @Override
        public ResultInitSPAD[] newArray(int size) {
            return new ResultInitSPAD[size];
        }

    };
}
