
package com.panasonic.avc.smartpayment.devctlservice.printer;

public class QRCodeData {

    public static final int MIN_VERSION = 1;
    public static final int MAX_VERSION = 17;
    public static final int MIN_SIZE = 1;
    public static final int MAX_SIZE = 3;

    private static int[] mQRDataMaxSize = {
            20, 38, 60, 90, 122, 154, 178, 220, 262, 310, 366, 418, 482, 528, 600, 656, 734
    };

    private static int[][] mQRDataMaxLength = {
            {
                    116, 132, 148, 164, 180, 196, 212, 228, 244, 260, 276, 292, 308, 324, 340, 356,
                    372
            },
            {
                    145, 165, 185, 205, 225, 245, 265, 285, 305, 325, 345, 365, 0, 0, 0, 0, 0
            },
            {
                    174, 198, 222, 246, 270, 294, 318, 342, 366, 0, 0, 0, 0, 0, 0, 0, 0
            }
    };

    private int mVersion;
    private int mSize;
    private String mQRData;

    public QRCodeData(int version, int size, String qrdata) {
        mVersion = version;
        mSize = size;
        mQRData = qrdata;
    }

    public boolean isValidValue() {
        if (mVersion < MIN_VERSION || mVersion > MAX_VERSION || mSize < MIN_SIZE
                || mSize > MAX_SIZE || mQRData == null || mQRData.length() <= 0
                || mQRData.length() > mQRDataMaxSize[mVersion - 1]) {
            return false;
        }

        if (mQRDataMaxLength[mSize - 1][mVersion - 1] == 0) {
            return false;
        }

        return true;
    }

    /**
     * QRコードの画像の１辺の長さを取得する
     * 
     * @param version
     * @param size
     * @return
     */
    public int getImageLength() {
        if (isValidValue()) {
            return mQRDataMaxLength[mSize - 1][mVersion - 1];
        }
        return -1;
    }

    public int get8Multiple(int length) {
        int tmp = length / 8;
        return 8 * (tmp + 1);
    }

    /**
     * QRコードの画像の１辺の長さを(8byte)取得する
     * 
     * @param version
     * @param size
     * @return
     */
    public int get8Length(int length) {
        int ret = 8;
        int count = 1;
        while (true) {
            count++;
            ret = 8 * count;
            if (ret > length) {
                break;
            }
        }
        return ret;
    }

}
