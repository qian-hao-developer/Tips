
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.printer.device.data.RequestPrinterData;

/**
 * 通信終了要求
 */
public class RequestStopComunication extends RequestPrinterData {

    /** @brief コマンド種別 */
    private static final int COMMAND_ID = 0x8004;

    /** @brief コマンド詳細 */
    private static final int COMMAND_DETAIL = 0x0000;

    /**
     * @brief コンストラクタ
     */
    public RequestStopComunication() {
        mCommandId = COMMAND_ID;
        mCommandDetail = COMMAND_DETAIL;
    }

    /**
     * @see RequestPrinterData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        return true;
    }

}
