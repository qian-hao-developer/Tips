
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * 機器設定コマンド
 */
public class RequestDeviceSetting extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = (byte) 0x20;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = (byte) 0x01;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 0x92;

    public static final int CONTRAST_NO_CHANGE = 0;

    /**
     * @brief 言語設定
     */
    public enum Language {
        JAPANESE((byte) 0x00),
        ENGLISE((byte) 0x01),
        SPANISH((byte) 0x02);

        private final byte mValue;

        private Language(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }
    }

    /**
     * @brief ブザー設定
     */
    public enum BuzzerVolume {
        VOLUME_NO_CHANGE((byte) 0xFF),
        VOLUME_LARGE((byte) 0x03),
        VOLUME_MIDIUM((byte) 0x02),
        VOLUME_SMALL((byte) 0x01),
        VOLUME_SILENT((byte) 0x00);

        private final byte mValue;

        private BuzzerVolume(byte value) {
            mValue = value;
        }

        public byte getValue() {
            return mValue;
        }
    }

    /** @brief 音量大 **/
    private static final int VOLUME_LARGE = 4;

    /** @brief 音量中 **/
    private static final int VOLUME_MIDIUM = 3;

    /** @brief 音量小 **/
    private static final int VOLUME_SMALL = 2;

    /** @brief 消音 **/
    private static final int VOLUME_SILENT = 1;

    /** @brief 設定変更なし **/
    public static final int VOLUME_NO_CHANGE = 0;

    /** @brief コントラストの変更有効無効設定 */
    private boolean mChangeContrast;

    /** @brief ブザーの変更有効無効設定 */
    private boolean mChangeBuzzer;

    /** @brief 言語の変更有効無効設定 */
    private boolean mChangeLanguage;

    /** @brief コントラスト */
    private byte mContrast;

    /** @brief ブザー音量 */
    private BuzzerVolume mBuzzer;

    /** @brief 言語設定 */
    private Language mLanguage;

    /**
     * @brief コンストラクタ
     * @param changeContrast コントラスト設定変更有無
     * @param contrast コントラスト値
     * @param changeBuzzer ブザー設定変更有無
     * @param buzzer ブザー
     * @param changeLanguage 言語変更有無
     * @param language 言語
     */
    public RequestDeviceSetting(boolean changeContrast, byte contrast, boolean changeBuzzer,
            int buzzer, boolean changeLanguage, Language language) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mChangeContrast = changeContrast;
        mChangeBuzzer = changeBuzzer;
        mChangeLanguage = changeLanguage;
        mContrast = contrast;

        switch (buzzer) {
            case VOLUME_LARGE:
                mBuzzer = BuzzerVolume.VOLUME_LARGE;
                break;
            case VOLUME_MIDIUM:
                mBuzzer = BuzzerVolume.VOLUME_MIDIUM;
                break;
            case VOLUME_SMALL:
                mBuzzer = BuzzerVolume.VOLUME_SMALL;
                break;
            case VOLUME_SILENT:
                mBuzzer = BuzzerVolume.VOLUME_SILENT;
                break;
            case VOLUME_NO_CHANGE:
                mBuzzer = BuzzerVolume.VOLUME_NO_CHANGE;
                mChangeBuzzer = false;
                break;
            default:
                mBuzzer = null;
                break;
        }

        mLanguage = language;
    }

    /**
     * @brief コントラストの設定変更有無を取得する
     * @return コントラスト設定有無
     */
    public boolean isChangeContrast() {
        return mChangeContrast;
    }

    /**
     * @brief コントラストの設定変更有無を設定する
     * @param changeContrast コントラスト設定の有無
     */
    public void setChangeContrast(boolean changeContrast) {
        mChangeContrast = changeContrast;
    }

    /**
     * @brief ブザーの音量変更有無を取得する
     * @return ブザーの音量変更有無
     */
    public boolean isChangeBuzzer() {
        return mChangeBuzzer;
    }

    /**
     * @brief ブザーの音量変更有無を設定する
     * @param changeBuzzer ブザー音量有無
     */
    public void setChangeBuzzer(boolean changeBuzzer) {
        mChangeBuzzer = changeBuzzer;
    }

    /**
     * @brief 言語変更有無を取得する
     * @return 言語変更有無
     */
    public boolean isChangeLanguage() {
        return mChangeLanguage;
    }

    /**
     * @brief 言語変更有無を設定する
     * @param changeLanguage 言語設定有無
     */
    public void setChangeLanguage(boolean changeLanguage) {
        mChangeLanguage = changeLanguage;
    }

    /**
     * @brief コントラスト値を取得する
     * @return コントラスト値
     */
    public byte getContrast() {
        return mContrast;
    }

    /**
     * @brief コントラスト値を設定する
     * @param contrast コントラスト値
     */
    public void setContrast(byte contrast) {
        mContrast = contrast;
    }

    /**
     * @brief ブザー音量を取得する
     * @return ブザー音量
     */
    public BuzzerVolume getBuzzer() {
        return mBuzzer;
    }

    /**
     * @brief ブザー音量を設定する
     * @param buzzer ブザー音量
     */
    public void setBuzzer(BuzzerVolume buzzer) {
        mBuzzer = buzzer;
    }

    /**
     * @brief 言語を取得する
     * @return 言語
     */
    public Language getLanguage() {
        return mLanguage;
    }

    /**
     * @brief 言語を設定する
     * @param language 言語
     */
    public void setLanguage(Language language) {
        mLanguage = language;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] parameter = new byte[LENGTH];

        parameter[0] = (byte) (mSequence & 0xff);
        parameter[1] = (byte) ((mSequence >> 8) & 0xff);

        int cons = mChangeContrast ? 1 : 0;
        int buzz = mChangeBuzzer ? 1 : 0;
        int lang = mChangeLanguage ? 1 : 0;

        parameter[2] = (byte) ((cons << 7) + (buzz << 6) + (lang << 5));
        if (mChangeContrast) {
            parameter[18] = mContrast;
        } else {
            parameter[18] = 0x00;
        }

        if (mChangeBuzzer) {
            parameter[19] = mBuzzer.getValue();
        } else {
            parameter[19] = 0x00;
        }

        if (mChangeLanguage) {
            parameter[20] = mLanguage.getValue();
        } else {
            parameter[20] = 0x00;
        }

        return toCommand(parameter);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {
        if (mChangeContrast) {
            if (!((0 <= mContrast) && (mContrast <= 7))) {
                return false;
            }
        }

        if (mChangeBuzzer) {
            if (mBuzzer == null) {
                return false;
            }
        }

        if (mChangeLanguage) {
            if (mLanguage == null) {
                return false;
            }
        }

        return true;
    }
}
