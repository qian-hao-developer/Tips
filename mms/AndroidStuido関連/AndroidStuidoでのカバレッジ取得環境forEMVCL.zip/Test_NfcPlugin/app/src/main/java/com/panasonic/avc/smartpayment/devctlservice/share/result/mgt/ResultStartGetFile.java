
package com.panasonic.avc.smartpayment.devctlservice.share.result.mgt;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPEDの実行結果データ
 */
public class ResultStartGetFile extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultStartGetFile(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultStartGetFile() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultStartGetFile> CREATOR = new Parcelable.Creator<ResultStartGetFile>() {
        public ResultStartGetFile createFromParcel(Parcel in) {
            return new ResultStartGetFile(in);
        }

        public ResultStartGetFile[] newArray(int size) {
            return new ResultStartGetFile[size];
        }
    };
}
