
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultPenData implements Parcelable {

    /** @brief X座標 tag */
    private static final String X = "x";

    /** @brief Y座標 tag */
    private static final String Y = "y";

    /** @brief switch tag */
    private static final String SWITCH = "switch";

    /** @brief pressure tag */
    private static final String PRESSURE = "pressure";

    /** @brief X座標データ */
    private int mX;

    /** @brief Y座標データ */
    private int mY;

    /** @brief switchデータ */
    private int mSwitch;

    /** @brief 筆圧データ */
    private int mPressure;

    /**
     * コンストラクタ
     */
    public ResultPenData() {
        setX(0);
        setY(0);
        setSwitch(0);
        setPressure(0);
    }

    /**
     * コンストラクタ
     * 
     * @param[in] x X座標
     * @param[in] y Y座標
     * @param[in] sw switch
     * @param[in] pressure 筆圧
     */
    public ResultPenData(int x, int y, int sw, int pressure) {
        setX(x);
        setY(y);
        setSwitch(sw);
        setPressure(pressure);
    }

    /**
     * コンストラクタ
     * 
     * @param[in] source Parcelデータ
     */
    public ResultPenData(Parcel source) {
        readFromParcel(source);
    }

    /**
     * @brief JSON形式で各フィールドの値を出力します
     * @return 各フィールドの値を保持したJSONObject（失敗時はnull）
     *         (通常はtoString()するが、ResultPenDataはResponseSignpadの中身になるので
     *         、JSONArrayにこのJSONObjectを突っ込んだ時に問題が出ないようにObjectのまま返す。)
     */
    public JSONObject toJSON() {
        JSONObject retobj = new JSONObject();

        try {
            retobj.put(X, this.mX);
            retobj.put(Y, this.mY);
            retobj.put(SWITCH, this.mSwitch);
            retobj.put(PRESSURE, this.mPressure);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

        return retobj;
    }

    /**
     * @brief Parcelable
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @brief Parcelable
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mX);
        dest.writeInt(mY);
        dest.writeInt(mSwitch);
        dest.writeInt(mPressure);
    }

    /**
     * @brief Parcelable
     * @param in Parcelデータ
     */
    public void readFromParcel(Parcel in) {
        setX(in.readInt());
        setY(in.readInt());
        setSwitch(in.readInt());
        setPressure(in.readInt());
    }

    /**
     * @brief X座標を取得します
     * @return mX
     */
    public int getX() {
        return mX;
    }

    /**
     * @brief X座標を設定します
     * @param[in] x X座標
     */
    public void setX(int x) {
        this.mX = x;
    }

    /**
     * @brief Y座標を取得します
     * @return mY
     */
    public int getY() {
        return mY;
    }

    /**
     * @brief Y座標を設定します
     * @param[in] y Y座標
     */
    public void setY(int y) {
        this.mY = y;
    }

    /**
     * @brief switchを取得します
     * @return mSwitch
     */
    public int getSwitch() {
        return mSwitch;
    }

    /**
     * @brief switchを設定します
     * @param[in] sw Switch
     */
    public void setSwitch(int sw) {
        this.mSwitch = sw;
    }

    /**
     * @brief 筆圧を取得します
     * @return mPressure
     */
    public int getPressure() {
        return mPressure;
    }

    /**
     * @brief 筆圧を設定します
     * @param[in] pressure 筆圧
     */
    public void setPressure(int pressure) {
        this.mPressure = pressure;
    }

    /**
     * @brief 復元用
     */
    public static final Parcelable.Creator<ResultPenData> CREATOR = new Parcelable.Creator<ResultPenData>() {

        @Override
        public ResultPenData createFromParcel(Parcel arg0) {
            return new ResultPenData(arg0);
        }

        @Override
        public ResultPenData[] newArray(int arg0) {
            return new ResultPenData[arg0];
        }
    };

}
