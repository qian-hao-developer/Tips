
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetArea extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x2a;

    private static final int LENGTH = 9;

    private static final String ULX = "ulx";

    private int mUlx;

    private static final String ULY = "uly";

    private int mUly;

    private static final String LRX = "lrx";

    private int mLrx;

    private static final String LRY = "lry";

    private int mLry;

    public ResponseGetArea(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mUlx = CalcUtil.toInt(result[1], result[2]);
        mUly = CalcUtil.toInt(result[3], result[4]);
        mLrx = CalcUtil.toInt(result[5], result[6]);
        mLry = CalcUtil.toInt(result[7], result[8]);

        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(ULX, mUlx);
            json.put(ULY, mUly);
            json.put(LRX, mLrx);
            json.put(LRY, mLry);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
}
