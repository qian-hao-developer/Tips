
package com.panasonic.avc.smartpayment.devctlservice.bcr;

import java.util.List;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;

/**
 * バーコードリーダ用便利関数
 */
public class BarcodeReaderUtil {

    /** @brief 受信データタイプ */
    private enum DataType {

        /** @brief ACK or NAK */
        CTRL_CHAR,

        /** @brief 診断コマンド結果 */
        DIAGNOSIS,

        /** @brief バーコードのスキャン結果 */
        SCAN_DATA,

        /** @brief データ受信未完了のため判別不可 */
        UNKNOWN,

    }

    /**
     * @brief 受信データをコールバック通知毎に分割する
     * @param data 受信データ
     * @return 分割された受信データ
     */
    public static byte[][] splitReceiveData(byte[] data) {
        switch (getDataType(data)) {
            case CTRL_CHAR:
                return new byte[][] {
                        data
                };
            case DIAGNOSIS:
                return new byte[][] {
                        CalcUtil.cutArray(data, data.length - BarcodeReaderDefine.SUFFIX_SIZE),
                        new byte[] {
                                BarcodeReaderDefine.ACK_CODE
                        }
                };
            case SCAN_DATA:
                return new byte[][] {
                        CalcUtil.cutArray(data, data.length - BarcodeReaderDefine.SUFFIX_SIZE)
                };
            default:
                return new byte[0][0];
        }
    }

    /**
     * @brief 受信完了したかを判定する
     * @param dataList
     * @return 受信完了
     */
    public static boolean isReceiveEnd(List<Byte> dataList) {
        return getDataType(CalcUtil.toArray(dataList)) != DataType.UNKNOWN;
    }

    /**
     * @brief 受信完了データがバーコードのスキャン結果であるか
     * @param dataList
     * @return 受信完了データがバーコードのスキャン結果であるか
     */
    public static boolean isScanData(List<Byte> dataList) {
        return getDataType(CalcUtil.toArray(dataList)) == DataType.SCAN_DATA;
    }

    /**
     * @brief 受信データタイプを判定する
     * @param data 受信データ
     * @return 受信データタイプ
     */
    private static DataType getDataType(byte[] data) {
        if (data.length == BarcodeReaderDefine.ACK_SIZE) {
            byte b = data[0];
            if (b == BarcodeReaderDefine.ACK_CODE || b == BarcodeReaderDefine.NAK_CODE) {
                // ACK or NAK 応答
                return DataType.CTRL_CHAR;
            }
        }
        if (data.length < BarcodeReaderDefine.SUFFIX_SIZE) {
            return DataType.UNKNOWN;
        }
        int positionCommonSFX = data.length - BarcodeReaderDefine.COMMON_SUFFIX_SIZE;
        int positionIndividualSFX = positionCommonSFX - BarcodeReaderDefine.INDIVIDUAL_SUFFIX_SIZE;
        if (data[positionIndividualSFX] == BarcodeReaderDefine.CR_CODE) {
            if (data[positionCommonSFX] == BarcodeReaderDefine.ACK_CODE) {
                // 診断コマンド応答(データ + <CR><ACK>)
                return DataType.DIAGNOSIS;
            }
            if (data[positionCommonSFX] == BarcodeReaderDefine.EOT_CODE) {
                // バーコード読み取り結果(データ + <CR><EOT>)
                return DataType.SCAN_DATA;
            }
        }
        return DataType.UNKNOWN;
    }

    /**
     * @brief デバイスタイプに変換する
     * @param productId プロダクトID
     * @return デバイスタイプを返却する
     */
    public static int toType(int productId) {
        switch (productId) {
            case BarcodeReaderDefine.PID_M_10:
                return BarcodeReaderDefine.TYPE_M_10;
            case BarcodeReaderDefine.PID_C_40_C_41:
                return BarcodeReaderDefine.TYPE_C_40_C_41;
            default:
                return -1;
        }
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    public static boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer.length == 0) {
            return true;
        }
        return false;
    }

}
