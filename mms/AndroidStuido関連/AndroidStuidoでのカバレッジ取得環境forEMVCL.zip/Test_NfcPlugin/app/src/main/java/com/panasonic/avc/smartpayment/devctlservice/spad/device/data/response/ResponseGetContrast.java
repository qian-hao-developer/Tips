
package com.panasonic.avc.smartpayment.devctlservice.spad.device.data.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.spad.device.data.ResponseSpadData;

public class ResponseGetContrast extends ResponseSpadData {

    public static final byte COMMAND_ID = 0x2c;

    private static final int LENGTH = 3;

    private static final String CONTRAST = "contrast";

    private int mContrast;

    public ResponseGetContrast(byte id) {
        super(id);
    }

    @Override
    public boolean parse(byte[] result) {
        if (!isCorrect(result)) {
            return false;
        }

        if (result.length != LENGTH) {
            return false;
        }

        mContrast = CalcUtil.toInt(result[1], result[2]);
        return true;
    }

    @Override
    public JSONObject toJSONObject() {
        JSONObject json = super.toJSONObject();
        try {
            json.put(CONTRAST, mContrast);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

}
