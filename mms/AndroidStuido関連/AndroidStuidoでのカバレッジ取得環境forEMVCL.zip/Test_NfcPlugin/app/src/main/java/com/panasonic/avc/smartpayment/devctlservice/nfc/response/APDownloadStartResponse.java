package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHHIGH_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DATALENGTHLOW_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.MAINCOMMAND_INDEX;
import static com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.SUBCOMMAND_INDEX;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.Logger;

/**
 * APダウンロード開始Responseクラス.
 * 
 */
public class APDownloadStartResponse extends BaseDownloadStartResponse {

    /** @brief ログ用タグ */
    protected static final String TAG = APDownloadStartResponse.class
            .getSimpleName();

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x01;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x80;

    /** Constructor */
    public APDownloadStartResponse() {
        setMCSC(MAINCOMMAND, SUBCOMMAND);
    }
}

