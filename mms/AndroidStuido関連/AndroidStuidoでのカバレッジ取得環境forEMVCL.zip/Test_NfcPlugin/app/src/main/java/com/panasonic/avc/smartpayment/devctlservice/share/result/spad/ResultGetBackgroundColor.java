
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetBackgroundColor extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetBackgroundColor(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetBackgroundColor() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetBackgroundColor> CREATOR = new Parcelable.Creator<ResultGetBackgroundColor>() {

        @Override
        public ResultGetBackgroundColor createFromParcel(Parcel in) {
            return new ResultGetBackgroundColor(in);
        }

        @Override
        public ResultGetBackgroundColor[] newArray(int size) {
            return new ResultGetBackgroundColor[size];
        }
    };
}
