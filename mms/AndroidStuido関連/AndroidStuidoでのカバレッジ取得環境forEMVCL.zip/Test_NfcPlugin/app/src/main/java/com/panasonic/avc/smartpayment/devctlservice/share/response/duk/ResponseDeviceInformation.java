
package com.panasonic.avc.smartpayment.devctlservice.share.response.duk;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;
import com.panasonic.avc.smartpayment.util.thinclientlog.ITcLogServiceConstants;

/**
 * 機器情報応答
 */
public class ResponseDeviceInformation extends com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseDeviceInformation {

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        if (!checkResponseData(buffer)) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
            setUpos(PluginDefine.RESULT_UPOS_RECEIVE_DATA_ERROR);
            return false;
        }

        mResult = buffer[PinpadDefine.INDEX_PARAMETER];
        if (mResult != PluginDefine.RESULT_DEVICE_SCCESS) {
        	mLoggingManager.putLogDevice(ITcLogServiceConstants.DeviceType.DUK, mResult, -1, buffer[PinpadDefine.INDEX_MC], buffer[PinpadDefine.INDEX_SC], null);
            setDevice(mResult);
            setUpos(PluginDefine.RESULT_UPOS_SCCESS);
            return false;
        }

        byte[] status = new byte[12];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 1, status, 0, status.length);
        status = CalcUtil.reverseByte(status);

        byte[] uid = new byte[8];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 12, uid, 0, uid.length);
        uid = CalcUtil.reverseByte(uid);
        mUid = String.valueOf((long) (uid[0] << 24) | (long) (uid[1] << 16) | (long) (uid[2] << 8)
                | (long) (uid[3]));

        byte[] fv = new byte[4];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 20, fv, 0, fv.length);
        fv = CalcUtil.reverseByte(fv);
        mFirmwareVersion = new String(fv);

        byte[] ifd = new byte[4];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 24, ifd, 0, ifd.length);
        ifd = CalcUtil.reverseByte(ifd);
        mIfd = new String(ifd);

        byte[] advance = new byte[2];
        System.arraycopy(buffer, PinpadDefine.INDEX_PARAMETER + 28, advance, 0, advance.length);
        advance = CalcUtil.reverseByte(advance);
        mAdvance = new String(advance);

        return true;
    }

}
