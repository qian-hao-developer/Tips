
package com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw;

import android.os.Parcel;
import android.os.Parcelable;

public class ResultCarrierOn extends ResultFeliCaApl {

    /**
     * @brief コンストラクタ
     */
    public ResultCarrierOn(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultCarrierOn() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultCarrierOn> CREATOR = new Parcelable.Creator<ResultCarrierOn>() {

        @Override
        public ResultCarrierOn createFromParcel(Parcel in) {
            return new ResultCarrierOn(in);
        }

        @Override
        public ResultCarrierOn[] newArray(int size) {
            return new ResultCarrierOn[size];
        }

    };

    /**
     * @brief AIDL用
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
    }

}
