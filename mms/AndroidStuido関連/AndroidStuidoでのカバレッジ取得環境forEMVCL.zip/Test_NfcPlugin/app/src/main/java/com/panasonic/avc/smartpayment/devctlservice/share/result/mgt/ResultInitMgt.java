
package com.panasonic.avc.smartpayment.devctlservice.share.result.mgt;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * InitPEDの実行結果データ
 */
public class ResultInitMgt extends ResultData {
    /**
     * @brief コンストラクタ
     */
    public ResultInitMgt(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitMgt() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitMgt> CREATOR = new Parcelable.Creator<ResultInitMgt>() {
        public ResultInitMgt createFromParcel(Parcel in) {
            return new ResultInitMgt(in);
        }

        public ResultInitMgt[] newArray(int size) {
            return new ResultInitMgt[size];
        }
    };
}
