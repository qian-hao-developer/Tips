
package com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.os.RemoteException;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.util.Log;

import com.panasonic.avc.smartpayment.devctlservice.TerminalStatusManager;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwApplicationDataMap;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwPlatformData;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwUpdateInfo;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.EmcrwUpdateInfoCreator;
import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.ControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestIplData;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestIplEnd;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestIplInterruption;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request.RequestIplStart;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseAck;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseDeviceInformation;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseIplData;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseIplEnd;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseIplInterruption;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.response.ResponseIplStart;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.icrw.ContactIcCard;
import com.panasonic.avc.smartpayment.devctlservice.share.IMgtPrivateServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.IMgtServiceListener;
import com.panasonic.avc.smartpayment.devctlservice.share.PluginDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.UpdateDeviceType;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetPackageInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultGetVersionInfo;
import com.panasonic.avc.smartpayment.devctlservice.share.result.emcrw.ResultCheckHealth;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultExecUpdate;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultInitMgt;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultStartGetFile;
import com.panasonic.avc.smartpayment.devctlservice.share.result.mgt.ResultStartSendFile;
import com.panasonic.avc.smartpayment.devctlservice.system.util.Util;
import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;

/**
 * 端末管理処理部
 */
public class Management {

    /** @brief ログ出力用タグ */
    private static final String TAG = Management.class.getSimpleName();

    /** @brief シングルトンインスタンス */
    private static Management sInstance = new Management();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IMgtServiceListener> mIMgtServiceListener = new ConcurrentHashMap<String, IMgtServiceListener>();

    /** @brief バインド相手のリスナー */
    private ConcurrentHashMap<String, IMgtPrivateServiceListener> mIMgtPrivateServiceListener = new ConcurrentHashMap<String, IMgtPrivateServiceListener>();

    /** @brief デバイスコントロール管理クラス */
    private ConcurrentHashMap<UpdateDeviceType, ControlDeviceManager> mControlDeviceManagerMap = new ConcurrentHashMap<UpdateDeviceType, ControlDeviceManager>();

    /** @brief 非接触ICカードリーダーライター操作クラス */
    private NonContactICCard mNonContactICCard;

    /** @brief RW更新のリセット待ちタイムアウト */
    private static final int TIME_OUT_RW_RESET_WAIT = 120000;

    /** @brief Write時のタイムアウト */
    private static final int TIME_OUT = 5000;

    /** @brief IPL開始応答待のタイムアウト */
    private static final int TIME_OUT_IPL_START = 80000;

    /** @brief 更新時間待のタイムアウト */
    private static final int TIME_OUT_WRITE_ROM = 30000;

    private static final String FIRMWARE_FILE_NAME = "/firmware2/pinpad/";

    private static final String FIRMWARE_FILE_EXTENTION = ".bin";

    /* SystemPropertiesキー */
    private static final String PROP_KEY_DEBUG_DOWNGRADE = "persist.sys.fwupdate.downgrade";

    /** ダウングレード可否フラグ */
    public static final boolean DOWNGRADE_ENABLED = SystemProperties.getBoolean(PROP_KEY_DEBUG_DOWNGRADE, false);

    /** IC カードリーダライタ FW 更新情報ディレクトリパス */
    public static final String FIRMWARE_DIRECTORY_NON_CONTACT_ICCARD_RW = "/firmware2/rw";

    private boolean mIsAvailableUpdate;

    /** 接触ICカードリーダライタコントロールクラス */
    private ContactIcCard mContactIcCard = ContactIcCard.getInstance();

    /** 端末情報通知 */
    private TerminalStatusManager mTerminalStatusManager;

    public enum CallbackType {
        PUBLIC,
        PRIVATE
    }

    /**
     * @brief コンストラクタ
     */
    private Management() {

    }

    /**
     * @brief インスタンスを取得する
     * @return インスタンス
     */
    public static Management getInstance() {
        return sInstance;
    }

    /**
     * @brief MGTプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerMgtServiceListener(String tag, IMgtServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIMgtServiceListener) {
            mIMgtServiceListener.put(tag, listener);
        }
    }

    /**
     * @brief MGTプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterMgtServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIMgtServiceListener) {
            mIMgtServiceListener.remove(tag);
        }
    }

    /**
     * @brief MGT Priavteプラグインのリスナーを登録します
     * @param[in] listener リスナー
     */
    public void registerMgtPrivateServiceListener(String tag, IMgtPrivateServiceListener listener) {
        if (listener == null || tag == null) {
            return;
        }

        synchronized (mIMgtPrivateServiceListener) {
            mIMgtPrivateServiceListener.put(tag, listener);
        }
    }

    /**
     * @brief MGT Privateプラグインのリスナーを解除します
     * @param[in] listener リスナー
     */
    public void unregisterMgtPrivateServiceListener(String tag) {
        if (tag == null) {
            return;
        }

        synchronized (mIMgtPrivateServiceListener) {
            mIMgtPrivateServiceListener.remove(tag);
        }
    }

    /**
     * @brief MGTを初期化します
     * @return JSON形式 [device, upos]
     */
    public ResultInitMgt initMtg() {
        ResultInitMgt result = new ResultInitMgt();
        result.setDevice(PluginDefine.RESULT_DEVICE_SCCESS);
        result.setUpos(PluginDefine.RESULT_UPOS_SCCESS);
        return result;
    }

    /**
     * @brief ソフトウェア更新用ファイルを送信します
     * @param[in] name 格納ファイル名
     * @param[in] flen ファイルサイズ
     * @param[in] crc CRC16
     * @param[in] data ファイルデータ
     * @return JSON形式 [device, upos]
     */
    public ResultStartSendFile startSendFile(String name, int flen, int crc, String data) {

        // TODO
        return null;
    }

    /**
     * @brief ソフトウェア更新を実行します
     * @return JSON形式 [device, upos]
     */
    public ResultExecUpdate execUpdate() {

        // TODO
        return null;
    }

    /**
     * @brief デバイスログを取得します
     * @param[in] name ファイル名
     * @return JSON形式 [device, upos]
     */
    public ResultStartGetFile startGetFile(String name) {

        // TODO
        return null;
    }

    /**
     * @brief パッケージ情報を取得します
     * @return JSON形式[package]
     * @retval package パッケージ情報[name,ver]
     * @retval name パッケージ名[文字列型]
     * @retval ver パッケージバージョン[文字列型]
     */
    public ResultGetPackageInfo getPackageInfo(String jsName, String jsVer, String pluginName,
            String pluginVer) {

        // TODO
        return null;
    }

    /**
     * @brief 特定デバイスのバージョンと端末が把握しているバージョンとが異なるかどうか
     * @param[in] type デバイスの種類
     * @return 端末FW内のバージョンと異なるかどうか
     */
    public boolean isDefferentVersion(UpdateDeviceType type) {
        ResultGetVersionInfo verInfo = mContactIcCard.getVersionInfo();

        // PDS(管理) への通知用に、周辺機器の品番・製造番号・ファームウェアバージョンを設定する
        if (verInfo.getPfVer() != null && !verInfo.getPfVer().isEmpty()) {
            mTerminalStatusManager.setPinpadStatus(verInfo.getModel(), verInfo.getSno(), verInfo.getPfVer());
        }

        String sVersion = verInfo.getPfVer();
        String version;
        boolean ret = false;

        switch (type) {
            case PINPAD:
                version = Util.getFirmVersion(PdsClientManager.KEY_FMV_PINPAD);
                String[] pfver = version.split("_");
                if (pfver == null || pfver.length != 3 || pfver[2].length() < 4 || sVersion == null) {  // PT_IMPOSSIBLE_BRANCH
                    ret = false;
                } else {
                    String fwVersion = pfver[2].substring(0, 4);
                    int compare = fwVersion.compareToIgnoreCase(sVersion);
                    if (DOWNGRADE_ENABLED) {  // PT_IMPOSSIBLE_BRANCH
                        if (compare != 0) {  // PT_IMPOSSIBLE_INSTRUCTIONS, PT_IMPOSSIBLE_BRANCH
                            ret = true;  // PT_IMPOSSIBLE_INSTRUCTIONS
                        }
                    } else {
                        if (compare > 0) {
                            ret = true;
                        }
                    }
                }
                break;
            default:
                return false;
        }

        return ret;
    }

    /**
     * @beief 更新するデバイスを指定する
     * @param type デバイス
     * @return 成功したかどうか
     */
    public boolean startSendFile(UpdateDeviceType type) {

        String path = null;
        String version;

        switch (type) {
            case PINPAD:
                version = Util.getFirmVersion(PdsClientManager.KEY_FMV_PINPAD);
                if (!version.isEmpty()) {
                    path = FIRMWARE_FILE_NAME + version + FIRMWARE_FILE_EXTENTION;
                }
                break;
            default:
                return false;
        }

        if (path == null || path.isEmpty()) {
            return false;
        }

        File file = new File(path);
        if (!file.exists()) {
            return false;
        }

        return sendFile(CallbackType.PRIVATE, type, path);
    }

    /**
     * @beief 更新を実行する
     * @param type デバイス
     * @return 成功したかどうか
     */
    public boolean execUpdate(final CallbackType callback, final UpdateDeviceType type) {

        if (type == UpdateDeviceType.CONTACT_LESS_ICRW) {
            mIsAvailableUpdate = true;
        }
        if (!mIsAvailableUpdate) {
            return false;
        }

        Thread thread = new Thread() {
            @Override
            public void run() {
                boolean ret = false;

                switch (type) {
                    case PINPAD:
                        ret = execUpdatePinpad(type);
                        break;
                    case CONTACT_LESS_ICRW:
                        ret = execUpdateContactLessICRW();
                        break;

                    default:
                        break;
                }

                try {
                    sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                for (int i = 0; i < 250; i++) {
                    boolean alive = false;
                    switch (type) {
                        case PINPAD:
                            alive = checkHealthPinpad(type);
                            break;
                        case CONTACT_LESS_ICRW:

                            alive = checkHealthNonContactICCard();
                            break;
                    }
                    if (alive) {
                        break;
                    }
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                mIsAvailableUpdate = false;

                switch (callback) {
                    case PRIVATE:
                        for (Map.Entry<String, IMgtPrivateServiceListener> listener : mIMgtPrivateServiceListener
                                .entrySet()) {
                            try {
                                listener.getValue().onExecUpdate(type, ret);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                        break;
                    case PUBLIC:
                        for (Map.Entry<String, IMgtServiceListener> listener : mIMgtServiceListener
                                .entrySet()) {
                            // TODO Public版を作る際に実装する
                        }
                        break;
                    default:
                        break;
                }
            }
        };

        thread.start();

        return true;
    }

    /**
     * 非接触ICカードリーダライタ
     * 
     * @return
     */
    private boolean checkHealthNonContactICCard() {
        ResultCheckHealth result = mNonContactICCard.checkHealth();
        return result.getSts();
    }

    /**
     * 非接触 IC カード R/W 更新対象
     */
    private class ContactLessICRWUpdateTarget {

        /** アップデート(新規インストール含む)する AP のパスリスト */
        private List<String> updateAPPathList;

        /** アンインストールする AP の ID リスト */
        private List<Byte> uninstallAPIDList;

        /** アップデートする PF のパス (アップデート不要時は {@code null} ) */
        private String updatePFPath;

        /**
         * コンストラクタ
         * 
         * @param curtAPDataMap インストール済み AP
         * @param curtPFData インストール済み PF
         * @param updateInfo 更新情報
         */
        private ContactLessICRWUpdateTarget(EmcrwApplicationDataMap curtAPDataMap,
                EmcrwPlatformData curtPFData, EmcrwUpdateInfo updateInfo) {
            updateAPPathList = updateInfo.getUpdateAPPathList(curtAPDataMap);
            uninstallAPIDList = updateInfo.getUninstallAPIDList(curtAPDataMap.keySet());
            updatePFPath = updateInfo.getUpdatePFPath(curtPFData);
        }

        /**
         * アップデートの必要有無を判定する
         * 
         * @return アップデートの必要有無
         */
        private boolean isNeedUpdate() {
            return !updateAPPathList.isEmpty() || !uninstallAPIDList.isEmpty()
                    || updatePFPath != null;
        }
    }

    /**
     * 非接触 IC カード R/W のアップデートを実施する
     * 
     * @return アップデート実行結果
     */
    private boolean execUpdateContactLessICRW() {

        EmcrwApplicationDataMap curtAPDataMap = mNonContactICCard.getAPDataMap();
        EmcrwPlatformData curtPFData = mNonContactICCard.getPFData();
        EmcrwUpdateInfo updateInfo = EmcrwUpdateInfoCreator
                .create(FIRMWARE_DIRECTORY_NON_CONTACT_ICCARD_RW);
        if (curtAPDataMap == null || curtPFData == null || updateInfo == null) {
            // FW 更新情報がない or 非接触ICカードリーダライタが接続されていない
            return false;
        }

        ContactLessICRWUpdateTarget target =
                new ContactLessICRWUpdateTarget(curtAPDataMap, curtPFData, updateInfo);

        // 更新情報から
        // アップデートが必要なAPとPFが存在するはずなので、リストを作成する
        // アップデートするAppのパスリスト - パスが入っていなければアップデート不要
        List<String> updateApPaths = target.updateAPPathList;

        // アンインストールするアプリのIDリスト
        List<Byte> uninstallAppList = target.uninstallAPIDList;

        // プラットフォームは一つだけ（？）なので一つだけ用意 - null であれば、不要
        String pfPath = target.updatePFPath;

        boolean result = false;// アップデート実行結果

        // PFのアップデート処理
        if (pfPath != null) {
            byte[] pfData = readFile(pfPath);
            if (pfData == null) {
                return false;
            }
            if (pfData.length == 0) {
                return false;
            }

            result = mNonContactICCard.execUpdatePF(pfData);
            if (result == false) {
                Log.e(TAG, " PF update retry");
                result = mNonContactICCard.execUpdatePF(pfData);
                return result;
            }

            // PFのアップデートが行われた場合、ダウンロード領域枯渇を防止するため
            // 必ずRWリセットを実行する
            // 本処理は暫定的なもので、正式にはファームウェアファイルの復号化後の
            // サイズをもとにダウンロード領域の使用状況を計算し、RWリセット要否を
            // 導出するロジックを追加する必要がある
            resetRw(TIME_OUT_RW_RESET_WAIT);
        }

        wait(5000);

        // アプリのアップデート処理
        for (String path : updateApPaths) {
            byte[] file = readFile(path);
            if (file == null) {
                return result;
            }
            if (file.length == 0) {
                return result;
            }

            wait(1000);

            result = mNonContactICCard.execUpdateAP(file);
            if (result == false) {
                return result;
            }
        }

        wait(5000);

        // アプリのアンインストール処理
        for (byte apId : uninstallAppList) {
            result = mNonContactICCard.uninstallAP(apId);
            if (result == false) {
                return result;
            }
            wait(500);
        }

        return mNonContactICCard.reset();
    }

    private boolean sendFile(final CallbackType callback, final UpdateDeviceType type,
            final String path) {
        Thread thread = new Thread() {
            @Override
            public void run() {

                boolean ret = false;

                switch (type) {
                    case PINPAD:
                        ret = sendFilePinpad(type, path);
                        break;
                    default:
                        break;
                }

                switch (callback) {
                    case PRIVATE:
                        for (Map.Entry<String, IMgtPrivateServiceListener> listener : mIMgtPrivateServiceListener
                                .entrySet()) {
                            try {
                                listener.getValue().onSentFilePinpad(ret);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                        }
                        break;
                    case PUBLIC:
                        for (Map.Entry<String, IMgtServiceListener> listener : mIMgtServiceListener
                                .entrySet()) {
                            // TODO Public版を作る際に実装する
                        }
                        break;
                    default:
                        break;
                }
            }
        };

        thread.start();

        return true;
    }

    private boolean sendFilePinpad(UpdateDeviceType type, final String path) {
        File file = new File(path);
        ResponseAck responseAck = new ResponseAck();

        // IPL開始コマンド
        RequestIplStart requestIplStart = new RequestIplStart(file.length());
        ResponseIplStart responseIplStart = new ResponseIplStart();

        if (!request(type, requestIplStart, responseAck, TIME_OUT)) {
            return false;
        }

        if (!response(type, responseIplStart, TIME_OUT_IPL_START)) {
            return false;
        }

        try {
            // IPLデータコマンド
            FileInputStream fis = new FileInputStream(path);
            byte[] buffer = new byte[1024];

            int read = 0;
            int num = 0;
            int write = 0;
            while ((read = fis.read(buffer)) != -1) {
                if (read < buffer.length) {
                    byte[] tmp = new byte[read];
                    System.arraycopy(buffer, 0, tmp, 0, read);
                    buffer = tmp;
                }

                RequestIplData requestIplData = new RequestIplData(num, buffer);
                ResponseIplData responseIplData = new ResponseIplData();
                responseAck = new ResponseAck();
                write += read;

                if (!request(type, requestIplData, responseAck, TIME_OUT)) {
                    sendIplIntrruptionPinpad(type);
                    return false;
                }

                if (!response(type, responseIplData, TIME_OUT)) {
                    sendIplIntrruptionPinpad(type);
                    return false;
                }
                num++;
                buffer = new byte[1024];
            }
            mIsAvailableUpdate = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            sendIplIntrruptionPinpad(type);
            return false;
        }
        return true;
    }

    private void sendIplIntrruptionPinpad(UpdateDeviceType type) {
        ResponseAck responseAck = new ResponseAck();
        RequestIplInterruption requestIplInterruption = new RequestIplInterruption();
        ResponseIplInterruption responseIplInterruption = new ResponseIplInterruption();
        request(type, requestIplInterruption, responseAck, TIME_OUT);
        response(type, responseIplInterruption, TIME_OUT);
    }

    private boolean execUpdatePinpad(UpdateDeviceType type) {
        ResponseAck responseAck = new ResponseAck();

        clear(type, TIME_OUT);

        // IPL終了コマンド
        RequestIplEnd requestIplEnd = new RequestIplEnd();
        ResponseIplEnd responseIplEnd = new ResponseIplEnd();
        if (!request(type, requestIplEnd, responseAck, TIME_OUT_WRITE_ROM)) {
            return false;
        }

        if (!response(type, responseIplEnd, TIME_OUT_WRITE_ROM)) {
            return false;
        }

        return true;
    }

    private boolean checkHealthPinpad(UpdateDeviceType type) {
        RequestDeviceInformation requestDeviceInformation = new RequestDeviceInformation();
        ResponseDeviceInformation responseDeviceInformation = new ResponseDeviceInformation();
        if (!request(type, requestDeviceInformation, responseDeviceInformation, TIME_OUT)) {
            return false;
        }

        return true;
    }

    private boolean request(UpdateDeviceType type, RequestData request, ResponseData response,
            int timeout) {
        ControlDeviceManager device = mControlDeviceManagerMap.get(type);

        if (device == null) {
            return false;
        }

        if (!device.write(request, timeout)) {
            return false;
        }

        byte[] buffer;
        if ((buffer = device.read(timeout)) != null) {
            if (isTimeout(buffer)) {
                return false;
            }
            if (!response.inputPinpadResult(buffer)) {
                return false;
            }
        } else {
            return false;
        }

        return true;
    }

    private boolean response(UpdateDeviceType type, ResponseData response, int timeout) {
        ControlDeviceManager device = mControlDeviceManagerMap.get(type);

        if (device == null) {
            return false;
        }

        byte[] buffer;
        if ((buffer = device.read(timeout)) != null) {
            if (isTimeout(buffer)) {
                return false;
            }
            if (!response.inputPinpadResult(buffer)) {
                return false;
            }
        } else {
            return false;
        }

        return true;
    }

    private boolean clear(UpdateDeviceType type, int timeout) {
        ControlDeviceManager device = mControlDeviceManagerMap.get(type);

        if (device == null) {
            return false;
        }

        byte[] buffer = device.read(timeout);
        return true;
    }

    /**
     * @brief タイムアウトかどうか判定する
     * @param buffer 確認する
     * @return タイムアウトかどうか
     */
    private boolean isTimeout(byte[] buffer) {
        if (buffer != null && buffer[0] == 0x00) {
            return true;
        }
        return false;
    }

    /**
     * @brief デバイスコントロール管理クラスを設定する
     * @param controlDeviceManager デバイスコントロール管理クラス
     */
    public void putControlDeviceManager(UpdateDeviceType type,
            ControlDeviceManager controlDeviceManager) {
        mControlDeviceManagerMap.put(type, controlDeviceManager);
    }

    /**
     * @brief 非接触ICカードリーダライタ操作クラスを設定する
     * @param nonContactICCard the nonContactICCard to set
     */
    public void setNonContactICCard(NonContactICCard nonContactICCard) {
        mNonContactICCard = nonContactICCard;
    }

    private byte[] readFile(String filePath) {
        byte[] result = null;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(filePath);
            result = new byte[fis.available()];
            fis.read(result);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return result;
        } catch (IOException e) {
            e.printStackTrace();
            return result;
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    /**
     * FW 更新情報と接続中非接触ICカードリーダライタを比較しアップデートの必要有無を判定する
     * 
     * @param updateInfo 更新情報
     * @param curtPFData PF バージョン
     * @param curtAPDataMap AP バージョン
     * @return アップデートの必要有無
     */
    public boolean needUpdateNonContactICCard(EmcrwUpdateInfo updateInfo,
            EmcrwPlatformData curtPFData, EmcrwApplicationDataMap curtAPDataMap) {

        // アップデートの必要有無
        boolean ret = new ContactLessICRWUpdateTarget(curtAPDataMap, curtPFData, updateInfo)
                .isNeedUpdate();

        // PDS(管理) への通知用に、周辺機器の品番・製造番号・ファームウェアバージョンを設定する
        // PDS に通知する fwvRw は、RW 統一バージョンに判定フラグを追加したもの
        // 判定フラグ：PF と各 AP が 全て一致 = 0, 不一致あり = 1
        // ※ アップデートの必要有無とは異なる
        int flag = updateInfo.equalsVersion(curtPFData, curtAPDataMap) ? 0 : 1;
        String status = updateInfo.getRWUnityVersion() + flag;

        mTerminalStatusManager.setRWStatus(mNonContactICCard.getModel(), mNonContactICCard.getSno(), status);

        return ret;
    }

    /**
     * wait
     * 
     * @param ms 待ち時間
     */
    private void wait(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 最大待ち時間指定のRWリセット要求
     *
     * @param timeout RWリセット最大待ち時間
     * @return true:RW使用可能状態, false:RWリセットタイムアウトまたはRWリセット失敗
     */
    private boolean resetRw(long timeout) {
        Log.d(TAG, "rw reset start. timeout=" + timeout);

        // RWリセット実行、失敗した場合は即時復帰
        boolean ret = mNonContactICCard.reset();
        if (!ret) {
            return ret;
        }

        // RWが未接続または未認証な場合は認証完了を待つ(指定された最大待ち時間まで)
        long now = SystemClock.elapsedRealtime();
        long end = now + timeout;

        // RWリセット直後はRWがリセット準備中で状態がRW_STATE_USE_NONEである
        // 場合があるため、リセットが実行されるのを待ってから状態チェックをする
        wait(10000);
        Log.d(TAG, "start check rw status.");
        while (true) {
            if (mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_NONE) {
                Log.d(TAG, "rw reset finish.");
                return true;
            }
            wait(1000);
            now = SystemClock.elapsedRealtime();
            Log.d(TAG, " now=" + now + ", end=" + end);
            if (now > end) {
                Log.d(TAG, "rw reset timeout.");
                return false;
            }
        }
    }

    public void setTerminalStatusManager(TerminalStatusManager manager) {
        mTerminalStatusManager = manager;
    }

}
