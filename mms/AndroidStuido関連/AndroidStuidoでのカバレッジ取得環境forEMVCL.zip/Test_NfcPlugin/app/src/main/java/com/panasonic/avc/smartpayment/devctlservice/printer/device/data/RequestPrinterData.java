
package com.panasonic.avc.smartpayment.devctlservice.printer.device.data;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.PrinterDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;

/**
 * プリンタ要求データ
 */
public class RequestPrinterData {

    /** @brief STX */
    private byte mStx = PinpadDefine.STX_CODE;

    /** @brief コマンド種別 */
    protected int mCommandId;

    /** @brief コマンド詳細 */
    protected int mCommandDetail;

    /** @brief SEQ */
    protected int mSequence;

    /** @brief CRC */
    private int mCrc;

    /**
     * @brief コンストラクタ
     */
    public RequestPrinterData() {

    }

    /**
     * @brief STXを取得する
     * @return STX
     */
    public byte getStx() {
        return mStx;
    }

    /**
     * @brief STXを設定する
     * @param stx STX
     */
    public void setStx(byte stx) {
        mStx = stx;
    }

    /**
     * @brief コマンド種別を取得する
     * @return コマンド種別
     */
    public int getCommandId() {
        return mCommandId;
    }

    /**
     * @brief コマンド種別を設定する
     * @param commandId コマンド種別
     */
    public void setCommandId(int commandId) {
        mCommandId = commandId;
    }

    /**
     * @brief コマンド詳細を取得する
     * @return コマンド詳細
     */
    public int getCommandDetail() {
        return mCommandDetail;
    }

    /**
     * @brief コマンド詳細を設定する
     * @param commandDetail コマンド詳細
     */
    public void setCommandDetail(int commandDetail) {
        mCommandDetail = commandDetail;
    }

    /**
     * @brief シーケンス番号を取得する
     * @return シーケンス番号
     */
    public int getSequence() {
        return mSequence;
    }

    /**
     * @brief シーケンス番号を設定する
     * @param sequence シーケンス番号
     */
    public void setSequence(int sequence) {
        mSequence = sequence;
    }

    /**
     * @brief CRCを取得する
     * @return CRC
     */
    public int getCrc() {
        return mCrc;
    }

    /**
     * @brief CRCを設定する
     * @param crc CRC
     */
    public void setCrc(int crc) {
        mCrc = crc;
    }

    /**
     * @brief パラメータ部を合成しコマンドに変換する
     * @param parameter パラメータ部
     * @return コマンド
     */
    protected byte[] toCommand(byte[] parameter) {

        int len = 0;

        if (parameter != null) {
            len = parameter.length;
        }

        byte[] data = new byte[PrinterDefine.DATA_SIZE_WITHOUT_PARAMETER + len];
        byte[] calcCRC = new byte[PrinterDefine.CRC_CALC_SIZE_WITHOUT_PARAMETER + len];

        data[0] = mStx;
        data[1] = 0x00;
        data[2] = (byte) (mCommandId & 0x00ff);
        data[3] = (byte) ((mCommandId >> 8) & 0x00ff);
        data[4] = (byte) (mCommandDetail & 0x00ff);
        data[5] = (byte) ((mCommandDetail >> 8) & 0x00ff);
        data[6] = (byte) (mSequence & 0x00ff);
        data[7] = (byte) ((mSequence >> 8) & 0x00ff);
        data[8] = (byte) (len & 0x00ff);
        data[9] = (byte) ((len >> 8) & 0x00ff);

        if (len != 0) {
            System.arraycopy(parameter, 0, data, 10, len);
        }

        System.arraycopy(data, 2, calcCRC, 0, PrinterDefine.CRC_CALC_SIZE_WITHOUT_PARAMETER + len);

        int crc = CalcUtil.createCRC(calcCRC);

        // CRC付与
        data[data.length - 1] = (byte) (crc & 0x00ff);
        data[data.length - 2] = (byte) (crc >> 8 & 0x00ff);

        return data;
    }

    /**
     * @brief コマンドを作成する
     * @return コマンド
     */
    public byte[] toCommand() {
        return toCommand(null);
    }

    /**
     * @brief データの上限下限チェック
     * @return 問題があるかどうか
     */
    public boolean isValidValue() {
        return false;
    }

}
