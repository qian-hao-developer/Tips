
package com.panasonic.avc.smartpayment.devctlservice.share.result.spad;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

public class ResultGetInkingThreshold extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultGetInkingThreshold(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultGetInkingThreshold() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultGetInkingThreshold> CREATOR = new Parcelable.Creator<ResultGetInkingThreshold>() {

        @Override
        public ResultGetInkingThreshold createFromParcel(Parcel in) {
            return new ResultGetInkingThreshold(in);
        }

        @Override
        public ResultGetInkingThreshold[] newArray(int size) {
            return new ResultGetInkingThreshold[size];
        }
    };
}
