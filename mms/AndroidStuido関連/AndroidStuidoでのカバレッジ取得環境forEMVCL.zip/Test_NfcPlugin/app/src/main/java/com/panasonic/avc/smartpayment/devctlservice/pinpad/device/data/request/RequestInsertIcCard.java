
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.request;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * カード挿入要求クラス
 */
public class RequestInsertIcCard extends RequestData {

    /** @brief マスターコマンド */
    private static final byte MASTER_COMMAND = 0x05;

    /** @brief サブコマンド */
    private static final byte SUB_COMMAND = 0x00;

    /** @brief コマンドの長さ */
    private static final int LENGTH = 0x000a;

    /** @brief 音声ガイダンス設定 */
    public enum InsertIcCardSound {
        NONE((byte) 0x00),
        JAPAN((byte) 0x80),
        US((byte) 0xC0);

        private final byte mNum;

        private InsertIcCardSound(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief オートバックライトオフ設定 */
    public enum InsertIcCardBackLight {
        NONE((byte) 0x00),
        AUTO_1MIN((byte) 0x01),
        AUTO_5MIN((byte) 0x02);

        private final byte mNum;

        private InsertIcCardBackLight(byte num) {
            mNum = num;
        }

        public byte getNum() {
            return mNum;
        }
    }

    /** @brief タイムアウト時間 */
    private int mIcTimeOut;

    /** @brief 音声ガイダンス */
    private InsertIcCardSound mSound;

    /** @brief オートバックライトオフ */
    private InsertIcCardBackLight mBackLight;

    /**
     * @brief コンストラクタ
     * @param[in] icTimeOut タイムアウト時間
     */
    public RequestInsertIcCard(int icTimeOut, InsertIcCardSound sound, InsertIcCardBackLight light) {
        mMainCommand = MASTER_COMMAND;
        mSubCommand = SUB_COMMAND;
        mId = CommandId.DeviceToPinpad;
        mIcTimeOut = icTimeOut;
        mSound = sound;
        mBackLight = light;
    }

    /**
     * @brief タイムアウト時間を取得します
     * @retun タイムアウト時間
     */
    public int getIcTimeOut() {
        return mIcTimeOut;
    }

    /**
     * @brief タイムアウト時間を設定します
     * @param[in] タイムアウト時間
     */
    public void setIcTimeOut(int icTimeOut) {
        mIcTimeOut = icTimeOut;
    }

    /**
     * @brief 音声ガイダンス設定を取得します
     * @retun 音声ガイダンス設定
     */
    public InsertIcCardSound getSound() {
        return mSound;
    }

    /**
     * @brief 音声ガイダンスを設定します
     * @param[in] 音声ガイダンス設定
     */
    public void setSound(InsertIcCardSound sound) {
        mSound = sound;
    }

    /**
     * @brief オートバックライトオフ設定を取得します
     * @retun オートバックライトオフ設定
     */
    public InsertIcCardBackLight getBackLight() {
        return mBackLight;
    }

    /**
     * @brief オートバックライトオフを設定します
     * @param[in] オートバックライトオフ設定
     */
    public void setBackLight(InsertIcCardBackLight backLight) {
        mBackLight = backLight;
    }

    /**
     * @see RequestData#toCommand()
     */
    @Override
    public byte[] toCommand() {

        if (!isValidValue()) {
            return null;
        }

        byte[] paramater = new byte[LENGTH];

        paramater[0] = (byte) (mSequence & 0x00ff);
        paramater[1] = (byte) ((mSequence >> 8) & 0x00ff);
        paramater[2] = 0;
        paramater[3] = 0;
        paramater[4] = 0;
        paramater[5] = 0;
        paramater[6] = mSound.getNum();
        paramater[7] = 0;
        paramater[8] = mBackLight.getNum();
        paramater[9] = (byte) (mIcTimeOut & 0xff);

        return toCommand(paramater);
    }

    /**
     * @see RequestData#isValidValue()
     */
    @Override
    public boolean isValidValue() {

        if (mSound == null) {
            return false;
        }

        if (mBackLight == null) {
            return false;
        }

        if (!(3 <= mIcTimeOut && mIcTimeOut <= 180)) {
            return false;
        }

        return true;
    }

}
