
package com.panasonic.avc.smartpayment.devctlservice.share.result.duk;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.result.ResultData;

/**
 * ResultInitDuk処理結果データ
 */
public class ResultInitDuk extends ResultData {

    /**
     * @brief コンストラクタ
     */
    public ResultInitDuk(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultInitDuk() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultInitDuk> CREATOR = new Parcelable.Creator<ResultInitDuk>() {
        public ResultInitDuk createFromParcel(Parcel in) {
            return new ResultInitDuk(in);
        }

        public ResultInitDuk[] newArray(int size) {
            return new ResultInitDuk[size];
        }
    };

}
