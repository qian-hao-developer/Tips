
package com.panasonic.avc.smartpayment.devctlservice.share.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * レスポンス用共通クラス
 */
public class ResponseData {

    /** @brief 周辺装置処理結果 */
    private int mDevice;

    /** @brief 周辺装置処理結果タグ */
    protected static final String DEVICE = "device";

    /** @brief UPOS処理結果 */
    private int mUpos;

    /** @brief UPOS処理結果タグ */
    protected static final String UPOS = "upos";

    /** @brief デバッグ用文字列：不正な値の場合 */
    private static final String ERROR_INVALID = "Invalid Value";

    /** @brief STXコード */
    private byte mStx = PinpadDefine.STX_CODE;

    /** @brief ID */
    protected CommandId mId;

    /** @brief メインコマンド */
    protected byte mMainCommand;

    /** @brief サブコマンド */
    protected byte mSubCommand;

    /** @brief ETXコード */
    private byte mEtx = PinpadDefine.ETX_CODE;

    /** @brief CRC */
    private int mCrc;

    /** @brief ログ出力 */
    protected LoggingManager mLoggingManager = LoggingManager.getInstance();

    public ResponseData() {

    }

    /**
     * @brief STXを取得する
     * @return STX
     */
    public byte getStx() {
        return mStx;
    }

    /**
     * @brief STXを設定する
     * @param stx STX
     */
    public void setStx(byte stx) {
        mStx = stx;
    }

    /**
     * @brief IDを取得する
     * @return ID
     */
    public CommandId getId() {
        return mId;
    }

    /**
     * @brief IDを設定する
     * @param id ID
     */
    public void setId(CommandId id) {
        mId = id;
    }

    /**
     * @brief メインコマンドを取得する
     * @return メインコマンド
     */
    public byte getMainCommand() {
        return mMainCommand;
    }

    /**
     * @brief メインコマンドを設定する
     * @param mainCommand メインコマンド
     */
    public void setMainCommand(byte mainCommand) {
        mMainCommand = mainCommand;
    }

    /**
     * @brief サブコマンドを取得する
     * @return サブコマンド
     */
    public byte getSubCommand() {
        return mSubCommand;
    }

    /**
     * @brief サブコマンドを設定する
     * @param subCommand サブコマンド
     */
    public void setSubCommand(byte subCommand) {
        mSubCommand = subCommand;
    }

    /**
     * @brief ETXを取得する
     * @return ETX
     */
    public byte getEtx() {
        return mEtx;
    }

    /**
     * @brief ETXを設定する
     * @param etx ETX
     */
    public void setEtx(byte etx) {
        mEtx = etx;
    }

    /**
     * @brief 周辺装置処理結果を取得します
     * @return 周辺装置処理結果
     */
    public int getDevice() {
        return mDevice;
    }

    /**
     * @brief 周辺装置処理結果を設定します
     * @param[in] device 周辺装置処理結果
     */
    public void setDevice(int device) {
        mDevice = device;
    }

    /**
     * @brief 周辺装置処理結果を取得します
     * @return
     */
    public int getUpos() {
        return mUpos;
    }

    /**
     * @brief UPOS処理結果を設定します
     * @param[in] upos UPOS処理結果
     */
    public void setUpos(int upos) {
        mUpos = upos;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }

    /**
     * @brief レスポンスデータを解析する(データ長、CRC)
     * @param bytes チェックしたいバイト列
     * @return 成否
     */
    protected boolean checkResponseData(byte[] bytes) {

        if (bytes == null || bytes.length < PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER) {
            return false;
        }

        if (bytes[0] != mStx) {
            return false;
        }

        if (bytes[bytes.length - PinpadDefine.CRC_SIZE - 1] != mEtx) {
            return false;
        }

        byte[] calcCRC = new byte[bytes.length - PinpadDefine.CRC_NOT_CALC_SIZE];

        System.arraycopy(bytes, PinpadDefine.STX_SIZE, calcCRC, 0, bytes.length
                - PinpadDefine.CRC_NOT_CALC_SIZE);

        int crc = CalcUtil.createCRC(calcCRC);

        int inputCrc = (int) ((bytes[bytes.length - PinpadDefine.CRC_SIZE] & 0xff) << 8)
                | (int) (bytes[bytes.length - PinpadDefine.CRC_SIZE + 1] & 0xff);

        if (crc != inputCrc) {
            return false;
        }

        return true;
    }

    /**
     * @brief PINPADからのレスポンスをデータクラスに反映する
     * @param bytes バイト列
     * @return 反映できたかどうか
     */
    public boolean inputPinpadResult(byte[] bytes) {
        return false;
    }

    /**
     * @brief PINPADからのレスポンスをデータクラスに反映する
     * @param bytes1 バイト列
     * @param bytes2 バイト列
     * @return 反映できたかどうか
     */
    public boolean inputPinpadResult(byte[] bytes1, byte[] bytes2) {
        return false;
    }

    /**
     * @brief PINPADからのレスポンスをデータサイズにカットする
     * @param bytes レスポンスデータ
     * @return カット後のデータ
     */
    protected byte[] cutPinpadResult(byte[] bytes) {
        if (bytes == null || bytes.length < PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER) {
            return null;
        }

        byte low = bytes[PinpadDefine.INDEX_LEN_1];
        byte high = bytes[PinpadDefine.INDEX_LEN_2];

        int len = CalcUtil.toInt(low, high) + PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER;

        if (bytes.length < len) {
            return null;
        }

        byte[] buffer = new byte[len];

        System.arraycopy(bytes, 0, buffer, 0, len);

        return buffer;
    }

}
