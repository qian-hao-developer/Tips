
package com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.LoggingManager;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine.CommandId;

/**
 * デバイスへの要求用クラス
 */
public class RequestData {

    /** @brief ログ用タグ */
    private static final String TAG = RequestData.class.getSimpleName();

    /** @brief ログ表示 */
    private LoggingManager mLoggingManager = LoggingManager.getInstance();

    /** @brief STX */
    private byte mStx = PinpadDefine.STX_CODE;

    /** @brief ID */
    protected CommandId mId;

    /** @brief MC */
    protected byte mMainCommand;

    /** @brief SC */
    protected byte mSubCommand;

    /** @brief ETX */
    private byte mEtx = PinpadDefine.ETX_CODE;

    /** @brief CRC */
    private int mCrc;

    /** @brief SEQ */
    protected int mSequence;

    /**
     * コンストラクタ
     */
    public RequestData() {

    }

    /**
     * @brief STXを取得する
     * @return STX
     */
    public byte getStx() {
        return mStx;
    }

    /**
     * @brief STXを設定する
     * @param stx STX
     */
    public void setStx(byte stx) {
        mStx = stx;
    }

    /**
     * @brief IDを取得する
     * @return ID
     */
    public CommandId getId() {
        return mId;
    }

    /**
     * @brief IDを設定する
     * @param ID
     */
    public void setId(CommandId id) {
        mId = id;
    }

    /**
     * @brief メインコマンドを取得する
     * @return メインコマンド
     */
    public byte getMainCommand() {
        return mMainCommand;
    }

    /**
     * @brief メインコマンドを設定する
     * @param mainCommand メインコマンド
     */
    public void setMainCommand(byte mainCommand) {
        mMainCommand = mainCommand;
    }

    /**
     * @brief サブコマンドを取得する
     * @return サブコマンド
     */
    public byte getSubCommand() {
        return mSubCommand;
    }

    /**
     * @brief サブコマンドを設定する
     * @param subCommand サブコマンド
     */
    public void setSubCommand(byte subCommand) {
        mSubCommand = subCommand;
    }

    /**
     * @brief ETXを取得する
     * @return ETX
     */
    public byte getEtx() {
        return mEtx;
    }

    /**
     * @brief ETXを設定する
     * @param etx ETX
     */
    public void setEtx(byte etx) {
        mEtx = etx;
    }

    /**
     * @brief CRCを取得する
     * @return CRC
     */
    public int getCrc() {
        return mCrc;
    }

    /**
     * @brief CRCを設定する
     * @param crc CRC
     */
    public void setCrc(int crc) {
        mCrc = crc;
    }

    /**
     * @brief シーケンス番号を設定する
     * @param sequence シーケンス番号
     */
    public void setSequence(int sequence) {
        mSequence = sequence;
    }

    /**
     * @brief パラメータ部を合成しコマンドに変換する
     * @param parameter パラメータ部
     * @return コマンド
     */
    protected byte[] toCommand(byte[] parameter) {

        int len = 0;

        if (parameter != null) {
            len = parameter.length;
        }

        byte[] data = new byte[PinpadDefine.DATA_SIZE_WITHOUT_PARAMETER + len];
        byte[] calcCRC = new byte[PinpadDefine.CRC_CALC_SIZE_WITHOUT_PARAMETER + len];

        data[0] = mStx;
        data[1] = mId.getId();
        data[2] = mMainCommand;
        data[3] = mSubCommand;
        data[4] = (byte) (len & 0x00ff);
        data[5] = (byte) ((len >> 8) & 0x00ff);

        if (len != 0) {
            System.arraycopy(parameter, 0, data, 6, len);
        }

        data[6 + len] = mEtx;

        System.arraycopy(data, 1, calcCRC, 0, PinpadDefine.CRC_CALC_SIZE_WITHOUT_PARAMETER + len);

        int crc = CalcUtil.createCRC(calcCRC);

        // CRC付与
        data[data.length - 1] = (byte) (crc & 0x00ff);
        data[data.length - 2] = (byte) (crc >> 8 & 0x00ff);

        // String log = "";
        // for (int i = 0; i < data.length; i++) {
        // log += (Integer.toHexString(data[i] & 0xff) + " ");
        // }
        // mLoggingManager.d(TAG, "data: " + log);

        // log = "";
        // for (int i = 0; i < calcCRC.length; i++) {
        // log += (Integer.toHexString(calcCRC[i] & 0xff) + " ");
        // }
        // mLoggingManager.d(TAG, "crc: " + log);

        // log = "";
        // for (int i = 0; i < len; i++) {
        // log += (Integer.toHexString(parameter[i] & 0xff) + " ");
        // }
        // mLoggingManager.d(TAG, "parameter: " + log);

        return data;
    }

    /**
     * @brief コマンドを作成する
     * @return コマンド
     */
    public byte[] toCommand() {
        return toCommand(null);
    }

    /**
     * @brief データの上限下限チェック
     * @return 問題があるかどうか
     */
    public boolean isValidValue() {
        return false;
    }

}
