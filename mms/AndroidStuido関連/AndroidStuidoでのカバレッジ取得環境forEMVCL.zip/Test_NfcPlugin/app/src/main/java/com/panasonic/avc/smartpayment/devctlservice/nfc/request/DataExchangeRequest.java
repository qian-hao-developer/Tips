package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

/**
 * Data Exchange コマンド
 */
public class DataExchangeRequest extends BaseRequest {

    /** @brief MC */
    private static byte MAINCOMMAND = (byte) 0x80;
    /** @brief SC */
    private static byte SUBCOMMAND = (byte) 0x43;

    /** @brief DataExchangeデータ. */
    private byte[] mDataExchangeInfo;

    /**
     * DataExchangeデータを設定する.
     * 
     * @param dataExchangeInfo DataExchangeデータ
     */
    public void setDataExchangeInfo(byte[] dataExchangeInfo) {
        mDataExchangeInfo = dataExchangeInfo;
    }

    /** Constructor */
    public DataExchangeRequest() {
        super(MAINCOMMAND, SUBCOMMAND);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isValidValue() {
        // ビットマップデータ必須チェック
        if (mDataExchangeInfo == null) {
            return false;
        }
        // サイズは可変の為チェック無し
        return true;
    }

    /**
     * コマンド用byte配列を取得する.
     * 
     * @return コマンド用byte配列
     */
    public byte[] toCommand() {

        return super.toCommand(mDataExchangeInfo);
    }
}
