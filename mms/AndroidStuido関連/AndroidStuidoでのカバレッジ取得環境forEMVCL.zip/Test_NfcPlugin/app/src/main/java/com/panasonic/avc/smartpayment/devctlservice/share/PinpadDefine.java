
package com.panasonic.avc.smartpayment.devctlservice.share;

/**
 * PINPADプロトコル用定義
 */
public class PinpadDefine {
    /**
     * @breif コマンドID
     */
    public enum CommandId {
        DeviceToPinpad((byte) 0x06), // 端末からPINPAD
        PinpadToDevice((byte) 0x07), // PINPADから端末
        DeviceToAll((byte) 0xf0), // 端末から全体
        PinpadToAll((byte) 0xf1); // PINPADから全体

        /** @brief ID管理用 */
        private final byte mId;

        /** @brief コンストラクタ */
        private CommandId(byte id) {
            mId = id;
        }

        /**
         * @brief IDを取得する
         * @return ID
         */
        public byte getId() {
            return mId;
        }
    }

    /** @brief Pinpad PID */
    public static final int PID = 0x0ebe;

    /** @brief Pinpad VID */
    public static final int VID = 0x04da;

    /** @brief コマンドのSTX値 */
    public static final byte STX_CODE = 0x02;

    /** @brief コマンドのETX値 */
    public static final byte ETX_CODE = 0x03;

    /** @brief STXサイズ */
    public static final int STX_SIZE = 1;

    /** @brief ヘッダーサイズ */
    public static final int HEADER_SIZE = 5;

    /** @brief ETXサイズ */
    public static final int ETX_SIZE = 1;

    /** @brief CRCサイズ */
    public static final int CRC_SIZE = 2;

    /** @brief シーケンスサイズ */
    public static final int SEQUENCE_SIZE = 2;

    /** @brief パラメータを除いた固定のデータサイズ */
    public static final int DATA_SIZE_WITHOUT_PARAMETER = STX_SIZE + HEADER_SIZE + ETX_SIZE
            + CRC_SIZE;

    /** @brief CRC計算領域におけるパラメータを除いたデータサイズ */
    public static final int CRC_CALC_SIZE_WITHOUT_PARAMETER = HEADER_SIZE + ETX_SIZE;

    /** @brief CRCを計算しない領域のサイズ */
    public static final int CRC_NOT_CALC_SIZE = STX_SIZE + CRC_SIZE;

    /** @brief ETXとCRCの合計サイズ */
    public static final int ETX_AND_CRC_SIZE = ETX_SIZE + CRC_SIZE;

    /** @brief STXの配列要素位置 */
    public static final int INDEX_STX = 0;

    /** @brief ETXの配列要素位置 */
    public static final int INDEX_ID = INDEX_STX + 1;

    /** @brief マスターコマンドの配列要素位置 */
    public static final int INDEX_MC = INDEX_ID + 1;

    /** @brief サブコマンドの配列要素位置 */
    public static final int INDEX_SC = INDEX_MC + 1;

    /** @brief データ長(low)の配列要素位置 */
    public static final int INDEX_LEN_1 = INDEX_SC + 1;

    /** @brief データ長(high)の配列要素位置 */
    public static final int INDEX_LEN_2 = INDEX_LEN_1 + 1;

    /** @brief パラメータの配列要素位置 */
    public static final int INDEX_PARAMETER = INDEX_LEN_2 + 1;

}
