
package com.panasonic.avc.smartpayment.devctlservice.share.result;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Prn処理結果データ
 */
public class ResultPrnData extends ResultData {
    /** @brief 周辺装置処理結果タグ */
    protected static final String DEVICE = "prndev";

    /**
     * @brief コンストラクタ
     */
    public ResultPrnData(Parcel in) {
        super(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResultPrnData() {

    }

    /**
     * @brief AIDL用
     */
    public static final Parcelable.Creator<ResultPrnData> CREATOR = new Parcelable.Creator<ResultPrnData>() {
        public ResultPrnData createFromParcel(Parcel in) {
            return new ResultPrnData(in);
        }

        public ResultPrnData[] newArray(int size) {
            return new ResultPrnData[size];
        }
    };

    /**
     * @see ResultData#toJSON()
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(DEVICE, getDevice());
            json.put(UPOS, getUpos());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
