
package com.panasonic.avc.smartpayment.devctlservice.share.response.icrw;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

import com.panasonic.avc.smartpayment.devctlservice.share.CalcUtil;
import com.panasonic.avc.smartpayment.devctlservice.share.PinpadDefine;
import com.panasonic.avc.smartpayment.devctlservice.share.response.ResponseData;

/**
 * ICCardEventデータ
 */
public class ResponseIcCard extends ResponseData implements Parcelable {

    /** @brief イベントの種類 */
    private boolean mIcCard;

    /** @brief イベントの種類タグ */
    private static final String ICCARD = "iccard";

    /** @brief コマンドの長さ **/
    private static final int LENGTH = 8;

    /** @brief カード挿入時のバイト列 **/
    private static final int INSERT_CARD = 0xa;

    /**
     * @brief コンストラクタ
     * @param iccard イベントの種類
     */
    public ResponseIcCard(boolean iccard) {
        mIcCard = iccard;
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseIcCard(Parcel in) {
        readFromParcel(in);
    }

    /**
     * @brief コンストラクタ
     */
    public ResponseIcCard() {

    }

    /**
     * @see Parcelable.Creator
     */
    public static final Parcelable.Creator<ResponseIcCard> CREATOR = new Parcelable.Creator<ResponseIcCard>() {

        /**
         * @see Parcelable.Creator#createFromParcel(Parcel)
         */
        public ResponseIcCard createFromParcel(Parcel in) {
            return new ResponseIcCard(in);
        }

        /**
         * @see Parcelable.Creator#newArray(int)
         */
        public ResponseIcCard[] newArray(int size) {
            return new ResponseIcCard[size];
        }
    };

    /**
     * @see Parcelable#describeContents()
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @see Parcelable#writeToParcel(Parcel, int)
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mIcCard ? 1 : 0);
    }

    /**
     * @brief 読み込み時に値をセットするメソッド
     * @param in パーセルデータ
     */
    public void readFromParcel(Parcel in) {
        mIcCard = in.readInt() == 1 ? true : false;
    }

    /**
     * @brief イベントの種類を取得する
     * @return イベントの種類
     */
    public boolean isIcCard() {
        return mIcCard;
    }

    /**
     * @brief イベントの種類を設定する
     * @param イベントの種類
     */
    public void setIcCard(boolean icCard) {
        mIcCard = icCard;
    }

    /**
     * @see ResponseData#inputPinpadResult(byte[])
     */
    @Override
    public boolean inputPinpadResult(byte[] bytes) {

        mIcCard = false;

        byte[] buffer = cutPinpadResult(bytes);

        if (buffer == null) {
            return false;
        }

        if (!checkResponseData(buffer)) {
            return false;
        }

        int len = CalcUtil.toInt(buffer[PinpadDefine.INDEX_LEN_1],
                buffer[PinpadDefine.INDEX_LEN_2]);
        if (len != LENGTH) {
            return false;
        }

        int status = buffer[PinpadDefine.INDEX_PARAMETER + 1];

        int error = buffer[PinpadDefine.INDEX_PARAMETER + 5];

        int sensor = buffer[PinpadDefine.INDEX_PARAMETER + 6];

        if ((sensor & 0x0f) == INSERT_CARD) {
            mIcCard = true;
        }

        int activation = buffer[PinpadDefine.INDEX_PARAMETER + 7];

        return true;
    }

    /**
     * @brief JSON形式での出力
     * @return 処理結果をJSON形式で返す(失敗時null)
     */
    @Override
    public String toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put(ICCARD, isIcCard());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return json.toString();
    }
}
