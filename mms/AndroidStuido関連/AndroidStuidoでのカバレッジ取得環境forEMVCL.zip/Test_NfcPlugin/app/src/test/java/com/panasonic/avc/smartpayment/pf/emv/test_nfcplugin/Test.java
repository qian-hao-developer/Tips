package com.panasonic.avc.smartpayment.pf.emv.test_nfcplugin;

import org.mockito.cglib.core.Predicate;
import org.mockito.exceptions.misusing.NullInsteadOfMockException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.String;
import java.lang.System;
//import java.lang.Comparable;
//import java.util.Comparator;
//import java.util.ArrayDeque;
//import java.util.ArrayList;
//import java.util.Comparator;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.NavigableMap;
//import java.util.Queue;
//import java.util.TreeSet;
//import java.util.TreeMap;
import java.util.*;

/**
 * Created by ryu on 2017/06/16.
 */

//関数型インタフェース
//Function<T,R> R apply(T t)
//BiFunction<T,U,R> R apply(T t, U u)

//Consumer<T> void accept(T t)
//BiConsumer<T,U> void accept(T t, U u)
//Supplier<T> T get()

//Predicate<T> boolean test(T t)
//BiPredicate<T,U> boolean test(T t, U u)

//UnaryOperator<T> T apply(T t)
//BinaryOperator<T> T apply(T t1, T t2)

//IntFunction<R> R apply(int value)
//ToIntFunction<T> int applyAsInt(T value)
//ToIntBiFunction<T,U> int applyAsInt(T t, U u)
//IntToDoubleFunction double applyAsDouble(int value)
//IntToLongFunction long applyAsLong(int value)

//IntConsumer void accept(int value)
//ToIntConsumer<T> int accept(T value)
//ObjIntConsumer<T> void accept(T t, int value)

//IntPredicate boolean test(int value)
//IntSupplier int getAsInt()
//IntUnaryOperator int applyAsInt(int value)
//IntBinaryOperator int applyAsInt(int left, int right)

//autoboxing

public class Test implements AutoCloseable{

    public static void main(String[] args){
        try(Test t = new Test()) {
            System.out.print("x");
        }catch (Exception e){

        }
    }
    public void close() throws Exception {
        throw new Exception("y");
    }
}


