package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.nfc.data.INSTALLEDFILEDATE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.SETTINGINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.VERSIONINFO;

import java.lang.reflect.Method;

/**
 * NfcPluginのUTクラス </br>
 */
public class NfcPluginTestOther extends ApplicationTestCase<Application> {

    public NfcPluginTestOther() {
        super(Application.class);
    }

    /**
     *  Test:GetPackageInfo <br/>
     *  ・異常(JSONException)
     */
    @SmallTest
    public void  testGetPackageInfoError() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            //到達不可能ロジック
            //JSONException
            nfcPlugin.GetPackageInfo("jsName", "jsVer", "pluginName", "pluginVer");
        } catch(Exception e) {
            e.printStackTrace();
            fail("testGetPackageInfoError 例外発生");
        }
    }

    /**
     *  Test:setKernel <br/>
     *  ・異常(JSONException)
     */
    @SmallTest
    public void  testSetKernelError() {
        INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
        VERSIONINFO versioninfo = new VERSIONINFO();

        byte[] bytes = {0x01, 0x02, 0x03, 0x04};

        versioninfo.ReaderVersion = bytes;
        versioninfo.EntryPointVersion = bytes;
        versioninfo.KernelC1Version = bytes;
        versioninfo.KernelC2Version = bytes;
        versioninfo.KernelC3Version = bytes;
        versioninfo.KernelC4Version = bytes;
        versioninfo.KernelC5Version = bytes;
        versioninfo.KernelC6Version = bytes;
        versioninfo.KernelC7Version = bytes;
        versioninfo.KernelC8Version = bytes;
        versioninfo.KernelC9Version = bytes;
        versioninfo.KernelC10Version = bytes;
        versioninfo.KernelC11Version = bytes;
        versioninfo.KernelC12Version = bytes;
        versioninfo.KernelC13Version = bytes;
        versioninfo.KernelC14Version = bytes;
        versioninfo.KernelC15Version = bytes;

        installedfiledate.CommonFile = bytes;
        installedfiledate.KernelC1File = bytes;
        installedfiledate.KernelC2File = bytes;
        installedfiledate.KernelC3File = bytes;
        installedfiledate.KernelC4File = bytes;
        installedfiledate.KernelC5File = bytes;
        installedfiledate.KernelC6File = bytes;
        installedfiledate.KernelC7File = bytes;
        installedfiledate.KernelC8File = bytes;
        installedfiledate.KernelC9File = bytes;
        installedfiledate.KernelC10File = bytes;
        installedfiledate.KernelC11File = bytes;
        installedfiledate.KernelC12File = bytes;
        installedfiledate.KernelC13File = bytes;
        installedfiledate.KernelC14File = bytes;
        installedfiledate.KernelC15File = bytes;
        installedfiledate.KernelC15File = bytes;

        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method mSetKernelMethod;
            mSetKernelMethod = NfcPlugin.class.getDeclaredMethod("setKernel", INSTALLEDFILEDATE.class, VERSIONINFO.class);
            mSetKernelMethod.setAccessible(true);
            //到達不可能ロジック
            //JSONException
            mSetKernelMethod.invoke(nfcPlugin, installedfiledate, versioninfo);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetKernelError 例外発生");
        }
    }

    /**
     *  Test:setDll <br/>
     *  ・異常(JSONException)
     */
    @SmallTest
    public void  testSetDllError() {
        INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();

        byte[] bytes = {0x01, 0x02, 0x03, 0x04, 0x05 };

        installedfiledate.FileDLL1 = bytes;
        installedfiledate.FileDLL2 = bytes;
        installedfiledate.FileDLL3 = bytes;
        installedfiledate.FileDLL4 = bytes;
        installedfiledate.FileDLL5 = bytes;
        installedfiledate.FileDLL6 = bytes;
        installedfiledate.FileDLL7 = bytes;
        installedfiledate.FileDLL8 = bytes;
        installedfiledate.FileDLL9 = bytes;
        installedfiledate.FileDLL10 = bytes;
        installedfiledate.FileDLL11 = bytes;
        installedfiledate.FileDLL12 = bytes;
        installedfiledate.FileDLL13 = bytes;
        installedfiledate.FileDLL14 = bytes;
        installedfiledate.FileDLL15 = bytes;

        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method mSetDllMethod;
            mSetDllMethod = NfcPlugin.class.getDeclaredMethod("setDll", INSTALLEDFILEDATE.class);
            mSetDllMethod.setAccessible(true);
            //到達不可能ロジック
            //JSONException
            mSetDllMethod.invoke(nfcPlugin, installedfiledate);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetDllError 例外発生");
        }
    }

    /**
     *  Test:setSettings <br/>
     *  ・異常(JSONException)
     */
    @SmallTest
    public void  testSetSettingsError() {
        SETTINGINFO settinginfo = new SETTINGINFO();
        settinginfo.VolumeOfSound = 0x01;

        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method mSetSettingsMethod;
            mSetSettingsMethod = NfcPlugin.class.getDeclaredMethod("setSettings", SETTINGINFO.class);
            mSetSettingsMethod.setAccessible(true);
            //到達不可能ロジック
            //JSONException
            mSetSettingsMethod.invoke(nfcPlugin, settinginfo);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetSettingsError 例外発生");
        }
    }

    /**
     *  Test:setVersion <br/>
     *  ・異常(JSONException)
     */
    @SmallTest
    public void  testSetVersionError() {
        SETTINGINFO settinginfo = new SETTINGINFO();

        byte[] bytes1 = {0x01, 0x02, 0x03, 0x04, 0x05 };
        byte[] bytes2 = {0x01, 0x02, 0x03, 0x04, 0x05 };
        byte[] bytes3 = {0x01, 0x02, 0x03, 0x04, 0x05 };
        byte[] bytes4 = new byte[80];

        for(int i=0; i< bytes4.length; i++)
            bytes4[i] = 0x41;

        settinginfo.Model = bytes1;
        settinginfo.SNo = bytes2;
        settinginfo.AplId = bytes3;
        settinginfo.AplVer = bytes4;

        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method mSetVersionMethod;
            mSetVersionMethod = NfcPlugin.class.getDeclaredMethod("setVersion", SETTINGINFO.class);
            mSetVersionMethod.setAccessible(true);
            //到達不可能ロジック
            //JSONException
            mSetVersionMethod.invoke(nfcPlugin, settinginfo);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetVersionError 例外発生");
        }
    }

    /**
     *  Test:setHealth <br/>
     *  ・異常(JSONException)
     */
    @SmallTest
    public void  testSetHealthError() {
        SETTINGINFO settinginfo = new SETTINGINFO();
        settinginfo.StatusFlag = 0x00;
        int upos = 1;

        try{
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method mSetHealthMethod;
            mSetHealthMethod = NfcPlugin.class.getDeclaredMethod("setHealth", int.class, SETTINGINFO.class);
            mSetHealthMethod.setAccessible(true);
            //到達不可能ロジック
            //JSONException
            mSetHealthMethod.invoke(nfcPlugin, upos, settinginfo);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetHealthError 例外発生");
        }
    }
}
