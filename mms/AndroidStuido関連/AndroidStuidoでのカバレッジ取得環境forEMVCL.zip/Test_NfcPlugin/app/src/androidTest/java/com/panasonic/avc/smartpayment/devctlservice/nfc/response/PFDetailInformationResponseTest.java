package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * PFDetailInformationResponseのUTクラス </br>
 */
public class PFDetailInformationResponseTest extends ApplicationTestCase<Application> {

    public PFDetailInformationResponseTest() {
        super(Application.class);
    }

    PFDetailInformationResponse pf_dir = new PFDetailInformationResponse();

    public boolean InputDevice(){
        boolean result;
        //byte[] buffer =  new byte[262];
        byte[] buffer =  new byte[261];
        buffer[0] = (byte) 0x03;
        buffer[1] = (byte) 0x25;
        buffer[2] = (byte) 0x04;
        buffer[3] = (byte) 0x00;
        buffer[4] = (byte) 0x01;
        //CalcUtil.toIntの結果：22, メモリ使用状態の個数 = 1(startIndex:6~12) → buffer Size: 28を要求
        //CalcUtil.toIntの結果：44, メモリ使用状態の個数 = 2(startIndex:28~34) → buffer Size: 50を要求
        //CalcUtil.toIntの結果：66, メモリ使用状態の個数 = 3(startIndex:50~56) → buffer Size: 72を要求
        //buffer[3] = 0x00, buffer[4] = 0x01に設定した場合、CalcUtil.toIntの結果は256
        //CalcUtil.toIntの結果：256, メモリ使用状態の個数 = 11(startIndex:50~56) → buffer Size: 262を要求
        result = pf_dir.inputDeviceResult(buffer);

        return result;
    }

    /**
     *  Test:PFDetailInformationResponse <br/>
     *  ・正常
     */
    @SmallTest
    public void  testPFDetailInformationResponse() {
        try{
            assertNotNull("testPFDetailInformationResponse", pf_dir);
        } catch(Exception e){
            e.printStackTrace();
            fail("testPFDetailInformationResponse 例外発生");
        }
    }

    /**
     *  Test:cloneMemoryNo <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneMemoryNo() {
        try{
            assertNull("testCloneMemoryNo", pf_dir.cloneMemoryNo());
            InputDevice();
            assertNotNull("testCloneMemoryNo", pf_dir.cloneMemoryNo());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneMemoryNo 例外発生");
        }
    }

    /**
     *  Test:cloneApId <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneApId() {
         try{
            assertNull("testCloneApId", pf_dir.cloneApId());
            InputDevice();
            assertNotNull("testCloneApId", pf_dir.cloneApId());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneApId 例外発生");
        }
    }

    /**
     *  Test:cloneStaticFROMSize <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneStaticFROMSize() {
        try{
            assertNull("testCloneStaticFROMSize", pf_dir.cloneStaticFROMSize());
            InputDevice();
            assertNotNull("testCloneStaticFROMSize", pf_dir.cloneStaticFROMSize());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneStaticFROMSize 例外発生");
        }
    }

    /**
     *  Test:cloneSwitchingFROMSize <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneSwitchingFROMSize() {
        try{
            assertNull("testCloneSwitchingFROMSize", pf_dir.cloneSwitchingFROMSize());
            InputDevice();
            assertNotNull("testCloneSwitchingFROMSize", pf_dir.cloneSwitchingFROMSize());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneSwitchingFROMSize 例外発生");
        }
    }

    /**
     *  Test:cloneStaticRAMSize <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneStaticRAMSize() {
        try{
            assertNull("testCloneStaticRAMSize", pf_dir.cloneStaticRAMSize());
            InputDevice();
            assertNotNull("testCloneStaticRAMSize", pf_dir.cloneStaticRAMSize());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneStaticRAMSize 例外発生");
        }
    }

    /**
     *  Test:cloneSwitchingRAMSize <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneSwitchingRAMSize() {
        try{
            assertNull("testCloneSwitchingRAMSize", pf_dir.cloneSwitchingRAMSize());
            InputDevice();
            assertNotNull("testCloneSwitchingRAMSize", pf_dir.cloneSwitchingRAMSize());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneSwitchingRAMSize 例外発生");
        }
    }

    /**
     *  Test:cloneVersion <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCloneVersion() {
        try{
            assertNull("testCloneVersion", pf_dir.cloneVersion());
            InputDevice();
            assertNotNull("testCloneVersion", pf_dir.cloneVersion());
        } catch(Exception e){
            e.printStackTrace();
            fail("testCloneVersion 例外発生");
        }
    }

    /**
     *  Test:inputDeviceResult <br/>
     *  ・準正常
     */
    @SmallTest
    public void testInputDeviceResult() {
        try {
            PFDetailInformationResponse response = new PFDetailInformationResponse();

            byte[] buffer =  new byte[5];
            buffer[0] = (byte) 0x03;
            buffer[1] = (byte) 0x25;
            buffer[2] = (byte) 0x04;
            buffer[3] = (byte) 0x00;
            buffer[4] = (byte) 0x00;

            // !super.checkResponseData(bytes)
            boolean ret1 = response.inputDeviceResult(null);
            assertEquals(false, ret1);

            // bytes[MAINCOMMAND_INDEX] != MASTER_COMMAND
            buffer[1] = (byte) 0x00;
            boolean ret2 = response.inputDeviceResult(buffer);
            assertEquals(false, ret2);

            // bytes[SUBCOMMAND_INDEX] != SUB_COMMAND
            buffer[1] = (byte) 0x25;
            buffer[2] = (byte) 0x00;
            boolean ret3 = response.inputDeviceResult(buffer);
            assertEquals(false, ret3);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInputDeviceResult 例外発生");
        }
    }
}
