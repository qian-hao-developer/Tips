package com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.TerminalStatusManager;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.icrw.ContactIcCard;
import com.panasonic.avc.smartpayment.devctlservice.share.UpdateDeviceType;
import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;

import java.lang.reflect.Field;

/**
 * ByteUtilのUTクラス </br>
 */
public class ManagementTestFull extends ApplicationTestCase<Application> {

    public ManagementTestFull() {
        super(Application.class);
    }

    /**
     *  Test:isDefferentVersion <br/>
     *  ・正常
     */
    @SmallTest
    public void  testIsDefferentVersion_FULL() {
        Management management = Management.getInstance();
        PdsClientManager pdsClientManager = new PdsClientManager();
        TerminalStatusManager mTerminalStatusManager = new TerminalStatusManager(pdsClientManager);
        management.setTerminalStatusManager(mTerminalStatusManager);

        ContactIcCard contactIcCard = ContactIcCard.getInstance();
        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        boolean ret;

        try {
            Field mContactIcCard = Management.class.getDeclaredField("mContactIcCard");
            mContactIcCard.setAccessible(true);

            // case PINPADを通らない場合
            byte[] bufferOpen1 = ByteUtil.hex2bin("020000002100000000000000000000000000000000000000000000312e30390000000000000000031bda");
            byte[] bufferOpen2 = ByteUtil.hex2bin("020000001a00000000000000000000000000000000000000000000000000303903ec35");
            controlDeviceManager.addByteList(bufferOpen1);
            controlDeviceManager.addByteList(bufferOpen2);
            contactIcCard.setControlDeviceManager(controlDeviceManager);
            mContactIcCard.set(management, contactIcCard);

            ret = management.isDefferentVersion(UpdateDeviceType.PRINTER);
            assertFalse("testIsDefferentVersion_FULL", ret);

            ret = management.isDefferentVersion(UpdateDeviceType.MSR);
            assertFalse("testIsDefferentVersion_FULL", ret);

            ret = management.isDefferentVersion(UpdateDeviceType.CONTACT_LESS_ICRW);
            assertFalse("testIsDefferentVersion_FULL", ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testIsDefferentVersion 例外発生");
        }
    }
}