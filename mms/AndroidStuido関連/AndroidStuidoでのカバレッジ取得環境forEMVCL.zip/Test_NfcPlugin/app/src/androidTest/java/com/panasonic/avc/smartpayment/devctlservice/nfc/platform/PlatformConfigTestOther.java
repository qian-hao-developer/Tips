package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.request.RWInformationRequest;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * PlatformConfigのUTクラス </br>
 */
public class PlatformConfigTestOther extends ApplicationTestCase<Application> {

    public PlatformConfigTestOther() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    private PlatformConfig setContext(TestControlDeviceManager controlDeviceManager, List<byte[]> bufferList) {

        PlatformConfig platformConfig = PlatformConfig.getInstance();

        if (controlDeviceManager == null) {
            controlDeviceManager = new TestControlDeviceManager();
        }

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);
        platformConfig.setContext(controlDeviceManager, nonContactICCard);

        return platformConfig;
    }

    // get current time
    private Calendar getCalendar() {
        Date date = new Date(System.currentTimeMillis());
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    /**
     *  Test:cipherData <br/>
     *  ・異常
     */
    @SmallTest
    public void  testCipherDataError() {
        PlatformConfig platformConfig = setContext(null, null);
        RWInformationRequest rwInfoReq = new RWInformationRequest();
        rwInfoReq.setCommDateTime(getCalendar());
        byte[] bytes = ByteUtil.hex2bin("01");

        try {
            Field mSessionKeyField = PlatformConfig.class.getDeclaredField("mSessionKey");
            mSessionKeyField.setAccessible(true);
            mSessionKeyField.set(platformConfig, bytes);

            Method internalWrite = PlatformConfig.class.getDeclaredMethod("internalWrite", byte[].class, int.class);
            internalWrite.setAccessible(true);
            // 有効ではないSessionKeyを設定してCipherの初期化(init)にてInvalidKeyExceptionの結果を出す。
            int ret = (Integer)internalWrite.invoke(platformConfig, rwInfoReq.toCommand(), 5000);
            assertEquals("testCipherDataError", -1, ret);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testCipherDataError 例外発生");
        }
    }
}





