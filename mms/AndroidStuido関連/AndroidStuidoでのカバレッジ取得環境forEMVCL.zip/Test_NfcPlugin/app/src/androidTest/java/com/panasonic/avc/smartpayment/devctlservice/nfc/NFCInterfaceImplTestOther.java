package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.nfc.data.INSTALLEDFILEDATE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.SETTINGINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.VERSIONINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.response.DeviceInformationResponse;
import com.panasonic.avc.smartpayment.devctlservice.nfc.response.PFDetailInformationResponse;
import com.panasonic.avc.smartpayment.devctlservice.nfc.response.RWInformationResponse;

import java.lang.reflect.*;
import java.util.Calendar;
import java.util.Date;

/**
 * NFCInterfaceImplのUTクラス </br>
 */
public class NFCInterfaceImplTestOther extends ApplicationTestCase<Application> {

    public NFCInterfaceImplTestOther() {
        super(Application.class);
    }

    /**
     *  Test:checkStatus_RWVer <br/>
     *  ・正常 <br/>
     *  ・準正常 <br/>
     */
    @SmallTest
    public void  testCheckStatus_RWVer() {
        NFCInterfaceImpl nfc_ii = NFCInterfaceImpl.getInstance();
        Method mCheckStatus_RWVerMethod;
        Field m_EMVStatus;
        int result;

        try{
            mCheckStatus_RWVerMethod = NFCInterfaceImpl.class.getDeclaredMethod("checkStatus_RWVer");
            mCheckStatus_RWVerMethod.setAccessible(true);
            m_EMVStatus = nfc_ii.getClass().getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            // 保持状態status：CLOSED
            m_EMVStatus.set(nfc_ii, NFCInterfaceImpl.EMVStatus.EMVCL_CLOSED);
            result = (int)mCheckStatus_RWVerMethod.invoke(nfc_ii);
            assertEquals("testCheckStatus_RWVer CLOSED", ApiReturnValues.E_CLOSED, result);

            // 保持状態status：OPENED
            m_EMVStatus.set(nfc_ii, NFCInterfaceImpl.EMVStatus.EMVCL_OPENED);
            result = (int)mCheckStatus_RWVerMethod.invoke(nfc_ii);
            assertEquals("testCheckStatus_RWVer OPENED", ApiReturnValues.SUCCESS, result);

            // 保持状態status：BUSY
            m_EMVStatus.set(nfc_ii, NFCInterfaceImpl.EMVStatus.EMVCL_BUSY);
            result = (int)mCheckStatus_RWVerMethod.invoke(nfc_ii);
            assertEquals("testCheckStatus_RWVer BUSY", ApiReturnValues.E_BUSY, result);

            // 保持状態status：CLAIMED
            m_EMVStatus.set(nfc_ii, NFCInterfaceImpl.EMVStatus.EMVCL_CLAIMED);
            result = (int)mCheckStatus_RWVerMethod.invoke(nfc_ii);
            assertEquals("testCheckStatus_RWVer CLAIMED", ApiReturnValues.E_ILLEGAL, result);

        } catch(Exception e){
            e.printStackTrace();
            fail("testCheckStatus_RWVer 例外発生");
        }
    }

    /**
     *  Test:setVerResponseData <br/>
     *  ・異常(ApiReturnValues.GetInfo.E_ILLEGALリターン) <br/>
     */
    @SmallTest
    public void  testSetVerResponseDataError() {
        NFCInterfaceImpl nfc_ii = NFCInterfaceImpl.getInstance();
        Method msetVerResponseDataMethod;

        //setVerResponseDataのメソッドのパラメータにnullがある場合、異常な結果を出す。
        RWInformationResponse rwInfoResp = null;
        PFDetailInformationResponse pfInfoResp = new PFDetailInformationResponse();
        SETTINGINFO SettingInfo = new SETTINGINFO();
        ApiReturnValues.GetInfo returnStatus;

        try{
            msetVerResponseDataMethod = NFCInterfaceImpl.class.getDeclaredMethod("setVerResponseData",
                    RWInformationResponse.class , PFDetailInformationResponse.class, SETTINGINFO.class);
            msetVerResponseDataMethod.setAccessible(true);
            returnStatus = (ApiReturnValues.GetInfo)msetVerResponseDataMethod.invoke(nfc_ii, rwInfoResp, pfInfoResp, SettingInfo);
            assertEquals("testSetVerResponseDataError", ApiReturnValues.GetInfo.E_ILLEGAL, returnStatus);
        } catch(Exception e){
            e.printStackTrace();
            fail("testSetVerResponseDataError 例外発生");
        }
    }

    /**
     *  Test:setResponseData <br/>
     *  ・正常 <br/>
     *  ・異常 <br/>
     */
    @SmallTest
    public void  testSetResponseData() {
        NFCInterfaceImpl nfc_ii = NFCInterfaceImpl.getInstance();
        Method mSetResponseDataMethod;

        // setResponseDataメソッドのパラメータがnullではない場合、正常な結果を出す。
        DeviceInformationResponse deviceInformationResponse = new DeviceInformationResponse();
        SETTINGINFO SettingInfo = new SETTINGINFO();
        VERSIONINFO VersionInfo = new VERSIONINFO();
        INSTALLEDFILEDATE InstalledFileDate = new INSTALLEDFILEDATE();
        ApiReturnValues.GetInfo returnStatus;

        try{
            mSetResponseDataMethod = NFCInterfaceImpl.class.getDeclaredMethod("setResponseData",
                    DeviceInformationResponse.class , SETTINGINFO.class, VERSIONINFO.class, INSTALLEDFILEDATE.class);
            mSetResponseDataMethod.setAccessible(true);

            // 正常：Null
            returnStatus = (ApiReturnValues.GetInfo)mSetResponseDataMethod.invoke
                    (nfc_ii, deviceInformationResponse, SettingInfo, VersionInfo, InstalledFileDate);
            assertEquals("testSetResponseData 正常：Null", ApiReturnValues.GetInfo.SUCCESS, returnStatus);

            // 正常：NotNull
            Date date = new Date();
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);

            for (int i = 1; i <= 15; i++) {
                Field mFileDLLDate = DeviceInformationResponse.class.getDeclaredField("mFileDLLDate" + i);
                mFileDLLDate.setAccessible(true);
                mFileDLLDate.set(deviceInformationResponse, cal);
            }

            returnStatus = (ApiReturnValues.GetInfo)mSetResponseDataMethod.invoke
                    (nfc_ii, deviceInformationResponse, SettingInfo, VersionInfo, InstalledFileDate);
            assertEquals("testSetResponseData 正常：NotNull", ApiReturnValues.GetInfo.SUCCESS, returnStatus);

            // 異常
            deviceInformationResponse = null;
            returnStatus = (ApiReturnValues.GetInfo)mSetResponseDataMethod.invoke
                    (nfc_ii, deviceInformationResponse, SettingInfo, VersionInfo, InstalledFileDate);
            assertEquals("testSetResponseData 異常", ApiReturnValues.GetInfo.E_ILLEGAL, returnStatus);

        } catch(Exception e){
            e.printStackTrace();
            fail("testSetResponseData 例外発生");
        }
    }

    /**
     *  Test:inputCheckEMVCL_GetRWVerInfo <br/>
     *  ・正常 <br/>
     *  ・準正常 <br/>
     */
    @SmallTest
    public void  testInputCheckEMVCL_GetRWVerInfo() {
        NFCInterfaceImpl nfc_ii = NFCInterfaceImpl.getInstance();
        Method mInputCheckEMVCL_GetRWVerInfoMethod;

        // inputCheckEMVCL_GetRWVerInfoメソッドのパラメータがnullではないかつ配列の長さが0ではない場合、正常な結果を出す。
        SETTINGINFO SettingInfo = new SETTINGINFO();
        INSTALLEDFILEDATE InstalledFileDate = new INSTALLEDFILEDATE();
        int[] ResultCode = { 1 };
        int[] ResultCodeExtended = { 1 };
        ApiReturnValues.GetInfo returnStatus;

        try{
            mInputCheckEMVCL_GetRWVerInfoMethod = NFCInterfaceImpl.class.getDeclaredMethod("inputCheckEMVCL_GetRWVerInfo",
                    SETTINGINFO.class , INSTALLEDFILEDATE.class, int[].class, int[].class);
            mInputCheckEMVCL_GetRWVerInfoMethod.setAccessible(true);

            // SUCCESS
            returnStatus = (ApiReturnValues.GetInfo)mInputCheckEMVCL_GetRWVerInfoMethod.invoke(nfc_ii,
                    SettingInfo, InstalledFileDate, ResultCode, ResultCodeExtended);
            assertEquals("testInputCheckEMVCL_GetRWVerInfo SUCCESS", ApiReturnValues.GetInfo.SUCCESS, returnStatus);

            // ILLEGAL：ALL NULL
            SettingInfo = null;
            InstalledFileDate = null;
            ResultCode = null;
            ResultCodeExtended = null;
            returnStatus = (ApiReturnValues.GetInfo)mInputCheckEMVCL_GetRWVerInfoMethod.invoke(nfc_ii,
                    SettingInfo, InstalledFileDate, ResultCode, ResultCodeExtended);
            assertEquals("testInputCheckEMVCL_GetRWVerInfo ILLEGAL：ALL NULL", ApiReturnValues.GetInfo.E_ILLEGAL, returnStatus);

            // ILLEGAL：length 0
            ResultCode = new int[0];
            ResultCodeExtended = new int[0];
            returnStatus = (ApiReturnValues.GetInfo)mInputCheckEMVCL_GetRWVerInfoMethod.invoke(nfc_ii,
                    SettingInfo, InstalledFileDate, ResultCode, ResultCodeExtended);
            assertEquals("testInputCheckEMVCL_GetRWVerInfo ILLEGAL：length 0", ApiReturnValues.GetInfo.E_ILLEGAL, returnStatus);

        } catch(Exception e){
            e.printStackTrace();
            fail("testInputCheckEMVCL_GetRWVerInfo 例外発生");
        }
    }
}
