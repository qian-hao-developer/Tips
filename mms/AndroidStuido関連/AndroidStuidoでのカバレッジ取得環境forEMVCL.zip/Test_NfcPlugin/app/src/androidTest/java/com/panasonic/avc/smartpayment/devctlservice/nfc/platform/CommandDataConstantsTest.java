package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * CommandDataConstantsのUTクラス </br>
 */
public class CommandDataConstantsTest extends ApplicationTestCase<Application> {

    public CommandDataConstantsTest() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    private PlatformConfig setContext(TestControlDeviceManager controlDeviceManager, List<byte[]> bufferList) {

        PlatformConfig platformConfig = PlatformConfig.getInstance();

        if (controlDeviceManager == null) {
            controlDeviceManager = new TestControlDeviceManager();
        }

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);

        platformConfig.setContext(controlDeviceManager, nonContactICCard);

        return platformConfig;
    }

    /**
     *  Test:calcCRC <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCalcCRC() {
        // readの返却値設定
        List<byte[]> bufferList = new ArrayList<byte[]>();
        byte[] buffer = ByteUtil.hex2bin("020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5");
        bufferList.add(buffer);
        byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB3265");
        PlatformConfig platformConfig = setContext(null, bufferList);

        try {
            Field mSessionKeyField = PlatformConfig.class.getDeclaredField("mSessionKey");
            mSessionKeyField.setAccessible(true);
            mSessionKeyField.set(platformConfig, sessionArray);

            Method internalReadMethod = PlatformConfig.class.getDeclaredMethod("internalRead", int.class);
            internalReadMethod.setAccessible(true);
            // crc != CommandDataConstants.calcCRC(crcTarget)を通らない正常
            byte[] ret = (byte[])internalReadMethod.invoke(platformConfig, 5000);
            assertNotNull("testCalcCRC", ret);
        } catch(Exception e){
            e.printStackTrace();
            fail("testCalcCRC 例外発生");
        }
    }

    /**
     *  Test:printByte <br/>
     *  ・正常
     */
    @SmallTest
    public void  testPrintByte() throws Exception {
        byte[] data = new byte[17];
        data[0] = 127;
        String tag = "tag";

        try{
            CommandDataConstants.printByte(data, tag);
        } catch(Exception e){
            e.printStackTrace();
            fail("testCalcCRC 例外発生");
        }
    }
}
