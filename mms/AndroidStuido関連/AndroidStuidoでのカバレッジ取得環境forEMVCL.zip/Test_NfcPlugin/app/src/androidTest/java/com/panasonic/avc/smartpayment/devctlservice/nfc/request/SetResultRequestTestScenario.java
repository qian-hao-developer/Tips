package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * SetResultRequestのUTクラス (シナリオ)<br/>
 */
public class SetResultRequestTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public SetResultRequestTestScenario() {
        super(Application.class);
    }

    /**
     * Test:isValidValue <br/>
     *   ・準正常 (結果通知データ必須チェックエラー) <br/>
     */
    @SmallTest
    public void testIsValidValue_err() {
        try {
            SetResultRequest setResultRequest = new SetResultRequest();

            // パターン：結果通知データ必須チェックエラー
            boolean ret = setResultRequest.isValidValue();

            // 結果確認
            assertEquals(false, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testIsValidValue_err");
        }
    }
}
