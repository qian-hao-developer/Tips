package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

/**
 * SetResultResponseのUTクラス (シナリオ)<br/>
 */
public class SetResultResponseTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public SetResultResponseTestScenario() {
        super(Application.class);
    }

    // ****************************** SetResultResponse.inputDeviceResult start ******************************

    /**
     * Test:inputDeviceResult <br/>
     *   ・準正常 <br/>
     */
    @SmallTest
    public void testInputDeviceResult_err() {
        try {
            SetResultResponse setResultResponse = new SetResultResponse();

            // パターン：checkResponseData エラー
            byte[] bytes = null;
            boolean ret = setResultResponse.inputDeviceResult(bytes);

            // 結果確認
            assertEquals(false, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInputDeviceResult_err");
        }
    }

    /**
     * Test:inputDeviceResult <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testInputDeviceResult_normal() {
        try {
            SetResultResponse setResultResponse = new SetResultResponse();

            // パターン：正常
            byte[] bytes = ByteUtil.hex2bin("0380010000");
            boolean ret = setResultResponse.inputDeviceResult(bytes);

            // 結果確認
            assertEquals(true, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInputDeviceResult_normal");
        }
    }

    // ****************************** SetResultResponse.inputDeviceResult end ******************************

    // ****************************** SetResultResponse.checkResponseData start ******************************

    /**
     * Test:checkResponseData <br/>
     *   ・準正常 <br/>
     */
    @SmallTest
    public void testCheckResponseData_err() {
        try {
            SetResultResponse setResultResponse = new SetResultResponse();

            // パターン：MAINCOMMAND エラー
            byte[] bytes1 = ByteUtil.hex2bin("0388010000");
            boolean ret1 = setResultResponse.checkResponseData(bytes1);
            assertEquals(false, ret1);

            // パターン：SUBCOMMAND エラー
            byte[] bytes2 = ByteUtil.hex2bin("0380110000");
            boolean ret2 = setResultResponse.checkResponseData(bytes2);
            assertEquals(false, ret2);

            // パターン：DATALENGTH_HIGH エラー
            byte[] bytes3 = ByteUtil.hex2bin("038001010011");
            boolean ret3 = setResultResponse.checkResponseData(bytes3);
            assertEquals(false, ret3);

            // パターン：DATALENGTH_LOW エラー
            byte[] bytes4 = ByteUtil.hex2bin("0380010001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2");
            boolean ret4 = setResultResponse.checkResponseData(bytes4);
            assertEquals(false, ret4);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCheckResponseData_err");
        }
    }

    // ****************************** SetResultResponse.checkResponseData end ******************************

    // ****************************** SetResultResponse.cutDeviceResult start ******************************

    /**
     * Test:cutDeviceResult <br/>
     *   ・準正常 <br/>
     */
    @SmallTest
    public void testCutDeviceResult_err() {
        try {
            SetResultResponse setResultResponse = new SetResultResponse();

            // パターン：super.cutDeviceResult エラー
            byte[] bytes = null;
            byte[] ret = setResultResponse.cutDeviceResult(bytes);

            // 結果確認
            assertEquals(null, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCutDeviceResult_err");
        }
    }

    // ****************************** SetResultResponse.cutDeviceResult end ******************************
}
