package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.DEINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.TRANSACTIONDATA;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.PlatformConfig;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * NFCInterfaceImplのUTクラス <br/>
 */
public class NFCInterfaceImplTestFull extends ApplicationTestCase<Application> {

    // StartTransaction：取引データ (mIsNeedExpand = false)
    private static final String TRAN_DATA = "{\"TransactionType\":\"00\",\"FunctionMode\":\"0000\",\"CommunicationTime\":\"000000000000\",\"BlockNumber\":\"0000\",\"AmountAuthorised\":\"000000011000\",\"AmountOther\":\"000000000000\",\"MerchantSpecificData\":\"00\",\"TLVData\":\"3030300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\"}";


    // コンストラクタ
    public NFCInterfaceImplTestFull() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    private NFCInterfaceImpl setContext(List<byte[]> bufferList, String sessionKey) throws Exception {

        NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
        PlatformConfig platformConfig = nfcInterfaceImpl.getPlatformConfig();
        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);

        // 相互認証用セッションキー
        byte[] sessionArray = ByteUtil.hex2bin(sessionKey);
        Field mSessionKey2 = NonContactICCard.class.getDeclaredField("mSessionKey2");
        mSessionKey2.setAccessible(true);
        mSessionKey2.set(nonContactICCard, sessionArray);

        platformConfig.setContext(controlDeviceManager, nonContactICCard);

        return nfcInterfaceImpl;
    }

    // 保持状態statusを変更する
    private void setEMVStatus(String status) throws Exception {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object statusObj = null;
            for (Object o : enumEMVStatus) {
                if (((Enum)o).name().equals(status)) {
                    statusObj = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, statusObj);

        } catch (Exception e) {
            throw e;
        }
    }

    // TRANSACTIONDATAを取得する
    private TRANSACTIONDATA getTransactionData() throws Exception {
        NfcPlugin nfcPlugin = NfcPlugin.getInstance();
        Method convertTransactionData = NfcPlugin.class.getDeclaredMethod("convertTransactionData", String.class);
        convertTransactionData.setAccessible(true);
        TRANSACTIONDATA transactionData = (TRANSACTIONDATA)convertTransactionData.invoke(nfcPlugin, TRAN_DATA);
        return transactionData;
    }

    // ****************************** EMVCL_Transaction start **********************************

    /**
     * Test:EMVCL_Transaction <br/>
     *   ・準正常 (RetryTimeout > 65535) <br/>
     */
    @SmallTest
    public void testEMVCL_Transaction_RetryTimeout() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            TRANSACTIONDATA transactionData = getTransactionData();
            int retryTimeout = 65536;

            // パターン：RetryTimeout > 65535
            int ret = nfcInterfaceImpl.EMVCL_Transaction(transactionData, retryTimeout);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_Transaction_RetryTimeout");
        }
    }

    /**
     * Test:EMVCL_Transaction <br/>
     *   ・準正常 (inputCheckEMVCL_Transactionの戻り値がSUCCESSではない) <br/>
     */
    @SmallTest
    public void testEMVCL_Transaction_inputCheckEMVCL_Transaction() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            TRANSACTIONDATA transactionData = null;
            int retryTimeout = 65535;

            // パターン：inputCheckEMVCL_Transactionの戻り値がSUCCESSではない
            int ret = nfcInterfaceImpl.EMVCL_Transaction(transactionData, retryTimeout);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_Transaction_inputCheckEMVCL_Transaction");
        }
    }

    /**
     * Test:EMVCL_Transaction <br/>
     *   ・準正常 (checkStatusの戻り値がSUCCESSではない) <br/>
     */
    @SmallTest
    public void testEMVCL_Transaction_checkStatus() {
        try {
            setEMVStatus("EMVCL_CLOSED");

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            TRANSACTIONDATA transactionData = getTransactionData();
            int retryTimeout = 65535;

            // パターン：checkStatusの戻り値がSUCCESSではない
            int ret = nfcInterfaceImpl.EMVCL_Transaction(transactionData, retryTimeout);

            // 結果確認
            assertEquals(101, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_Transaction_checkStatus");
        }
    }

    /**
     * Test:EMVCL_Transaction <br/>
     *   ・準正常 (ウインドウハンドルが登録されていない) <br/>
     */
    @SmallTest
    public void testEMVCL_Transaction_mCompleteEvent() {
        try {
            setEMVStatus("EMVCL_CLAIMED");

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            TRANSACTIONDATA transactionData = getTransactionData();
            int retryTimeout = 65535;

            // パターン：ウインドウハンドルが登録されていない
            int ret = nfcInterfaceImpl.EMVCL_Transaction(transactionData, retryTimeout);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_Transaction_mCompleteEvent");
        }
    }

    // ****************************** EMVCL_Transaction end **********************************


    // ****************************** TransactionTask.doInBackground start **********************************

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (params == null) <br/>
     */
    @SmallTest
    public void testTransactionTask_params() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            TRANSACTIONDATA[] params = null;

            // パターン：params == null
            Integer ret = transactionTask.doInBackground(params);

            // 結果確認
            assertEquals("106", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_params");
        }
    }

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (トレーニングモード) <br/>
     */
    @SmallTest
    public void testTransactionTask_isTraining() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = setContext(null, "240DEE76580C8FC4008BB007EBCB3265");
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            transactionTask.isTraining = true;
            transactionTask.retryTimeout = 60;
            TRANSACTIONDATA transactionData = getTransactionData();

            // パターン：isTraining == true
            // パターン：BitmapTransferRequestのreadがnull
            Integer ret = transactionTask.doInBackground(transactionData);

            // 結果確認
            assertEquals("106", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_isTraining");
        }
    }

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (Timeout判定) <br/>
     */
    @SmallTest
    public void testTransactionTask_timeout() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020340063000b05873ee53a16a283bb2258ef1d9d465983d4a20c568fab04886a7b8775e99742cf715ed5586f076a939c89e98c287ce03752c");
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext(bufferList, "A23A9B51524375BA738D9D8F4EC5DB7C");
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            transactionTask.retryTimeout = 1;
            TRANSACTIONDATA transactionData = getTransactionData();

            // パターン：checkSetBitMapDataの戻り値が通信エラー
            // パターン：Timeout判定
            Integer ret = transactionTask.doInBackground(transactionData);

            // 結果確認
            assertEquals("111", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_timeout");
        }
    }

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (checkErrorResponse エラー) <br/>
     */
    @SmallTest
    public void testTransactionTask_checkErrorResponse() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            TRANSACTIONDATA transactionData = getTransactionData();

            // パターン：checkErrorResponse エラー
            Integer ret = transactionTask.doInBackground(transactionData);

            // 結果確認
            assertEquals("106", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_checkErrorResponse");
        }
    }

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (処理キャンセル) <br/>
     */
    @SmallTest
    public void testTransactionTask_isCancel() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020340063000b05873ee53a16a283bb2258ef1d9d465983d4a20c568fab04886a7b8775e99742cf715ed5586f076a939c89e98c287ce03752c");
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext(bufferList, "A23A9B51524375BA738D9D8F4EC5DB7C");
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            transactionTask.isCancel = true;
            transactionTask.retryTimeout = 60;
            TRANSACTIONDATA transactionData = getTransactionData();

            // パターン：checkSetBitMapDataの戻り値が通信エラー
            // パターン：処理キャンセル指示確認
            Integer ret = transactionTask.doInBackground(transactionData);

            // 結果確認
            assertEquals("111", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_isCancel");
        }
    }

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (checkSetBitMapDataの戻り値が通信エラー) <br/>
     */
    @SmallTest
    public void testTransactionTask_checkSetBitMapData() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020340063000b05873ee53a16a283bb2258ef1d9d465983d4a20c568fab04886a7b8775e99742cf715ed5586f076a939c89e98c287ce03752c");
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext(bufferList, "A23A9B51524375BA738D9D8F4EC5DB7C");
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            transactionTask.isCancel = false;
            transactionTask.retryTimeout = 60;
            TRANSACTIONDATA transactionData = getTransactionData();

            // パターン：checkSetBitMapDataの戻り値が通信エラー
            Integer ret = transactionTask.doInBackground(transactionData);

            // 結果確認
            assertEquals("106", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_checkSetBitMapData");
        }
    }

    // ****************************** TransactionTask.doInBackground end **********************************


    // ****************************** inputCheckEMVCL_SetEMV start **********************************

    /**
     * Test:inputCheckEMVCL_SetEMV <br/>
     *   ・準正常 (inputCheckResultCodeの戻り値がfalse) <br/>
     */
    @SmallTest
    public void testinputCheckEMVCL_SetEMV_inputCheckResultCode() {
        try {
            byte FileNumber = 0;
            int FileDataLength = 0;
            byte[] FileData = null;
            int[] ResultCode = null;
            int[] ResultCodeExtended = null;
            byte[] serviceCode = null;

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Method inputCheckEMVCL_SetEMV = NFCInterfaceImpl.class.getDeclaredMethod("inputCheckEMVCL_SetEMV",
                    byte.class, int.class, byte[].class, int[].class, int[].class, byte[].class);
            inputCheckEMVCL_SetEMV.setAccessible(true);

            // パターン：inputCheckResultCodeの戻り値がfalse
            ApiReturnValues.SetEMV ret = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testinputCheckEMVCL_SetEMV_inputCheckResultCode");
        }
    }

    /**
     * Test:inputCheckEMVCL_SetEMV <br/>
     *   ・準正常 (FileData == null || FileData.length == 0) <br/>
     */
    @SmallTest
    public void testinputCheckEMVCL_SetEMV_FileData() {
        try {
            byte FileNumber = 0;
            int FileDataLength = 0;
            byte[] FileData = null;
            int[] ResultCode = new int[1];
            int[] ResultCodeExtended = new int[1];
            byte[] serviceCode = null;

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Method inputCheckEMVCL_SetEMV = NFCInterfaceImpl.class.getDeclaredMethod("inputCheckEMVCL_SetEMV",
                    byte.class, int.class, byte[].class, int[].class, int[].class, byte[].class);
            inputCheckEMVCL_SetEMV.setAccessible(true);

            // パターン：FileData == null
            ApiReturnValues.SetEMV ret = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret);

            // パターン：FileData.length == 0
            FileData = new byte[0];
            ApiReturnValues.SetEMV ret2 = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testinputCheckEMVCL_SetEMV_FileData");
        }
    }

    /**
     * Test:inputCheckEMVCL_SetEMV <br/>
     *   ・準正常 (FileData.length != FileDataLength) <br/>
     */
    @SmallTest
    public void testinputCheckEMVCL_SetEMV_FileDataLength() {
        try {
            byte FileNumber = 0;
            int FileDataLength = 81;
            byte[] FileData = ByteUtil.hex2bin("9F1A020392DF8130010D00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            int[] ResultCode = new int[1];
            int[] ResultCodeExtended = new int[1];
            byte[] serviceCode = null;

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Method inputCheckEMVCL_SetEMV = NFCInterfaceImpl.class.getDeclaredMethod("inputCheckEMVCL_SetEMV",
                    byte.class, int.class, byte[].class, int[].class, int[].class, byte[].class);
            inputCheckEMVCL_SetEMV.setAccessible(true);

            // パターン：FileData.length != FileDataLength
            ApiReturnValues.SetEMV ret = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testinputCheckEMVCL_SetEMV_FileDataLength");
        }
    }

    /**
     * Test:inputCheckEMVCL_SetEMV <br/>
     *   ・準正常 (serviceCode == null || serviceCode.length != 2) <br/>
     */
    @SmallTest
    public void testinputCheckEMVCL_SetEMV_serviceCode() {
        try {
            byte FileNumber = 0;
            int FileDataLength = 80;
            byte[] FileData = ByteUtil.hex2bin("9F1A020392DF8130010D00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            int[] ResultCode = new int[1];
            int[] ResultCodeExtended = new int[1];
            byte[] serviceCode = null;

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Method inputCheckEMVCL_SetEMV = NFCInterfaceImpl.class.getDeclaredMethod("inputCheckEMVCL_SetEMV",
                    byte.class, int.class, byte[].class, int[].class, int[].class, byte[].class);
            inputCheckEMVCL_SetEMV.setAccessible(true);

            // パターン：serviceCode == null
            ApiReturnValues.SetEMV ret = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret);

            // パターン：serviceCode.length != 2
            serviceCode = new byte[]{(byte) 0x00, (byte) 0x00, (byte) 0x00};
            ApiReturnValues.SetEMV ret2 = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testinputCheckEMVCL_SetEMV_serviceCode");
        }
    }

    /**
     * Test:inputCheckEMVCL_SetEMV <br/>
     *   ・準正常 (設定ファイル番号が既定のもの以外) <br/>
     */
    @SmallTest
    public void testinputCheckEMVCL_SetEMV_isCheck() {
        try {
            byte FileNumber = (byte) 0x16;
            int FileDataLength = 80;
            byte[] FileData = ByteUtil.hex2bin("9F1A020392DF8130010D00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            int[] ResultCode = new int[1];
            int[] ResultCodeExtended = new int[1];
            byte[] serviceCode = new byte[]{(byte) 0x00, (byte) 0x00};

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Method inputCheckEMVCL_SetEMV = NFCInterfaceImpl.class.getDeclaredMethod("inputCheckEMVCL_SetEMV",
                    byte.class, int.class, byte[].class, int[].class, int[].class, byte[].class);
            inputCheckEMVCL_SetEMV.setAccessible(true);

            // パターン：設定ファイル番号が既定のもの以外  !isCheck
            ApiReturnValues.SetEMV ret = (ApiReturnValues.SetEMV)inputCheckEMVCL_SetEMV.invoke(nfcInterfaceImpl,
                    FileNumber, FileDataLength, FileData, ResultCode, ResultCodeExtended, serviceCode);

            // 結果確認
            assertEquals(ApiReturnValues.SetEMV.E_ILLEGAL, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testinputCheckEMVCL_SetEMV_isCheck");
        }
    }

    // ****************************** inputCheckEMVCL_SetEMV end **********************************


    // ****************************** EMVCL_DeviceSetting start **********************************

    /**
     * Test:EMVCL_DeviceSetting <br/>
     *   ・準正常 (inputCheckエラー) <br/>
     */
    @SmallTest
    public void testEMVCL_DeviceSetting_inputCheck() {
        try {
            byte VolumeOfSound = (byte) 0x03;
            int RemovalProcedureTimer = 100;
            byte MessageStatus = (byte) 0x00;
            int[] ResultCode = new int[1];
            int[] ResultCodeExtended = new int[1];

            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();

            // パターン：inputCheckエラー
            int ret = nfcInterfaceImpl.EMVCL_DeviceSetting(VolumeOfSound, RemovalProcedureTimer, MessageStatus, ResultCode, ResultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_DeviceSetting_inputCheck");
        }
    }

    // ****************************** EMVCL_DeviceSetting end **********************************


    // ****************************** TransactionTask.doInBackground start **********************************

    /**
     * Test:TransactionTask.doInBackground <br/>
     *   ・準正常 (checkErrorResponseエラー＆FatalErrorではない) <br/>
     */
    @SmallTest
    public void testTransactionTask_isFatalError() {
        try {
            NFCInterfaceImplTestDE de = new NFCInterfaceImplTestDE();
            byte[] data1 = ByteUtil.hex2bin("03ffff080000050000fefe0000");
            byte[] data2 = ByteUtil.hex2bin("03ffff080000050000fefe0000".substring(10));
            byte[] buffer = de.getByteData(data1, data2);

            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            NFCInterfaceImpl.TransactionTask transactionTask = nfcInterfaceImpl.new TransactionTask();

            TRANSACTIONDATA transactionData = getTransactionData();

            // パターン：resp[9] != (byte)0xFF
            Integer ret = transactionTask.doInBackground(transactionData);

            // 結果確認
            assertEquals("106", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testTransactionTask_isFatalError");
        }
    }

    // ****************************** TransactionTask.doInBackground end **********************************


    // ****************************** DataExchangeTask.doInBackground start **********************************

    /**
     * Test:DataExchangeTask.doInBackground <br/>
     *   ・準正常 (checkErrorResponseエラー＆FatalErrorではない) <br/>
     */
    @SmallTest
    public void testDataExchangeTask_isFatalError() {
        try {
            NFCInterfaceImplTestDE de = new NFCInterfaceImplTestDE();
            byte[] data1 = ByteUtil.hex2bin("03ffff080000050000fefe0000");
            byte[] data2 = ByteUtil.hex2bin("03ffff080000050000fefe0000".substring(10));
            byte[] buffer = de.getByteData(data1, data2);

            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            NFCInterfaceImpl.DataExchangeTask dataExchangeTask = nfcInterfaceImpl.new DataExchangeTask();

            DEINFO deInfo = new DEINFO();
            deInfo.ContinueFlag = (byte)0x00;
            deInfo.Result = ByteUtil.hex2bin("0000");
            deInfo.DataExchangeData = ByteUtil.hex2bin("0100070005df81120182");

            // パターン：resp[9] != (byte)0xFF
            Integer ret = dataExchangeTask.doInBackground(deInfo);

            // 結果確認
            assertEquals("106", String.valueOf(ret));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchangeTask_isFatalError");
        }
    }

    // ****************************** DataExchangeTask.doInBackground end **********************************
}
