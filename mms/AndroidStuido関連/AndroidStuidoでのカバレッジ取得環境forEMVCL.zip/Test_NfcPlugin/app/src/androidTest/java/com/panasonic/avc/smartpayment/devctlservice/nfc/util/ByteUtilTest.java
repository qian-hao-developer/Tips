package com.panasonic.avc.smartpayment.devctlservice.nfc.util;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * ByteUtilのUTクラス </br>
 */
public class ByteUtilTest extends ApplicationTestCase<Application> {

    public ByteUtilTest() {
        super(Application.class);
    }

    /**
     *  Test:bin2hex <br/>
     *  ・正常
     */
    @SmallTest
    public void  testBin2hex() {
        byte[] bytes1 = { 0x00, 0x0f };
        byte[] bytes2 = { 0x10, 0x7f };

        try{
            assertEquals("testBin2hex_1", "000f", ByteUtil.bin2hex(bytes1));
            assertEquals("testBin2hex_2", "107f", ByteUtil.bin2hex(bytes2));
        } catch(Exception e){
            e.printStackTrace();
            fail("testBin2hex 例外発生");
        }
    }

    /**
     *  Test:toAscii <br/>
     *  ・正常
     */
    @SmallTest
    public void  testToAscii() {
        byte[] bytes1 = null;
        byte[] bytes2 = { 0x20 };
        byte[] bytes3 = { 0x7e };

        try{
            // testToAsciiメソッドのパラメータがnullの場合、正常な結果を出す。
            assertEquals("testToAscii_1", null, ByteUtil.toAscii(bytes1));
            // testToAsciiメソッドのパラメータがUS-ASCIIの範囲内(0x20~0x7e)の場合、正常な結果を出す。
            assertEquals("testToAscii_2", "", ByteUtil.toAscii(bytes2));
            assertEquals("testToAscii_3", "~", ByteUtil.toAscii(bytes3));
        } catch(Exception e){
            e.printStackTrace();
            fail("testToAscii 例外発生");
        }
    }
}
