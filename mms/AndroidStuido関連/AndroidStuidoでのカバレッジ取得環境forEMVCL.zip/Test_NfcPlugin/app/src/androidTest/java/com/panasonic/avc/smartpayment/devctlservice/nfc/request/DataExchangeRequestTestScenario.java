package com.panasonic.avc.smartpayment.devctlservice.nfc.request;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * DataExchangeRequestのUTクラス (シナリオ)<br/>
 */
public class DataExchangeRequestTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public DataExchangeRequestTestScenario() {
        super(Application.class);
    }

    /**
     * Test:isValidValue <br/>
     *   ・準正常 (ビットマップデータ必須チェックエラー) <br/>
     */
    @SmallTest
    public void testIsValidValue_err() {
        try {
            DataExchangeRequest dataExchangeRequest = new DataExchangeRequest();

            // パターン：ビットマップデータ必須チェックエラー
            boolean ret = dataExchangeRequest.isValidValue();

            // 結果確認
            assertEquals(false, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testIsValidValue_err");
        }
    }
}
