package com.panasonic.avc.smartpayment.devctlservice.nfc.platform;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.request.RWInformationRequest;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * PlatformConfigのUTクラス (シナリオ)<br/>
 */
public class PlatformConfigTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public PlatformConfigTestScenario() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    private PlatformConfig setContext(TestControlDeviceManager controlDeviceManager, List<byte[]> bufferList) {

        PlatformConfig platformConfig = PlatformConfig.getInstance();

        if (controlDeviceManager == null) {
            controlDeviceManager = new TestControlDeviceManager();
        }

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);
        platformConfig.setContext(controlDeviceManager, nonContactICCard);

        return platformConfig;
    }

    // get current time
    private Calendar getCalendar() {
        Date date = new Date(System.currentTimeMillis());
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    /**
     * Test:deviceSendReceive <br/>
     *   ・準正常 (waitロジックに入る) <br/>
     */
    @SmallTest
    public void testDeviceSendReceive_wait() {
        try {
            RWInformationRequest rwInfoReq = new RWInformationRequest();
            rwInfoReq.setCommDateTime(getCalendar());

            TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();
            controlDeviceManager.setActiveFlg(false);
            PlatformConfig platformConfig = setContext(controlDeviceManager, null);

            // パターン：!mControlDeviceManager.isActive()でwaitロジックに入る
            byte[] ret1 = platformConfig.deviceSendReceive(rwInfoReq.toCommand(), 5000);
            assertNull(ret1);

            // パターン：mControlDeviceManager == nullでwaitロジックに入る
            Field mControlDeviceManager = PlatformConfig.class.getDeclaredField("mControlDeviceManager");
            mControlDeviceManager.setAccessible(true);
            mControlDeviceManager.set(platformConfig, null);
            byte[] ret2 = platformConfig.deviceSendReceive(rwInfoReq.toCommand(), 5000);
            assertNull(ret2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDeviceSendReceive_wait");
        }
    }

    /**
     * Test:deviceSendReceive <br/>
     *   ・準正常 (internalWriteの戻り値が-1) <br/>
     */
    @SmallTest
    public void testDeviceSendReceive_internalWrite() {
        try {
            PlatformConfig platformConfig = setContext(null, null);
            byte[] data = new byte[4];

            // パターン：internalWriteの戻り値が-1
            byte[] ret = platformConfig.deviceSendReceive(data, 5000);

            // 結果確認
            assertNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDeviceSendReceive_internalWrite");
        }
    }

    /**
     * Test:internalWrite <br/>
     *   ・正常 (encryptData = encryptTargetを通る正常) <br/>
     */
    @SmallTest
    public void testInternalWrite_normal() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            RWInformationRequest rwInfoReq = new RWInformationRequest();
            rwInfoReq.setCommDateTime(getCalendar());

            byte[] data = rwInfoReq.toCommand();
            data[CommandDataConstants.MAINCOMMAND_INDEX] = (byte)0x01;
            data[CommandDataConstants.SUBCOMMAND_INDEX] = (byte)0x81;

            Method internalWrite = PlatformConfig.class.getDeclaredMethod("internalWrite", byte[].class, int.class);
            internalWrite.setAccessible(true);

            // パターン：encryptData = encryptTargetを通る正常
            int ret = (Integer)internalWrite.invoke(platformConfig, data, 5000);

            // 結果確認
            assertEquals(1, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalWrite_normal");
        }
    }

    /**
     * Test:internalWrite <br/>
     *   ・準正常 (writeの戻り値がfalse) <br/>
     */
    @SmallTest
    public void testInternalWrite_write() {
        try {
            TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();
            controlDeviceManager.setWriteFlg(false);
            PlatformConfig platformConfig = setContext(controlDeviceManager, null);

            RWInformationRequest rwInfoReq = new RWInformationRequest();
            rwInfoReq.setCommDateTime(getCalendar());

            byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB3265");
            Field mSessionKey = PlatformConfig.class.getDeclaredField("mSessionKey");
            mSessionKey.setAccessible(true);
            mSessionKey.set(platformConfig, sessionArray);

            Method internalWrite = PlatformConfig.class.getDeclaredMethod("internalWrite", byte[].class, int.class);
            internalWrite.setAccessible(true);

            // パターン：writeの戻り値がfalse
            int ret = (Integer)internalWrite.invoke(platformConfig, rwInfoReq.toCommand(), 5000);

            // 結果確認
            assertEquals(-1, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalWrite_write");
        }
    }

    /**
     * Test:internalWrite <br/>
     *   ・準正常 (cipherData失敗でencryptData == nullを通る準正常) <br/>
     */
    @SmallTest
    public void testInternalWrite_cipherData() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            RWInformationRequest rwInfoReq = new RWInformationRequest();
            rwInfoReq.setCommDateTime(getCalendar());

            byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB326501");
            Field mSessionKey = PlatformConfig.class.getDeclaredField("mSessionKey");
            mSessionKey.setAccessible(true);
            mSessionKey.set(platformConfig, sessionArray);

            Method internalWrite = PlatformConfig.class.getDeclaredMethod("internalWrite", byte[].class, int.class);
            internalWrite.setAccessible(true);

            // パターン：cipherData失敗でencryptData == nullを通る準正常
            int ret = (Integer)internalWrite.invoke(platformConfig, rwInfoReq.toCommand(), 5000);

            // 結果確認
            assertEquals(-1, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalWrite_cipherData");
        }
    }

    /**
     * Test:internalRead <br/>
     *   ・準正常 (cipherData失敗でdecryptData == nullを通る準正常) <br/>
     */
    @SmallTest
    public void testInternalRead_cipherData() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5");
            bufferList.add(buffer);

            PlatformConfig platformConfig = setContext(null, bufferList);

            byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB326501");
            Field mSessionKey = PlatformConfig.class.getDeclaredField("mSessionKey");
            mSessionKey.setAccessible(true);
            mSessionKey.set(platformConfig, sessionArray);

            Method internalRead = PlatformConfig.class.getDeclaredMethod("internalRead", int.class);
            internalRead.setAccessible(true);

            // パターン：cipherData失敗でdecryptData == nullを通る準正常
            byte[] ret = (byte[])internalRead.invoke(platformConfig, 5000);

            // 結果確認
            assertNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalRead_cipherData");
        }
    }

    /**
     * Test:internalRead <br/>
     *   ・準正常 (readの戻り値がnull) <br/>
     */
    @SmallTest
    public void testInternalRead_null() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method internalRead = PlatformConfig.class.getDeclaredMethod("internalRead", int.class);
            internalRead.setAccessible(true);

            // パターン：readの戻り値がnull
            byte[] ret = (byte[])internalRead.invoke(platformConfig, 5000);

            // 結果確認
            assertNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalRead_null");
        }
    }

    /**
     * Test:internalRead <br/>
     *   ・準正常 (readの戻り値が空) <br/>
     */
    @SmallTest
    public void testInternalRead_ArraysEquals() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] receiveDataBuff = new byte[10009];
            bufferList.add(receiveDataBuff);

            PlatformConfig platformConfig = setContext(null, bufferList);

            Method internalRead = PlatformConfig.class.getDeclaredMethod("internalRead", int.class);
            internalRead.setAccessible(true);

            // パターン：readの戻り値が空
            byte[] ret = (byte[])internalRead.invoke(platformConfig, 5000);

            // 結果確認
            assertNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalRead_ArraysEquals");
        }
    }

    /**
     * Test:internalRead <br/>
     *   ・準正常 (crc != CommandDataConstants.calcCRC(crcTarget)を通る準正常) <br/>
     */
    @SmallTest
    public void testInternalRead_crc() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("0252040000003377d714cd76d043160d28967bd21b290324bd");
            bufferList.add(buffer);

            PlatformConfig platformConfig = setContext(null, bufferList);

            Method internalRead = PlatformConfig.class.getDeclaredMethod("internalRead", int.class);
            internalRead.setAccessible(true);

            // パターン：crc != CommandDataConstants.calcCRC(crcTarget)を通る準正常
            byte[] ret = (byte[])internalRead.invoke(platformConfig, 5000);

            // 結果確認
            assertNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalRead_crc");
        }
    }

    /**
     * Test:internalRead <br/>
     *   ・正常 (decryptData = decryptTargetを通る正常) <br/>
     */
    @SmallTest
    public void testInternalRead_normal() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("000000000000000000");
            bufferList.add(buffer);

            PlatformConfig platformConfig = setContext(null, bufferList);

            Method internalRead = PlatformConfig.class.getDeclaredMethod("internalRead", int.class);
            internalRead.setAccessible(true);

            // パターン：decryptData = decryptTargetを通る正常
            byte[] ret = (byte[])internalRead.invoke(platformConfig, 5000);

            // 結果確認
            assertNotNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testInternalRead_normal");
        }
    }

    /**
     * Test:encryptCommand <br/>
     *   ・準正常 (引数のbyte配列のlengthが0) <br/>
     */
    @SmallTest
    public void testEncryptCommand_length0() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method encryptCommand = PlatformConfig.class.getDeclaredMethod("encryptCommand", byte[].class);
            encryptCommand.setAccessible(true);

            // パターン：data.length == 0
            byte[] data = new byte[0];
            byte[] ret = (byte[])encryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(data, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEncryptCommand_length0");
        }
    }

    /**
     * Test:encryptCommand <br/>
     *   ・準正常 (引数のbyte配列のlengthを16で割った余りが0ではない) <br/>
     */
    @SmallTest
    public void testEncryptCommand_length16() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method encryptCommand = PlatformConfig.class.getDeclaredMethod("encryptCommand", byte[].class);
            encryptCommand.setAccessible(true);

            // パターン：data.length % 16 != 0
            byte[] data = new byte[17];
            byte[] ret = (byte[])encryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(data, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEncryptCommand_length16");
        }
    }

    /**
     * Test:decryptCommand <br/>
     *   ・準正常 (引数のbyte配列のlengthが0) <br/>
     */
    @SmallTest
    public void testDecryptCommand_length0() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method decryptCommand = PlatformConfig.class.getDeclaredMethod("decryptCommand", byte[].class);
            decryptCommand.setAccessible(true);

            // パターン：data.length == 0
            byte[] data = new byte[0];
            byte[] ret = (byte[])decryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(data, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDecryptCommand_length0");
        }
    }

    /**
     * Test:decryptCommand <br/>
     *   ・準正常 (引数のbyte配列のlengthを16で割った余りが0ではない) <br/>
     */
    @SmallTest
    public void testDecryptCommand_length16() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method decryptCommand = PlatformConfig.class.getDeclaredMethod("decryptCommand", byte[].class);
            decryptCommand.setAccessible(true);

            // パターン：data.length % 16 != 0
            byte[] data = new byte[17];
            byte[] ret = (byte[])decryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(data, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDecryptCommand_length16");
        }
    }

    /**
     * Test:checkCryptCommand <br/>
     *   ・準正常 (引数のbyte配列がnull) <br/>
     */
    @SmallTest
    public void testCheckCryptCommand_null() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method checkCryptCommand = PlatformConfig.class.getDeclaredMethod("checkCryptCommand", byte[].class);
            checkCryptCommand.setAccessible(true);

            // パターン：引数のbyte配列がnull
            byte[] data = null;
            boolean ret = (boolean)checkCryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(false, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCheckCryptCommand_null");
        }
    }

    /**
     * Test:checkCryptCommand <br/>
     *   ・準正常 (MCが01・SCが81) <br/>
     */
    @SmallTest
    public void testCheckCryptCommand_01_81() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method checkCryptCommand = PlatformConfig.class.getDeclaredMethod("checkCryptCommand", byte[].class);
            checkCryptCommand.setAccessible(true);

            // パターン：MCが01・SCが81
            byte[] data = new byte[3];
            data[CommandDataConstants.MAINCOMMAND_INDEX] = (byte)0x01;
            data[CommandDataConstants.SUBCOMMAND_INDEX] = (byte)0x81;
            boolean ret = (boolean)checkCryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(false, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCheckCryptCommand_01_81");
        }
    }

    /**
     * Test:checkCryptCommand <br/>
     *   ・準正常 (MCが25・SCがC1) <br/>
     */
    @SmallTest
    public void testCheckCryptCommand_25_C1() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method checkCryptCommand = PlatformConfig.class.getDeclaredMethod("checkCryptCommand", byte[].class);
            checkCryptCommand.setAccessible(true);

            // パターン：MCが25・SCがC1
            byte[] data = new byte[3];
            data[CommandDataConstants.MAINCOMMAND_INDEX] = (byte)0x25;
            data[CommandDataConstants.SUBCOMMAND_INDEX] = (byte)0xC1;
            boolean ret = (boolean)checkCryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(false, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCheckCryptCommand_25_C1");
        }
    }

    /**
     * Test:checkCryptCommand <br/>
     *   ・正常 (MCが01・SCがC1) <br/>
     */
    @SmallTest
    public void testCheckCryptCommand_01_C1() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method checkCryptCommand = PlatformConfig.class.getDeclaredMethod("checkCryptCommand", byte[].class);
            checkCryptCommand.setAccessible(true);

            // パターン：MCが01・SCがC1
            byte[] data = new byte[3];
            data[CommandDataConstants.MAINCOMMAND_INDEX] = (byte)0x01;
            data[CommandDataConstants.SUBCOMMAND_INDEX] = (byte)0xC1;
            boolean ret = (boolean)checkCryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(true, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCheckCryptCommand_01_C1");
        }
    }

    /**
     * Test:checkCryptCommand <br/>
     *   ・正常 (MCが25・SCが81) <br/>
     */
    @SmallTest
    public void testCheckCryptCommand_25_81() {
        try {
            PlatformConfig platformConfig = setContext(null, null);

            Method checkCryptCommand = PlatformConfig.class.getDeclaredMethod("checkCryptCommand", byte[].class);
            checkCryptCommand.setAccessible(true);

            // パターン：MCが25・SCが81
            byte[] data = new byte[3];
            data[CommandDataConstants.MAINCOMMAND_INDEX] = (byte)0x25;
            data[CommandDataConstants.SUBCOMMAND_INDEX] = (byte)0x81;
            boolean ret = (boolean)checkCryptCommand.invoke(platformConfig, data);

            // 結果確認
            assertEquals(true, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCheckCryptCommand_25_81");
        }
    }

    /**
     * Test:deviceReceive <br/>
     *   ・準正常 (waitロジックに入る) <br/>
     */
    @SmallTest
    public void testDeviceReceive_wait() {
        try {
            TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();
            controlDeviceManager.setActiveFlg(false);
            PlatformConfig platformConfig = setContext(controlDeviceManager, null);

            // パターン：!mControlDeviceManager.isActive()でwaitロジックに入る
            platformConfig.deviceReceive(10000);

            // パターン：mControlDeviceManager == nullでwaitロジックに入る
            Field mControlDeviceManager = PlatformConfig.class.getDeclaredField("mControlDeviceManager");
            mControlDeviceManager.setAccessible(true);
            mControlDeviceManager.set(platformConfig, null);
            platformConfig.deviceReceive(10000);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDeviceReceive_wait");
        }
    }

    /**
     * Test:dump <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testDump() {
        try {
            PlatformConfig platformConfig = setContext(null, null);
            Method dump = PlatformConfig.class.getDeclaredMethod("dump", String.class, String.class, byte[].class, int.class);
            dump.setAccessible(true);

            byte[] data = ByteUtil.hex2bin("010203");

            // i が length を超える
            dump.invoke(platformConfig, "PlatformConfig", "[TEST]", data, 2);

            // i が data.length を超えるのは不可能
            dump.invoke(platformConfig, "PlatformConfig", "[TEST]", data, 4);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDump");
        }
    }
}
