package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

import java.lang.reflect.Field;

/**
 * RWInformationResponseのUTクラス (シナリオ)<br/>
 */
public class RWInformationResponseTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public RWInformationResponseTestScenario() {
        super(Application.class);
    }

    /**
     * Test:cutDeviceResult <br/>
     *   ・準正常 (引数のbyte配列がnull) <br/>
     */
    @SmallTest
    public void testCutDeviceResult_null() {
        try {
            // パターン：引数のbyte配列がnull
            RWInformationResponse response = new RWInformationResponse();
            byte[] ret = response.cutDeviceResult(null);

            // 結果確認
            assertNull(ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCutDeviceResult_null");
        }
    }

    /**
     * Test:cutDeviceResult <br/>
     *   ・準正常 (フォーマット１の場合のみ抽出するifを通らない) <br/>
     */
    @SmallTest
    public void testCutDeviceResult_format1() {
        try {
            // パターン：フォーマット１の場合のみ抽出するifを通らない
            RWInformationResponse response = new RWInformationResponse();
            byte[] bytes = ByteUtil.hex2bin("030000999900030107014A542D5235353043522D343131354D303030333800000000000000");
            byte[] ret = response.cutDeviceResult(bytes);

            // 結果確認
            assertEquals(bytes, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCutDeviceResult_format1");
        }
    }
}
