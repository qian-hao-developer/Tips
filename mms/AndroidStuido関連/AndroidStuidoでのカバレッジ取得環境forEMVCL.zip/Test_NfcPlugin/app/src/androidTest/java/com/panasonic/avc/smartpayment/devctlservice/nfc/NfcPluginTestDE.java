package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.DEINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.RESULTINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.CommandDataConstants;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.PlatformConfig;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.share.INfcServiceListener;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * NfcPluginのUTクラス (DataExchange)<br/>
 */
public class NfcPluginTestDE extends ApplicationTestCase<Application> {

    // コンストラクタ
    public NfcPluginTestDE() {
        super(Application.class);
    }

    // StartTransaction：取引データ (mIsNeedExpand = false)
    private static final String TRAN_DATA = "{\"TransactionType\":\"00\",\"FunctionMode\":\"0000\",\"CommunicationTime\":\"000000000000\",\"BlockNumber\":\"0000\",\"AmountAuthorised\":\"000000011000\",\"AmountOther\":\"000000000000\",\"MerchantSpecificData\":\"00\",\"TLVData\":\"3030300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\"}";

    // StartTransaction：取引データ (mIsNeedExpand = true)
    private static final String TRAN_DATA2 = "{\"TransactionType\":\"00\",\"FunctionMode\":\"0000\",\"CommunicationTime\":\"000000000000\",\"BlockNumber\":\"0000\",\"AmountAuthorised\":\"000000011000\",\"AmountOther\":\"000000000000\",\"MerchantSpecificData\":\"80\",\"TLVData\":\"3030300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\"}";

    // DataExchange：Data Exchangeのデータ構成（正常）
    private static final String DATA_EXCHANGE = "{\"ContinueFlag\":\"00\",\"Result\":\"0000\",\"DataExchangeData\":\"0100070005df81120182\"}";

    // DataExchange：Data Exchangeのデータ構成（異常）
    private static final String DATA_EXCHANGE_ERR1 = "{\"ContinueFlag\":\"02\",\"Result\":\"0000\",\"DataExchangeData\":\"0100070005df81120182\"}";

    // 次のtestメソッドを実行して良いか判定する（非同期タスク対策）
    private static boolean nextFlg = false;


    // PlatformConfig.setContextを呼び出す
    //   type  0:readなし
    //         1:readあり
    //         2:openのみ
    //         3:readあり(closeなし)
    private NfcPlugin setContext(int type, List<byte[]> bufferList) throws Exception {
        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        if (type != 0) {
            // readの返却値設定：OpenDevice
            byte[] bufferOpen = ByteUtil.hex2bin("02032402000003114A");
            controlDeviceManager.addByteList(bufferOpen);
        }

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);

        // 相互認証用セッションキー
        byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB3265");
        Field mSessionKey2 = NonContactICCard.class.getDeclaredField("mSessionKey2");
        mSessionKey2.setAccessible(true);
        mSessionKey2.set(nonContactICCard, sessionArray);

        NfcPlugin nfcPlugin = NfcPlugin.getInstance();
        nfcPlugin.setContext(controlDeviceManager, nonContactICCard);

        try {
            // 保持状態statusを初期状態にする
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object close = null;
            for (Object o : enumEMVStatus) {
                if (((Enum) o).name().equals("EMVCL_CLOSED")) {
                    close = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, close);

            // mIsDataExchangeを初期状態にする
            Field mIsDataExchange = NFCInterfaceImpl.class.getDeclaredField("mIsDataExchange");
            mIsDataExchange.setAccessible(true);
            mIsDataExchange.set(nfcInterfaceImpl, false);

        } catch (Exception e) {
            throw e;
        }

        return nfcPlugin;
    }

    private void setEMVStatus(String status) throws Exception {
        try {
            // 保持状態statusを変更する
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object statusObj = null;
            for (Object o : enumEMVStatus) {
                if (((Enum)o).name().equals(status)) {
                    statusObj = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, statusObj);

        } catch (Exception e) {
            throw e;
        }
    }

    private String createReadData(String encryptTarget) throws Exception {
        try {
            byte[] data = ByteUtil.hex2bin(encryptTarget);
            byte[] buffer = ByteUtil.hex2bin(encryptTarget.substring(10));

            // sessionキー
            byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB3265");

            PlatformConfig plat = PlatformConfig.getInstance();
            Method cipherData = PlatformConfig.class.getDeclaredMethod("cipherData", byte[].class, byte[].class, boolean.class);
            cipherData.setAccessible(true);
            byte[] encryptData = (byte[])cipherData.invoke(plat, buffer, sessionArray, true);

            byte[] readData = getByteData(data, encryptData);

            return ByteUtil.bin2hex(readData);

        } catch (Exception e) {
            throw e;
        }
    }

    private byte[] getByteData(byte[] data, byte[] encryptData) {
        // send data to R550
        byte[] sendData = new byte[data.length + 4];

        // CRC target data by data + ETX
        byte[] crcTarget = new byte[data.length + 1];

        // set STX
        sendData[CommandDataConstants.STX_INDEX] = CommandDataConstants.STX;

        // copy from data header to sendData of index 1 - 5
        System.arraycopy(data, 0, sendData, 1, CommandDataConstants.DATA_SIZE_HEADER);
        // copy from data header to crcTarget of index 0 - 4
        System.arraycopy(data, 0, crcTarget, 0, CommandDataConstants.DATA_SIZE_HEADER);

        // copy from encryptData to sendData of index 6 - end
        System.arraycopy(encryptData, 0, sendData, CommandDataConstants.DATA_SIZE_PRIFIX, encryptData.length);
        // copy from encryptData to crcTarget of index 5 - end
        System.arraycopy(encryptData, 0, crcTarget, CommandDataConstants.DATA_SIZE_HEADER, encryptData.length);

        // set ETX
        sendData[sendData.length - CommandDataConstants.ETX_INDEX_REV] = CommandDataConstants.ETX;
        crcTarget[crcTarget.length - 1] = CommandDataConstants.ETX;

        // calcCRC
        int crc = CommandDataConstants.calcCRC(crcTarget);
        sendData[sendData.length - CommandDataConstants.CRC_LOW_INDEX_REV] = (byte) (crc >> 8 & 0xff);
        sendData[sendData.length - CommandDataConstants.CRC_HIGH_INDEX_REV] = (byte) (crc & 0xff);

        return sendData;
    }

    // コールバックイベント１
    private INfcServiceListener.Stub mINfcServiceListener1 = new INfcServiceListener.Stub() {

        // 取引処理完了時に処理結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactioncomplete(String value) {
            try {
                assertTrue(true);
            } catch (Exception e) {
                e.printStackTrace();
                fail("ontransactioncomplete");
            } finally {
                nextFlg = true;
            }
        }

        // 取引処理失敗時にエラー結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactionerror(int ecode, String extcode) {
            try {
                fail("コールバックイベント１: ecode=" + ecode + " extcode=" + extcode);
            } catch (Exception e) {
                e.printStackTrace();
                fail("ontransactionerror");
            } finally {
                nextFlg = true;
            }
        }
    };

    // コールバックイベント２：RESULTINFO
    private INfcServiceListener.Stub mINfcServiceListener2 = new INfcServiceListener.Stub() {

        // 取引処理完了時に処理結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactioncomplete(String value) {
            try {
                JSONObject jsonObjectMain = new JSONObject(value);
                JSONObject jsonObjectSub = jsonObjectMain.getJSONObject("ResultInfo");

                String ResultCodeExtended = jsonObjectMain.getString("ResultCodeExtended");
                String ResultCode = jsonObjectMain.getString("ResultCode");
                String TLVDataExtended2 = jsonObjectSub.getString("TLVDataExtended2");
                String TLVDataExtended = jsonObjectSub.getString("TLVDataExtended");
                String TLVData = jsonObjectSub.getString("TLVData");
                String OUTCOMEParameter = jsonObjectSub.getString("OUTCOMEParameter");
                String CardBrandIdentifier = jsonObjectSub.getString("CardBrandIdentifier");
                String MemberNumber = jsonObjectSub.getString("MemberNumber");
                String ExpirationDate = jsonObjectSub.getString("ExpirationDate");
                String CardHolderName = jsonObjectSub.getString("CardHolderName");
                String ApplicationPANSequenceNumber = jsonObjectSub.getString("ApplicationPANSequenceNumber");
                String TransactionResultBit = jsonObjectSub.getString("TransactionResultBit");

                assertEquals("ResultCodeExtended", "23000000".toUpperCase(), ResultCodeExtended);
                assertEquals("ResultCode", "1", ResultCode);
                // TLV拡張データ２
                assertEquals("TLVDataExtended2", "30303639df81290830f0f01038f0ff00df8116161e04000000656e646566720000000000000000000000ff81061bdf8115060000000000ffdf812b079000990000000f9f5d03000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000".toUpperCase(), TLVDataExtended2);
                // TLV拡張データ
                assertEquals("TLVDataExtended", "30313830500a4d6173746572436172645f2d06656e646566729f38089f02069f33039c019f6102a2c49f6502000e9f66020e709f6701039f690f9f6a049f7e019f02065f2a029f1a029f6a04000004129f7c1431323334353637383930313233343536373839309f7e0101df61080000000000000000df810c0102df81280100ff810534500a4d6173746572436172648407a00000000410109f1101019f6d0200019f6b135413339000001513d49121019017994126683f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000".toUpperCase(), TLVDataExtended);
                // TLVデータ
                assertEquals("TLVData", "313339820200008407a0000000041010950500000000009a031704259b0200009c01005f2a0209785f3601029f02060000000015009f03060000000000009f090200029f1a0200569f1e0831354e30303133339f21031640489f33030000009f3501009f360203f99f370458548f699f5301019f6b135413339000001513d49121019017994126683fdf811b016000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000".toUpperCase(), TLVData);
                // OUTCOME情報
                assertEquals("OUTCOMEParameter", "30f0f01038f0ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000".toUpperCase(), OUTCOMEParameter);
                // ブランド識別子
                assertEquals("CardBrandIdentifier", "01".toUpperCase(), CardBrandIdentifier);
                // 会員番号
                assertEquals("MemberNumber", "35343133333339303030303031353133000000".toUpperCase(), MemberNumber);
                // 有効期限
                assertEquals("ExpirationDate", "34393132".toUpperCase(), ExpirationDate);
                // Cardholder Name（カナ氏名）
                assertEquals("CardHolderName", "1234567890abcdef000000000000000000001234567890abcdef".toUpperCase(), CardHolderName);
                // Application PAN Sequence Number
                assertEquals("ApplicationPANSequenceNumber", "ff".toUpperCase(), ApplicationPANSequenceNumber);
                // 取引結果ビット
                assertEquals("TransactionResultBit", "6414000000".toUpperCase(), TransactionResultBit);

            } catch (Exception e) {
                e.printStackTrace();
                fail("コールバックイベント２:ontransactioncomplete");
            } finally {
                nextFlg = true;
            }
        }

        // 取引処理失敗時にエラー結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactionerror(int ecode, String extcode) {
            try {
                fail("コールバックイベント２: ecode=" + ecode + " extcode=" + extcode);
            } catch (Exception e) {
                e.printStackTrace();
                fail("コールバックイベント２:ontransactionerror");
            } finally {
                nextFlg = true;
            }
        }
    };

    // コールバックイベント３：DEINFO
    private INfcServiceListener.Stub mINfcServiceListener3 = new INfcServiceListener.Stub() {

        // 取引処理完了時に処理結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactioncomplete(String value) {
            try {
                JSONObject jsonObjectMain = new JSONObject(value);
                JSONObject jsonObjectSub = jsonObjectMain.getJSONObject("deinfo");

                String ResultCodeExtended = jsonObjectMain.getString("ResultCodeExtended");
                String ResultCode = jsonObjectMain.getString("ResultCode");
                String ContinueFlag = jsonObjectSub.getString("ContinueFlag");
                String Result = jsonObjectSub.getString("Result");
                String DataExchangeData = jsonObjectSub.getString("DataExchangeData");

                assertEquals("ResultCodeExtended", "00000000", ResultCodeExtended);
                assertEquals("ResultCode", "2", ResultCode);
                assertEquals("ContinueFlag", "00", ContinueFlag);                                               // 継続フラグ
                assertEquals("Result", "0000", Result);                                                          // 処理結果
                assertEquals("DataExchangeData", "01000D000BFF810400DF810603DF8112", DataExchangeData);   // DataExchangeデータ

            } catch (Exception e) {
                e.printStackTrace();
                fail("コールバックイベント３:ontransactioncomplete");
            } finally {
                nextFlg = true;
            }
        }

        // 取引処理失敗時にエラー結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactionerror(int ecode, String extcode) {
            try {
                fail("コールバックイベント３: ecode=" + ecode + " extcode=" + extcode);
            } catch (Exception e) {
                e.printStackTrace();
                fail("コールバックイベント３:ontransactionerror");
            } finally {
                nextFlg = true;
            }
        }
    };


    // ****************************** NFCInterfaceImpl.EMVCL_DataExchange start ******************************

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (!mIsDataExchangeでエラー) <br/>
     */
    @SmallTest
    public void testDataExchange_mIsDataExchange() {
        try {
            NfcPlugin nfcPlugin = setContext(2, null);
            nfcPlugin.OpenDevice();

            // パターン：!mIsDataExchangeでエラー（StartTransactionを行わずにDataExchangeを実行）
            String ret = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_mIsDataExchange");
        }
    }

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (ウインドウハンドルが登録されていない) <br/>
     */
    @SmallTest
    public void testDataExchange_mCompleteEvent() {
        try {
            // *************** StartTransaction ****************
            nextFlg = false;

            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            nfcPlugin.CloseDevice();
            nfcPlugin.registerNfcServiceListener("Transaction1", mINfcServiceListener1);
            nfcPlugin.OpenDevice();

            // パターン：DataExchangeResponse
            String ret = nfcPlugin.StartTransaction(TRAN_DATA, 0, "", "");
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction1");

            // *************** DataExchange ****************
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_CompleteEvent = NFCInterfaceImpl.class.getDeclaredField("m_CompleteEvent");
            m_CompleteEvent.setAccessible(true);
            m_CompleteEvent.set(nfcInterfaceImpl, null);

            // パターン：ウインドウハンドルが登録されていない
            String ret2 = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain2 = new JSONObject(ret2);
            String RunResult2 = jsonObjectMain2.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_mCompleteEvent");
        }
    }

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (状態チェックでBUSY以外になる) <br/>
     */
    @SmallTest
    public void testDataExchange_notBUSY() {
        try {
            // *************** StartTransaction ****************
            nextFlg = false;

            // readの返却値設定：StartTransaction
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            nfcPlugin.CloseDevice();
            nfcPlugin.registerNfcServiceListener("Transaction1", mINfcServiceListener1);
            nfcPlugin.OpenDevice();

            // パターン：DataExchangeResponse
            String ret = nfcPlugin.StartTransaction(TRAN_DATA, 0, "", "");
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction1");

            // ステータスをbusy以外にする
            setEMVStatus("EMVCL_CLAIMED");

            // *************** DataExchange ****************
            // パターン：状態チェックでE_BUSY以外になる
            String ret3 = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain3 = new JSONObject(ret3);
            String RunResult3 = jsonObjectMain3.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult3);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_notBUSY");
        }
    }

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (inputCheckEMVCL_DataExchangeの戻り値がSUCCESS以外) <br/>
     */
    @SmallTest
    public void testDataExchange_inputCheck() {
        try {
            // *************** StartTransaction ****************
            nextFlg = false;

            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            nfcPlugin.CloseDevice();
            nfcPlugin.registerNfcServiceListener("Transaction1", mINfcServiceListener1);
            nfcPlugin.OpenDevice();

            // パターン：DataExchangeResponse
            String ret = nfcPlugin.StartTransaction(TRAN_DATA, 0, "", "");
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction1");

            // *************** DataExchange ****************
            // パターン：inputCheckEMVCL_DataExchangeの戻り値がSUCCESS以外
            String ret2 = nfcPlugin.SendDataExchange(DATA_EXCHANGE_ERR1);

            // RETURN VALUE
            JSONObject jsonObjectMain2 = new JSONObject(ret2);
            String RunResult2 = jsonObjectMain2.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_inputCheck");
        }
    }

    // ****************************** NFCInterfaceImpl.EMVCL_DataExchange end ******************************

    // ****************************** NFCInterfaceImpl.DataExchangeTask start ******************************

    /**
     * Test:SendDataExchange <br/>
     *   ・正常 (BitmapTransferResponseが返る) <br/>
     */
    @SmallTest
    public void testDataExchange_normal() {
        try {
            // *************** StartTransaction ****************
            nextFlg = false;

            // readの返却値設定：StartTransaction
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            bufferList.add(buffer);

            // readの返却値設定：DataExchange
            byte[] buffer2 = ByteUtil.hex2bin("02034006f0187cb19f45235c498dcb95382829e3e85d85e4d4d8a21ab39abbf293d3be4c103a563d5a627837fb53163a3e4ef6d71f3507a499debfe220eb67de934153d3e3b51f8f6564de4d28d369b69ea53f6fe58a193737aa791608718f39307aa8fa0d1cd1abb8f38cdd7ab41b7f164b9c1e9522a9accca33232ac7203515ddcfa117fa2646f6b127dde0ad51aea7cca433f2b11e4e7daee496b246060b9cb093aea36988568db91cb5a14a688be39c6192619e59f553dd4d2d1ec400f16a5d82e9a480baee977f530117c53087fce688438596f409c0eeb8f1c4e011747eb6c9f876ca5c85d6cb91cc1726469b1696f3c82487434dbd094a11c03a481c90aa08a61ffe53399acc5044d041dde3c388636c17d2f7131e67acb2af00c2f467aba3dc3689c29e94bf06da4be19b38fc8ad08e69dd6c042e29353bf2875544daae4357d4cd6039ba7e039a15be3922105e2c71182014fe8277c148c2982205cc0162c3ac79ca20b45f916a26695c7be57126feee4b59589bf3caae292b77cb6105f6cd8e46f483325586b1b98c7e0a777f2e2eebd8be58c820d59c5a36044fac7f9a03d6afd80c840c4b3a276ec53e3c877d6f4ac4c1ae941ddc6e1db02352ad4489d273b270b42cba50079ca2d123e222cf3b067f907f8f176cf9225ab753840b62dc3824bed8597daa48b05e65be279c27730f38795ac7bdb6328eba4e17104219669d0e69c7e9bb88bf32f62dbd33dbd56b1cf839a9bbcf7825e9500222169e7fff09c8bb3eb1543b84a21caf808ea133474bdabfb802a037d4b22422631155a0c9e6f589d01cdd43a56db315e352c86505f2ff6a6a348086c0ec89b553661047ba24b0893bda9cc94e87d670454e6a6bb5d2fe22c454d9915cbcd62c8b8f5c7b3c4b9a91b4df8614ab3ab7d0f1e2e2f6a9b5eddfbcf6b9f50add667cb86105392c42d223e8a04df567725cbfdec29f8173ff1b6e8fc86c1968b296687eb22ce8129633ca26703f664e46a7f1a00eb64c5c3fc459316476e899dbd59deeaa8ca97acfe2a209671842a8014e8ae64d8b3566c182ff9f7d67962d4fcf84877e5abf3c096ed6fe1651ab195df36e1ef1796f0dcc1bc5ebf2d185c15bf307a855a30c8e98f2b106c3115c6689bcdb218c27c14539c36941ddbef8b88246b2a990dd54f94ff03738866310dce5c3b4e43a850eb29271bc98a4af02a1833f7e5ba20bfd59b4f9540a002051c4fc81994473cbc2cce8ab43513f925eb52a82dab8d77689c96a7c14ebacf1ef7440a512d96e5d1d4b63d2b714578969f11f209aeaca20d8b63b8097a34822943b24648e7975a9d825cc7add1c38d3b594e0f1ed502c202d9c154c9c9d78b5137646ac1aab0cd262d18ba013715f6f8981114050165cf5777166d656d09216ccbf788c8309802665ea65b7d5f844f2cbee8c2c6f4c4b776dbfd0fee7947b8c16a405081768df2d3260b786f7076327e967cd1c2f13941d5a2a9e5c7d07941548112eb9986632b52378b5ed0145f5dc439e95bfc3623d64f6f878414807518f21d3753150ca0dfad9baf928a3925215efb2367992c5c1cc470b8e0b36ff208369d7fcd48f244bb68f46bded630485702fe087e10bbea0772fc9e1a1fd00208332bb5f17c4c051e64d8966c902af7abade06f119e2b833667249202adace71aa8ae9ae77e57f983c9ff2cd9610577e07bbb8c7e877b994c548c14c775fe4e50a89e95af4f2f7985aad9832e64ebdc5cc0e3b9ea7d9bfdc2484b3eeeca3fad9731c1f677abdfc4a655327b02c1b7c56d8c0444863ea8a2afae6de553a7a03082cc80f15301f83f72f4396662836593b0f14c2fc9990e31b5bebb827d1a158c0164f85ab9e22a99b536ff0a858db0377285cd49cc4da0cc92189b55e5936c25df54cb80b2adb92ddf58f1b58fb6aff45260945abf3f0faefd89225b5e460850a5a7e6bbffa42bf91688af10f15c489840efc1c24f4b0aed0c97ea172899cd1eaa877a0256bb473bbf364c31b6d46bed0aee1da4e82d5c34341c20a2bc11f39c5c42f6d2c226580aec3d3df9a236178deedf5001fd9e716379f47ed76a712d72b72f8d88d27864403b5b554e180329f331b9e065c5a2d56581aea9dbeb02ee575e483f86a4e668b0c4d5f6e15add2289f9c4dcb030976c417c8e8186d0c54254fe48765d3af53b8055b87395aa2351717626bb0efaa30421c078f98f4199089a491fdcec35700d5f3bf87f272cfd82c307400e544c7d43d9464b364cded753f83047efa0d1b7f5cbb19f4748e0840a83b09a26cbe4ba86477d7bad7973284f92340f88686fe96bd11f425ec7e7e218f80c063fa43d48259f6a640707b22f53a03f0c21882d3b9586351c42b1a12a24580487c34574926af17b8f8ea5984b6e4cc6d9ee8d3d56a1439f27f1e9803d01c5978b690c558f21a1f1e27fc8ce68770d670b4336c14bd422d8e4c81ec5bf9e06cf4cf95fc1037a86abf4d681f1a91e8e91927d8eee3febce7750b411a0b4ae0ffcb2fa3d97245e7f771d8fde460ce0c09889c0eb3c215a9434666812a2b26857e4aa934ee546035e4eb630959b053e08f0cf5b71182cf9070b0089457afc383a8e65d96d9a357c947180e178f66c32d68e688c29144b8d1b1b2642a94143c23cafda60e0085ad92fae1bac9422a7ddf3211c2e0b1dc888ed5982b53ee3eb7f5cfd452c4ad73d074511de56dbe962a6dee2291c8737400a4bf25e51a42d40d1aa29761236886eddc7bac9b806365ee18d380a4f6e51c10a8c08ccd33300cc1c93b696b376e8f522b04fcdb6b7f2ff90c0c89230657048a72b4db5a0edc1b90c0838aaa9101a1c15d087e5d0f37cb44026abc44cd51a6f560e4343f2acb39dd3ebebdcde22c078b6294cbf8a6c503157967640eb015ba618c216041109dfca1687809c193c6f31fc5edf0ba725c6f5c8cf84c7719e12f3ca32ac8c59b61e1fc17fca66b20b59143c1f62fb5ef11d8215e95022309fc4fc98c7f671eb8097039ca5c39913d4c8dd3b55450688ee32723cb8265fec53e08a244c1018903ad5523652cf9608d0c0bdc6419d80008a25e9612c0f365c326de691e9ad7aad0eb701fc3515c303dd309855b12914f77dc44e0a0185da2bb01359697ef41f3fa287fc296b2624f3acbeac72a3ba56fa45ec57311dd608b6300d7f29420f30ff98352a7141cf8a0a6e769ce3e96621257155b9086a6bf8ef585c8b2e317f7d70f7b9692cc56c686062ca142a53cae20dcdfd01a3673abfee5c61e78c95d1e2832b84180997ee2a5bee6423ff939cb5a0b44aa9a32d872ec4b8d96a119327242268ca480122be0d02a60b9771e7cdf19691958891561f8990acd3631f7b175cf5382480abc103ad10f21d6adef6f3fe2b4c5dc9fa170c1c2809952a426ff9b84213aa86173442d70305cd4dac9274bb7b3294ba006d1eb81f8ca2dd403003d04709c174d311545bfbcdb0be5e8a340d15c84de6f64ac61ed0ebac1dfd1767394dda2cc2cda3c45fa5c4183265845528e4915c8e2c027ac7eb0f011536b8db5ff13058bf9c6999f3ac6eefc591be9a8635e0bc6992f72113de51d5000940c2b1344284d3e18e1f92a68678ce85554004d6e4c2af181c300598310fab3ccd42c93adbdf36b0fcdd44f2fe0bed74c2e4a1d65d3d9c92f8747e6494556efd4af4f6d5a119e7d87f0edd6facef702b17ab2986a08b4f5967797ddb9ebb94165eebec315179e0e216fe706e4222b56e56ba9716fa6681a4b88821c711157d98967ab738e6b113a54132b4287d8a0fe461624e76e75cf407a70cc83f6a0df3f3520603ca13ded1716f63829f1c44f9c56264eb187807cd9946793f5f04313252f9202bd283b96abb8e3af15e48e4334cc60cb0b954a4947d95fbf2fc72e4f713509ca09e02b8721dd0c93452583eccf6089d16379511049e9af744756e91f2f638e8e17d6516f0c4ddebb177567d8b26dd3a5514b381634d8fe533859e72c6ddb52feaa681a83eeed1c05f067c719cbc57ea73130ac11743690bfacde7c836ad0da513bb2ef4aa456593d450cdb53df4496415a2e8ada09b26fcb9e7e6e2c929399294875cdc816665e1f2c4efdacc2d841fcdc4076e7579587de285dc93870b70d4c8cdbca3d40890f03b7090a2647e765264e17be02794a62c42e4e9d31411b3658f77b26015d113b674a867a6d53edd7099b9e4e173a2b91625076401251231eace17b566d326681652b86b79c8273211f35b62f390b982939793e6ea5e8c0b495d57f48e833f9c7e268892199feaa425bd0981cd784031241f0df774069f939484b879949c6126972a4031f154e36a60fc154e579a212435283b947ba5ff2ff3f56314651a15c3dd2fae7f0f7a9d569394badb629d4bf11e131e1d2c0b96e266930612d8828011bce8e5e12eaf283df47683276b8d2c96da9b9eb92c20187242d6db17d39015bfb92676ce39721df96d74ff518e9a9b6619d4550874b1be48c0f1a89ed7b11bed4478888b2279a978ef234be86f0621e45abfd21401f785bb5d6169166f9c4bb75abe7bec31a91c34cc0dee433189dc48f3297073e538ce63b148e8ea5cd0890275831f79a5c63058a8552a68d319069c32de66f911ed69c760d18c6e80f80df4cd91a3cb2631b138d2a96f422b2cb58e143af732978fef4b31aa5f6a4e8169353fe0450bf4fce8a7d16de56e0a1ab7228a991f6911b03e0113c1ebaad6fa54034fe7464dd269480c69e44ca8cb23219674c34a4f0c9820be035d1a2f33a491656a90103b0d691d4a42e067e5c4c78b0b56a1b00ddfd57ee73ee6a260c0ac5b98efc050a93026c1e2af10f7cb746365a0ae0b6b65ae8b94e4321b8de447ca92555362c1a491d51164c952e4d188d35f5d9155e024e84a8eadeb0d34a88009a34cea8cd7ff7af13b474977556b64fd7f94889d0f9bda90cd430f9b38c5310437da9650ca72ec02b19fba890422bb48d9305b7cdec313a8b8b2888bae9e7c6cb26955ee8d9c1f4b82b4f9e6a00e8e9bee3f6109b54a6c02830d417a65fa477aa8c75280b58e65d7e499a70db1bd446a2d668d5460cda31b8582348f0c7eecca22c312abc4ad6ddaa8445420d3ce4241be3aa29a84059be7ca2270a826f0d350c3738785dd94104827495c7baef22793f8428d8483e2f822a3628fbc354ee5ddcf7a054e53074c1c358b3a431933124009028d794c9cfde79cbe5c5c5fd704a5e861f1107e0dd72d625d8695544fd1cfbfd7c5879538c2f59a065a30e3c26dd5c954dda8884fee1c07491d25e3050d44b720ff084e92e813f94164ff58a18ab4a9933d3206909156bc925f441a0fab2c9e2e060e1cc9e20dfcbe23b65477d555609f6d6837222b30f09201e0df48fff1e017658564d05deaf6b6c495ee5df8de576106a3341c300c3ef02ebc3ec20f9b4a799b3fc4b35bfd0467b9c699bd7e630ba44fe446048e26f570ebac94a5acff17362d949311d10fc61f89cf9bc69c981c1c02c4c0cb998ba195d2890fb2e534a5089932b0812a899557068eb204379fcc9129ce7e0b165507f2a299f9876a0579d276f7275be15f57e38a38090b7df9fda65408f698afe2e7503dda682bb28ebff42d40b3dbc60c98174afb1c93703aca0f2649ab8b228511e64d7361a77fae19052faa96eebb64ba60dd722a746c50cd62cbcc639ece1b70e6e39ddc4e162fe7ff869b46a8d91eea8660b026bcef6e50ee3c96cb82774bc363a9f1aa3ba46f238afe780b64be84fe44fcf90a6254bfeec1fc8b9b0703a0de5ee0436492d8d29bb736a959cce5015d421fef1be4eb2719e0590c20f15be2b030f3744628dec70f86a7e08cce085ff9267512de5c83e62b9f4d5bec002981db5ff85e5cbf9149398a4aa2589dcecf8bde11c6b485ae0fb829eb34e62a5c821da3ddf2d3f0941e0886df509893643a8719538925989be53296d3d139a05d7fc47c5667b1e666d6a944331ce6439c591da5d9e7cb9306cbcdb75cd139e3f43bf577d65a01df77fc7bd119c131dcc0f2e4b02c148ca61d24839922858d251c928c166f5e789f698edee4329f20e8449d1b875a3e14298f952fab720f3453ef65bc0e0cc52a9051bf92eb0d0598d39a2e54c914c9141ea3247186801750a580d8ee128b16882d714ed6ff7f9bf72e71705619c3adb28d19e2252608e1d6e18d23fae5c592c734018cb1b9227730a2fef6d6467b9db4c91784f1bae27e92dcfb111bca6b20bc81680f477c343acc69b398477012308f1ad2adca45b8b6560db26352724f44d5d01d12ada8b65b6d3cb74285c5179447aabcdbc6bfd9f279b9f74f14f2f10b49987482748e031f0982774639e97bc02daa9c82fb1799a0fd2ef9d8d9d7bb91da48e853963a24f116fbd2798aa905f52e37a16dd91da2b50b451a634728fd4deb56fc6ad95c9cf1b61c5732828824d933c9869fd18761bbafd015b1723f5f85eda08c137b3ddfe2fb37e71e787468faeaf793777916cdb8f985c85e1105ae77900bf626aca8544cacbdb95d714d22ecccfb4ec14d2d4d5471a0bce804610ac262ca35ee807ba656739537fe11ac69a90c4d6679f633fd08931dde74aec2a2303aaf17c809a83b2ccdd88f3996493df5aac29ad85acfce9b0739986ec28f9502b11652c29f1b34114ffaca5f206f75bd8f3017d81a3616e7e041f3f82b7cc674a8f857b70bb43139adffa85f6960acf1a4955fbcccffa993195cbd81e44fc7fa9cff370ebfedfec5fd63eab06037a7ea4d155b42677e384ca1f09003cb27b74881676860c281d7dc959a83dbd5911b8415a4bf432087152647b382608d52e53fcd10e08b8fb97f95cbc5f15ab56e498c7c2ecca04f26179bf113dd3aa2038627bcd1542faa498121fea7e5099bf1fb3f081be613db337889ae83a266c4c75ae1b15411141ab45d097fa66e1fec24d8dafff0348259441a7d7029bf537ce4e1c48687fab5678a92dce22798c88e1ef2fcadef794d787cc55a55be4e672adadec29d8474145d3640e8314155958dc2f669645a819d0fd6258086e05a58b1e28fcc33588d5511872e6215b804970438bb6e7138373eb2fa7b17bf242b24225d64abb4c475e755ce4f1b0fb6067d18e828bb086db8dac83a439366e1e87a7c79f3bd6015504a4a1492368b90f71af8aef0f390127f869fb1824482266bf8d1e554a57f03e9d9e38d868e96014d7d7049dcfecc593002c4580d6b3de7725c8f2d67dda415e6f7498f246b0d97a6551c6080e19f565d6a3ff4eeb805e6b9e3619084733085d43a75b308b450945aca1d46618a4433c6ce8ed7cdd05deae889ac8634efe667b1c5cc128d5f39cc0cd3efe8ef9f8dbfdb5930a879b6d85b27521b5a5b7b827f4d380b928738f9ae2ba619717430af32264b9bd7bf818ef7515f4a3ea4030b6b4dd24912b5423d0b5dc108ce38f07a728d4189ef70b59841d93be59308dacd3dd7d3ed80ad2d432c7a16ae4adb8fb0b1dabfa374d777876d098428a95452c1bfb22d2d572dfa92f75220b43feb9ec7e36fc7047ace972771cd822f3efc49898a943d2481c2fef9ab9dc28a7e21e35b0137d762a9e4ec9bf1c82c26ad9863a241002848674581eb5d922e4b3365a9da0bce848ab8c5320a8ea17e4989d77b3c7de8453071e86fe65bbb4dcfad5626f6f3323248a56ac55930760691ff06557d0ab7295e440649b16dfa090beaf68f33b6ebcaff7dc5b74e3a7015d12aa7faf561765055afb887cd0af53d7ab33fdbf4605e0267fb34d9b0f7e10f69e99c28ef22f1f1aa6d6ae5020ef1cef671c927b30d81e2bd67207b4f9f71f2b0d1cc86098ef3a18a56e4b4baf7c1fa93d92b05e82f0d44aeb0af5e51d08469f0a2aa2dc19e64b73d34a5b59c7835698be670858ed2e7a51db546e326e64849d955432c3b2d8fbfa2255744a49173a0417299a19e9b2c7380e8dc91b8e63f4247eb31f7c6ea36a2c82348381205c4a196aad35c272f454269b84ae0ea7df0607918c6f59de7461cac39f8020334ae3cb2095ea5759d7219888ad4e50616296395118e66ae2ef8f298434aeadb0bd2da03ee65c93a209704c781f92b6eaff15f25e686974619000e1d11128038e10c870c1fec7f62cb9ab6607552e43ad28ba875e9628f6669d48c5ca300267b3f295c5f0c5f67a439a2d4eea76b42e40f4cc62030b5b69b74c103d5b58b4b43d32e050ea5d6e308da2a542b76504a15a82137d69a9562e007823783f2669f921236f7f224debeeeea43e93876b9f65a2b10eb28b91a356614e8c2c7449e6e95816b340626a4cad084cee746ca2fe3a9d3837682e10c1b140d98b24e4b918eec22073e7208a3fe37eebaea80ddd87afd9008c2405899ae55e84ca364da4dc8212e7d529979773e23f3789938101ffb22b791629d3a151b2039912ac34e7cd8794ad83dbae4e450833ae63228f4d398e83df926bb08fce5656babbd1d79bb1f5886867da0315a18cba6ba35680a88bc80d9d2ba9d0f5656a7d9b224760cd43cd6eae5f92e46a3bf621aafe2506d03830a242a5e6eee8f3fae607811a033b7607797f64e55402ce7e6c6b46bc201fa4b97eafb063c4c298711172deb011cc286ef31e822ad1827050fdb879ec14316a650120843463466eb947db49ed470390b3177aeacca49c85a69ec0f7eabda2aa45215b729f7f64bfaa7d0a9241466371042307c571d9d7c95d797c6e7ba2541263498bb25bb04583d2f03b7ad8fb68e6b4ea386f0660aaf3d7b9ca7878ec9fd24776a822184522fb9304ade05504bcf94ac5284a6e84b4db9a37b5534c89f0d7d625bea27dcec5642e9aa5df32b1bb527a8e46654081006b64ec4f84aeef4c11b76eac69ce5808bdbe76275fe34e9b77c7b4490558a80eeb0025b68ef399316c66b86600b4239418b2e829eed26bc95d24ec1a9e2a149554e16d50107f42a2f757e5d929beea6a0b180b37e44ec2dd56fc8cdd5976e45d189963f55d69012f37f39294f3963b48732c69a7d711ad06bde371100d3e206e4e2234e04ec03dddc");
            bufferList.add(buffer2);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            nfcPlugin.CloseDevice();
            nfcPlugin.registerNfcServiceListener("Transaction1", mINfcServiceListener1);
            nfcPlugin.OpenDevice();

            // パターン：DataExchangeResponse
            String ret = nfcPlugin.StartTransaction(TRAN_DATA2, 0, "", "");
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            // *************** DataExchange ****************
            nextFlg = false;

            // パターン：BitmapTransferResponse
            String ret2 = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain2 = new JSONObject(ret2);
            String RunResult2 = jsonObjectMain2.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult2);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction1");

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_normal");
        }
    }

    /**
     * Test:SendDataExchange <br/>
     *   ・正常 (DataExchangeResponseが返る) <br/>
     */
    @SmallTest
    public void testDataExchange_reDataExchange() {
        try {
            // *************** StartTransaction ****************
            nextFlg = false;

            // readの返却値設定：StartTransaction
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            bufferList.add(buffer);

            // readの返却値設定：DataExchange
            byte[] buffer2 = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            bufferList.add(buffer2);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            nfcPlugin.CloseDevice();
            nfcPlugin.registerNfcServiceListener("Transaction1", mINfcServiceListener1);
            nfcPlugin.OpenDevice();

            // パターン：DataExchangeResponse
            String ret = nfcPlugin.StartTransaction(TRAN_DATA, 0, "", "");
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            // *************** DataExchange ****************
            nextFlg = false;

            // パターン：DataExchangeResponse
            String ret2 = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain2 = new JSONObject(ret2);
            String RunResult2 = jsonObjectMain2.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult2);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction1");

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_reDataExchange");
        }
    }

    // ****************************** NFCInterfaceImpl.DataExchangeTask end ******************************


    // ****************************** NfcPlugin.SendDataExchange start ******************************

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (引数deinfoがnull) <br/>
     */
    @SmallTest
    public void testDataExchange_deinfoNull() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();

            // パターン：deinfo == null
            String ret = nfcPlugin.SendDataExchange(null);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_deinfoNull");
        }
    }

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (mNFCInterfaceImplがnull) <br/>
     */
    @SmallTest
    public void testDataExchange_mNFCInterfaceImplNull() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();

            Field mNFCInterfaceImpl = NfcPlugin.class.getDeclaredField("mNFCInterfaceImpl");
            mNFCInterfaceImpl.setAccessible(true);
            mNFCInterfaceImpl.set(nfcPlugin, null);

            // パターン：mNFCInterfaceImpl == null
            String ret = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // 元に戻す
            mNFCInterfaceImpl.set(nfcPlugin, NFCInterfaceImpl.getInstance());

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_mNFCInterfaceImplNull");
        }
    }

    /**
     * Test:SendDataExchange <br/>
     *   ・準正常 (convertDeinfoの戻り値がnull) <br/>
     */
    @SmallTest
    public void testDataExchange_setDeinfoNull() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();

            String deinfo = "{\"Result\":\"0000\",\"DataExchangeData\":\"0100070005df81120182\"}";

            // パターン：setDeinfo == null
            String ret = nfcPlugin.SendDataExchange(deinfo);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDataExchange_setDeinfoNull");
        }
    }

    // ****************************** NfcPlugin.SendDataExchange end ******************************

    // ****************************** NfcPlugin.convertDeinfo start ******************************

    /**
     * Test:convertDeinfo <br/>
     *   ・準正常 (setContinueFlag == null) <br/>
     */
    @SmallTest
    public void testConvertDeinfo_ContinueFlag() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertDeinfo = NfcPlugin.class.getDeclaredMethod("convertDeinfo", String.class);
            convertDeinfo.setAccessible(true);

            String deinfo = "{\"ContinueFlag\":\"\",\"Result\":\"0000\",\"DataExchangeData\":\"0100070005df81120182\"}";

            // パターン：setContinueFlag == null
            DEINFO ret = (DEINFO)convertDeinfo.invoke(nfcPlugin, deinfo);

            // 結果確認
            assertEquals(null, ret);

        } catch (Exception e ) {
            e.printStackTrace();
            fail("testConvertDeinfo_ContinueFlag");
        }
    }

    /**
     * Test:convertDeinfo <br/>
     *   ・準正常 (setContinueFlag.length != 1) <br/>
     */
    @SmallTest
    public void testConvertDeinfo_ContinueFlagLength() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertDeinfo = NfcPlugin.class.getDeclaredMethod("convertDeinfo", String.class);
            convertDeinfo.setAccessible(true);

            String deinfo = "{\"ContinueFlag\":\"0000\",\"Result\":\"0000\",\"DataExchangeData\":\"0100070005df81120182\"}";

            // パターン：setContinueFlag.length != 1
            DEINFO ret = (DEINFO)convertDeinfo.invoke(nfcPlugin, deinfo);

            // 結果確認
            assertEquals(null, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertDeinfo_ContinueFlagLength");
        }
    }

    /**
     * Test:convertDeinfo <br/>
     *   ・準正常 (setResult == null) <br/>
     */
    @SmallTest
    public void testConvertDeinfo_Result() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertDeinfo = NfcPlugin.class.getDeclaredMethod("convertDeinfo", String.class);
            convertDeinfo.setAccessible(true);

            String deinfo = "{\"ContinueFlag\":\"00\",\"Result\":\"\",\"DataExchangeData\":\"0100070005df81120182\"}";

            // パターン：setResult == null
            DEINFO ret = (DEINFO)convertDeinfo.invoke(nfcPlugin, deinfo);

            // 結果確認
            assertEquals(null, ret);

        } catch (Exception e ) {
            e.printStackTrace();
            fail("testConvertDeinfo_Result");
        }
    }

    /**
     * Test:convertDeinfo <br/>
     *   ・準正常 (setDataExchangeData == null) <br/>
     */
    @SmallTest
    public void testConvertDeinfo_DataExchangeData() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertDeinfo = NfcPlugin.class.getDeclaredMethod("convertDeinfo", String.class);
            convertDeinfo.setAccessible(true);

            String deinfo = "{\"ContinueFlag\":\"00\",\"Result\":\"0000\",\"DataExchangeData\":\"\"}";

            // パターン：setDataExchangeData == null
            DEINFO ret = (DEINFO)convertDeinfo.invoke(nfcPlugin, deinfo);

            // 結果確認
            assertEquals(null, ret);

        } catch (Exception e ) {
            e.printStackTrace();
            fail("testConvertDeinfo_DataExchangeData");
        }
    }

    /**
     * Test:convertDeinfo <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testConvertDeinfo_normal() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertDeinfo = NfcPlugin.class.getDeclaredMethod("convertDeinfo", String.class);
            convertDeinfo.setAccessible(true);

            // パターン：正常
            DEINFO ret = (DEINFO)convertDeinfo.invoke(nfcPlugin, DATA_EXCHANGE);

            // 結果確認
            assertEquals("ContinueFlag", (byte)0x00, ret.ContinueFlag);
            assertEquals("Result", "0000", ByteUtil.bin2hex(ret.Result));
            assertEquals("DataExchangeData", "0100070005df81120182", ByteUtil.bin2hex(ret.DataExchangeData));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertDeinfo_normal");
        }
    }

    // ****************************** NfcPlugin.convertDeinfo end ******************************

    // ****************************** NfcPlugin.convertCompleJSONData start ******************************

    /**
     * Test:convertCompleJSONData <br/>
     *   ・準正常 (resultInfo.isSet == false && deInfo.isSet == false) <br/>
     */
    @SmallTest
    public void testConvertCompleJSONData_NoInfo() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertCompleJSONData = NfcPlugin.class.getDeclaredMethod("convertCompleJSONData", RESULTINFO.class, DEINFO.class, String.class);
            convertCompleJSONData.setAccessible(true);

            RESULTINFO resultInfo = new RESULTINFO();
            DEINFO deInfo = new DEINFO();
            String resultCodeExtendsString = "";

            // パターン：resultInfo.isSet == false && deInfo.isSet == false
            String ret = (String)convertCompleJSONData.invoke(nfcPlugin, resultInfo, deInfo, resultCodeExtendsString);

            // 結果確認
            JSONObject jsonObjectMain = new JSONObject(ret);
            assertEquals("ResultCodeExtended", false, jsonObjectMain.has("ResultCodeExtended"));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertCompleJSONData_NoInfo");
        }
    }

    /**
     * Test:convertCompleJSONData <br/>
     *   ・正常 (resultInfo) <br/>
     */
    @SmallTest
    public void testConvertCompleJSONData_resultInfo() {
        try {
            nextFlg = false;

            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            String readDat1 = createReadData("034006f018008418eb019010018000000000000000a0000000000000008000000000000000100000000060ffc0000023000000000000000000000000000000000000000000003534313333333930303030303135313300000034393132303030011234567890abcdef000000000000000000001234567890abcdefff64140000000000363430f0f01038f0ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000313339820200008407a0000000041010950500000000009a031704259b0200009c01005f2a0209785f3601029f02060000000015009f03060000000000009f090200029f1a0200569f1e0831354e30303133339f21031640489f33030000009f3501009f360203f99f370458548f699f5301019f6b135413339000001513d49121019017994126683fdf811b01600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030313830500a4d6173746572436172645f2d06656e646566729f38089f02069f33039c019f6102a2c49f6502000e9f66020e709f6701039f690f9f6a049f7e019f02065f2a029f1a029f6a04000004129f7c1431323334353637383930313233343536373839309f7e0101df61080000000000000000df810c0102df81280100ff810534500a4d6173746572436172648407a00000000410109f1101019f6d0200019f6b135413339000001513d49121019017994126683f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030303639df81290830f0f01038f0ff00df8116161e04000000656e646566720000000000000000000000ff81061bdf8115060000000000ffdf812b079000990000000f9f5d0300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            byte[] buffer = ByteUtil.hex2bin(readDat1);
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            setClearNfcPlugin(nfcPlugin);
            nfcPlugin.registerNfcServiceListener("Transaction2", mINfcServiceListener2);
            nfcPlugin.OpenDevice();

            // パターン：resultInfo 正常
            String ret = nfcPlugin.StartTransaction(TRAN_DATA2, 0, "", "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction2");

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertCompleJSONData_resultInfo");
        }
    }

    private void setClearNfcPlugin(NfcPlugin nfcPlugin) {
        try {
            //NonContactICCard mNonContactICCard
            nfcPlugin.CloseDevice();
            Field mNonContactICCardField = NfcPlugin.class.getDeclaredField("mNonContactICCard");
            mNonContactICCardField.setAccessible(true);
            NonContactICCard mNonContactICCard = (NonContactICCard)mNonContactICCardField.get(nfcPlugin);
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NONE);
            mNonContactICCardField.set(nfcPlugin,mNonContactICCard);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * Test:convertCompleJSONData <br/>
     *   ・正常 (resultInfo null) <br/>
     */
    @SmallTest
    public void testConvertCompleJSONData_resultInfoNull() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertCompleJSONData = NfcPlugin.class.getDeclaredMethod("convertCompleJSONData", RESULTINFO.class, DEINFO.class, String.class);
            convertCompleJSONData.setAccessible(true);

            RESULTINFO resultInfo = new RESULTINFO();
            DEINFO deInfo = new DEINFO();
            String resultCodeExtendsString = "";

            resultInfo.isSet = true;

            // パターン：resultInfo 正常
            //   TLVDataExtended2 == null
            //   TLVDataExtended == null
            //   TLVData == null
            //   OUTCOMEParameter == null
            //   MemberNumber == null
            //   ExpirationDate == null
            //   CardHolderName == null
            //   TransactionResultBit == null
            String ret = (String)convertCompleJSONData.invoke(nfcPlugin, resultInfo, deInfo, resultCodeExtendsString);

            // 結果確認
            JSONObject jsonObjectMain = new JSONObject(ret);
            JSONObject jsonObjectSub = jsonObjectMain.getJSONObject("ResultInfo");

            assertEquals("ResultInfo", true, jsonObjectMain.has("ResultInfo"));
            assertEquals("TLVDataExtended2", false, jsonObjectSub.has("TLVDataExtended2"));
            assertEquals("TLVDataExtended", false, jsonObjectSub.has("TLVDataExtended"));
            assertEquals("TLVData", false, jsonObjectSub.has("TLVData"));
            assertEquals("OUTCOMEParameter", false, jsonObjectSub.has("OUTCOMEParameter"));
            assertEquals("MemberNumber", false, jsonObjectSub.has("MemberNumber"));
            assertEquals("ExpirationDate", false, jsonObjectSub.has("ExpirationDate"));
            assertEquals("CardHolderName", false, jsonObjectSub.has("CardHolderName"));
            assertEquals("TransactionResultBit", false, jsonObjectSub.has("TransactionResultBit"));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertCompleJSONData_resultInfoNull");
        }
    }

    /**
     * Test:convertCompleJSONData <br/>
     *   ・正常 (deInfo) <br/>
     */
    @SmallTest
    public void testConvertCompleJSONData_deInfo() {
        try {
            // *************** StartTransaction deInfo ****************
            nextFlg = false;

            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            byte[] buffer2 = ByteUtil.hex2bin("020380432000D2B1394F920230587330F383C3518EFAA312B815CB95BAA62860B092B57E0D9603E825");
            String readDat = createReadData("034006f018008418eb019010018000000000000000a0000000000000008000000000000000100000000060ffc0000023000000000000000000000000000000000000000000003534313333333930303030303135313300000034393132303030011234567890abcdef000000000000000000001234567890abcdefff64140000000000363430f0f01038f0ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000313339820200008407a0000000041010950500000000009a031704259b0200009c01005f2a0209785f3601029f02060000000015009f03060000000000009f090200029f1a0200569f1e0831354e30303133339f21031640489f33030000009f3501009f360203f99f370458548f699f5301019f6b135413339000001513d49121019017994126683fdf811b01600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030313830500a4d6173746572436172645f2d06656e646566729f38089f02069f33039c019f6102a2c49f6502000e9f66020e709f6701039f690f9f6a049f7e019f02065f2a029f1a029f6a04000004129f7c1431323334353637383930313233343536373839309f7e0101df61080000000000000000df810c0102df81280100ff810534500a4d6173746572436172648407a00000000410109f1101019f6d0200019f6b135413339000001513d49121019017994126683f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030303639df81290830f0f01038f0ff00df8116161e04000000656e646566720000000000000000000000ff81061bdf8115060000000000ffdf812b079000990000000f9f5d0300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            byte[] buffer3 = ByteUtil.hex2bin(readDat);
            bufferList.add(buffer1);
            bufferList.add(buffer2);
            bufferList.add(buffer3);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            setClearNfcPlugin(nfcPlugin);
            nfcPlugin.registerNfcServiceListener("Transaction3", mINfcServiceListener3);
            nfcPlugin.OpenDevice();

            // パターン：deInfo 正常
            String ret = nfcPlugin.StartTransaction(TRAN_DATA2, 0, "", "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult);

            while (!nextFlg) {
                Thread.sleep(100);
            }


            // *************** DataExchange deInfo ****************
            nextFlg = false;

            // パターン：deInfo 正常
            String ret2 = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain2 = new JSONObject(ret2);
            String RunResult2 = jsonObjectMain2.getString("RunResult");

            // 結果確認
            assertEquals("RunResult2", "00", RunResult2);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction3");


            // *************** DataExchange resultInfo ****************
            nextFlg = false;

            nfcPlugin.registerNfcServiceListener("Transaction2", mINfcServiceListener2);

            // パターン：resultInfo 正常
            String ret3 = nfcPlugin.SendDataExchange(DATA_EXCHANGE);

            // RETURN VALUE
            JSONObject jsonObjectMain3 = new JSONObject(ret3);
            String RunResult3 = jsonObjectMain3.getString("RunResult");

            // 結果確認
            assertEquals("RunResult3", "00", RunResult3);

            while (!nextFlg) {
                Thread.sleep(100);
            }

            nfcPlugin.unregisterNfcServiceListener("Transaction2");

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertCompleJSONData_deInfo");
        }
    }

    /**
     * Test:convertCompleJSONData <br/>
     *   ・正常 (deInfo null) <br/>
     */
    @SmallTest
    public void testConvertCompleJSONData_deInfoNull() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Method convertCompleJSONData = NfcPlugin.class.getDeclaredMethod("convertCompleJSONData", RESULTINFO.class, DEINFO.class, String.class);
            convertCompleJSONData.setAccessible(true);

            RESULTINFO resultInfo = new RESULTINFO();
            DEINFO deInfo = new DEINFO();
            String resultCodeExtendsString = "";

            deInfo.isSet = true;

            // パターン：deInfo 正常
            //   Result == null
            //   DataExchangeData == null
            String ret = (String)convertCompleJSONData.invoke(nfcPlugin, resultInfo, deInfo, resultCodeExtendsString);

            // 結果確認
            JSONObject jsonObjectMain = new JSONObject(ret);
            JSONObject jsonObjectSub = jsonObjectMain.getJSONObject("deinfo");

            assertEquals("ResultInfo", true, jsonObjectMain.has("deinfo"));
            assertEquals("Result", false, jsonObjectSub.has("Result"));
            assertEquals("DataExchangeData", false, jsonObjectSub.has("DataExchangeData"));

        } catch (Exception e) {
            e.printStackTrace();
            fail("testConvertCompleJSONData_deInfoNull");
        }
    }

    // ****************************** NfcPlugin.convertCompleJSONData end ******************************

}
