package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants;
import com.panasonic.avc.smartpayment.devctlservice.nfc.CommandDataConstants.DEVICE_INFORMATION_RESPONSE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * DeviceInformationResponseのUTクラス </br>
 */
public class DeviceInformationResponseTest extends ApplicationTestCase<Application> {

    public DeviceInformationResponseTest() {
        super(Application.class);
    }

    /**
     *  Test:checkDateCalendar <br/>
     *  ・正常
     */
    @SmallTest
    public void  testCheckDateCalendar() {
        //020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5

        DeviceInformationResponse dr = new DeviceInformationResponse();
        Method mCheckDateCalendarMethod;

        // 機器情報要求レスポンスにて日付のサイズは4
        byte[] bytes1 = { 0x01, 0x02, 0x03, 0x04 };
        byte[] bytes2 = { 0x00, 0x00, 0x00, 0x00 };

        DateFormat dateFormat = new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYYYMMDD);
        boolean result;

        try{
            mCheckDateCalendarMethod = DeviceInformationResponse.class.getDeclaredMethod
                    ("checkDateCalendar", byte[].class, DateFormat.class, DEVICE_INFORMATION_RESPONSE.class);
            mCheckDateCalendarMethod.setAccessible(true);

            // byte配列≠nullかつbyte配列≠{ 0x00, 0x00, 0x00, 0x00 }の場合、日付変換し、正常な結果を出す。
            result = (boolean)mCheckDateCalendarMethod.invoke(dr, bytes1, dateFormat, DEVICE_INFORMATION_RESPONSE.CHECKSUMENTRYPOINT);
            assertTrue("testCheckDateCalendar", result);
            // byte配列＝{ 0x00, 0x00, 0x00, 0x00 }の場合、日付変換対象にならず正常な結果を出す。
            result = (Boolean)mCheckDateCalendarMethod.invoke(dr, bytes2, dateFormat, DEVICE_INFORMATION_RESPONSE.CHECKSUMENTRYPOINT);
            assertTrue("testCheckDateCalendar", result);
            // byte配列＝nullの場合、日付変換対象にならず正常な結果を出す。
            bytes2 = null;
            result = (Boolean)mCheckDateCalendarMethod.invoke(dr, bytes2, dateFormat, DEVICE_INFORMATION_RESPONSE.CHECKSUMENTRYPOINT);
            assertTrue("testCheckDateCalendar", result);
        } catch(Exception e){
            e.printStackTrace();
            fail("testCheckDateCalendar 例外発生");
        }
    }

    /**
     *  Test:checkDateCalendar <br/>
     *  ・異常(ParseException)
     */
    @SmallTest
    public void  testCheckDateCalendarError() {
        DeviceInformationResponse dr = new DeviceInformationResponse();
        Method mCheckDateCalendarMethod;
        byte[] bytes = { 0x01, 0x02, 0x03 };
        DateFormat dateFormat = new SimpleDateFormat(CommandDataConstants.DATE_FORMAT_YYYYMMDD);
        boolean result;

        try{
            mCheckDateCalendarMethod = DeviceInformationResponse.class.getDeclaredMethod
                    ("checkDateCalendar", byte[].class, DateFormat.class, DEVICE_INFORMATION_RESPONSE.class);
            mCheckDateCalendarMethod.setAccessible(true);
            // byte配列のサイズが3以下の場合、ParseExceptionが発生して異常な結果を出す。
            result = (Boolean)mCheckDateCalendarMethod.invoke(dr, bytes, dateFormat, DEVICE_INFORMATION_RESPONSE.CHECKSUMENTRYPOINT);
            assertFalse("testCheckDateCalendar", result);
        } catch(Exception e){
            e.printStackTrace();
            fail("testCheckDateCalendar 例外発生");
        }
    }
}
