package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.SETTINGINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.share.INfcServiceListener;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * NfcPluginのUTクラス (シナリオ)<br/>
 */
public class NfcPluginTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public NfcPluginTestScenario() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    //   type  0:readなし
    //         1:readあり
    //         2:openのみ
    //         3:readあり(closeなし)
    private NfcPlugin setContext(int type, List<byte[]> bufferList) throws Exception {
        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        if (type != 0) {
            // readの返却値設定：OpenDevice
            byte[] bufferOpen = ByteUtil.hex2bin("02032402000003114A");
            controlDeviceManager.addByteList(bufferOpen);
        }

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);

        // 相互認証用セッションキー
        byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB3265");
        Field mSessionKey2 = NonContactICCard.class.getDeclaredField("mSessionKey2");
        mSessionKey2.setAccessible(true);
        mSessionKey2.set(nonContactICCard, sessionArray);

        NfcPlugin nfcPlugin = NfcPlugin.getInstance();
        nfcPlugin.setContext(controlDeviceManager, nonContactICCard);

        try {
            // 保持状態statusを初期状態にする
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object close = null;
            for (Object o : enumEMVStatus) {
                if (((Enum)o).name().equals("EMVCL_CLOSED")) {
                    close = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, close);

        } catch (Exception e) {
            throw e;
        }

        return nfcPlugin;
    }

    private void setEMVStatus(String status) throws Exception {
        try {
            // 保持状態statusを変更する
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object statusObj = null;
            for (Object o : enumEMVStatus) {
                if (((Enum)o).name().equals(status)) {
                    statusObj = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, statusObj);

        } catch (Exception e) {
            throw e;
        }
    }


    /**
     * Test:GetConfiguration <br/>
     *   ・正常 (バージョン情報) <br/>
     */
    @SmallTest
    public void testGetConfiguration_version() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("02032480000003095E");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("020300002000A2058DE794FE88A19C369570633888A811B9DFD26A74B1D4292F03C0474B417F0341F8");
            bufferList.add(buffer2);
            byte[] buffer3 = ByteUtil.hex2bin("02032504A0004DC1E1F44AE9B3C337D4AD30C393A3BB9357FEBB99578B28CE0A054DAA9D433A768EBB2EA93E5B8F1007A3805AE511F279E7130C7B0ADE59703A71DCF441BA91A11DAE8CAB791ACA0C746ADB8CA08E6041DFC2C2C6F15CCF002E84A300FC48085892B88158321B952AE6FF8750A926D1BA648C85D51FA3D0E08E26AD537F85BD3A2BD006B69AEF61528D28BBE6327E01BF63E26A167D19908C376A54AB435493036C8C");
            bufferList.add(buffer3);
            byte[] buffer4 = ByteUtil.hex2bin("02032402000003114A");
            bufferList.add(buffer4);

            NfcPlugin nfcPlugin = setContext(1, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：バージョン情報
            String ret = nfcPlugin.GetConfiguration("version");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");

            String conf = jsonObjectMain.getString("conf");
            JSONObject jsonObjectConf = new JSONObject(conf);
            JSONObject jsonObjectVer = jsonObjectConf.getJSONObject("version");

            String model = jsonObjectVer.getString("model");
            String sno = jsonObjectVer.getString("sno");
            Object hdinfo = jsonObjectVer.get("hdinfo");
            String aplver = jsonObjectVer.getString("aplver");
            String pfver = jsonObjectVer.getString("pfver");

            // 結果確認
            assertEquals("upos", 0, upos);
            assertEquals("model", "JT-R550CR-41", model);
            assertEquals("sno", "15M00038", sno);
            assertEquals("hdinfo", JSONObject.NULL, hdinfo);
            assertEquals("aplver", "00:013300-01-00-STD,40:XXXX64-30-01-001,D0:XXXXD0-40-01-021,D1:XXXXD1-20-00-011,D2:XXXXD2-20-00-011,D3:XXXXD3-20-00-031,D4:XXXXD4-10-01-011", aplver);
            assertEquals("pfver", "013300-01-00-STD", pfver);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_version");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・正常 (DLL情報) <br/>
     */
    @SmallTest
    public void testGetConfiguration_dll() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：DLL情報
            String ret = nfcPlugin.GetConfiguration("dll");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");

            String conf = jsonObjectMain.getString("conf");
            JSONObject jsonObjectConf = new JSONObject(conf);
            JSONObject jsonObjectDll = jsonObjectConf.getJSONObject("dll");
            JSONObject jsonObjectDlldate = jsonObjectDll.getJSONObject("dlldate");

            String dll1 = jsonObjectDlldate.getString("dll1");
            String dll2 = jsonObjectDlldate.getString("dll2");
            String dll3 = jsonObjectDlldate.getString("dll3");
            String dll4 = jsonObjectDlldate.getString("dll4");
            String dll5 = jsonObjectDlldate.getString("dll5");
            String dll6 = jsonObjectDlldate.getString("dll6");
            String dll7 = jsonObjectDlldate.getString("dll7");
            String dll8 = jsonObjectDlldate.getString("dll8");
            String dll9 = jsonObjectDlldate.getString("dll9");
            String dll10 = jsonObjectDlldate.getString("dll10");
            String dll11 = jsonObjectDlldate.getString("dll11");
            String dll12 = jsonObjectDlldate.getString("dll12");
            String dll13 = jsonObjectDlldate.getString("dll13");
            String dll14 = jsonObjectDlldate.getString("dll14");
            String dll15 = jsonObjectDlldate.getString("dll15");

            // 結果確認
            assertEquals("upos", 0, upos);
            assertEquals("dll1", "20170421", dll1);
            assertEquals("dll2", "20170421", dll2);
            assertEquals("dll3", "20170421", dll3);
            assertEquals("dll4", "00000000", dll4);
            assertEquals("dll5", "00000000", dll5);
            assertEquals("dll6", "00000000", dll6);
            assertEquals("dll7", "00000000", dll7);
            assertEquals("dll8", "00000000", dll8);
            assertEquals("dll9", "00000000", dll9);
            assertEquals("dll10", "00000000", dll10);
            assertEquals("dll11", "00000000", dll11);
            assertEquals("dll12", "00000000", dll12);
            assertEquals("dll13", "00000000", dll13);
            assertEquals("dll14", "00000000", dll14);
            assertEquals("dll15", "00000000", dll15);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_dll");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・正常 (Kernel情報) <br/>
     */
    @SmallTest
    public void testGetConfiguration_kernel() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：Kernel情報
            String ret = nfcPlugin.GetConfiguration("kernel");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");

            String conf = jsonObjectMain.getString("conf");
            JSONObject jsonObjectConf = new JSONObject(conf);
            JSONObject jsonObjectKernel = jsonObjectConf.getJSONObject("kernel");

            JSONObject jsonObjectAplver = jsonObjectKernel.getJSONObject("aplver");
            String reader = jsonObjectAplver.getString("reader");
            String apKernel1 = jsonObjectAplver.getString("kernel1");
            String apKernel2 = jsonObjectAplver.getString("kernel2");
            String apKernel3 = jsonObjectAplver.getString("kernel3");
            String apKernel4 = jsonObjectAplver.getString("kernel4");
            String apKernel5 = jsonObjectAplver.getString("kernel5");
            String apKernel6 = jsonObjectAplver.getString("kernel6");
            String apKernel7 = jsonObjectAplver.getString("kernel7");
            String apKernel8 = jsonObjectAplver.getString("kernel8");
            String apKernel9 = jsonObjectAplver.getString("kernel9");
            String apKernel10 = jsonObjectAplver.getString("kernel10");
            String apKernel11 = jsonObjectAplver.getString("kernel11");
            String apKernel12 = jsonObjectAplver.getString("kernel12");
            String apKernel13 = jsonObjectAplver.getString("kernel13");
            String apKernel14 = jsonObjectAplver.getString("kernel14");
            String apKernel15 = jsonObjectAplver.getString("kernel15");

            JSONObject jsonObjectEmvdate = jsonObjectKernel.getJSONObject("emvdate");
            String common = jsonObjectEmvdate.getString("common");
            String emKernel1 = jsonObjectEmvdate.getString("kernel1");
            String emKernel2 = jsonObjectEmvdate.getString("kernel2");
            String emKernel3 = jsonObjectEmvdate.getString("kernel3");
            String emKernel4 = jsonObjectEmvdate.getString("kernel4");
            String emKernel5 = jsonObjectEmvdate.getString("kernel5");
            String emKernel6 = jsonObjectEmvdate.getString("kernel6");
            String emKernel7 = jsonObjectEmvdate.getString("kernel7");
            String emKernel8 = jsonObjectEmvdate.getString("kernel8");
            String emKernel9 = jsonObjectEmvdate.getString("kernel9");
            String emKernel10 = jsonObjectEmvdate.getString("kernel10");
            String emKernel11 = jsonObjectEmvdate.getString("kernel11");
            String emKernel12 = jsonObjectEmvdate.getString("kernel12");
            String emKernel13 = jsonObjectEmvdate.getString("kernel13");
            String emKernel14 = jsonObjectEmvdate.getString("kernel14");
            String emKernel15 = jsonObjectEmvdate.getString("kernel15");

            // 結果確認
            assertEquals("upos", 0, upos);

            assertEquals("reader", "4001", reader);
            assertEquals("apKernel1", "0000", apKernel1);
            assertEquals("apKernel2", "0000", apKernel2);
            assertEquals("apKernel3", "0000", apKernel3);
            assertEquals("apKernel4", "0000", apKernel4);
            assertEquals("apKernel5", "0000", apKernel5);
            assertEquals("apKernel6", "0000", apKernel6);
            assertEquals("apKernel7", "0000", apKernel7);
            assertEquals("apKernel8", "0000", apKernel8);
            assertEquals("apKernel9", "0000", apKernel9);
            assertEquals("apKernel10", "0000", apKernel10);
            assertEquals("apKernel11", "0000", apKernel11);
            assertEquals("apKernel12", "0000", apKernel12);
            assertEquals("apKernel13", "0000", apKernel13);
            assertEquals("apKernel14", "0000", apKernel14);
            assertEquals("apKernel15", "0000", apKernel15);

            assertEquals("common", "20170421", common);
            assertEquals("emKernel1", "20170421", emKernel1);
            assertEquals("emKernel2", "20170421", emKernel2);
            assertEquals("emKernel3", "20170421", emKernel3);
            assertEquals("emKernel4", "20170421", emKernel4);
            assertEquals("emKernel5", "00000000", emKernel5);
            assertEquals("emKernel6", "00000000", emKernel6);
            assertEquals("emKernel7", "00000000", emKernel7);
            assertEquals("emKernel8", "00000000", emKernel8);
            assertEquals("emKernel9", "00000000", emKernel9);
            assertEquals("emKernel10", "00000000", emKernel10);
            assertEquals("emKernel11", "00000000", emKernel11);
            assertEquals("emKernel12", "00000000", emKernel12);
            assertEquals("emKernel13", "00000000", emKernel13);
            assertEquals("emKernel14", "00000000", emKernel14);
            assertEquals("emKernel15", "00000000", emKernel15);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_kernel");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・正常 (設定情報) <br/>
     */
    @SmallTest
    public void testGetConfiguration_settings() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：設定情報
            String ret = nfcPlugin.GetConfiguration("settings");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");

            String conf = jsonObjectMain.getString("conf");
            JSONObject jsonObjectConf = new JSONObject(conf);
            JSONObject jsonObjectSet = jsonObjectConf.getJSONObject("settings");
            String volume = jsonObjectSet.getString("volume");
            String messageStatus = jsonObjectSet.getString("messageStatus");

            // 結果確認
            assertEquals("upos", 0, upos);
            assertEquals("volume", "1", volume);
            assertEquals("messageStatus", "23", messageStatus);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_settings");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・準正常 (EMVCL_Releaseの戻り値がE_CLOSED) <br/>
     */
    @SmallTest
    public void testGetConfiguration_Release_CLOSED() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);

            // パターン：EMVCL_Releaseの戻り値がE_CLOSED
            String ret = nfcPlugin.GetConfiguration("version");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            Object conf = jsonObjectMain.get("conf");

            // 結果確認
            assertEquals("upos", 101, upos);
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_Release_CLOSED");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・準正常 (EMVCL_Releaseの戻り値がE_ILLEGAL) <br/>
     */
    @SmallTest
    public void testGetConfiguration_Release_ILLEGAL() {
        try {
            // readがNULLだとchangeRW()からE_FAILUREが戻りE_ILLEGALに差し替わる
            NfcPlugin nfcPlugin = setContext(2, null);

            nfcPlugin.OpenDevice();

            // パターン：EMVCL_Releaseの戻り値がE_ILLEGAL
            String ret = nfcPlugin.GetConfiguration("version");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            Object conf = jsonObjectMain.get("conf");

            // 結果確認
            assertEquals("upos", 106, upos);
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_Release_ILLEGAL");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・準正常 (EMVCL_GetRWVerInfoの戻り値がE_FAILURE) <br/>
     */
    @SmallTest
    public void testGetConfiguration_GetRWVerInfo_FAILURE() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("02032480000003095E");
            bufferList.add(buffer1);

            // EMVCL_GetRWVerInfoのreadがNULLだとE_FAILUREが戻る
            NfcPlugin nfcPlugin = setContext(3, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：EMVCL_GetRWVerInfoの戻り値がE_FAILURE
            String ret = nfcPlugin.GetConfiguration("version");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            Object conf = jsonObjectMain.get("conf");

            // 結果確認
            assertEquals("upos", 111, upos);
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_GetRWVerInfo_FAILURE");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・準正常 (EMVCL_Claimの戻り値がE_FAILURE) <br/>
     */
    @SmallTest
    public void testGetConfiguration_Claim_FAILURE() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("02032480000003095E");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("020300002000A2058DE794FE88A19C369570633888A811B9DFD26A74B1D4292F03C0474B417F0341F8");
            bufferList.add(buffer2);
            byte[] buffer3 = ByteUtil.hex2bin("02032504A0004DC1E1F44AE9B3C337D4AD30C393A3BB9357FEBB99578B28CE0A054DAA9D433A768EBB2EA93E5B8F1007A3805AE511F279E7130C7B0ADE59703A71DCF441BA91A11DAE8CAB791ACA0C746ADB8CA08E6041DFC2C2C6F15CCF002E84A300FC48085892B88158321B952AE6FF8750A926D1BA648C85D51FA3D0E08E26AD537F85BD3A2BD006B69AEF61528D28BBE6327E01BF63E26A167D19908C376A54AB435493036C8C");
            bufferList.add(buffer3);

            // EMVCL_ClaimのreadがNULLだとE_FAILUREが戻る
            NfcPlugin nfcPlugin = setContext(3, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：EMVCL_Claimの戻り値がE_FAILURE
            String ret = nfcPlugin.GetConfiguration("version");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            Object conf = jsonObjectMain.get("conf");

            // 結果確認
            assertEquals("upos", 111, upos);
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_Claim_FAILURE");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・準正常 (EMVCL_GetInfoの戻り値がE_FAILURE) <br/>
     */
    @SmallTest
    public void testGetConfiguration_GetInfo_FAILURE() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);

            // パターン：EMVCL_GetInfoの戻り値がE_FAILURE
            String ret = nfcPlugin.GetConfiguration("dll");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            Object conf = jsonObjectMain.get("conf");

            // 結果確認
            assertEquals("upos", 111, upos);
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_GetInfo_FAILURE");
        }
    }

    /**
     * Test:GetConfiguration <br/>
     *   ・準正常 (設定キーが指定のもの以外) <br/>
     */
    @SmallTest
    public void testGetConfiguration_ILLEGAL() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020330110001055D1588C471998E522CCF779E2EC57E50BC98DA15476D0F744395333AFACC8F61B857E904945A7E9AF6569193B3706192D8EF6AF20682BA11D6353748A929D2D05D516C70120B0E3211CC32EF61B675C21DE14067A57B4C3DC46BD09EA79C0885E4F6FACBFB2B3140D3993FC843BC0608E0D3D785F6036A0177ADE73123B40D31817391491CD6FD90E05BA4409DD5CEF07C0799F4622DB101C17FA19A51392D6A50A445D1D1CE8E1A2EA239682C93B1988BA03074D8550563964BAC8F0378B4A7D17F44840F09F26BF3C109F9E2F8643C23871FA3CEC05889EA57A1B8AEC80DCA87145A6AE25F5C103EDC1A71B24E3383284D789EB9F188E3833268986E85D2036ED5");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(1, bufferList);

            nfcPlugin.OpenDevice();

            // パターン：設定キーが指定のもの以外(最後の106が戻る)
            String ret = nfcPlugin.GetConfiguration("kernelaaa");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            int upos = jsonObjectMain.getInt("upos");
            Object conf = jsonObjectMain.get("conf");

            // 結果確認
            assertEquals("upos", 106, upos);
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("GetConfiguration_ILLEGAL");
        }
    }

    /**
     * Test:createResultJson <br/>
     *   ・準正常 <br/>
     */
    @SmallTest
    public void testCreateResultJson() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);

            Method createResultJsonMethod = NfcPlugin.class.getDeclaredMethod("createResultJson", int.class, String.class);
            createResultJsonMethod.setAccessible(true);

            // パターン：準正常
            JSONObject ret = (JSONObject)createResultJsonMethod.invoke(nfcPlugin, 0, "");

            // RETURN VALUE
            Object conf = ret.get("conf");

            // 結果確認
            assertEquals("conf", JSONObject.NULL, conf);

        } catch (Exception e) {
            e.printStackTrace();
            fail("createResultJson");
        }
    }

    /**
     * Test:setHealth <br/>
     *   ・正常 (tamperがfalseで戻る) <br/>
     */
    @SmallTest
    public void testSetHealth_tamper() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);
            SETTINGINFO settinginfo = new SETTINGINFO();
            settinginfo.StatusFlag = (byte)0x01;

            Method setHealth = NfcPlugin.class.getDeclaredMethod("setHealth", int.class, SETTINGINFO.class);
            setHealth.setAccessible(true);
            String ret = (String)setHealth.invoke(nfcPlugin, 0, settinginfo);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String upos = jsonObjectMain.getString("upos");
            String device = jsonObjectMain.getString("device");

            JSONObject jsonObjectCon = jsonObjectMain.getJSONObject("condition");
            boolean sts = jsonObjectCon.getBoolean("sts");
            boolean tamper = jsonObjectCon.getBoolean("tamper");

            // 結果確認
            assertEquals("upos", "0", upos);
            assertEquals("device", "0", device);
            assertTrue("sts", sts);
            assertEquals("tamper", false, tamper);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetHealth_tamper");
        }
    }

    /**
     * Test:ontransactioncomplete <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testOntransactioncomplete() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);
            nfcPlugin.registerNfcServiceListener("test3", mINfcServiceListener);

            Method ontransactioncompleteMethod = NfcPlugin.class.getDeclaredMethod("ontransactioncomplete", String.class);
            ontransactioncompleteMethod.setAccessible(true);
            ontransactioncompleteMethod.invoke(nfcPlugin, "");

        } catch (Exception e) {
            e.printStackTrace();
            fail("testOntransactioncomplete");
        }
    }

    /**
     * Test:ontransactionerror <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testOntransactionerror() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);
            nfcPlugin.registerNfcServiceListener("test4", mINfcServiceListener);

            Method ontransactionerrorMethod = NfcPlugin.class.getDeclaredMethod("ontransactionerror", int.class, String.class);
            ontransactionerrorMethod.setAccessible(true);
            ontransactionerrorMethod.invoke(nfcPlugin, 303, "");

        } catch (Exception e) {
            e.printStackTrace();
            fail("testOntransactionerror");
        }
    }

    // コールバックイベント
    private INfcServiceListener.Stub mINfcServiceListener = new INfcServiceListener.Stub() {

        // 取引処理完了時に処理結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactioncomplete(String value) {}

        // 取引処理失敗時にエラー結果の通知処理を行うイベントハンドラ
        @Override
        public void ontransactionerror(int ecode, String extcode) {}
    };

    // ***************************** NfcPlugin.SetResult start *****************************

    /**
     * Test:SetResult <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testSetResult_normal() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("0203800100000308a8");
            byte[] buffer2 = ByteUtil.hex2bin("0203800100000308a8");
            byte[] buffer3 = ByteUtil.hex2bin("0203800100000308a8");
            bufferList.add(buffer1);
            bufferList.add(buffer2);
            bufferList.add(buffer3);

            NfcPlugin nfcPlugin = setContext(1, bufferList);
            nfcPlugin.OpenDevice();

            // パターン：hostResult 0
            String ret0 = nfcPlugin.SetResult(0, 0);
            // 結果確認
            assertEquals("hostResult 0", "00", ret0);

            // パターン：hostResult 1
            String ret1 = nfcPlugin.SetResult(1, 255);
            // 結果確認
            assertEquals("hostResult 1", "00", ret1);

            // パターン：hostResult 2
            String ret2 = nfcPlugin.SetResult(2, 123);
            // 結果確認
            assertEquals("hostResult 2", "00", ret2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetResult_normal");
        }
    }

    /**
     * Test:SetResult <br/>
     *   ・準正常 (引数エラー) <br/>
     */
    @SmallTest
    public void testSetResult_err() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);

            // パターン：hostResult エラー
            String ret = nfcPlugin.SetResult(3, 0);
            // 結果確認
            assertEquals("106", ret);

            // パターン：showTime < 0x00
            String ret2 = nfcPlugin.SetResult(0, -1);
            // 結果確認
            assertEquals("106", ret2);

            // パターン：0xff < showTime
            String ret3 = nfcPlugin.SetResult(0, 256);
            // 結果確認
            assertEquals("106", ret3);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetResult_err");
        }
    }

    /**
     * Test:SetResult <br/>
     *   ・準正常 (Open状態ではない) <br/>
     */
    @SmallTest
    public void testSetResult_CLOSED() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);

            // パターン：Open状態ではない
            String ret = nfcPlugin.SetResult(0, 0);

            // 結果確認
            assertEquals("101", ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetResult_CLOSED");
        }
    }

    /**
     * Test:SetResult <br/>
     *   ・準正常 (通信エラー発生) <br/>
     */
    @SmallTest
    public void testSetResult_FAILURE() {
        try {
            NfcPlugin nfcPlugin = setContext(2, null);
            nfcPlugin.OpenDevice();

            // パターン：通信エラー発生
            String ret = nfcPlugin.SetResult(0, 0);

            // 結果確認
            assertEquals("111", ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetResult_FAILURE");
        }
    }

    /**
     * Test:SetResult <br/>
     *   ・準正常 (非同期処理実行中) <br/>
     */
    @SmallTest
    public void testSetResult_BUSY() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);
            setEMVStatus("EMVCL_BUSY");

            // パターン：非同期処理実行中のため、実行できない
            String ret = nfcPlugin.SetResult(0, 0);

            // 結果確認
            assertEquals("113", ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetResult_BUSY");
        }
    }

    /**
     * Test:SetResult <br/>
     *   ・準正常 (ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testSetResult_ILLEGAL() {
        try {
            NfcPlugin nfcPlugin = setContext(0, null);
            setEMVStatus("EMVCL_OPENED");

            // パターン：ILLEGAL_ERROR
            String ret = nfcPlugin.SetResult(0, 0);

            // 結果確認
            assertEquals("106", ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testSetResult_ILLEGAL");
        }
    }

    // ***************************** NfcPlugin.SetResult end *****************************

}
