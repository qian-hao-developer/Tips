package com.panasonic.avc.smartpayment.devctlservice.pinpad.mgt;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.TerminalStatusManager;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.icrw.ContactIcCard;
import com.panasonic.avc.smartpayment.devctlservice.share.UpdateDeviceType;
import com.panasonic.avc.smartpayment.pf.pds.PdsClientManager;

import java.lang.reflect.Field;

/**
 * ByteUtilのUTクラス </br>
 */
public class ManagementTest extends ApplicationTestCase<Application> {

    public ManagementTest() {
        super(Application.class);
    }

    /**
     *  Test:isDefferentVersion <br/>
     *  ・正常
     */
    @SmallTest
    public void  testIsDefferentVersion() {
        Management management = Management.getInstance();
        PdsClientManager pdsClientManager = new PdsClientManager();
        TerminalStatusManager mTerminalStatusManager = new TerminalStatusManager(pdsClientManager);
        management.setTerminalStatusManager(mTerminalStatusManager);

        ContactIcCard contactIcCard = ContactIcCard.getInstance();
        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        try {
            Field mContactIcCard = Management.class.getDeclaredField("mContactIcCard");
            mContactIcCard.setAccessible(true);

            // sVersion＝nullの場合
            boolean ret1 = management.isDefferentVersion(UpdateDeviceType.PINPAD);
            assertFalse("testEqualsVersion", ret1);

            // fwVersion＝sVersionの場合
            byte[] bufferOpen1 = ByteUtil.hex2bin("020000002100000000000000000000000000000000000000000000312e30390000000000000000031bda");
            byte[] bufferOpen2 = ByteUtil.hex2bin("020000001a00000000000000000000000000000000000000000000000000303903ec35");
            controlDeviceManager.addByteList(bufferOpen1);
            controlDeviceManager.addByteList(bufferOpen2);
            contactIcCard.setControlDeviceManager(controlDeviceManager);
            mContactIcCard.set(management, contactIcCard);
            boolean ret2 = management.isDefferentVersion(UpdateDeviceType.PINPAD);
            assertFalse("testEqualsVersion", ret2);

            // fwVersion≠sVersionの場合
            byte[] bufferOpen3 = ByteUtil.hex2bin("020000002100000000000000000000000000000000000000000000312e30380000000000000000033cf6");
            byte[] bufferOpen4 = ByteUtil.hex2bin("020000001a00000000000000000000000000000000000000000000000000303903ec35");
            controlDeviceManager.addByteList(bufferOpen3);
            controlDeviceManager.addByteList(bufferOpen4);
            contactIcCard.setControlDeviceManager(controlDeviceManager);
            boolean ret3 = management.isDefferentVersion(UpdateDeviceType.PINPAD);
            assertTrue("testEqualsVersion", ret3);
        } catch (Exception e) {
            e.printStackTrace();
            fail("testIsDefferentVersion 例外発生");
        }
    }
}