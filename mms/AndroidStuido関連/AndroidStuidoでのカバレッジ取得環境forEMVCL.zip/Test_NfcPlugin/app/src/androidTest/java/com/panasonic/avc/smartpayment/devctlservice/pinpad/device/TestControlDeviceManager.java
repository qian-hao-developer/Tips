package com.panasonic.avc.smartpayment.devctlservice.pinpad.device;

import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.data.RequestData;

import java.util.LinkedList;

/**
 * ControlDeviceManagerのテスト用クラス <br/>
 */
public class TestControlDeviceManager extends ControlDeviceManager {

    private LinkedList<byte[]> mByteList = new LinkedList<byte[]>();

    private boolean mWriteFlg = true;

    private boolean mActiveFlg = true;


    /**
     * @param venderId
     * @param productId
     * @brief 初期化
     */
    @Override
    public boolean init(int venderId, int productId) {
        return false;
    }

    /**
     *
     * @param vendorId
     * @param productIds
     * @param busPower
     * @brief 初期化【マルチデバイス対応】
     */
    @Override
    public boolean init(int vendorId, int[] productIds, boolean[] busPower) {
        return false;
    }

    /**
     * @param deviceInterface 通信インタフェース シリアル:0 USB:1
     * @param baudrate        通信速度
     * @param parity          パリティ種別 パリティチェックなし:0 奇数パリティ:1 偶数パリティ:2
     * @return 成功したかどうか
     * @brief Serialデバイス用初期化メソッド
     */
    @Override
    public boolean init(int deviceInterface, int baudrate, int parity) {
        return false;
    }

    /**
     * データ読み出し(Pinpad)
     *
     * @param timeout タイムアウト時間
     * @return 読みだしたデータ
     */
    @Override
    public byte[] read(byte[] buffer, int timeout) {

        if(mByteList.size() == 0){
            return null;
        }

        return mByteList.poll();
    }

    /**
     * @brief デバイスにデータを書き込みする
     * @param data 書込するデータ
     * @param timeout タイムアウト
     * @return 書き込みに成功したかどうか
     */
    @Override
    public boolean write(byte[] data, int timeout) {
        return mWriteFlg;
    }

    /**
     * @brief デバイスの有無
     * @return 有無
     */
    @Override
    public boolean isActive() {
        return mActiveFlg;
    }



    public void addByteList(byte[] buffer) {
        mByteList.add(buffer);
    }

    public void setWriteFlg(boolean writeFlg) {
        mWriteFlg = writeFlg;
    }

    public void setActiveFlg(boolean activeFlg) {
        mActiveFlg = activeFlg;
    }

    public void lock() { return; }

    public void unlock() {
        return;
    }

    public void clearLock() { return; }

    public Object getLockObject() {
        Object obj = new Object();
        return obj;
    }

    public synchronized boolean write(RequestData request, int timeout)  {
        return mWriteFlg;
    }

    public byte[] read(int timeout) {
        return mByteList.poll();
    }
}
