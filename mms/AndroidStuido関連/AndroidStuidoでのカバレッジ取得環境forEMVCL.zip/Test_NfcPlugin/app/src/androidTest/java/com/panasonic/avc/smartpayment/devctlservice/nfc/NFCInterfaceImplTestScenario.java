package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.INSTALLEDFILEDATE;
import com.panasonic.avc.smartpayment.devctlservice.nfc.data.SETTINGINFO;
import com.panasonic.avc.smartpayment.devctlservice.nfc.platform.PlatformConfig;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * NFCInterfaceImplのUTクラス (シナリオ)<br/>
 */
public class NFCInterfaceImplTestScenario extends ApplicationTestCase<Application> {

    // コンストラクタ
    public NFCInterfaceImplTestScenario() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    private NFCInterfaceImpl setContext(String status, List<byte[]> bufferList) throws Exception {

        NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
        PlatformConfig platformConfig = nfcInterfaceImpl.getPlatformConfig();
        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);

        // 相互認証用セッションキー
        byte[] sessionArray = ByteUtil.hex2bin("240DEE76580C8FC4008BB007EBCB3265");
        Field mSessionKey2 = NonContactICCard.class.getDeclaredField("mSessionKey2");
        mSessionKey2.setAccessible(true);
        mSessionKey2.set(nonContactICCard, sessionArray);

        platformConfig.setContext(controlDeviceManager, nonContactICCard);

        try {
            // 保持状態statusを引数statusの状態にする
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object objStatus = null;
            for (Object o : enumEMVStatus) {
                if (((Enum)o).name().equals(status)) {
                    objStatus = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, objStatus);

        } catch (Exception e) {
            throw e;
        }

        return nfcInterfaceImpl;
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (inputCheckEMVCL_GetRWVerInfoの戻り値がE_ILLEGAL) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_inputCheck_err() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_CLOSED", null);

            //SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：inputCheckEMVCL_GetRWVerInfoの戻り値がE_ILLEGAL
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, null, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_inputCheck_err");
        }
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (checkStatus_RWVerの戻り値がE_ILLEGAL) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_checkStatus_RWVer_err() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_CLAIMED", null);

            SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：checkStatus_RWVerの戻り値がE_ILLEGAL
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_checkStatus_RWVer_err");
        }
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (RWInformationRequestのreadがnull) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_rwResp_null() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_OPENED", null);

            SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：RWInformationRequestのreadがnull
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(111, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_rwResp_null");
        }
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (PFDetailInformationRequestのreadがnull) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_pfResp_null() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020300002000A2058DE794FE88A19C369570633888A811B9DFD26A74B1D4292F03C0474B417F0341F8");
            bufferList.add(buffer1);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_OPENED", bufferList);

            SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：PFDetailInformationRequestのreadがnull
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(111, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_pfResp_null");
        }
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (RWInformationRequestのreadがcheckErrorResponseでエラー) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_checkErrorRes_rw() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("02032504A0004DC1E1F44AE9B3C337D4AD30C393A3BB9357FEBB99578B28CE0A054DAA9D433A768EBB2EA93E5B8F1007A3805AE511F279E7130C7B0ADE59703A71DCF441BA91A11DAE8CAB791ACA0C746ADB8CA08E6041DFC2C2C6F15CCF002E84A300FC48085892B88158321B952AE6FF8750A926D1BA648C85D51FA3D0E08E26AD537F85BD3A2BD006B69AEF61528D28BBE6327E01BF63E26A167D19908C376A54AB435493036C8C");
            bufferList.add(buffer2);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_OPENED", bufferList);

            SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：RWInformationRequestのreadがcheckErrorResponseでエラー
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_checkErrorRes_rw");
        }
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (PFDetailInformationRequestのreadがcheckErrorResponseでエラー) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_checkErrorRes_pf() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020300002000A2058DE794FE88A19C369570633888A811B9DFD26A74B1D4292F03C0474B417F0341F8");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer2);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_OPENED", bufferList);

            SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：PFDetailInformationRequestのreadがcheckErrorResponseでエラー
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_checkErrorRes_pf");
        }
    }

    /**
     * Test:EMVCL_GetRWVerInfo <br/>
     *   ・準正常 (RWInformationResponseのinputDeviceResultでエラー) <br/>
     */
    @SmallTest
    public void testEMVCL_GetRWVerInfo_inputDeviceResult_rw() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("02032504A0004DC1E1F44AE9B3C337D4AD30C393A3BB9357FEBB99578B28CE0A054DAA9D433A768EBB2EA93E5B8F1007A3805AE511F279E7130C7B0ADE59703A71DCF441BA91A11DAE8CAB791ACA0C746ADB8CA08E6041DFC2C2C6F15CCF002E84A300FC48085892B88158321B952AE6FF8750A926D1BA648C85D51FA3D0E08E26AD537F85BD3A2BD006B69AEF61528D28BBE6327E01BF63E26A167D19908C376A54AB435493036C8C");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("02032504A0004DC1E1F44AE9B3C337D4AD30C393A3BB9357FEBB99578B28CE0A054DAA9D433A768EBB2EA93E5B8F1007A3805AE511F279E7130C7B0ADE59703A71DCF441BA91A11DAE8CAB791ACA0C746ADB8CA08E6041DFC2C2C6F15CCF002E84A300FC48085892B88158321B952AE6FF8750A926D1BA648C85D51FA3D0E08E26AD537F85BD3A2BD006B69AEF61528D28BBE6327E01BF63E26A167D19908C376A54AB435493036C8C");
            bufferList.add(buffer2);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_OPENED", bufferList);

            SETTINGINFO settingInfo = new SETTINGINFO();
            INSTALLEDFILEDATE installedfiledate = new INSTALLEDFILEDATE();
            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：RWInformationResponseのinputDeviceResultでエラー
            int ret = nfcInterfaceImpl.EMVCL_GetRWVerInfo((byte)0x00, settingInfo, installedfiledate, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_GetRWVerInfo_inputDeviceResult_rw");
        }
    }


    // ***************************** NFCInterfaceImpl.EMVCL_SetResult start *****************************

    /**
     * Test:EMVCL_SetResult <br/>
     *   ・正常 <br/>
     */
    @SmallTest
    public void testEMVCL_SetResult_normal() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("0203800100000308a8");
            byte[] buffer2 = ByteUtil.hex2bin("0203800100000308a8");
            byte[] buffer3 = ByteUtil.hex2bin("0203800100000308a8");
            bufferList.add(buffer1);
            bufferList.add(buffer2);
            bufferList.add(buffer3);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_CLAIMED", bufferList);

            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：hostResult 0
            int ret0 = nfcInterfaceImpl.EMVCL_SetResult((byte)0, (byte)0, resultCode, resultCodeExtended);
            // 結果確認
            assertEquals("hostResult 0", 0, ret0);

            // パターン：hostResult 1
            int ret1 = nfcInterfaceImpl.EMVCL_SetResult((byte)1, (byte)255, resultCode, resultCodeExtended);
            // 結果確認
            assertEquals("hostResult 1", 0, ret1);

            // パターン：hostResult 2
            int ret2 = nfcInterfaceImpl.EMVCL_SetResult((byte)2, (byte)123, resultCode, resultCodeExtended);
            // 結果確認
            assertEquals("hostResult 2", 0, ret2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_SetResult_normal");
        }
    }

    /**
     * Test:EMVCL_SetResult <br/>
     *   ・準正常 (引数エラー) <br/>
     */
    @SmallTest
    public void testEMVCL_SetResult_err() {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_OPENED", null);

            // パターン：inputCheckResultCode エラー
            int[] resultCode = null;
            int[] resultCodeExtended = null;
            int ret = nfcInterfaceImpl.EMVCL_SetResult((byte) 0x02, (byte) 0xff, resultCode, resultCodeExtended);
            // 結果確認
            assertEquals("inputCheckResultCode エラー", 106, ret);

            // パターン：HostResult エラー
            resultCode = new int[1];
            resultCodeExtended = new int[1];
            int ret2 = nfcInterfaceImpl.EMVCL_SetResult((byte) 0x03, (byte) 0xff, resultCode, resultCodeExtended);
            // 結果確認
            assertEquals("inputCheckResultCode エラー", 106, ret2);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_SetResult_err");
        }
    }

    /**
     * Test:EMVCL_SetResult <br/>
     *   ・準正常 (checkErrorResponse エラー) <br/>
     */
    @SmallTest
    public void testEMVCL_SetResult_checkErrorResponse() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_CLAIMED", bufferList);

            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン：checkErrorResponse エラー
            int ret = nfcInterfaceImpl.EMVCL_SetResult((byte) 0x02, (byte) 0xff, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_SetResult_checkErrorResponse");
        }
    }

    /**
     * Test:EMVCL_SetResult <br/>
     *   ・準正常 (inputDeviceResult エラー) <br/>
     */
    @SmallTest
    public void testEMVCL_SetResult_inputDeviceResult() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("02032402000003114A");
            bufferList.add(buffer);

            NFCInterfaceImpl nfcInterfaceImpl = setContext("EMVCL_CLAIMED", bufferList);

            int[] resultCode = new int[1];
            int[] resultCodeExtended = new int[1];

            // パターン： setResultResponse.inputDeviceResult エラー
            int ret = nfcInterfaceImpl.EMVCL_SetResult((byte) 0x02, (byte) 0xff, resultCode, resultCodeExtended);

            // 結果確認
            assertEquals(106, ret);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testEMVCL_SetResult_inputDeviceResult");
        }
    }

    // ***************************** NFCInterfaceImpl.EMVCL_SetResult end *****************************
}
