package com.panasonic.avc.smartpayment.devctlservice.nfc;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.emcrw.NonContactICCard;
import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;
import com.panasonic.avc.smartpayment.devctlservice.pinpad.device.TestControlDeviceManager;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * NfcPluginのUTクラス <br/>
 */
public class NfcPluginTestFull extends ApplicationTestCase<Application> {

    // コンストラクタ
    public NfcPluginTestFull() {
        super(Application.class);
    }

    // PlatformConfig.setContextを呼び出す
    private NfcPlugin setContext(List<byte[]> bufferList, String sessionKey) throws Exception {

        TestControlDeviceManager controlDeviceManager = new TestControlDeviceManager();

        if (bufferList != null) {
            // readの返却値設定：テスト対象メソッド
            for (byte[] buffer : bufferList) {
                controlDeviceManager.addByteList(buffer);
            }
        }

        NonContactICCard nonContactICCard= NonContactICCard.getInstance();
        nonContactICCard.setControlDeviceManager(controlDeviceManager);

        // 相互認証用セッションキー
        byte[] sessionArray = ByteUtil.hex2bin(sessionKey);
        Field mSessionKey2 = NonContactICCard.class.getDeclaredField("mSessionKey2");
        mSessionKey2.setAccessible(true);
        mSessionKey2.set(nonContactICCard, sessionArray);

        NfcPlugin nfcPlugin = NfcPlugin.getInstance();
        nfcPlugin.setContext(controlDeviceManager, nonContactICCard);

        return nfcPlugin;
    }

    // 保持状態statusを変更する
    private void setEMVStatus(String status) throws Exception {
        try {
            NFCInterfaceImpl nfcInterfaceImpl = NFCInterfaceImpl.getInstance();
            Field m_EMVStatus = NFCInterfaceImpl.class.getDeclaredField("m_EMVStatus");
            m_EMVStatus.setAccessible(true);

            Object[] enumEMVStatus = null;
            for (Class cls : NFCInterfaceImpl.class.getDeclaredClasses()) {
                if (!"EMVStatus".equals(cls.getSimpleName())) {
                    continue;
                }
                enumEMVStatus = cls.getEnumConstants();
                break;
            }

            Object statusObj = null;
            for (Object o : enumEMVStatus) {
                if (((Enum)o).name().equals(status)) {
                    statusObj = o;
                    break;
                }
            }

            m_EMVStatus.set(nfcInterfaceImpl, statusObj);

        } catch (Exception e) {
            throw e;
        }
    }


    // ****************************** WM_CompleteEvent start **********************************

    /**
     * Test:WM_CompleteEvent <br/>
     *   ・準正常 (mNFCInterfaceImpl == null) <br/>
     */
    @SmallTest
    public void testWM_CompleteEvent_mNFCInterfaceImpl() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Field mNFCInterfaceImpl = NfcPlugin.class.getDeclaredField("mNFCInterfaceImpl");
            mNFCInterfaceImpl.setAccessible(true);
            mNFCInterfaceImpl.set(nfcPlugin, null);

            // パターン：mNFCInterfaceImpl == null
            nfcPlugin.WM_CompleteEvent();

            // 元に戻す
            mNFCInterfaceImpl.set(nfcPlugin, NFCInterfaceImpl.getInstance());

        } catch (Exception e ) {
            e.printStackTrace();
            fail("testWM_CompleteEvent_mNFCInterfaceImpl");
        }
    }

    /**
     * Test:WM_CompleteEvent <br/>
     *   ・準正常 (致命的エラー) <br/>
     */
    @SmallTest
    public void testWM_CompleteEvent_FATAL() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();

            // パターン：致命的エラー
            nfcPlugin.WM_CompleteEvent();

        } catch (Exception e ) {
            e.printStackTrace();
            fail("testWM_CompleteEvent_FATAL");
        }
    }

    /**
     * Test:WM_CompleteEvent <br/>
     *   ・準正常 <br/>
     */
    @SmallTest
    public void testWM_CompleteEvent_ForceClose() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();

            // パターン：mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_NOT_AUTH
            NonContactICCard mNonContactICCard = NonContactICCard.getInstance();
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_NOT_AUTH);
            nfcPlugin.WM_CompleteEvent();

            // パターン：mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_NONE
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NONE);
            nfcPlugin.WM_CompleteEvent();

            // パターン：mNonContactICCard.getRwState() == NonContactICCard.RW_STATE_USE_EMCRW
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_EMCRW);
            nfcPlugin.WM_CompleteEvent();

            // 元に戻す
            mNonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NONE);

        } catch (Exception e ) {
            e.printStackTrace();
            fail("testWM_CompleteEvent_ForceClose");
        }
    }

    // ****************************** WM_CompleteEvent end **********************************


    // ****************************** CloseDevice start **********************************

    /**
     * Test:CloseDevice <br/>
     *   ・準正常 (EMVCL_Clearの戻り値がILLEGAL) <br/>
     */
    @SmallTest
    public void testCloseDevice_Clear_ILLEGAL() {
        try {
            // readの返却値設定：CloseDevice
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] bufferClose1 = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");   // EMVCL_Clear
            bufferList.add(bufferClose1);

            NfcPlugin nfcPlugin = setContext(bufferList, "72158C7E3865921DF767620AEC1F3A4B");
            setEMVStatus("EMVCL_CLAIMED");

            // API使用中
            NonContactICCard nonContactICCard= NonContactICCard.getInstance();
            nonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_EMCRW);

            // パターン：EMVCL_Clearの戻り値がILLEGAL
            String ret = nfcPlugin.CloseDevice();

            // 結果確認
            assertEquals("106", ret);

            // 元に戻す
            nonContactICCard.setRwState(NonContactICCard.RW_STATE_USE_NONE);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testCloseDevice_Clear_ILLEGAL");
        }
    }

    // ****************************** CloseDevice end **********************************



    // ****************************** DoDeviceSettingData start **********************************

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (mNFCInterfaceImpl == null) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_mNFCInterfaceImpl() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            Field mNFCInterfaceImpl = NfcPlugin.class.getDeclaredField("mNFCInterfaceImpl");
            mNFCInterfaceImpl.setAccessible(true);
            mNFCInterfaceImpl.set(nfcPlugin, null);

            // パターン：mNFCInterfaceImpl == null
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // 元に戻す
            mNFCInterfaceImpl.set(nfcPlugin, NFCInterfaceImpl.getInstance());

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_mNFCInterfaceImpl");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・正常 (FILETYPE_DELETE) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FILETYPE_DELETE() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020330110001dff1ae23a2b15340bee025186e0c8ee6fa1ffea2211f2ac3398ea56ee04e501468f13b73fae673c250c96e7a24aad64d95dd5e4eda6a8e02d23eaeb544ff645f9de3a94114c698f6f498412e88b4d95acfaafd8bdb0106679c67a0028630a94da751071207e2de34b37534446a035a56b40ad9edd4a57420f6b128d44fe373856c86b40c16880594fa936ae4e3b6eac327bb236942a0d9586639c708e64d648af6406c64319a223cca07a9241d12d8cdba4370fa0d730de7b3e3eb5a1da69dc958289fb6f849bd8f04d874f262af3a296a202b0ef079b6247a14e24ad3c9dac05efab5db6cad2aae7be6b0e72cb6f6fd7b65f417454d7eafe53fd182deb76ecb03dfa6");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("020355030000031d48");
            bufferList.add(buffer2);
            byte[] buffer3 = ByteUtil.hex2bin("02035204000003e02f");
            bufferList.add(buffer3);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：FILETYPE_DELETE
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FILETYPE_DELETE");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_GetInfo Open状態ではない) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_GetInfo_CLOSED() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLOSED");

            // パターン：EMVCL_GetInfo Open状態ではない
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "101", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_GetInfo_CLOSED");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_GetInfo 通信エラー発生) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_GetInfo_FAILURE() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_GetInfo 通信エラー発生
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "111", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_GetInfo_FAILURE");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_GetInfo 非同期処理実行中) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_GetInfo_BUSY() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_BUSY");

            // パターン：EMVCL_GetInfo 非同期処理実行中
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "113", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_GetInfo_BUSY");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_GetInfo ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_GetInfo_ILLEGAL() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer1);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_GetInfo ILLEGAL_ERROR
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_GetInfo_ILLEGAL");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_ClearSetting 通信エラー発生) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_ClearSetting_FAILURE() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020330110001dff1ae23a2b15340bee025186e0c8ee6fa1ffea2211f2ac3398ea56ee04e501468f13b73fae673c250c96e7a24aad64d95dd5e4eda6a8e02d23eaeb544ff645f9de3a94114c698f6f498412e88b4d95acfaafd8bdb0106679c67a0028630a94da751071207e2de34b37534446a035a56b40ad9edd4a57420f6b128d44fe373856c86b40c16880594fa936ae4e3b6eac327bb236942a0d9586639c708e64d648af6406c64319a223cca07a9241d12d8cdba4370fa0d730de7b3e3eb5a1da69dc958289fb6f849bd8f04d874f262af3a296a202b0ef079b6247a14e24ad3c9dac05efab5db6cad2aae7be6b0e72cb6f6fd7b65f417454d7eafe53fd182deb76ecb03dfa6");
            bufferList.add(buffer1);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_ClearSetting 通信エラー発生
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認：後続のEMVCL_DeviceSettingでCLOSEDエラーになる
            assertEquals("RunResult", "101", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_ClearSetting_FAILURE");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_ClearSetting ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_ClearSetting_ILLEGAL() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020330110001dff1ae23a2b15340bee025186e0c8ee6fa1ffea2211f2ac3398ea56ee04e501468f13b73fae673c250c96e7a24aad64d95dd5e4eda6a8e02d23eaeb544ff645f9de3a94114c698f6f498412e88b4d95acfaafd8bdb0106679c67a0028630a94da751071207e2de34b37534446a035a56b40ad9edd4a57420f6b128d44fe373856c86b40c16880594fa936ae4e3b6eac327bb236942a0d9586639c708e64d648af6406c64319a223cca07a9241d12d8cdba4370fa0d730de7b3e3eb5a1da69dc958289fb6f849bd8f04d874f262af3a296a202b0ef079b6247a14e24ad3c9dac05efab5db6cad2aae7be6b0e72cb6f6fd7b65f417454d7eafe53fd182deb76ecb03dfa6");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer2);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_ClearSetting ILLEGAL_ERROR
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認：後続のEMVCL_DeviceSettingでFAILUREエラーになる
            assertEquals("RunResult", "111", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_ClearSetting_ILLEGAL");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_DeviceSetting 通信エラー発生) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_DeviceSetting_FAILURE() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020330110001dff1ae23a2b15340bee025186e0c8ee6fa1ffea2211f2ac3398ea56ee04e501468f13b73fae673c250c96e7a24aad64d95dd5e4eda6a8e02d23eaeb544ff645f9de3a94114c698f6f498412e88b4d95acfaafd8bdb0106679c67a0028630a94da751071207e2de34b37534446a035a56b40ad9edd4a57420f6b128d44fe373856c86b40c16880594fa936ae4e3b6eac327bb236942a0d9586639c708e64d648af6406c64319a223cca07a9241d12d8cdba4370fa0d730de7b3e3eb5a1da69dc958289fb6f849bd8f04d874f262af3a296a202b0ef079b6247a14e24ad3c9dac05efab5db6cad2aae7be6b0e72cb6f6fd7b65f417454d7eafe53fd182deb76ecb03dfa6");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("020355030000031d48");
            bufferList.add(buffer2);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_DeviceSetting 通信エラー発生
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "111", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_DeviceSetting_FAILURE");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_DeviceSetting ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_DeviceSetting_ILLEGAL1() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020330110001dff1ae23a2b15340bee025186e0c8ee6fa1ffea2211f2ac3398ea56ee04e501468f13b73fae673c250c96e7a24aad64d95dd5e4eda6a8e02d23eaeb544ff645f9de3a94114c698f6f498412e88b4d95acfaafd8bdb0106679c67a0028630a94da751071207e2de34b37534446a035a56b40ad9edd4a57420f6b128d44fe373856c86b40c16880594fa936ae4e3b6eac327bb236942a0d9586639c708e64d648af6406c64319a223cca07a9241d12d8cdba4370fa0d730de7b3e3eb5a1da69dc958289fb6f849bd8f04d874f262af3a296a202b0ef079b6247a14e24ad3c9dac05efab5db6cad2aae7be6b0e72cb6f6fd7b65f417454d7eafe53fd182deb76ecb03dfa6");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("020355030000031d48");
            bufferList.add(buffer2);
            byte[] buffer3 = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer3);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_DeviceSetting ILLEGAL_ERROR (checkErrorResponse)
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_DeviceSetting_ILLEGAL1");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_DeviceSetting ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_DeviceSetting_ILLEGAL2() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer1 = ByteUtil.hex2bin("020330110001dff1ae23a2b15340bee025186e0c8ee6fa1ffea2211f2ac3398ea56ee04e501468f13b73fae673c250c96e7a24aad64d95dd5e4eda6a8e02d23eaeb544ff645f9de3a94114c698f6f498412e88b4d95acfaafd8bdb0106679c67a0028630a94da751071207e2de34b37534446a035a56b40ad9edd4a57420f6b128d44fe373856c86b40c16880594fa936ae4e3b6eac327bb236942a0d9586639c708e64d648af6406c64319a223cca07a9241d12d8cdba4370fa0d730de7b3e3eb5a1da69dc958289fb6f849bd8f04d874f262af3a296a202b0ef079b6247a14e24ad3c9dac05efab5db6cad2aae7be6b0e72cb6f6fd7b65f417454d7eafe53fd182deb76ecb03dfa6");
            bufferList.add(buffer1);
            byte[] buffer2 = ByteUtil.hex2bin("020355030000031d48");
            bufferList.add(buffer2);
            byte[] buffer3 = ByteUtil.hex2bin("020355030000031d48");
            bufferList.add(buffer3);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_DeviceSetting ILLEGAL_ERROR (inputDeviceResult)
            String ret = nfcPlugin.DoDeviceSettingData(192, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_DeviceSetting_ILLEGAL2");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (fileDataByte == null) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_fileDataByte() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：fileDataByte == null
            String ret = nfcPlugin.DoDeviceSettingData(33, "");

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_fileDataByte");
        }
    }

    private static final String DLL_DATA = "303030A0000000653030303030303030303030303030309F3704C8000000000000000000C8000000000000303030300000000000000000303030A0000000033030303030303030303030303030309F3704C8000000000000000000C8000000000000303030300000000000000000303030A0000000043030303030303030303030303030309F37040000000000000000000000000000000000303030300000000000000000303030A0000000253030303030303030303030303030309F02060000000000000000000000000000000000303030300000000000000000303030B0123456783030303030303030303030303030309F37040000000000000000000000000000000000303030300000000000000000303030B0000000013030303030303030303030303030309F37040000000000000000000000000000000000303030300000000000000000";

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・正常 (FILETYPE_DLL) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FILETYPE_DLL() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("020340063000dad47196dcb05fe1a57f23263c44c7966fe1cc762700b750a1a04a3727a7089a52d19a9a3d69f12fa5f97fc43c25f23203d71a");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：FILETYPE_DLL
            String ret = nfcPlugin.DoDeviceSettingData(33, DLL_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FILETYPE_DLL");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_FileDLL Open状態ではない) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FileDLL_CLOSED() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLOSED");

            // パターン：EMVCL_FileDLL Open状態ではない
            String ret = nfcPlugin.DoDeviceSettingData(33, DLL_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "101", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FileDLL_CLOSED");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_FileDLL 通信エラー発生) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FileDLL_FAILURE() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_FileDLL 通信エラー発生
            String ret = nfcPlugin.DoDeviceSettingData(33, DLL_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "111", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FileDLL_FAILURE");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_FileDLL 非同期処理実行中) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FileDLL_BUSY() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_BUSY");

            // パターン：EMVCL_FileDLL 非同期処理実行中
            String ret = nfcPlugin.DoDeviceSettingData(33, DLL_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "113", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FileDLL_BUSY");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_FileDLL ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FileDLL_ILLEGAL() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_FileDLL ILLEGAL_ERROR
            String ret = nfcPlugin.DoDeviceSettingData(33, DLL_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FileDLL_ILLEGAL");
        }
    }

    private static final String EMV_DATA = "9F01061234567890129F7A0101DF04020100DF0301005F2A0204585F360102000000000000000000000000000000000000000000000000000000000000000000023037A00000000310100000000000000000003038010000000000000000E09F6604A200C0000000000000000000000100000000000060000000000080009F35012230300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003037A00000006510100000000000000000003038010000000000000000E09F6604A200C0000000000000000000000100000000000060000000000080009F3501223030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・正常 (FILETYPE_EMV) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_FILETYPE_EMV() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("0203400630003067796db0558e6941d1236a1ad2b8f890283761b84f71f4f40330f68dca88037d40b3be6ecdefaff6701391362c2aca03530e");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：FILETYPE_EMV
            String ret = nfcPlugin.DoDeviceSettingData(1, EMV_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "00", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_FILETYPE_EMV");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_SetEMV Open状態ではない) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_SetEMV_CLOSED() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLOSED");

            // パターン：EMVCL_SetEMV Open状態ではない
            String ret = nfcPlugin.DoDeviceSettingData(1, EMV_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "101", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_SetEMV_CLOSED");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_SetEMV 通信エラー発生) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_SetEMV_FAILURE() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_SetEMV 通信エラー発生
            String ret = nfcPlugin.DoDeviceSettingData(1, EMV_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "111", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_SetEMV_FAILURE");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_SetEMV 非同期処理実行中) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_SetEMV_BUSY() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_BUSY");

            // パターン：EMVCL_SetEMV 非同期処理実行中
            String ret = nfcPlugin.DoDeviceSettingData(1, EMV_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "113", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_SetEMV_BUSY");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (EMVCL_SetEMV ILLEGAL_ERROR) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_SetEMV_ILLEGAL() {
        try {
            // readの返却値設定
            List<byte[]> bufferList = new ArrayList<byte[]>();
            byte[] buffer = ByteUtil.hex2bin("0203ffff080000050000fffe0000034986");
            bufferList.add(buffer);

            NfcPlugin nfcPlugin = setContext(bufferList, "240DEE76580C8FC4008BB007EBCB3265");
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：EMVCL_SetEMV ILLEGAL_ERROR
            String ret = nfcPlugin.DoDeviceSettingData(1, EMV_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_SetEMV_ILLEGAL");
        }
    }

    /**
     * Test:DoDeviceSettingData <br/>
     *   ・準正常 (規定ファイル番号以外) <br/>
     */
    @SmallTest
    public void testDoDeviceSettingData_NOT_TARGET() {
        try {
            NfcPlugin nfcPlugin = NfcPlugin.getInstance();
            setEMVStatus("EMVCL_CLAIMED");

            // パターン：規定ファイル番号以外
            String ret = nfcPlugin.DoDeviceSettingData(255, EMV_DATA);

            // RETURN VALUE
            JSONObject jsonObjectMain = new JSONObject(ret);
            String RunResult = jsonObjectMain.getString("RunResult");

            // 結果確認
            assertEquals("RunResult", "106", RunResult);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testDoDeviceSettingData_NOT_TARGET");
        }
    }

    // ****************************** DoDeviceSettingData end **********************************
}
