package com.panasonic.avc.smartpayment.devctlservice.nfc.response;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.panasonic.avc.smartpayment.devctlservice.nfc.util.ByteUtil;

import java.lang.reflect.Method;

/**
 * BitmapTransferResponseのUTクラス <br/>
 */
public class BitmapTransferResponseTestFull extends ApplicationTestCase<Application> {

    // コンストラクタ
    public BitmapTransferResponseTestFull() {
        super(Application.class);
    }


    // ****************************** perseBitmap start ******************************

    /**
     * Test:perseBitmap <br/>
     *   ・準正常 (bitが全て立っていない) <br/>
     */
    @SmallTest
    public void testPerseBitmap() {
        try {
            byte[] bitmapByteArray = ByteUtil.hex2bin("18eb019010010000000000000000000000000000000000000000000000000000000000000000");

            BitmapTransferResponse bitmapTransferResponse = new BitmapTransferResponse();
            Method perseBitmap = BitmapTransferResponse.class.getDeclaredMethod("perseBitmap", byte[].class);
            perseBitmap.setAccessible(true);
            perseBitmap.invoke(bitmapTransferResponse, bitmapByteArray);

        } catch (Exception e) {
            e.printStackTrace();
            fail("testPerseBitmap");
        }
    }

    // ****************************** perseBitmap end ******************************
}
